define([], () => {
  'use strict';

  class PageModule {
    uploadInternal(empBO, capBO, skillgrpBO, internalTrainingBo, exceldata) {
      var readExcelPromise = new Promise(resolve => {
        var excelFile = exceldata[0];
        var reader = new FileReader();
        reader.onload = function (e) {
          var data = e.target.result;
          var workBook = XLSX.read(data, { type: 'binary' });
          var allSheets = workBook.SheetNames;
          var excelPayloadArray = {
            createrecord: [],
            updaterecord: [],
            errordata: []
          };


          for (var i = 0; i < allSheets.length; i++) {
            var sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);

            for (var index = 0; index < sheetRows.length; index++) {
              var parsedSheetRows = sheetRows[index];
              var retpayload = {};
              var emp = empBO.find(ele => ele.employeeId == parsedSheetRows['Employee ID']);
              var employee = emp?.id;
              var capid = capBO.find(ele => ele.name == parsedSheetRows['Capability'])?.id;
              var skid = skillgrpBO.find(ele => ele.skillGroupName == parsedSheetRows['Skill'])?.id;

              if (employee) {
                retpayload['employeeID'] = employee;
                retpayload['employeeName'] = emp?.name;;
                retpayload['capability'] = capid;
                retpayload['skill'] = skid;
                retpayload['assessmentTraining'] = parsedSheetRows['Assessment / Training'];
                retpayload['completedDate'] = parsedSheetRows['Completed Date']? new Date(parsedSheetRows['Completed Date']).toISOString().split('T')[0]: null;
                retpayload['category'] = parsedSheetRows['Category'];
                retpayload['internalExternal'] = parsedSheetRows['Internal / External'];
                retpayload['trainingType'] = parsedSheetRows['Training Type'];
                retpayload['dataSource'] = parsedSheetRows['Data Source'];
                retpayload['uploadedDate'] = new Date().toISOString().split('T')[0];

                var existingRecord = internalTrainingBo.find(record => record.employeeId === parsedSheetRows['Employee ID']);
                var newRecord = Object.assign({}, retpayload);

                if (existingRecord) {
                  newRecord.id = existingRecord.id;
                  var existingRecordIndex = internalTrainingBo.indexOf(existingRecord);
                  internalTrainingBo[existingRecordIndex] = newRecord;
                  excelPayloadArray.updaterecord.push(newRecord);
                } else {
                  excelPayloadArray.createrecord.push(newRecord);
                }
              } else {
                excelPayloadArray.errordata.push({
                  message: `Employee with ID ${parsedSheetRows['Employee ID']} not found.`
                });
              }
            }
          }
          resolve(excelPayloadArray);
        };

        reader.onerror = function () {
          excelPayloadArray.errordata.push({ message: 'Error reading the file.' });
          resolve(excelPayloadArray);
        };

        reader.readAsBinaryString(excelFile);
      });

      return readExcelPromise;
    }

    createrecordbatch(dataBO, operation, BOName) {
      var batchProcessingVariableArray = [];

      for (var index = 0; index < dataBO.length; index++) {
        var data = '{"id": "part' + index + '","path": "/' + BOName + '/","operation": "' + operation + '", "payload":' + JSON.stringify(dataBO[index]) + '}';
        batchProcessingVariableArray.push(data);
      }
      return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }

    updatebatch(updatearray, operation, BOName, batchsize) {
      let batchupdate = [];

      for (let j = 0; j < updatearray.length; j += batchsize) {
        let batchend = Math.min(j + batchsize, updatearray.length);
        let batchData = updatearray.slice(j, batchend);

        for (let index = 0; index < batchData.length; index++) {
          let data = {
            id: "part" + index,
            path: "/" + BOName + "/" + batchData[index].id,
            operation: operation,
            payload: {
              employeeName: batchData[index].employeeName,
              employeeID: batchData[index].employeeID,
              capability: batchData[index].capability,
              skill: batchData[index].skill,
              assessmentTraining: batchData[index].assessmentTraining,
              completedDate: batchData[index].completedDate,
              category: batchData[index].category,
              internalExternal: batchData[index].internalExternal,
              dataSource: batchData[index].dataSource,
              trainingType: batchData[index].trainingType,
              uploadedDate: new Date().toISOString().split('T')[0]
            }
          };
          batchupdate.push(data);
        }
      }
      return { parts: batchupdate };
    }
  }

  return PageModule;
});
