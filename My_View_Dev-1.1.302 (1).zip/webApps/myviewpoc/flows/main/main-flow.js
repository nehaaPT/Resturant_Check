define([], function() {
  'use strict';

  var FlowModule = function FlowModule() {};
  
  function changeFormat(currentDate) {
		try{
			var now = new Date(currentDate);
			return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
		}
		catch(err){
			console.log('#131'+currentDate);
			return currentDate;
		}
	};

	FlowModule.prototype.createTask=function(P_TaskBO, P_CategoryBO, P_Detail, P_Token, P_TaskID, P_CreatedBy, P_AssignmentEmployees, P_EmployeeBO){
		var retPayload = [];
    retPayload['taskData'] = {};
    retPayload['assignDetails'] = {};
		var taskID = P_TaskID+1;
    var existingTask = '';

		
    for(var i=0; i<P_AssignmentEmployees.length; i++){
      var emp = P_EmployeeBO.find(ele => ele.employeeID == P_AssignmentEmployees[i]);
      if(P_CategoryBO[0].allocationType == 'Single'){
        if(P_Token==undefined){
          existingTask = P_TaskBO.find(ele => ele.taskAssignmentBOCollect.items[0].employeeID == emp.id);}
        else{
          existingTask = P_TaskBO.find(function(data){return data.categoryID == P_CategoryBO.id  && data.data.token == P_Token && data.taskAssignmentBOCollect.items[0].employeeID == emp.id});
        }
          //existingTask = P_TaskBO.find(ele => ele.taskAssignmentBOCollect.items[0].employeeID == emp.id);
      }
      else{
        existingTask  = P_TaskBO.find(function(data){return data.categoryID == P_CategoryBO.id  && data.data.token == P_Token;});
		    // var existingTask  = P_TaskBO.find(function(data){return data.categoryID == cat.categoryID  && data.token == '9992';});
      }


      if(existingTask != undefined){
        retPayload['assignDetails']['taskID'] = existingTask.id;
        retPayload['assignDetails']['status'] = 'True';
      }

      else{
        retPayload['taskData']['taskID'] = taskID;
        retPayload['taskData']['categoryID'] = P_CategoryBO[0].id;
        retPayload['taskData']['details'] = P_Detail;
        retPayload['taskData']['token'] = P_Token ? P_Token : null;
        retPayload['taskData']['assignedDate'] = changeFormat(new Date());
        retPayload['taskData']['createdBy'] = P_CreatedBy;
        retPayload['assignDetails']['status'] = 'False';
      }
    }

		return retPayload;
	};

  

	FlowModule.prototype.createAssignTaskBody = function(P_TaskID, P_EmployeeID, P_EmployeeBO){
		var retPayload = {};

    var emp = P_EmployeeBO.find(ele => ele.employeeID == P_EmployeeID);
		retPayload['taskID'] = P_TaskID;
		retPayload['employeeID'] = emp.id;
		// retPayload['employeeID'] = 6;
		return retPayload;
	};
  
  FlowModule.prototype.checkAssignmentTask = function(P_TaskID, P_EmployeeID, P_AssignmentBO, P_EmployeeBO){
    var retPayload = '';

    var emp = P_EmployeeBO.find(ele => ele.employeeID == P_EmployeeID);
		var existingAssign  = P_AssignmentBO.find(function(data){return data.taskID == P_TaskID  && data.employeeID == emp.id;});
		if (existingAssign == undefined){
			retPayload = 'False';
		}
		else{
			retPayload = 'True';
		}
		return retPayload;
  };


  FlowModule.prototype.calSkillStats=function(empBO,buBO,capabillityBO){
    var freshInd=0,freshUS=0,deliInd=0,deliUS=0,staleInd=0,staleUS=0,freshAPAC=0,staleAPAC=0,deliAPAC=0,freshEurope=0,staleEurope=0,deliEurope=0;
    var adpArrayIndex={};
    var dataArray=new Array();
    for(var index=0;index<empBO.length;index++)
    {
      if(empBO[index].format=='India' && empBO[index].region=='NA Oracle')
      {
          empBO[index].skillSurveyDate==undefined?deliInd++:getFreshnessStatus(empBO[index].skillSurveyDate)?freshInd++:staleInd++;


      }
        else if(empBO[index].format=='US' && empBO[index].region=='NA Oracle')
      {
        
          empBO[index].skillSurveyDate==null?deliUS++:getFreshnessStatus(empBO[index].skillSurveyDate)?freshUS++:staleUS++;

      }
       else if(empBO[index].region=='Europe')
      {
        
          empBO[index].skillSurveyDate==null?deliEurope++:getFreshnessStatus(empBO[index].skillSurveyDate)?freshEurope++:staleEurope++;

      }
      else if(empBO[index].region=='APAC')
      {
        
          empBO[index].skillSurveyDate==null?deliAPAC++:getFreshnessStatus(empBO[index].skillSurveyDate)?freshAPAC++:staleAPAC++;

      }
      empBO[index].bo=buBO.find(each=>each.id==empBO[index].bu).name ;
      
      empBO[index].globalPractice = capabillityBO.find(each => each.id == empBO[index].globalPractice)?.name || 'Unknown Global Practice';

      dataArray.push(empBO[index]);
    }
    var adpArray=new Array();
    
    adpArray.push(JSON.parse('{"status":"Skill Survey Completion Status","india":"India Offshore","US":"US On","APAC":"APAC","Europe":"Europe","total":"Total"}'));
    adpArray.push(JSON.parse('{"status":"Fresh : Completed within last 6 Month","india":'+freshInd+',"US":'+freshUS+',"APAC":'+freshAPAC+',"Europe":'+freshEurope+',"total":'+(freshInd+freshUS+freshEurope+freshAPAC)+'}'));
    adpArray.push(JSON.parse('{"status":"Stale : Completed more than 6 Month ago","india":'+staleInd+',"US":'+staleUS+',"APAC":'+staleAPAC+',"Europe":'+staleEurope+',"total":'+(staleInd+staleUS+staleAPAC+staleEurope)+'}'));
    adpArray.push(JSON.parse('{"status":"Delinquent : Not yet completed","india":'+deliInd+',"US":'+deliUS+',"APAC":'+deliAPAC+',"Europe":'+deliEurope+',"total":'+(deliInd+deliUS+deliAPAC+deliEurope)+'}'));
    adpArray.push(JSON.parse('{"status":"Total","india":'+(freshInd+deliInd+staleInd)+',"APAC":'+(freshAPAC+deliAPAC+staleAPAC)+',"Europe":'+(freshEurope+deliEurope+staleEurope)+',"US":'+(freshUS+deliUS+staleUS)+',"total":'+((freshInd+freshUS+freshAPAC+freshEurope)+(staleInd+staleUS+staleAPAC+staleEurope)+(deliInd+deliUS+deliEurope+deliAPAC))+'}'));
    adpArray.push(JSON.parse('{"status":"% Freshness (Fresh / Total)","india":"'+Number.parseFloat((freshInd*100)/(freshInd+deliInd+staleInd)).toFixed(1)+'%","US":"'+Number.parseFloat(((freshUS*100)/(freshUS+deliUS+staleUS))).toFixed(1)+'%","APAC":"'+Number.parseFloat(((freshAPAC*100)/(freshAPAC+deliAPAC+staleAPAC))).toFixed(1)+'%","Europe":"'+Number.parseFloat(((freshEurope*100)/(freshEurope+deliEurope+staleEurope))).toFixed(1)+'%","total":"'+Number.parseFloat(((freshInd+freshUS)*100)/(freshInd+deliInd+staleInd+freshUS+freshUS+deliUS+staleUS)).toFixed(1)+'%"}'));

    var returnDataArray={"statsArray":adpArray,"dataArray":dataArray};
   // console.log(returnDataArray.dataArray.length);

    return returnDataArray;   
  };

 
  function getFreshnessStatus(employeeSkillSurveyDate)
  {  
    var surveyDate=new Date(employeeSkillSurveyDate);
    surveyDate.setDate(surveyDate.getDate()+180);
  
    if(new Date()<surveyDate)
    {
      return true;
    }
    else{
      return false;
    }
  };


  FlowModule.prototype.downloadFile = function(base64File,filename){
         //console.log('@@File Name'+filename);

        var fileBytes=atob(base64File);
        fileBytes=FileToBytes(fileBytes);
        //console.log(fileBytes);
          // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
        //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        var blob = new Blob([fileBytes],{type:'octet/stream'});
        //var filename = "CDE.xlsx";

        
        if(navigator.msSaveBlob){ // IE 10+
          navigator.msSaveBlob(blob,filename);
        } 
        else {
          var link = document.createElement("a");
          if(link.download !== undefined){ // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href",url);
            link.setAttribute("download",filename);
            link.setAttribute("target","_blank");
            link.style.visibility='hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
        }
  }
  function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
        }

  return FlowModule;
});