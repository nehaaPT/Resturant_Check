
define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

    PageModule.prototype.getVoucherName=function(context){
      
    return context.data.linkName+"-"+context.data.link1;

  };
  
  PageModule.prototype.validateExamDate=function(date,status,planned,category){
     
    let today = new Date();
    let mM=today.getMonth()<11?today.getMonth()===0?''+'11':today.getMonth()===1?''+'12':'0'+(today.getMonth()-1):''+(today.getMonth()-1);
    let yY=(today.getMonth()===0||today.getMonth()===1)?today.getFullYear()-1:today.getFullYear();
    const compareDate = new Date(`${mM}-${'01'}-${yY}`).getTime();

    let examDate = new Date(date);
    let D=(examDate.getDate()<10?'0'+examDate.getDate():''+examDate.getDate());
    let M=examDate.getMonth()<9?'0'+(examDate.getMonth()+1):''+(examDate.getMonth()+1);
    let Y=examDate.getFullYear();
    const CurrentDate = new Date(`${M}-${D}-${Y}`).getTime();
    // `${D}-${M}-${Y}`;
    

    if(CurrentDate>=compareDate){
      if(status==='Pass' && category===1){
      return true;
    }}
    else if(status==='Pass' && category===1 && planned!==null){
      return true;
    }
    else{
      return false;
    }
  };
// PageModule.prototype.exportTable=function(empCertData,metaDataArray,capabilityBo,certMaster,locatBo,categoryBO,empProject,projectBO){
//   //console.log(empCertData);
//   //console.log(JSON.stringify(metaDataArray));
//   var multidata = new Array();
//   var header = new Array();
//   for(let i = 0;i<metaDataArray.length;i++)
//   {
//       header.push(metaDataArray[i].headerName);
//   }
//   multidata.push(header);
// const d= new Date();
//   for(let i = 0;i<empCertData.length;i++)
//   {
    
//     var instanceArray = [];     
//     instanceArray.push(empCertData[i].certificationNamerObject.items.length>0?(categoryBO.find(element=>element.id==empCertData[i].certificationNamerObject.items[0].Category).category):'NA');
//     instanceArray.push(empCertData[i].certificationNamerObject.items.length>0?empCertData[i].certificationNamerObject.items[0].subCategory:'NA');
//     instanceArray.push(empCertData[i].certificationNamerObject.items.length>0?empCertData[i].certificationNamerObject.items[0].certificationType:'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].globalEmployeeID:'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].employeeID:'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].name:'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].localGrade:'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?(capabilityBo.find(element=>element.id==empCertData[i].employeeIdObject.items[0].globalPractice).name):'NA');
//     //console.log("@g"+empCertData[i].employeeIdObject.items.length>0?(empProject.find(element=>element.id==empCertData[i].employeeId).project):'No');
    
//     var projectIdArr = empCertData[i].employeeIdObject.items.length>0?(empProject.filter(element=>element.employee==empCertData[i].employeeId)):[];
//     console.log(JSON.stringify(projectIdArr));
//     instanceArray.push(projectIdArr.length!=0?projectBO.find(element=>element.id==projectIdArr[projectIdArr.length-1].project).projectName:'NA');
    
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].email:'NA');
  
    
//     instanceArray.push(empCertData[i].certificationNamerObject.items.length>0?empCertData[i].certificationNamerObject.items[0].certificationCode:'NA');
//     instanceArray.push(empCertData[i].certificationNamerObject.items.length>0?empCertData[i].certificationNamerObject.items[0].certificationName:'NA');
//     instanceArray.push(empCertData[i].status);
//     if(empCertData[i].status=='CL_Approved'||empCertData[i].status=='CL_Rejected'||empCertData[i].status=='Voucher_Requested'||empCertData[i].status=='Voucher_Rejected'||empCertData[i].status=='Voucher_Approved'||empCertData[i].status=='Cancelled')
//     {
//       instanceArray.push(empCertData[i].examPlannedDate != null ?formatDate(empCertData[i].examPlannedDate):' ');
//     }
//     else
//     {
//       instanceArray.push(empCertData[i].examDate != null ?formatDate(empCertData[i].examDate):' ');
//     }
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?(locatBo.find(element=>element.id==empCertData[i].employeeIdObject.items[0].location).location):'NA');
//     instanceArray.push(empCertData[i].employeeIdObject.items.length>0?empCertData[i].employeeIdObject.items[0].format:'NA');
    
//     instanceArray.push(empCertData[i].expirationDate != null ?formatDate(empCertData[i].expirationDate):' ');
    
    
//     multidata.push(instanceArray);
//     //console.log("-------------------");
//     //console.log(instanceArray);
//     //console.log("-------------------");
//   }

//   var wb = XLSX.utils.book_new();
//   wb.SheetNames.push("Certification Details");
//   var ws = XLSX.utils.aoa_to_sheet(multidata);
//   wb.Sheets["Certification Details"] = ws;
//   var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

//   //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



//   fileBytes=FileToBytes(fileBytes);
// //console.log(fileBytes);
// var blob = new Blob([fileBytes],{type:'octet/stream'});
// var filename = "Certification Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
// if(navigator.msSaveBlob){ // IE 10+
//   navigator.msSaveBlob(blob,filename);
// } else {
//   var link = document.createElement("a");
//   if(link.download !== undefined){ // feature detection
//     // Browsers that support HTML5 download attribute
//     var url = URL.createObjectURL(blob);
//     link.setAttribute("href",url);
//     link.setAttribute("download",filename);
//     link.setAttribute("target","_blank");
//     link.style.visibility='hidden';
//     document.body.appendChild(link);
//     link.click();
//     //console.log('Link'+JSON.stringify(link));
//    // var win = window.open(url, "_blank");
//   //  win.focus();
//     document.body.removeChild(link);
//   }
// }
//   // try
//   // {
//   // console.log(empCertData[0].voucherDetailsObject.items[0].voucherCode);
//   // }
//   // catch(err)
//   // {
//   //   console.log("Aakash");
//   // }
// };





   PageModule.prototype.requestedstatus = function (format,searchData,certSearchFields) {
    console.log("ffff"+format)
    var status=format
    var qparameter=''
    if (format=="Credit_Requested")
    
    qparameter="(status='Credit_Requested' OR status='Voucher_Requested') AND  employeeIdObject.activeFlag='Y' and employeeIdObject.format='"+searchData.Location+"' and certificationNamerObject.categoryObject.category='"+searchData.certificationType+"'"+ 
      " and certificationNamerObject.certificationName='"+(searchData.certificationName==''?searchData.certificationName:certificationName)+"' and employeeIdObject.globalPracticeObject.name='"+searchData.Community+"' and "+
      "(employeeIdObject.employeeID LIKE '%"+ searchData.EmpIdGlobalId+"%' or employeeIdObject.globalEmployeeID LIKE '%"+ searchData.EmpIdGlobalId +"%')"+
      " and employeeIdObject.name LIKE '%"+ searchData.EmpName+"%' and employeeIdObject.email LIKE '%"+searchData.Email+"%' and employeeIdObject.region='"+certSearchFields.region+"'";

    

    console.log("zzzzzz"+qparameter)

   return qparameter;
  };


   PageModule.prototype.approvedstatus = function (format,searchData,certSearchFields) {
    console.log("ffff"+format)
    var status=format
    var qparameter=''
    if (format=="Credit_Approved")
    qparameter="(status='Credit_Approved' OR status='Voucher_Approved') AND  employeeIdObject.activeFlag='Y' and employeeIdObject.format='"+searchData.Location+"' and certificationNamerObject.categoryObject.category='"+searchData.certificationType+"'"+ 
      " and certificationNamerObject.certificationName='"+(searchData.certificationName==''?searchData.certificationName:certificateName)+"' and employeeIdObject.globalPracticeObject.name='"+searchData.Community+"' and "+
      "(employeeIdObject.employeeID LIKE '%"+ searchData.EmpIdGlobalId+"%' or employeeIdObject.globalEmployeeID LIKE '%"+ searchData.EmpIdGlobalId +"%')"+
      " and employeeIdObject.name LIKE '%"+ searchData.EmpName+"%' and employeeIdObject.email LIKE '%"+searchData.Email+"%'and employeeIdObject.region='"+certSearchFields.region+"'";



    console.log("zzzzzz"+qparameter)

   return qparameter;
  };



   PageModule.prototype.notclearedstatus = function (format,searchData,certSearchFields) {
    console.log("ffff"+format)
    var status=format
    var qparameter=''
    if (format=="Not_Cleared")
    qparameter="(status='Not_Cleared' OR status='Not Cleared') AND  employeeIdObject.activeFlag='Y' and employeeIdObject.format='"+searchData.Location+"' and certificationNamerObject.categoryObject.category='"+searchData.certificationType+"'"+ 
      " and certificationNamerObject.certificationName='"+(searchData.certificationName==''?searchData.certificationName:certificateName)+"' and employeeIdObject.globalPracticeObject.name='"+searchData.Community+"' and "+
      "(employeeIdObject.employeeID LIKE '%"+ searchData.EmpIdGlobalId+"%' or employeeIdObject.globalEmployeeID LIKE '%"+ searchData.EmpIdGlobalId +"%')"+
      " and employeeIdObject.name LIKE '%"+ searchData.EmpName+"%' and employeeIdObject.email LIKE '%"+searchData.Email+"%' and employeeIdObject.region='"+certSearchFields.region+"'";



    console.log("zzzzzz"+qparameter)

   return qparameter;
  };


   PageModule.prototype.rejectedstatus = function (format,searchData,certSearchFields) {
    console.log("ffff"+format)
    var status=format
    var qparameter=''
    if (format=="Credit_Rejected")
    qparameter="(status='Credit_Rejected' OR status='Voucher_Rejected') AND  employeeIdObject.activeFlag='Y' and employeeIdObject.format='"+searchData.Location+"' and certificationNamerObject.categoryObject.category='"+searchData.certificationType+"'"+ 
      " and certificationNamerObject.certificationName='"+(searchData.certificationName==''?searchData.certificationName:certificateName)+"' and employeeIdObject.globalPracticeObject.name='"+searchData.Community+"' and "+
      "(employeeIdObject.employeeID LIKE '%"+ searchData.EmpIdGlobalId+"%' or employeeIdObject.globalEmployeeID LIKE '%"+ searchData.EmpIdGlobalId +"%')"+
      " and employeeIdObject.name LIKE '%"+ searchData.EmpName+"%' and employeeIdObject.email LIKE '%"+searchData.Email+"%' and employeeIdObject.region='"+certSearchFields.region+"'";



    console.log("zzzzzz"+qparameter)

   return qparameter;
  };  
















   PageModule.prototype.validateFile = function(ext) {
        var extt = ext.split('.').pop();
        //console.log('@@uu :' + extt);
        if (extt == "pdf" || extt == "docx" || extt == "jpg" || extt == "jpeg") {
            //console.log('@@uu11 :' + extt);
            return 'valid';

        }

        return 'non-valid';
    };
    
     PageModule.prototype.createPay = function(fileObj, bucketName, fileName) {
        
        var form = new FormData();
        form.append('file', fileObj, fileName);
        form.append('json', '{"filename":"' + fileName + '", "bucket_name" : "' + bucketName + '"}');
    
        return form;
    };

PageModule.prototype.exportTable=function(empCertData,metaDataArray,capabilityBo,certMaster,locatBo,categoryBO,empProject,projectBO,employeeBO,businessUnitBO,workflow){
  console.log(empCertData);
 // console.log(JSON.stringify(employeeBO));
  var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<metaDataArray.length;i++)
  {
      header.push(metaDataArray[i].headerName);
  }
  multidata.push(header);
const d= new Date();
  for(let i = 0;i<empCertData.length;i++)
  {
    
    var instanceArray = [];
    var empid= employeeBO.find(ele =>ele.id==empCertData[i].employeeId);
    var certid= certMaster.find(ele =>ele.id==empCertData[i].certification);
    let work=workflow.find(ele=>ele.referenceID==empCertData[i].id);
    console.log('#130'+console.log(empid));
    if(empid){
       console.log('#132'+console.log(empid));
    instanceArray.push(certid!=undefined?categoryBO.find(element=>element.id==certid.Category).category:'NA');
    instanceArray.push(certid!=undefined?certid.subCategory:'NA');
    instanceArray.push(certid!=undefined?certid.certificationType:'NA');
    instanceArray.push(empid!=undefined?empid.globalEmployeeID:'NA');
    instanceArray.push(empid!=undefined?empid.employeeID:'NA');
    instanceArray.push(empid!=undefined?empid.name:'NA');
    instanceArray.push(empid!=undefined?empid.localGrade:'NA');
    instanceArray.push(empid!=undefined?empid.region:'NA');
    
    
    // instanceArray.push(empid!=undefined?capabilityBo.find(element=>element.id==empid.globalPractice).name:'NA');
    
if (empid.globalPractice !== undefined && empid.globalPractice !== null && empid.globalPractice !== '') {
    instanceArray.push(empid && empid.globalPractice !== undefined ? capabilityBo.find(element => element.id == empid.globalPractice).name : 'NA');
} else {
    instanceArray.push('NA'); 
}



   
    var projectIdArr = employeeBO.find(ele =>ele.id==empCertData[i].employeeId)!=undefined?(empProject.filter(element=>element.employee==empCertData[i].employeeId)):[];
    instanceArray.push(projectIdArr.length!=0?(projectBO.find(element=>element.id==projectIdArr[projectIdArr.length-1].project)!=null || projectBO.find(element=>element.id==projectIdArr[projectIdArr.length-1].project)!=undefined)?(projectBO.find(element=>element.id==projectIdArr[projectIdArr.length-1].project).projectName):'NA':'NA');
   
    instanceArray.push(empid!=undefined?empid.email:'NA');
    instanceArray.push(certid!=undefined?certid.certificationCode:'NA');
    instanceArray.push(certid!=undefined?certid.certificationName:'NA');
   
    instanceArray.push(empCertData[i].status);
    if(empCertData[i].status=='CL_Approved'||empCertData[i].status=='CL_Rejected'||empCertData[i].status=='Voucher_Requested'||empCertData[i].status=='Voucher_Rejected'||empCertData[i].status=='Voucher_Approved'||empCertData[i].status=='Credit_Approved'||empCertData[i].status=='Credit_Requested'||empCertData[i].status=='Credit_Rejected'||empCertData[i].status=='Cancelled')
    {
      instanceArray.push(empCertData[i].examPlannedDate != null ?dateFormat(empCertData[i].examPlannedDate):' ');
    }
    else
    {
      instanceArray.push(empCertData[i].examDate != null ?dateFormat(empCertData[i].examDate):' ');
    }
   
    instanceArray.push(empid.location!=undefined?locatBo.find(element=>element.id==empid.location).location:'NA');
     
    instanceArray.push(empid!=undefined?empid.format:'NA');
    
    instanceArray.push(empCertData[i].expirationDate != null ?dateFormat(empCertData[i].expirationDate):' ');
    instanceArray.push(empid.bu != undefined? businessUnitBO.find(element => element.id == empid.bu).name : 'NA');
    instanceArray.push(empCertData[i].certificationRequestDate != null ? dateFormat(empCertData[i].certificationRequestDate) : 'NA');
    instanceArray.push(empCertData[i].examDate != null ?dateFormat(empCertData[i].examDate):' ');
    instanceArray.push(empCertData[i].scoreCard != null ?(empCertData[i].scoreCard):' ');
    instanceArray.push(empCertData[i].expirationDate != null ?(empCertData[i].expirationDate):'NIL  ');
    instanceArray.push(empCertData[i].certificationOther != null ?(empCertData[i].certificationOther):' ');
      if(work!=undefined){
     if(work.currentStatus=='CL_Approved'||work.currentStatus=='CL_Rejected'||work.currentStatus=='Voucher_Requested'||work.currentStatus=='Voucher_Rejected'||work.currentStatus=='Voucher_Approved'||work.currentStatus=='Credit_Approved'||work.currentStatus=='Credit_Requested'||work.currentStatus=='Credit_Rejected'||work.currentStatus=='Cancelled'){
        instanceArray.push(work.workflowCreatedBy ? work.workflowCreatedBy : 'NA');
        instanceArray.push(work.comments ? work.comments : 'NA');
    }
} else {
    instanceArray.push('NA');
    instanceArray.push('NA');
}
    console.log('instanceArray'+instanceArray);
    multidata.push(instanceArray);
  }
    
  }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Certification Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Certification Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
//console.log(fileBytes);
var blob = new Blob([fileBytes],{type:'octet/stream'});
var filename = "Certification Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
} else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    //console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
  // try
  // {
  // console.log(empCertData[0].voucherDetailsObject.items[0].voucherCode);
  // }
  // catch(err)
  // {
  //   console.log("Aakash");
  // }
};

function formatDate(date)
{
  var month = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  var tmp = date.split('-');
 // console.log('@date'+tmp[2]+'-'+month[tmp[1]-1]+'-'+tmp[0].substring(2));
  return (tmp[2]+'-'+month[tmp[1]-1]+'-'+tmp[0].substring(2));
}

  function dateFormat (bo_date){
    const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var date = new Date(bo_date);
    var reqd_date = (date.getDate()<10?'0'+date.getDate():''+date.getDate())+'-'+months[date.getMonth()]+'-'+date.getFullYear();
    return reqd_date;
  }

PageModule.prototype.appendEmployeeEmails = function(P_CapabilityDetails, empEmail, P_Format) {
        var employeeMail = "";        
        console.log('#185' + P_Format);
        if(P_Format=="India")
        {
          employeeMail += P_CapabilityDetails.lead1 != null ? P_CapabilityDetails['lead1Object'].items[0].email+"," : "";
          employeeMail += P_CapabilityDetails.lead2 != null ? P_CapabilityDetails['lead2Object'].items[0].email+"," : "";
        }
        else if(P_Format=="US")
        {
          employeeMail += P_CapabilityDetails.uSCapabilityLead1 != null ? P_CapabilityDetails['uSCapabilityLead1Object'].items[0].email+"," : "";
          employeeMail += P_CapabilityDetails.uSCapabilityLead2 != null ? P_CapabilityDetails['uSCapabilityLead2Object'].items[0].email+"," : "";
        }
        
        if(employeeMail.includes(empEmail))
        {
            employeeMail=employeeMail.substring(0,employeeMail.length-1);
        }
        else
        {
            employeeMail+=empEmail;
        }
        
        console.log('#185' + employeeMail);
        return employeeMail;
    }

PageModule.prototype.addExpiry=function(validity,examDate,examStatus,expirationDate)
  {

    //console.log('Validity = '+validity);
    //console.log('Date = '+examDate);
    //console.log('Status = '+examStatus);
    // if((validity!=null || validity!=0) && examStatus=='Pass')
    // {
    // var eDate=new Date(examDate);
    //  eDate.setMonth(eDate.getMonth()+validity);
    //  //console.log('Date'+eDate.toISOString().split('T')[0]);
    //  return eDate.toISOString().split('T')[0];
    // }
    
    // else{
    //   return null;
    // }

    console.log('expiryDate = '+expirationDate);
    if(expirationDate!= null || expirationDate!= undefined)
    {
      var expDate = expirationDate;
      return expDate;
    }
    else if((validity!=null || validity!=0) && examStatus=='Pass')
    {
      var eDate=new Date(examDate);
      eDate.setMonth(eDate.getMonth()+validity);
      //console.log('Date'+eDate.toISOString().split('T')[0]);
      return eDate.toISOString().split('T')[0];
    }




  };




 PageModule.prototype.getAgeing=function(plannedDate,examDate){

    const date1 = new Date(plannedDate);
     var date2;
    if(examDate == null){
      date2 = new Date();
    }
    else
    {
      date2 = new Date(examDate);
    }
var diffTime = Math.abs(date2 - date1);
var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
//console.log('@12'+diffDays);


  if(plannedDate == null || date1>=date2)
  {
    return 0;
  }
  else
  {
    return diffDays;
  }



  };
  PageModule.prototype.getData=function(data){
    //console.log('Data'+JSON.stringify(data));

    const yourDate = new Date();
    //console.log('@10'+yourDate.toISOString().split('T')[0]);
  }
 PageModule.prototype.chkRoles = function(roleArray, currentRowData, globalPractiseData, currentUserId, currentloc, currentreg) {
    var roles={var1:false,var2:false}; 
     //console.log(JSON.stringify(roleArray)+'#176');
     console.log(JSON.stringify(roleArray.certification));
      if (currentUserId === "1237" && currentRowData.status === 'Credit_Requested') {
        roles.var1 = true;
        // roles.var2 = false;
    }
    if (currentUserId === "8404" && currentRowData.status === 'Credit_Requested') {
        roles.var1 = true;
        // roles.var2 = false;
    }
    else {
    if(roleArray.certification.find(element=>element.functionality=='Certification Master').accessType=='N' && roleArray.certification.find(element=>element.functionality=='Voucher Details').accessType=='N')
    {
      if(roleArray.certification.find(element=>element.functionality=='Certification Approval').accessType=='R' && currentRowData.status=='Certificate_Uploaded_Approval_Pending' )
      {
          
          roles.var1=true;
        roles.var2=false;

      }
//CLs
      if(chkCLBOId(globalPractiseData,currentUserId) && currentRowData.status=='Voucher_Requested'||currentRowData.status=='Credit_Requested'){
        roles.var1=true;
        roles.var2=false;
      }
    }
    //L&D Admin
    else{
      if(currentRowData.status=='Certificate_Uploaded_Approval_Pending' || currentRowData.status=='CL_Approved')
      {
        roles.var1=true;
        roles.var2=false;
       }
       else if(currentRowData.status=='Voucher_Approved'||currentRowData.status=='Credit_Approved'){
         roles.var1=false;
        roles.var2=true;
       }
        

    }

    }
    
    //console.log('#30'+JSON.stringify(roles));
    //console.log('#29'+JSON.stringify(currentRowData));
    return roles;
};


  function chkCLBOId(globalPractiseData,userId)
  {
     var metaDataArray = ['lead1', 'lead2', 'uSCapabilityLead1', 'uSCapabilityLead2'];
     var data=false;
     
     for(var index=0;metaDataArray.length>index;index++)
     {
       if(globalPractiseData[metaDataArray[index]]!=null)
       {
          var  chk=globalPractiseData[metaDataArray[index]]==userId?true:false;
          if(chk){
            data=chk;
            break;
          }
       }
     }
     //console.log('#221'+data);

     return data;
     
  }

  PageModule.prototype.todaysDate = function() {
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0! 
        var yyyy = today.getFullYear();

        today = yyyy + '-' + mm + '-' + dd; //10/12/2021  YYYY-MM-DD 2021-10-30
        //console.log("@today 11:"+today );
        return today;
    };

  PageModule.prototype.createQParameter=function(searchData,certificateName,certSearchFields)
  {
    var q='';
    q="status='"+searchData.requestStatus+"' and employeeIdObject.activeFlag='Y' and employeeIdObject.format='"+searchData.Location+"' and certificationNamerObject.categoryObject.category='"+searchData.certificationType+"'"+ 
      " and certificationNamerObject.certificationName='"+(searchData.certificationName==''?searchData.certificationName:certificateName)+"' and employeeIdObject.globalPracticeObject.name='"+searchData.Community+"' and "+
      "(employeeIdObject.employeeID LIKE '%"+ searchData.EmpIdGlobalId+"%' or employeeIdObject.globalEmployeeID LIKE '%"+ searchData.EmpIdGlobalId +"%')"+
      " and employeeIdObject.name LIKE '%"+ searchData.EmpName+"%' and employeeIdObject.email LIKE '%"+searchData.Email+"%' and employeeIdObject.region='"+certSearchFields.region+"'";
console.log('@1243'+certificateName+'@1234');


    return q;
  }
   

  PageModule.prototype.getCertification = function (context) {
    return context.data.certificationCode+'-'+context.data.certificationName;
  };

  PageModule.prototype.returnSkillText=function(lookupBO,skillRating)
    {
      var lookupData=lookupBO.find(element=>element.lookupValue==skillRating);

      return lookupData.description;

    };

  PageModule.prototype.Skilldescription = function (lookupval, skillRating) {
    //console.log('#291'+JSON.stringify(lookupval)+':'+skillRating);
      
    const lookupData = lookupval.find(element=>element.lookupValue==skillRating);

      return lookupData.description;
    
  };
  PageModule.prototype.getColor= function(currentRowData,ret){
  
   var retention;
  retention = ret.find(ele=>ele.employeeID==currentRowData.items[0].id);
  //  var certificationArray =[];
  //  for(var i =0;i<ce_id.length;i++){
  //  for(var j=0;j<re_id.length;j++){
  //    if(re_id[j].employeeID ==ce_id[i].employeeId){
     var result;
    if(retention!=undefined)
    {
      result=true;
    }
 

     else {
            result = false;
          }
  if(result)
  {
   if(retention.withdrawlDate != null) result = false;
  }

  return result;
}
  
PageModule.prototype.downloadFile = function(base64File,filename){
         //console.log('@@File Name'+filename);

        var fileBytes=atob(base64File);
        fileBytes=FileToBytes(fileBytes);
        //console.log(fileBytes);
          // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
        //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        var blob = new Blob([fileBytes],{type:'octet/stream'});
        //var filename = "CDE.xlsx";

        
        if(navigator.msSaveBlob){ // IE 10+
          navigator.msSaveBlob(blob,filename);
        } 
        else {
          var link = document.createElement("a");
          if(link.download !== undefined){ // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href",url);
            link.setAttribute("download",filename);
            link.setAttribute("target","_blank");
            link.style.visibility='hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
        }
    
    };

PageModule.prototype.SkillEmp = function (skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO) {
     var empSkillArray=new Array(); 

    for(var index=0;index<empSkillBO.length;index++){

     var skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
      var skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      var capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      var empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}'
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
    }    
    return empSkillArray;
  };

function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
        }

 PageModule.prototype.validateNumber = function(number) {
   
        var num = number.replace(/[^0-9\.]/g, '');
        //console.log('@no' + no);
        //console.log('@num' + num);
        if(number){
        if(number=>0){
         if (number== num) {
           if(number>=0 && number<101){
           //console.log("Valid Score");
             return true;}
            }}}
            // console.log("In Valid Score");
            return false;
       }

          PageModule.prototype.returnVisibillity=function(roleAccessArray,screen,type){
              var data=roleAccessArray.find(element=>element.functionality==screen);
              if(data.accessType==type)
              {
                return false;
              }
              else{
              return true;
              }

          }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.incredit = function (ct) {
    var count=0;    
  count=++ct;
        
    return count;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.deccredit = function (assigned) {
     var count;    
  count= --assigned;
        
    return count; 
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.checkCredits = function (str) {
     var data =[];
   

    for(var i =0;i<str.length;i++)
    {
      if(str[i].assigned != str[i].totalCredits)
      data.push(str[i].id);

    }
    return data;
  };

  PageModule.prototype.nonrelevant = function()
{
        return 19;
};

PageModule.prototype.checkcapability = function(P_CapabilityDetails, P_CertCapability)
{
    if(P_CapabilityDetails == P_CertCapability)
    {
        return 3;
    }
    else
    {
        return 19;
    }
};

PageModule.prototype.checkcapabilityForHighlyRelevant = function(P_CapabilityDetails, P_CertCapability)
{
    if(P_CapabilityDetails == P_CertCapability)
    {
        return 20;
    }
    else
    {
        return 19;
    }
};

PageModule.prototype.ArchitectCategory = function(certCode)
{
    if(certCode == "L0")
    {
        return 5;
    }
    else if(certCode == "L1")
    {
        return 10;
    }
    else if(certCode == "L2")
    {
        return 20;
    }
    else if(certCode == "L3")
    {
        return 40;
    }
    else if(certCode == "L4")
    {
        return 80;
    }
    else
    {
        return 0;
    }
};

PageModule.prototype.EMcategory = function(certCode)
{
    if(certCode == "EM-Foundation")
    {
        return 5;
    }
    else if(certCode == "EM-L1")
    {
        return 10;
    }
    else if(certCode == "EM-L2")
    {
        return 20;
    }
    else if(certCode == "EM-L3")
    {
        return 40;
    }
    else if(certCode == "EM-L4")
    {
        return 80;
    }
    else
    {
        return 0;
    }
};


PageModule.prototype.methodologyCategory = function(certName, certCode, subcategory)
{

    if(certName== "ITIL Foundation")
    {
        return 5;
    }
    else if(certName== "ITIL Managing Professional" || subcategory== "Business Analyst" || certCode == "SA" || certCode == "PSM I" || certCode == "PSD-1")
    {
        return 10;
    }
    else if(certCode == "SP" || certCode == "SDP")
    {
        return 15;
    }
    else if(certName== "ITIL Strategic Leader" || subcategory == "PMP" || certCode == "SSM" || certCode == "PSM II" || certCode == "PSU-1" || certCode == "ARCH" || certCode == "POPM" || certCode == "RTE" || certCode == "LPM" || certCode == "PAL I")
    {
        return 20;
    }
    else if(certCode == "SPC")
    {
        return 25;
    }
    else if(certName== "ITIL Extension Modules")
    {
        return 40;
    }
    else
    {
        return 0;
    }
};

 PageModule.prototype.getYearnMonth = function () {
      var abc=[];
      var retpayload={};
      const d = new Date();

      retpayload['month'] = d.toLocaleString('default', { month: 'short' });
      retpayload['year'] = d.getFullYear();
      
      abc.push(retpayload);
      return abc;
  };

  PageModule.prototype.taskCreationAfterCreditApproved = function(approver,P_Format)
{
    var retPayload=[];
    if(P_Format=="India")
    {
      retPayload.push(approver);
    }
    else if(P_Format=="US")
    {
      retPayload.push(approver);
      
      //for creating task for jene.stratton@capgemini.com 
      retPayload.push('50591090');
      
    }
    
    
    return retPayload;
};
  
  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  return PageModule;
});
