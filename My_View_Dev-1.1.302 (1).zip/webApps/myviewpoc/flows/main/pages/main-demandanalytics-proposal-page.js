define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

   PageModule.prototype.demandScreenData=function(demandBO,buBO,cBO,sBO,clientBO){
      var data = [];

      for(var i=0;i<demandBO.length;i++){
        var retpayload = {};

         var cb = cBO.find(ele=>ele.id==demandBO[i].globalPractice);
         var bu = buBO.find(ele=>ele.id==demandBO[i].sector);
         var sg = sBO.find(ele=>ele.id==demandBO[i].skillGroup);
         var clientB = clientBO.find(ele=>ele.id==demandBO[i].client);
        
       retpayload['id']=demandBO[i].id!=null?demandBO[i].id:'';
       retpayload['teamRequestNumber'] = demandBO[i].teamRequestNumber != undefined ? demandBO[i].teamRequestNumber:'';    //demain ID
       retpayload['demandType'] = demandBO[i].demandType != undefined ? demandBO[i].demandType:'';
       retpayload['projectName'] = demandBO[i].projectName != undefined ? demandBO[i].projectName : '';
       retpayload['sector'] = bu != undefined ? bu.name  : '';
       retpayload['capability'] = cb != undefined ? cb.name  : '';
       retpayload['capabilityStatus'] = demandBO[i].capabilityStatus != undefined ? demandBO[i].capabilityStatus:'N';
       retpayload['skillStatus'] = demandBO[i].skillStatus != undefined ? demandBO[i].skillStatus:'N';
       retpayload['skillGroup'] = sg !=undefined ? sg.skillGroupName : '';
       retpayload['status'] = demandBO[i].status!=undefined?demandBO[i].status:'';
       retpayload['client'] = clientB !=undefined ? clientB.clientName : '';
       retpayload['demandCreationDate'] = demandBO[i].demandCreationDate != undefined ? demandBO[i].demandCreationDate:'';
       retpayload['requestedBy'] = demandBO[i].requestedBy != undefined ? demandBO[i].requestedBy:'';

      data.push(retpayload);
      }
      return data;
  };


  PageModule.prototype.demandUpdateValidation = function(cBO,sBO,cTabcopy,sTabcopy,load) {
 var record = [];

 var sRecord = sBO.filter(ele=>ele.skillGroupName == sTabcopy);

 for(var i=0;i<sRecord.length;i++){

    var matchingRecord = sRecord[i].capability;  

    var cRecord = cBO.filter(ele=>ele.id == matchingRecord);

    for(var j=0;j<cRecord.length;j++){
    
    var matchingCRecord = cRecord[j].name;

    if (matchingCRecord == cTabcopy) {
            load.record.push(matchingCRecord);
          
        }
    }

 }
   
return load;
 };

 PageModule.prototype.demandValidation = function(cBO,sBO,cTabcopy,sTabcopy,load) {
 var record = [];

 var sRecord = sBO.filter(ele=>ele.skillGroupName == sTabcopy);

 for(var i=0;i<sRecord.length;i++){

    var matchingRecord = sRecord[i].capability;  

    var cRecord = cBO.filter(ele=>ele.id == matchingRecord);

    for(var j=0;j<cRecord.length;j++){
    
    var matchingCRecord = cRecord[j].name;

    if (matchingCRecord == cTabcopy) {
            load.record.push(matchingCRecord);
          
        }
    }

 }
   
return load;
 };

PageModule.prototype.updateDemandScreenPayload = function (BOName,operation,sgBO,cBO,demandBO,panelData,capTab,skillTab,clientInterview,cloud) {
 var batchProcessingVariableArray = [];

 var sgRow=panelData.skillGroup;
 var cRow=panelData.capability;
 var boid=panelData.id;

 var sTab = skillTab;
 var cTab = capTab;

  var sgRowFound; 
  var cRowFound;

  var sgRowFoundduplicate;
  var cRowFoundduplicate;

    if(sTab!=undefined){
    for (var i = 0; i < sgBO.length; i++) {
    if (sgBO[i].skillGroupName === sTab) {
      sgRowFoundduplicate = sgBO[i]; 
      break; 
    }
  }
     }

if(cTab!=undefined){
  for (var j = 0; j < cBO.length; j++) {
    if (cBO[j].name === cTab) {
      cRowFoundduplicate = cBO[j]; 
      break; 
    }
  }
}

var skillId = sgRowFoundduplicate!=undefined?sgRowFoundduplicate.id:'';
var cId = cRowFoundduplicate!=undefined?cRowFoundduplicate.id:'';
var boID = boid;



var cFind = (cTab==cRow);
var sFind = (sTab==sgRow);


if(cTab!='' && sTab!='' && !cFind && !sFind){
   let data = {
      id: "part" + boid,
      path: "/" + BOName + "/" + boid,
      operation: operation,
      payload: {
                globalPractice: cId,
                skillGroup: skillId,
                clientInterview: clientInterview,
                cloud: cloud
                }
              };

    batchProcessingVariableArray.push(data);
}
else{
  if((cTab == '' || cTab != undefined) && sTab != undefined && !sFind){ //testing
     let data = {
      id: "part" + boid,
      path: "/" + BOName + "/" + boid,
      operation: operation,
      payload: {
                skillGroup: skillId
                }
              };

    batchProcessingVariableArray.push(data);

  }else{
    if((sTab == '' || sTab != undefined) && cTab != undefined && !cFind){
    let data = {
      id: "part" + boid,
      path: "/" + BOName + "/" + boid,
      operation: operation,
      payload: {
                globalPractice: cId
                }
              };

    batchProcessingVariableArray.push(data);
  }

  }
}

  // if((sTab == '' || sTab != undefined) && cTab != undefined && !cFind){
  //   let data = {
  //     id: "part" + boid,
  //     path: "/" + BOName + "/" + boid,
  //     operation: operation,
  //     payload: {
  //               globalPractice: cId,
  //               capabilityStatus: 'Y'
  //               }
  //             };

  //   batchProcessingVariableArray.push(data);
  // }
  return JSON.stringify({ parts: batchProcessingVariableArray });

  };

  PageModule.prototype.updateDemandDetails = function (BOName,operation,sgBO,cBO,demandBO,panelData,capTab,skillTab,clientInterview,cloud,stat) {
 var batchProcessingVariableArray = [];

 
 var boid=panelData.id;
 var st = stat;

 var sTab = skillTab;
 var cTab = capTab;

var sgRowFoundduplicate;
  var cRowFoundduplicate;

    if(sTab!=undefined){
    for (var i = 0; i < sgBO.length; i++) {
    if (sgBO[i].skillGroupName === sTab) {
      sgRowFoundduplicate = sgBO[i]; 
      break; 
    }
  }
     }

if(cTab!=undefined){
  for (var j = 0; j < cBO.length; j++) {
    if (cBO[j].name === cTab) {
      cRowFoundduplicate = cBO[j]; 
      break; 
    }
  }
}


var skillId = sgRowFoundduplicate!=undefined?sgRowFoundduplicate.id:'';
var cId = cRowFoundduplicate!=undefined?cRowFoundduplicate.id:'';
var boID = boid;



if(cTab!='' && sTab!=''&& st!=''){
   let data = {
      id: "part" + boid,
      path: "/" + BOName + "/" + boid,
      operation: operation,
      payload: {
                globalPractice: cId,
                skillGroup: skillId,
                clientInterview: clientInterview,
                cloud: cloud,
                status:st
                }
              };

    batchProcessingVariableArray.push(data);
}

  // if((sTab == '' || sTab != undefined) && cTab != undefined && !cFind){
  //   let data = {
  //     id: "part" + boid,
  //     path: "/" + BOName + "/" + boid,
  //     operation: operation,
  //     payload: {
  //               globalPractice: cId,
  //               capabilityStatus: 'Y'
  //               }
  //             };

  //   batchProcessingVariableArray.push(data);
  // }
  return JSON.stringify({ parts: batchProcessingVariableArray });

  };


    PageModule.prototype.demandScreenDialogTitle = function (data) {

    let name;
   var cap = data[0].globalPracticeObject.items[0]!=undefined?data[0].globalPracticeObject.items[0].name:'';
    var skill = data[0].skillGroupObject.items[0]!=undefined?data[0].skillGroupObject.items[0].skillGroupName:'';

      name=data[0].teamRequestNumber;
    return  name;
  };

PageModule.prototype.empIDArr=function(employeeBO)
{
  var a = new Array();
  for(var i = 0; i<employeeBO.length;i++)
  {
    a.push(employeeBO[i].id);
  }
  return a;
};
  PageModule.prototype.buildQFormat = function (format) {
    var qparameter=''
    if (format=="Both")
    qparameter="(employeeBOObject.format='US' or employeeBOObject.format='India')";

    else if(format=="US") {
      qparameter="employeeBOObject.format='US'";
    }
    else{
      qparameter="employeeBOObject.format='India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };
 PageModule.prototype.createEmployeeSkillArray=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     var empSkillArray=new Array(); 

    for(var index=0;index<empSkillBO.length;index++){

     var skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
      var skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      var capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      var empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}';
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
    }
    
return empSkillArray;

  };

  PageModule.prototype.pushData=function(demandSupplyBO,demandBO,employeeBo){
    var demandArray=new Array();
      console.log(JSON.stringify(demandBO));

    for(var index=0;index<demandSupplyBO.length;index++)
    {
      var demandFound=demandBO.find(element=>element.id==demandSupplyBO[index].demandID);
      if(demandFound){
      var data={"demandEmployeeId":demandSupplyBO[index].employeeID,"trn":demandFound.teamRequestNumber,"sector":demandFound.sectorObject.items[0].name,"clientName":demandFound.clientObject.items[0].clientName,"projectName":demandFound.projectName,"positionName":demandFound.positionName,"demandStatus":demandFound.status,"employeeId":demandSupplyBO[index].employeeIDObject.items[0] != undefined ? demandSupplyBO[index].employeeIDObject.items[0].employeeID:'NA',"employeeName":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].name : 'NA',"nominationStatus":demandSupplyBO[index].allocationType,"nominationComments":demandSupplyBO[index].allocationComments,"employeeGrade":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].localGrade : 'NA',"employeeGeography":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].format : 'NA'};
      demandArray.push(data);
      }
      

    }

    return demandArray;




  }

   PageModule.prototype.dateValidation = function (resignationDate,withdrawalDate,lastWorkingDate,demandId) {
     var notification = {
       }
     var resignation_Date = new Date(resignationDate);
     var withdrawal_Date = new Date(withdrawalDate);
     var lastWorking_Date = new Date(lastWorkingDate); 
     console.log('@1'+resignationDate);
     console.log('@2'+withdrawal_Date);
     console.log('@3'+lastWorkingDate);
    if ((demandId !=null || demandId != undefined) && isNaN(demandId)){
      notification.status=false;
      notification.message='Demand Id should be a Number';
      return notification;
    }
    if (withdrawalDate !=null || withdrawalDate != undefined ){
      console.log(lastWorking_Date.getTime()> withdrawal_Date.getTime()>resignation_Date.getTime());
      notification.status=(lastWorking_Date.getTime() > withdrawal_Date.getTime() && withdrawal_Date.getTime() > resignation_Date.getTime());
      notification.message='Withdrawal Date should be between Last Working Date and Resignation Date';
      console.log(JSON.stringify(notification));
      return notification;
      }
    else
     console.log(lastWorking_Date.getTime()>resignation_Date.getTime());
     notification.status=(lastWorking_Date.getTime()>resignation_Date.getTime());
     notification.message='Last Working Date should be greater than Resignation Date';
     console.log(JSON.stringify(notification));
      return notification;
         
  };

  PageModule.prototype.createQParameter=function(nominationVar){
   var qParam='';
   
        var qArray=[];
        if(nominationVar.bu!='')
         {qArray.push('demandIDObject.sector='+nominationVar.bu);}
        if(nominationVar.capability!='')
        qArray.push('demandIDObject.globalPractice='+nominationVar.capability);
        if(nominationVar.client!='')
        qArray.push('demandIDObject.client='+nominationVar.client);
        if(nominationVar.demandStatus!='')
        qArray.push("demandIDObject.status='"+nominationVar.demandStatus+"'");
        if(nominationVar.location!='')
        qArray.push("demandIDObject.format='"+nominationVar.location+"'");
        if( nominationVar.nominationStatus!='')
        qArray.push("allocationType='"+nominationVar.nominationStatus+"'");
        if(nominationVar.skillGroup!='')
        qArray.push('demandIDObject.skillGroup='+nominationVar.skillGroup);

        for(var i=0;i<qArray.length;i++)
        {
           if(i==qArray.length-1)
          {
            qParam=qParam+" "+qArray[i];
          }
          else{
              qParam=qParam+" "+qArray[i]+" and";
       
          }
        }

        console.log('QParam'+qParam)

       return qParam;
  }






   PageModule.prototype.getAgeing=function(plannedDate){
    const date1 = new Date(plannedDate);
const date2 = new Date();
const diffTime = Math.abs(date2 - date1);
const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
console.log('@12'+plannedDate);
  if(plannedDate == null || date1>date2)
  {
    return 0;
  }
  else
  {
    return diffDays-1;
  }


  };
  
function changeFormat(currentDate) {
    try{
   
      var now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
   
    }
    catch(err){
       console.log('#131'+currentDate);
      return currentDate;
    }
  }

PageModule.prototype.demandAnalyticsDataCreate = function(P_demandBO){
    // console.log(P_demandBO);
    var initData = [];
    var finalData = [];
        finalData['Total'] = [];
        
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec","Jan","Feb"];
    var row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0, row11=0, row12=0, row13=0, row14=0, row15=0, row16=0;

    for(var i=0; i<P_demandBO.length; i++){
      var row = {};
      
      // P_demandBO[0].roleStartDate
      var net_total=0, sold_total=0, pursuit_total=0, strategic_total=0;
      row['capability'] = P_demandBO[i].globalPracticeObject.items[0].name;
      row['skillGroups'] = P_demandBO[i].skillGroup != undefined ? P_demandBO[i].skillGroupObject.items[0].skillGroupName  : '';
      row['roleStartDate'] = P_demandBO[i].roleStartDate;
      row['demandType'] = P_demandBO[i].demandType.trim();

      initData.push(row);
    };
    var d = new Date();
    var curr_month = d.getMonth()+1;
    var curr_year=d.getFullYear();

    

    for (i=0; i<initData.length; i++){
      
      var roleStartDate = new Date(initData[i]['roleStartDate']);
      var month = roleStartDate.getMonth()+1;

      var month_year=roleStartDate.getFullYear();
      
      var element  = finalData.find(function(data){return data.capability == initData[i].capability && data.skillGroups == initData[i].skillGroups;});
    
      if(element == undefined){
        console.log("Insert");

        var temp = {};

        temp['capability'] = initData[i].capability;
        temp['skillGroups'] = initData[i].skillGroups;
        temp['sold_current_due'] = 0;
        temp['sold_next_due'] = 0;
        temp['sold_future_due'] = 0;
        temp['sold_past_due'] = 0;
        temp['sold_total'] = 0;
        temp['pursuit_current_due'] = 0;
        temp['pursuit_next_due'] = 0;
        temp['pursuit_future_due'] = 0;
        temp['pursuit_past_due'] = 0;
        temp['pursuit_total'] = 0;
        temp['strategic_current_due'] = 0;
        temp['strategic_next_due'] = 0;
        temp['strategic_future_due'] = 0;
        temp['strategic_past_due'] = 0;
        temp['strategic_total'] = 0;
        

        


        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month ){
            temp['sold_current_due'] = 1;
          }      
          else if(month == curr_month+1 ){
            temp['sold_next_due'] = 1;
          }
          else if(month > curr_month+1  ){
            temp['sold_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['sold_past_due'] = 1;
          }
          
          temp['sold_total'] = 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            temp['pursuit_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['pursuit_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['pursuit_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['pursuit_past_due'] = 1;
          }
          
          temp['pursuit_total'] = 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            temp['strategic_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['strategic_next_due'] = 1;
          }
          else if(month > curr_month+1 ){
            temp['strategic_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['strategic_past_due'] = 1;
          }
           
          temp['strategic_total'] = 1;
        }

        temp['net_demands'] = temp['sold_total'] + temp['pursuit_total'] + temp['strategic_total'];
        finalData.push(temp);
      }
        
      else{
        console.log("Update");
        var index = finalData.findIndex(function(data){return data.capability == element.capability && data.skillGroups == element.skillGroups;});
       

        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month ){
            finalData[index]['sold_current_due'] += 1;
          }      
          else if(month == curr_month+1 ){
            finalData[index]['sold_next_due'] += 1;
          }
          else if(month > curr_month+1  ){
            finalData[index]['sold_future_due'] += 1;
          }
          else if(month < curr_month ){
            finalData[index]['sold_past_due'] += 1;
          }
          
          finalData[index]['sold_total'] += 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            finalData[index]['pursuit_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['pursuit_next_due'] += 1;
          }
          else if(month > curr_month+1 ){
            finalData[index]['pursuit_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['pursuit_past_due'] += 1;
          }
          
          finalData[index]['pursuit_total'] += 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            finalData[index]['strategic_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['strategic_next_due'] += 1;
          }
          else if(month > curr_month+1 ){
            finalData[index]['strategic_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['strategic_past_due'] += 1;
          }
          
          finalData[index]['strategic_total'] += 1;
        }

        finalData[index]['net_demands'] = finalData[index]['sold_total'] + finalData[index]['pursuit_total'] + finalData[index]['strategic_total'];
      }
      // if(P_demandBO[0].demandType)
    };

    for (var i=0; i<finalData.length; i++){
      row1 += finalData[i].sold_past_due;
      row2 += finalData[i].sold_current_due;
      row3 += finalData[i].sold_next_due;
      row4 += finalData[i].sold_future_due;
      row5 += finalData[i].sold_total;
      row6 += finalData[i].pursuit_past_due;
      row7 += finalData[i].pursuit_current_due;
      row8 += finalData[i].pursuit_next_due;
      row9 += finalData[i].pursuit_future_due;
      row10 += finalData[i].pursuit_total;
      row11 += finalData[i].strategic_past_due;
      row12 += finalData[i].strategic_current_due;
      row13 += finalData[i].strategic_next_due;
      row14 += finalData[i].strategic_future_due;
      row15 += finalData[i].strategic_total;
      row16 += finalData[i].net_demands;
    };

    var temp = {};
    temp['capability'] = "";
    temp['skillGroups'] = "Total";
    temp['sold_current_due'] = row2;
    temp['sold_next_due'] = row3;
    temp['sold_future_due'] = row4;
    temp['sold_past_due'] = row1;
    temp['sold_total'] = row5;
    temp['pursuit_current_due'] = row7;
    temp['pursuit_next_due'] = row8;
    temp['pursuit_future_due'] = row9;
    temp['pursuit_past_due'] = row6;
    temp['pursuit_total'] = row10;
    temp['strategic_current_due'] = row12;
    temp['strategic_next_due'] = row13;
    temp['strategic_future_due'] = row14;
    temp['strategic_past_due'] = row11;
    temp['strategic_total'] = row15;
    temp['net_demands'] = row16;

    finalData['Total'].push(temp);

    finalData['currentMonth'] = monthNames[curr_month-1];
    finalData['nextMonth'] = monthNames[curr_month];
    finalData['future'] = monthNames[curr_month+1]+'+';
   
    console.log(finalData);
    return finalData;
  };

PageModule.prototype.analyticsReportData = function(P_BUSearch, P_ClientSearch, P_StatusSearch, P_CapabSearch, P_SkillSearch, P_proposalSearch, P_region){
    var retPayload = {};

    if(P_BUSearch == undefined || P_BUSearch == 'Oic.user'){
      retPayload['bu'] = '';
    }
    else{
      retPayload['bu'] = P_BUSearch;
    }

    if(P_ClientSearch == undefined){
      retPayload['client'] = '';
    }
    else{
      retPayload['client'] = P_ClientSearch;
    }

    if(P_StatusSearch == undefined){
      retPayload['status'] = '';
    }
    else{
      retPayload['status'] = P_StatusSearch;
    }

    if(P_CapabSearch == undefined){
      retPayload['capab'] = '';
    }
    else{
      retPayload['capab'] = P_CapabSearch;
    }

    if(P_SkillSearch == undefined){
      retPayload['skill'] = '';
    }
    else{
      retPayload['skill'] = P_SkillSearch;
    }
    if(P_proposalSearch == undefined){
      retPayload['proposalStatus'] = '';
    }
    else{
      retPayload['proposalStatus'] = P_proposalSearch;
    }
    if(P_region == undefined){
      retPayload['region'] = '';
    }
    else{
      retPayload['region'] = P_region;
    }

    return retPayload;
  };

    PageModule.prototype.selectedAnalyticsData1 = function (P_Data,P_DemandSupplyLinkBO,P_Emp,P_Supply){

    console.log(P_Data);
    var finalData=[];
    for(var i=0; i<P_Data.length; i++)
    {
      var temp={};
      var demandSup = P_DemandSupplyLinkBO.find(eledemand => eledemand.demandID == P_Data[i].id);
      // var empid= employeeBO.find(ele =>ele.id==empCertData[i].employeeId);
      // instanceArray.push(empid.location!=undefined?locatBo.find(element=>element.id==empid.location).location:'NA');
      //var supply = demandSup != undefined?P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID).profileID:'NA';
     //* var supply = demandSup != undefined?P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID):'NA';
      //var emp = demandSup != undefined?P_Emp.find(empele => empele.id == demandSup.employeeID).employeeID:'NA';
      //console.log('@421'+JSON.stringify(emp));
      if(demandSup != undefined)
      {
        if(demandSup.supplyID != undefined )
        {
         if(demandSup.employeeID == null)
         {
          var supply = P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID);
          // temp['profileID'] = demandSup != undefined?demandSup.supplyID:'NA';
          temp['profileID'] = supply != null?supply.profileID:'NA';
          temp['doj'] = supply != null?supply.doj:'NA';
         }
        }

        else if(demandSup.employeeID != undefined )
        {
         if(demandSup.supplyID == null)
         {
          var emp = P_Emp.find(empele => empele.id == demandSup.employeeID);
          // temp['profileID'] = demandSup != undefined?demandSup.employeeID:'NA';
          temp['profileID'] = emp != null?emp.employeeID:'NA';
          temp['doj'] = 'NA';
         }
        }
      }
      else
      {
        temp['profileID'] = 'NA';
        temp['doj'] = 'NA';
      }
      console.log('@417'+JSON.stringify(P_Emp));
      console.log('@418'+JSON.stringify(P_Supply));
      console.log('@419'+JSON.stringify(demandSup));
      console.log('@423'+JSON.stringify(supply));
      temp['format'] = P_Data[i].format;
      temp['teamRequestNumber'] = P_Data[i].teamRequestNumber;
      temp['positionId'] = P_Data[i].positionId;
      temp['recruitingID'] = P_Data[i].recruitingID;
      temp['demandStatus'] = P_Data[i].demandStatus;
      temp['sector'] = P_Data[i].sectorObject.items[0].name;
      temp['subSector'] = P_Data[i].subSector;
      temp['teamRequestName'] = P_Data[i].teamRequestName;
      temp['fulfillmentChannel'] = P_Data[i].fulfillmentChannel;
      temp['status'] = P_Data[i].status;
      temp['additionalNotes'] = P_Data[i].additionalNotes;
      temp['client'] = P_Data[i].clientObject.items[0].clientName;
      temp['demandType'] = P_Data[i].demandType;
      temp['demandTypeUpdated'] = P_Data[i].demandTypeUpdated;
      temp['projectCode'] = P_Data[i].projectCodeObject.items.length> 0?P_Data[i].projectCodeObject.items[0].projectCode:'NA';
      temp['project'] = P_Data[i].projectName;
      temp['position'] = P_Data[i].positionName;
      temp['localGrade'] = P_Data[i].localGrade;
      temp['roleNotes'] = P_Data[i].roleNotes;
      temp['roleType'] = P_Data[i].roleType;
      temp['backFillReason'] = P_Data[i].backFillReason;
      temp['roleStartDate'] = P_Data[i].roleStartDate;
      temp['roleEndDate'] = P_Data[i].roleEndDate;
      temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
      temp['demandCreationDate'] = P_Data[i].demandCreationDate;
      temp['weekByStatus'] = P_Data[i].weekByStatus;
      temp['leadtime'] = P_Data[i].leadtime;
      temp['ageing'] = P_Data[i].ageing;
      temp['bUSPHandler'] = P_Data[i].bUSPHandler;
      temp['pSPHandler'] = P_Data[i].pSPHandler;
      temp['recruiter'] = P_Data[i].recruiter;
      temp['requestedBy'] = P_Data[i].requestedBy;
      temp['deliveryType'] = P_Data[i].deliveryType;
      temp['primaryCity'] = P_Data[i].primaryCity;
      temp['primaryState'] = P_Data[i].primaryState;      
      temp['location'] = P_Data[i].location;
      temp['thorStage'] = P_Data[i].thorStage;
      temp['revenueStatus'] = P_Data[i].revenueStatus;
      //temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
      temp['skillGroup'] = P_Data[i].skillGroupObject.items.length>0 ?P_Data[i].skillGroupObject.items[0].skillGroupName:'NA';
      temp['newStatus'] = P_Data[i].newStatus;
      temp['comments'] = P_Data[i].comments;
       temp['cloud'] = P_Data[i].cloud;
        temp['clientInterview'] = P_Data[i].clientInterview;
       temp['proposalStatus'] = P_Data[i].proposalStatus;
     // temp['profileID'] = demandSup != undefined?supply:'NA';
      //temp['profileID'] = demandSup != undefined?demandSup.supplyID:'NA';
      //*temp['doj'] = supply != undefined?supply.id:'NA';
      //console.log('@456'+JSON.stringify(P_Data[i].demandSupplyLinkBOColle.items>0 ? P_Data[i].demandSupplyLinkBOColle.items[0].employeeID:'NA'));
      
     
      finalData.push(temp);
      console.log('@465'+JSON.stringify(temp));
    } 
    return finalData;
  };

  PageModule.prototype.selectedAnalyticsData = function (P_Data, P_type, P_Capab, P_Skill){
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    var d = new Date();
    var curr_month = d.getMonth();

    var finalData=[];

    for(var i=0; i<P_Data.length; i++){
    if(P_Data[i].skillGroup != undefined && P_Data[i].skillGroup !='' ){
      if(P_Data[i].globalPracticeObject.items[0].name == P_Capab && P_Data[i].skillGroupObject.items[0].skillGroupName == P_Skill){
        var roleStartDate = new Date(P_Data[i]['roleStartDate']);
        var month = roleStartDate.getMonth();
        var temp={};

        finalData['capability'] = P_Capab;
        finalData['skillGroup'] = P_Skill;
        temp['demandType'] == P_Data[i].demandType;
        //console.log('427'+P_Data[i].demandType);

        switch(P_type){
          case 's_past':
          
            if(P_Data[i]['demandType'] == 'Sold Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status; 
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              temp['proposalStatus'] = P_Data[i].proposalStatus;
              console.log(1);
              console.log(P_Data[i].demandType);

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] == P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              temp['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'net_demands':
            temp['trn'] = P_Data[i].teamRequestNumber;
            temp['sector'] = P_Data[i].sectorObject.items[0].name;
            temp['client'] = P_Data[i].clientObject.items[0].clientName;
            temp['project'] = P_Data[i].projectName;
            temp['position'] = P_Data[i].positionName;
            temp['roleNotes'] = P_Data[i].roleNotes;
            temp['status'] = P_Data[i].status;
             temp['roleStartDate'] = P_Data[i].roleStartDate; 

            temp['localGrade'] = P_Data[i].localGrade;
            temp['demandCreationDate'] = P_Data[i].demandCreationDate;
            temp['roleStartDate'] = P_Data[i].roleStartDate;
            temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
            temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
            temp['demandType'] = P_Data[i].demandType;
            temp['proposalStatus'] = P_Data[i].proposalStatus;

            finalData['role'] = 'All';
            finalData.push(temp);
          
        }
      }
    }
      else if(P_Skill == 'Total'){
        var roleStartDate1 = new Date(P_Data[i]['roleStartDate']);
        var month1 = roleStartDate1.getMonth();
        var temp1 = {};

        finalData['capability'] = 'All'
        finalData['skillGroup'] = 'All';

        switch(P_type){
          case 's_past':

            console.log(P_Data[i].demandType);
            console.log(month1);


            if(P_Data[i]['demandType'] == 'Sold Project' && month1 < curr_month){
              console.log('Inside');
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
              
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
               temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status; 
              temp['roleStartDate'] = P_Data[i].roleStartDate; 
              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
               temp['roleStartDate'] = P_Data[i].roleStartDate; 

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              //temp1['demandType'] == P_Data[i].demandType;
              temp1['proposalStatus'] = P_Data[i].proposalStatus;
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'net_demands':
            temp1['trn'] = P_Data[i].teamRequestNumber;
            temp1['sector'] = P_Data[i].sectorObject.items[0].name;
            temp1['client'] = P_Data[i].clientObject.items[0].clientName;
            temp1['project'] = P_Data[i].projectName;
            temp1['position'] = P_Data[i].positionName;
            temp1['roleNotes'] = P_Data[i].roleNotes;
            temp1['status'] = P_Data[i].status;
             temp['roleStartDate'] = P_Data[i].roleStartDate; 

            temp1['localGrade'] = P_Data[i].localGrade;
            temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
            temp1['roleStartDate'] = P_Data[i].roleStartDate;
            temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
            temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
            temp1['demandType'] = P_Data[i].demandType;
            temp1['proposalStatus'] = P_Data[i].proposalStatus;
            finalData['role'] = 'All';
            finalData.push(temp1);
          
        }
      }
    
    }
    console.log(finalData);
    return finalData;
  };


PageModule.prototype.internalSupplyData = function(P_Emp, P_Alloc, P_Type, P_Skill,P_Comments,P_demandSupplyId){
    var retPayload = [];
    if(P_Alloc.length >0){
      var alloc = P_Alloc.reduce((p, c) => p.value > c.value ? p : c);

      if(alloc != undefined){
        var availableDate = new Date(alloc.allocationEndDate);
        availableDate.setDate(availableDate.getDate() + 1); 

        var temp = {};
        temp['id'] = P_Emp[0].employeeID;
        temp['BoID']=P_Emp[0].id;
        temp['name'] = P_Emp[0].name;
        temp['grade'] = P_Emp[0].localGrade;
        temp['type'] = P_Type;
        temp['status'] = P_Emp[0].status;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[0].globalPracticeObject.items[0].name;
        temp['skill'] = P_Skill;
        temp['loc'] = P_Emp[0].locationObject.items[0].location;
        temp['demandSupplyBOId']=P_demandSupplyId;
        temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      }
    }

    return retPayload;
  };

  PageModule.prototype.externalSupplyData = function(P_SupplyData, P_Type, P_Skill){
    var retPayload = [];
    var temp1 = {};

    temp1['pID'] = P_SupplyData[0].profileID;
    temp1['pName'] = P_SupplyData[0].name;
    temp1['pGrade'] = P_SupplyData[0].recommendedGrade ? P_SupplyData.recommendedGrade : '';
    temp1['pType'] = P_Type;
    temp1['pStatus'] = P_SupplyData[0].status;
    if( P_SupplyData[0].doj != null &&  P_SupplyData[0].doj != undefined &&  P_SupplyData[0].doj !="" &&  P_SupplyData[0].doj !=" "&&  P_SupplyData[0].doj!=''&&  P_SupplyData[0].doj!=' '){
                     var date1 =  P_SupplyData[0].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyData[0].doj = date1;
      }
    temp1['doj'] = P_SupplyData[0].doj;
    temp1['pCapab'] = P_SupplyData[0].capabilityObject.items[0].name;
    temp1['pSkill'] = P_Skill;
    temp1['pLoc'] = P_SupplyData[0].location;

    retPayload.push(temp1);
   console.log('@1203'+JSON.stringify(retPayload));
    return retPayload;
  };



  PageModule.prototype.checkAvailabilityData = function(P_DemandLinkBO, P_EmployeeBO, P_AllocationBO, P_SupplyBO, P_Skill,P_Ret,P_Pip){
    var retPayload = [];

    retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
    retPayload['external'] = [];

    for(var i=0; i<P_EmployeeBO.length; i++){
      var link = P_DemandLinkBO.find(function(link){return link.employeeID != null && link.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID;});
      // var link = P_DemandLinkBO.find(ln => ln.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
      if(link != undefined){
        if(link.allocationType != 'LOCKED'){
          var allocArray = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
          
          if(allocArray.length >0){
            var alloc = allocArray.reduce((p, c) => p.value > c.value ? p : c);

            if(alloc != undefined){
              var availableDate = new Date(alloc.allocationEndDate);
              availableDate.setDate(availableDate.getDate() + 1); 

              var temp = {};

              temp['globalID'] = P_EmployeeBO[i].globalEmployeeID;
              temp['employeeID'] = P_EmployeeBO[i].employeeID;
              temp['name'] = P_EmployeeBO[i].name;
              temp['grade'] = P_EmployeeBO[i].localGrade;
              temp['billable'] = P_EmployeeBO[i].billable;
              temp['status'] = P_EmployeeBO[i].status;
              temp['sector'] = P_EmployeeBO[i].buObject.items[0].name;
              temp['client'] = alloc.clientObject.items[0].clientName;
              temp['project'] = alloc.projectObject.items[0].projectCode;
              temp['pName'] = alloc.projectObject.items[0].projectName;
              temp['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
              temp['skill'] = P_Skill;

               var retention = [];
              retention = P_Ret.filter(ele => ele.employeeID == P_EmployeeBO[i].id);
              retention.sort(function(a,b) {
                const nameA = a.id; 
                const nameB = b.id; 
                if (nameA < nameB) {
                  return 1;
                }
                if (nameA > nameB) {
                  return -1;
                }
                
              })


              //console.log(P_Emp[i].name+' '+JSON.stringify(retention));
              var color=false;
              if (retention.length>0) {
                color=retention[0].withdrawlDate==null?true:false;
              }  
              temp['color'] = color;

               var pip=[];
               var pip2=[];
              pip=P_Pip.filter(ele => ele.empID== P_EmployeeBO[i].id);
              pip2=P_Pip.find(ele => ele.empID== P_EmployeeBO[i].id);
              if(pip2!=undefined)
              {  
              temp['MH']= pip2.category;
             
              }
              else{
              temp['MH']=false;
                
              }

              temp['BgColor']=pip.length>0?true:false;


              if(temp.billable == 'Billable'){
              var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

                if(days <= 30 && days >=0){
                temp['available'] = changeFormat(availableDate);
                retPayload['internalb'].push(temp);
             }
            }
            else{
              temp['available'] = changeFormat(availableDate);
              retPayload['internalnb'].push(temp);
            }
          }
          }
        }
      }
      else{
        var allocArray1 = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
       // console.log('#858'+JSON.stringify(allocArray1));
        if(allocArray1.length > 0){
          var alloc1 = allocArray1.reduce((p, c) => p.lastUpdateDate > c.lastUpdateDate ? p : c);

          if(alloc1 != undefined){
            var availableDate1 = new Date(alloc1.allocationEndDate);
            availableDate1.setDate(availableDate1.getDate() + 1);

            var temp1 = {};

            temp1['globalID'] = P_EmployeeBO[i].globalEmployeeID;
            temp1['employeeID'] = P_EmployeeBO[i].employeeID;
            temp1['name'] = P_EmployeeBO[i].name;
            temp1['grade'] = P_EmployeeBO[i].localGrade;
            temp1['billable'] = P_EmployeeBO[i].billable;
            temp1['status'] = P_EmployeeBO[i].status;
            temp1['sector'] = P_EmployeeBO[i].buObject.items[0].name;
            temp1['client'] = alloc1.clientObject.items[0].clientName;
            temp1['project'] = alloc1.projectObject.items[0].projectCode;
            temp1['pName'] = alloc1.projectObject.items[0].projectName;
            temp1['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
            temp1['skill'] = P_Skill;

           var retention = [];
              retention = P_Ret.filter(ele => ele.employeeID == P_EmployeeBO[i].id);
              retention.sort(function(a,b) {
                const nameA = a.id; 
                const nameB = b.id; 
                if (nameA < nameB) {
                  return 1;
                }
                if (nameA > nameB) {
                  return -1;
                }
                
              })


              //console.log(P_Emp[i].name+' '+JSON.stringify(retention));
              var color=false;
              if (retention.length>0) {
                color=retention[0].withdrawlDate==null?true:false;
              }  
              temp1['color'] = color;

               var pip=[];
               var pip2=[];
              pip=P_Pip.filter(ele => ele.empID== P_EmployeeBO[i].id);
              pip2=P_Pip.find(ele => ele.empID== P_EmployeeBO[i].id);
              if(pip2!=undefined)
              {  
              temp1['MH']= pip2.category;
             
              }
              else{
              temp1['MH']=false;
                
              }

              temp1['BgColor']=pip.length>0?true:false;

            if(temp1.billable == 'Billable'){
              var avail_date2 = availableDate1;
              var today2 = new Date();
              var curr_date2 = today2;
              var difference1= (avail_date2-curr_date2);

              var days = Math.round(difference1/(1000 * 3600 * 24));

                if(days <= 30 && days >=0){
                temp1['available'] = changeFormat(availableDate1);
                retPayload['internalb'].push(temp1);
             }
            }
            else{
              temp1['available'] = changeFormat(availableDate1);
              retPayload['internalnb'].push(temp1);
            }
          }
        }
      }
    }

    for(var j=0; j<P_SupplyBO.length; j++){
      var link1 = P_DemandLinkBO.find(function(link){return link.supplyID != null && link.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID});
      // var link1 = P_DemandLinkBO.find(ln => ln.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID);
      if(link1 != undefined){
        if(link1.allocationType != 'LOCKED'){
          var st = P_SupplyBO[j].status;
          if(!(st.includes('Rejected') || st.includes('Declined') || st.includes('Drop'))){
            var temp2 = {};
            temp2['pID'] = P_SupplyBO[j].profileID;
            temp2['pName'] = P_SupplyBO[j].name;
            temp2['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
            temp2['pStatus'] = P_SupplyBO[j].status;
                  if(P_SupplyBO[j].doj != null && P_SupplyBO[j].doj != undefined && P_SupplyBO[j].doj !="" && P_SupplyBO[j].doj !=" "&& P_SupplyBO[j].doj!=''&& P_SupplyBO[j].doj!=' '){
                     var date1 = P_SupplyBO[j].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyBO[j].doj = date1 ;
      }
            temp2['doj'] = P_SupplyBO[j].doj;
            temp2['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
            temp2['pSkill'] = P_Skill;
            temp2['pLoc'] = P_SupplyBO[j].location;

            retPayload['external'].push(temp2);
          }
        }
      }
      else{
        var st1 = P_SupplyBO[j].status;
        if(!(st1.includes('Rejected') || st1.includes('Declined') || st1.includes('Drop'))){
          var temp3 = {};
          temp3['pID'] = P_SupplyBO[j].profileID;
          temp3['pName'] = P_SupplyBO[j].name;
          temp3['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
          temp3['pStatus'] = P_SupplyBO[j].status;
                if(P_SupplyBO[j].doj != null && P_SupplyBO[j].doj != undefined && P_SupplyBO[j].doj !="" && P_SupplyBO[j].doj !=" "&& P_SupplyBO[j].doj!=''&& P_SupplyBO[j].doj!=' '){
                     var date1 = P_SupplyBO[j].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyBO[j].doj = date1 ;
      }
          temp3['doj'] = P_SupplyBO[j].doj;
          temp3['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
          temp3['pSkill'] = P_Skill;
          temp3['pLoc'] = P_SupplyBO[j].location;

          retPayload['external'].push(temp3);
        }
      }
    }

    console.log(retPayload);

  
    

    return retPayload;
  };

   PageModule.prototype.assigncommunityandSG=function(P_Emp){
    var retpayload = {};

    if(P_Emp.globalPractice != null){
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.DownloadDemandNomination=function(demandNomination,metaDataArray){
  console.log(demandNomination);
  console.log(JSON.stringify(metaDataArray));
  var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<metaDataArray.length;i++)
  {
      header.push(metaDataArray[i].headerName);
  }
  multidata.push(header);

  for(let i = 0;i<demandNomination.length;i++)
  {
    
    var instanceArray = []; 
    for(var j = 0;j<metaDataArray.length;j++)
    {
      var data=demandNomination[i][metaDataArray[j]['metadata']]==null?'NA':demandNomination[i][metaDataArray[j]['metadata']];
      instanceArray.push(data);
    }



    
    multidata.push(instanceArray);
    console.log("-------------------");
    console.log(instanceArray);
    console.log("-------------------");
  }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Demand Nomination Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Demand Nomination Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
 console.log(fileBytes);
 var blob = new Blob([fileBytes],{type:'octet/stream'});
 var filename = "Demand Nomination Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
 if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
 } else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
}

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.DownloadDemandAnalytics=function(demandAnalytics,metaDataArray){
  console.log(demandAnalytics);
  console.log(JSON.stringify(metaDataArray));
  var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<metaDataArray.length;i++)
  {
      header.push(metaDataArray[i].headerName);
  }
  multidata.push(header);
  console.log('@1483'+JSON.stringify(multidata));

  for(let i = 0;i<demandAnalytics.length;i++)
  {
    
    var instanceArray = []; 
    for(var j = 0;j<metaDataArray.length;j++)
    {
      var data=demandAnalytics[i][metaDataArray[j]['metadata']]==null?'NA':demandAnalytics[i][metaDataArray[j]['metadata']];
      if(metaDataArray[j]['metadata'] == 'roleStartDate' || metaDataArray[j]['metadata'] == 'roleEndDate' || metaDataArray[j]['metadata'] == 'demandCreationDate' || metaDataArray[j]['metadata'] == 'doj'){
        data=isNaN(Date.parse(demandAnalytics[i][metaDataArray[j]['metadata']])) ?'NA':dateFormat(demandAnalytics[i][metaDataArray[j]['metadata']]);
      }
      instanceArray.push(data);
    }



    
    multidata.push(instanceArray);
    console.log("-------------------");
    console.log(instanceArray);
    console.log("-------------------");
  }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Demand Analytics Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Demand Analytics Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
 console.log(fileBytes);
 var blob = new Blob([fileBytes],{type:'octet/stream'});
 var filename = "Demand Analytics Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
 if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
 } else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
}

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.FilterDownloadData = function (P_DemandBO, P_ClientBO, P_CapabBO, P_BUBO, P_skillGroupBO) {
    console.log('DemandBO'+JSON.stringify(P_DemandBO));
    console.log('Client'+JSON.stringify(P_ClientBO));
    console.log('Capability'+JSON.stringify(P_CapabBO));
    console.log('BusinessUnit'+JSON.stringify(P_BUBO));
    console.log('Skill'+JSON.stringify(P_skillGroupBO));
    var retPayload=P_DemandBO;

    if(P_ClientBO.length == 1)
    {
      retPayload=retPayload.filter(ele=>ele.client==P_ClientBO.id);
    }
    console.log("Payload"+JSON.stringify(retPayload));
    return retPayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uniqueClientName = function (data) {
    const uniqueClientNames = new Set();
  const result = [];

  data.forEach(item => {
    if (item.clientName !== null && !uniqueClientNames.has(item.clientName)) {
      uniqueClientNames.add(item.clientName);
      result.push({ clientName: item.clientName });
    }
  });

  return result;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.buildQuery = function (activeFlag, format, clientName, sectorName, status, globalPractice, skillGroupName,teamRequestNumber,demandType,proposalStatus,selfNominated,roleStartDate,activeNonActive,status1) {

   
    let query='';

    if (activeNonActive=='Yes') {
        query += "activeFlag='Y'";
    }
    else{
       query += "activeFlag='N'";
    }

    if (clientName !== undefined && clientName !== null && clientName !== '') {
        query += " and clientObject.clientName = '" + clientName + "'";
    }

    if (sectorName !== undefined && sectorName !== null && sectorName !== '') {
        query += " and sector = '" + sectorName + "'";
    }
    if (status !== undefined && status !== null && status !== '') {
        query += " and status LIKE '%" + status + "%'";
    }
    if (proposalStatus.length!=0) {
       var dateRanges = [];
       var queryString = "";
       for (var i = 0; i < proposalStatus.length; i++) {
      var BU = proposalStatus[i];
      dateRanges.push("(" + "proposalStatus = '" + BU + "' " + ")");
      }
       if (dateRanges.length == 1) {
         queryString = "AND " + dateRanges ;
       }
      else if (dateRanges.length > 1) {
        queryString = "AND (" + dateRanges.join(" OR ") + ")";
      }
      query+=queryString;
    }
    else{
        query +="and proposalStatus <> 'Internal Identified' and proposalStatus <> 'Tagged'";
    }
    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPracticeObject.name LIKE '%" + globalPractice + "%'";
    }

    if (skillGroupName !== undefined && skillGroupName !== null && skillGroupName !== '') {
        query += " and skillGroupObject.skillGroupName LIKE '%" + skillGroupName + "%'";
    }

    if (teamRequestNumber !== undefined && teamRequestNumber !== null && teamRequestNumber !== '') {
        query += " and teamRequestNumber = '" + teamRequestNumber + "'";
    }
    if (demandType !== undefined && demandType !== null && demandType !== '') {
     query += " and demandType = '" + demandType + "'";
    }
    if (status1 !== undefined && status1 !== null && status1 !== '') {
     query += " and status = '" + status1 + "'";
    }
    if (selfNominated !== "No") {
     query += " and selfNominated = '" + selfNominated + "'";
    }
    if (roleStartDate !== null) {
     query += roleStartDate;
    }

    return query;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.dialogTitle = function (data) {

    let name;
    let client=(data[0].clientObject.items[0].clientName).substring(0, 25);
    let demand ;

    if ((data[0].demandType).endsWith("Project")) {
    
    demand= (data[0].demandType).slice(0, -"Project".length).trim();
  } else {
   demand=(data[0].demandType);
  }

    name=data[0].teamRequestNumber+' : '+data[0].globalPracticeObject.items[0].name+'-'+data[0].skillGroupObject.items[0].skillGroupName+' ('+data[0].localGrade+') '+'['+data[0].sectorObject.items[0].name+'-'+client+'..., '+demand+']';
    return  name;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.benchSearchADP = function (P_Emp, P_Alloc,P_Skill,proposalBO,currentDemandBOID,pipBO,rollofRadarBO) {
     var retPayload = [];
//      let empCheck = {
//     employeeID: null,
//     teamRequestNumber: null,
//     status:null
// };
 retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
     retPayload['internalshadow'] = [];


       for(var i=0; i<P_Emp.length; i++){
   let pip=pipBO.find(ele=>ele.empID==P_Emp[i].id);
    let rolloff=rollofRadarBO.find(ele=>ele.employeeID==P_Emp[i].id);
         let proposal=proposalBO.find(ele=>ele.employeeID==P_Emp[i].id && ele.teamRquestNumber==currentDemandBOID);
           let proposal1=proposalBO.filter(ele=>ele.employeeID==P_Emp[i].id);
           let containsStatus = proposal1.some(record => record.status === 'Allocated' || record.status === 'Blocked/Client interview');
           let containsStatus12 = proposal1.some(record => record.status === 'Proposed' );
      let alloc=P_Alloc.filter(ele=> ele.employee==P_Emp[i].id);
      let latestRecord = alloc.sort((a, b) => new Date(b.allocationEndDate) - new Date(a.allocationEndDate))[0];
       let latestRecord1 = alloc.sort((a, b) => new Date(b.allocationStartDate) - new Date(a.allocationStartDate))[0];
      if(proposal1.length!==0){
      if (containsStatus) {
    continue;
       } else if (proposal !== undefined && currentDemandBOID === proposal.teamRquestNumber && proposal.status!=='Rejected' && proposal.status!=='Cancelled') {
           continue;
       }
      }
      if(latestRecord != undefined){
        var availableDate = new Date(latestRecord.allocationEndDate);
          var startDate = new Date(latestRecord1.allocationStartDate);
        availableDate.setDate(availableDate.getDate() + 1); 
        

        var temp = {};
        temp['id'] = P_Emp[i].employeeID;
        temp['name'] = P_Emp[i].name;
        temp['grade'] = P_Emp[i].localGrade;
         temp['billable'] = (containsStatus12 === true) ? (P_Emp[i].billable + " (Proposed)") : P_Emp[i].billable;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[i].globalPracticeObject.items[0].name;
          temp['competency'] = P_Emp[i].suggestedCapabillityObj.items[0] ? P_Emp[i].suggestedCapabillityObj.items[0].name : '';
          temp['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp['skill'] = P_Emp[i].skillGroup1==null?'':P_Emp[i].skillGroup1Object.items[0].skillGroupName;
         temp['skill2'] = P_Emp[i].skillGroup2==null?'':P_Emp[i].skillGroup2Object.items[0].skillGroupName;
          temp['skill3'] = P_Emp[i].skillGroup3==null?'':P_Emp[i].skillGroup3Object.items[0].skillGroupName;
        temp['location'] = P_Emp[i].location==null?'':P_Emp[i].locationObject.items[0].location;
        // temp['status'] = P_Emp[0].status;
         temp['BoID']=P_Emp[i].id;
          temp['status']=P_Emp[i].status;
           temp['pip']=pip!=undefined?true:false;
      
      
        // temp['loc'] = P_Emp[0].locationObject.items[0].location;
        // temp['demandSupplyBOId']=P_demandSupplyId;
        // temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      
        
      
    var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

if(rolloff!=undefined){
   var availableDateRolloff = new Date(rolloff.releaseDate);
              var avail_date11 = availableDateRolloff;
              var today11 = new Date();
              var curr_date11 = today11;
              var difference1= (avail_date11-curr_date11);

              var days1 = Math.round(difference1/(1000 * 3600 * 24));
}
            //     if(days <= 30 && days >=0){
            //     temp['available'] = changeFormat(availableDate);
            //     retPayload['internalb'].push(temp);
            //  }
            

             if(rolloff!=undefined && days1 <= 30 && days1 >=0){
                 temp['available'] = changeFormat(rolloff.releaseDate);
                  temp['category']='Non-Bench';
                 retPayload['internalb'].push(temp);
              }


            else if(temp['status']==="Bench - Deployable" ||  temp['status']==="Bench - Resigned" ||  temp['status']==="Bench - Blocked" ){
              temp['available'] = changeFormat(availableDate);
               temp['category']='Bench';
              retPayload['internalnb'].push(temp);             
            }

            else if(temp['status']==="Shadow "){
              temp['available1'] = changeFormat(startDate);
               temp['category']='Shadow';
              temp['ageing'] = calculateAgeInPastDayss12233(temp['available1']);
             if (temp['ageing'] >= 60) {
        retPayload['internalshadow'].push(temp);
    }
              
            }
      }
       }

retPayload.internalbCount = retPayload['internalb'].length;
retPayload.internalnbCount = retPayload['internalnb'].length;
retPayload.internalshadowCount = retPayload['internalshadow'].length;

retPayload['internalnb'].sort((a, b) => {
    // First, sort by grade
    const gradeComparison = b.grade.localeCompare(a.grade);
    
    // If grades are equal, sort by id
    if (gradeComparison === 0) {
        return a.id - b.id;
    } else {
        return gradeComparison;
    }
});

retPayload['internalb'].sort((a, b) => new Date(a.available) - new Date(b.available));

 function calculateAgeInPastDayss12233(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
       
    return retPayload;
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.buildqueryforSearchBench = function (activeFlag, globalPractice, employeeID, name, localGrade, skillGroup) {
     let query = "activeFlag='Y'";

    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPractice='" + globalPractice + "'";
    }

    if (employeeID !== undefined && employeeID !== null && employeeID !== '') {
        query += " and employeeID='" + employeeID + "'";
    }

    if (name !== undefined && name !== null && name !== '') {
        query += " and id='" + name + "'";
    }

    if (localGrade !== undefined && localGrade !== null && localGrade !== '') {
        query += " and localGrade='" + localGrade + "'";
    }

    if (skillGroup !== undefined && skillGroup !== null && skillGroup !== '' && skillGroup !== 'All Skills') {
        // query += " and (skillGroup1='" + skillGroup + "' OR skillGroup2='" + skillGroup + "' OR skillGroup3='" + skillGroup + "')";
         query += " and (CapabilitySkillGroup='" + skillGroup + "')";
    }

    return query;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.skillGroupQuery = function (arg1) {
    let query;
    // query=
  };

   PageModule.prototype.checkBox = function (arg1,data) {
    // let data=[];
    if(data.includes(arg1)){
      data = data.filter(item => item !== arg1);
    }
    else{
      data.push(arg1);
    }
    return data;
  };
PageModule.prototype.areDifferent = function(oldValue, newValue) {
    if(JSON.stringify(newValue) === JSON.stringify(oldValue))
    return false
    else 
    return true;
  };

  PageModule.prototype.isFormValid = function(detail, event) {
    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      return true;
    }
    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
    let table = event.target;
    let editables = table.querySelectorAll('.editable');
    for (let i = 0; i < editables.length; i++) {
      let editable = editables.item(i);
      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        return false;
      }
    }
    return true;
  };



PageModule.prototype.proposedADP = function (emp, capb, skillg, proposalBO,pipBO,loca) {
    let data = [];
    let data1 = [];
    
    // Preprocessing for faster lookup
    const empMap = new Map(emp.map(e => [e.id, e]));
    const skillgMap = new Map(skillg.map(s => [s.id, s.skillGroupName]));
    const capbMap = new Map(capb.map(c => [c.id, c.name]));
    

    for (let i = 0; i < proposalBO.length; i++) {
      let pip=pipBO.find(ele=>ele.empID==proposalBO[i].employeeID);
     
      
        const proposal = proposalBO[i];
        const a = empMap.get(proposal.employeeID);
   let loc=loca.find(ele=> ele.id==a.location);
        if (!a) continue; // Skip if employee not found

        const skillgrp1 = skillgMap.get(a.skillGroup1) || '';
        const skillgrp2 = skillgMap.get(a.skillGroup2) || '';
        const skillgrp3 = skillgMap.get(a.skillGroup3) || '';
         const capabSkillg = skillgMap.get(a.CapabilitySkillGroup) || '';
          const compte = capbMap.get(a.suggestedCapabillity) || '';
        const capaba = capbMap.get(a.globalPractice) || '';

       const ageing11=calculateAgeInPastDays(proposal.proposalDate);
       const ageing1122=calculateAgeInPastDays8989(proposal.proposalDate,proposal.proposalEndDate);
        const retpayload = {
            employeeID: a.employeeID,
             location: loc.location,
             BoID: a.id,
            name: a.name,
            resignedstatus: a.status,
            capability: capaba,
            skillGroup1: skillgrp1,
            skillGroup2: skillgrp2,
            skillGroup3: skillgrp3,
            capabilityskillgroup: capabSkillg,
            competency: capaba,
            allocationEndDate: proposal.allocationEndDate,
            allocationStartDate: proposal.allocationStartDate,
            tEApproverEmail: proposal.tEApproverEmail,
            percentageAllocation: proposal.percentageAllocation,
            lockEndDate: proposal.lockEndDate,
            loctType: proposal.loctType,
            nBDCode: proposal.nBDCode,
            proposalDate: proposal.proposalDate,
             proposalEndDate: proposal.proposalEndDate,
            rejectionNote: proposal.rejectionNote,
            rejectionReason: proposal.rejectionReason,
            status: proposal.status,
            teamRquestNumber: proposal.teamRquestNumber,
            id: proposal.id,
            grade: a.localGrade,
            projectCode: proposal.projectCode,
            remarks: proposal.remarks,
             availability: proposal.availability,
             selfNominated: proposal.selfNominated,
             ageing:ageing11,
             ageingPast:ageing1122,
             color:ageing11 > 7,
             pip:pip!=undefined

        };
        if (proposal.status === "Proposed" || proposal.status === "Blocked/Client interview" || proposal.status === "Allocated" || proposal.status === "Self Nominated") {
            data.push(retpayload);
        } else {
            data1.push(retpayload);
        }
    }
    function calculateAgeInPastDays(birthdate) {
        var today = new Date();
        var birthDate = new Date(birthdate);
        var timeDiff = today.getTime() - birthDate.getTime();
        var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
        return daysDiff;
        }


        function calculateAgeInPastDays8989(birthdate,date) {
          if(date!=undefined){
        var today = new Date(date);
        var birthDate = new Date(birthdate);
        var timeDiff = today.getTime() - birthDate.getTime();
        var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
          
        return daysDiff;
          }
          else {
            return "" ;
          }
        }
    
    console.log('data', {data,data1});
    return { data, data1 };
};




// PageModule.prototype.proposedADPold = function (emp,array,capb,skillg,proposalBO) {
//     let data=[];
//     let data1=[];
//     for(let i=0; i<proposalBO.length; i++){
//       let a=emp.find(ele=> ele.id==proposalBO[i].employeeID);
//       let skillgrp1 = skillg.find (ele=> ele.id==a.skillGroup1);
//        let skillgrp2 = skillg.find (ele=> ele.id==a.skillGroup2);
//         let skillgrp3 = skillg.find (ele=> ele.id==a.skillGroup3);
//          let capaba = capb.find (ele=> ele.id==a.globalPractice);
//          if(proposalBO[i].status=="Proposed" || proposalBO[i].status=="Blocked/Client interview" || proposalBO[i].status=="NBD Block Expired"){
//             let retpayload={};
//       retpayload['employeeID']=a.employeeID;
//       retpayload['name']=a.name;
//       // retpayload['sector']=a.sectorObject.items[0].name;
//       retpayload['capability']=capaba.name;
//       retpayload['skillGroup1']=skillgrp1==undefined ? '':skillgrp1.skillGroupName;
//       retpayload['skillGroup2']=skillgrp2==undefined? '':skillgrp2.skillGroupName ;
//       retpayload['skillGroup3']=skillgrp3==undefined?'':skillgrp3.skillGroupName;
//         // retpayload['allocationenddate']=a.empProjectAllocationBOC.items[0].allocationEndDate;  
//         retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
//          retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
//           retpayload['lockEndDate']=proposalBO[i].lockEndDate;
//            retpayload['loctType']=proposalBO[i].loctType;
//             retpayload['nBDCode']=proposalBO[i].nBDCode;
//              retpayload['proposalDate']=proposalBO[i].proposalDate;
//               retpayload['rejectionNote']=proposalBO[i].rejectionNote;
//                retpayload['rejectionReason']=proposalBO[i].rejectionReason;
//                retpayload['status']=proposalBO[i].status;
//                retpayload['teamRquestNumber']=proposalBO[i].teamRquestNumber;
//                retpayload['proposalDate']=proposalBO[i].proposalDate;
//                retpayload['id']=proposalBO[i].id;
//                retpayload['grade']=a.localGrade;
//                 retpayload['projectCode']=proposalBO[i].projectCode;
//                  retpayload['remarks']=proposalBO[i].remarks;
//       data.push(retpayload);
//          }
//          else{
//             let retpayload={};
//       retpayload['employeeID']=a.employeeID;
//       retpayload['name']=a.name;
//       // retpayload['sector']=a.sectorObject.items[0].name;
//       retpayload['capability']=capaba.name;
//       retpayload['skillGroup1']=skillgrp1==undefined ? '':skillgrp1.skillGroupName;
//       retpayload['skillGroup2']=skillgrp2==undefined? '':skillgrp2.skillGroupName ;
//       retpayload['skillGroup3']=skillgrp3==undefined?'':skillgrp3.skillGroupName;
//         // retpayload['allocationenddate']=a.empProjectAllocationBOC.items[0].allocationEndDate;  
//         retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
//          retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
//           retpayload['lockEndDate']=proposalBO[i].lockEndDate;
//            retpayload['loctType']=proposalBO[i].loctType;
//             retpayload['nBDCode']=proposalBO[i].nBDCode;
//              retpayload['proposalDate']=proposalBO[i].proposalDate;
//               retpayload['rejectionNote']=proposalBO[i].rejectionNote;
//                retpayload['rejectionReason']=proposalBO[i].rejectionReason;
//                retpayload['status']=proposalBO[i].status;
//                retpayload['teamRquestNumber']=proposalBO[i].teamRquestNumber;
//                retpayload['proposalDate']=proposalBO[i].proposalDate;
//                retpayload['id']=proposalBO[i].id;
//                retpayload['grade']=a.localGrade;
//                  retpayload['projectCode']=proposalBO[i].projectCode;
//                  retpayload['remarks']=proposalBO[i].remarks;
              
//       data1.push(retpayload);
//          }
     
//     }
//     console.log('data',data);
//     return {data,data1};
//   };
PageModule.prototype.statusOptions = function (lockType) {
  let data1=[];
    let data={};

    if(lockType=="FIRM"){
      data['option']="Allocated";
      data1.push(data);
    }
    else if(lockType=="NBD"){
      let array=["Blocked/Client interview","NBD Block Expired","Rejected"];
      for(let i=0; i<array.length; i++){
         data['option']=array[i];
         data1.push(data);
      }
    }
    else if(lockType=="MP"){
      let array=["Proposed","Rejected","Allocated to alternate demand"];
      for(let i=0; i<array.length; i++){
         data['option']=array[i];
         data1.push(data);
      }
    }
    return data1;
}

function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
        }

  function dateFormat (bo_date){
    const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var date = new Date(bo_date);
    var reqd_date = (date.getDate()<10?'0'+date.getDate():''+date.getDate())+'-'+months[date.getMonth()]+'-'+date.getFullYear();
    return reqd_date;
  }


PageModule.prototype.dialogTitleforRadioset= function (data) {

    let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.id+' : '+data.name+' ('+data.grade+') '+'['+data.capab+']';
    return  name;
  };

PageModule.prototype.Dateset= function() {
      var rollOfDate = new Date();
      var currentDate = new Date();
      //setting the rollof date to 30 days from current date
      rollOfDate.setDate(currentDate.getDate()+30);
      return rollOfDate;
    };  

  PageModule.prototype.getCurrentYear = function () {
    let date = new Date().toISOString().split('T')[0];
    let currentYr = new Date(date).getFullYear();
    console.log('@@currYr',currentYr);
    return currentYr;
 
  };

 PageModule.prototype.createEmployeeSkillArray1=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     let empSkillArray=new Array(); 

    for(let index=0;index<empSkillBO.length;index++){

     let skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
     if(skillObject){
      let skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      if(skillGroupObject){
      let capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      let empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}'
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
     }

     }



    }
    
return empSkillArray;

  };


 PageModule.prototype.q = function (current) {
     let query="status='ADMIN APPROVED' AND (coAuthor ='"+current+"' OR author ='"+current+"' OR coAuthor2 ='"+current+"'OR coAuthor3 ='"+current+"')";
    return query;
  };


PageModule.prototype.assignCommunitywithSkillGroup = function (P_Emp) {
     var retpayload = {};

    if(P_Emp.globalPractice != null){
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  };


 PageModule.prototype.getDefaultedMonth=function(tcBO){

  let data = [];
  let currentYear = (new Date()).getFullYear();
  let def = tcBO.filter(ele => ele.defaultedYear == currentYear);
  let retpayload = {};
  retpayload['month'] = "Year : " + currentYear;
  let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  for (let i = 0; i < months.length; i++) {
    let month = months[i].toLowerCase().substring(0, 3);
    if (i < (new Date()).getMonth()+1) {
      retpayload[month] = def.find(ele => ele.defaultedMonth == months[i]) == undefined ? 'N' : def.find(ele => ele.initialFlag == 'Issue') ? 'N' : 'Y';
    } else {
      retpayload[month] = '-';
    }
  }
  data.push(retpayload);
  return data;
};
  
 PageModule.prototype.totalCrediHrsFunction = function (T_main) {
    let totalcredithrs = 0;
    let totalcreditHrs;
    let credithrs;
    if(T_main.length == 0){
      totalcreditHrs = '0 hrs';
    }
    else{
      for (let i = 0;i<T_main.length;i++){
        credithrs=T_main[i].creditHrs;
       totalcredithrs += Number(credithrs);

      }
      totalcreditHrs = totalcredithrs.toFixed(2) + ' hrs';
    }
        
   return totalcreditHrs;
  };



   PageModule.prototype.postAllData = function (E_cyl,E_mas,E_main) {

 let data = [];
     for(let i=0; i<E_main.length;i++){

       let retpayload = {};

       let ele=E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO);

       retpayload ['awardName']= E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO).awardName;

        retpayload ['yearMonth']= E_main[i].yearMonth;

        retpayload['rRType']=E_mas.find(recele =>recele.id == ele.recognisationMasterBO).rRType;

        data.push(retpayload);

     }

     console.log(">>",data);

    return data;

  };

   PageModule.prototype.getEmpProjAllocationData = function (P_EmpProjAllocBO,P_ClientBO,P_ProjectBO) {
    console.log('##1717',P_EmpProjAllocBO);
    let data = [];
       
    for(let i=0; i<P_EmpProjAllocBO.length; i++){
      let retpayload = {};
      let cliele = P_ClientBO.find(cliele => cliele.id == P_EmpProjAllocBO[i].client);
      let projele = P_ProjectBO.find(projele => projele.id == P_EmpProjAllocBO[i].project);
      
    if(P_EmpProjAllocBO[i].allocationEndDate == "2000-01-01" ){
      console.log('##12true');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = '';
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    else{
      console.log('##11false');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = P_EmpProjAllocBO[i].allocationEndDate;
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    console.log('##24',retpayload);    
    }
    return(data);
  };


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.batchProposal = function (dataBO,BOName,operation) {
      var batchProcessingVariableArray = new Array();
      for (var i = 0; i < dataBO.length; i++) {
      
      var data = '{"id": "part' + i + '","path": "/' + BOName + '/'+dataBO[i].id +'","operation": "' + operation + '","payload":{"status":"'+dataBO[i].status+'","loctType":"'+dataBO[i].loctType+'","proposalDate":"'+dataBO[i].proposalDate+'","lockEndDate":"'+dataBO[i].lockEndDate+'","allocationStartDate":"'+dataBO[i].allocationStartDate+'","allocationEndDate":"'+dataBO[i].allocationEndDate+'","nBDCode":"'+dataBO[i].nBDCode+'","rejectionReason":"'+dataBO[i].rejectionReason+'","rejectionNote":"'+dataBO[i].rejectionNote+'"}}';
        
      batchProcessingVariableArray.push(data);


    }
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.todayyy = function () {
    // Create a new Date object
var currentDate = new Date();
 
// Get the current date components
var year = currentDate.getFullYear();
var month = currentDate.getMonth() + 1; // Months are zero-based, so add 1
var day = currentDate.getDate();
 
// Format the date as a string (you can customize the format as needed)
var formattedDate = year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
 
console.log("Current Date: " + formattedDate);
return formattedDate;
  };


  PageModule.prototype.VisaExpiryDateConvert=function(VisaDate) {
    if(VisaDate != null && VisaDate!= undefined && VisaDate != ''){
    let orgDate = VisaDate;
    let [day,mon,year]=orgDate.split('-');
    let updatedDate;
    if(mon == undefined){
      return day;
    }
    else{
    day = day<10?'0'+day:''+day;
    year='20'+year;
    updatedDate = day+'-'+mon+'-'+year;
    return updatedDate;
    }
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.dialogTitleForProposedAdp = function (data) {

     let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.employeeID+' : '+data.name+' ('+data.grade+') '+'['+data.capability+']';
    return  name;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uodateRecords = function (proposalBOdata,BOName,operation,today,demandID,employee,currentStatus,currentTeamRequestNumber) {
    let data=[];
    let a='Alternate employee has allocated to Demand ID: '+currentTeamRequestNumber;
    let b='Allocated to alternate Demand ID: '+currentTeamRequestNumber;
    let proposalBO=proposalBOdata.filter(ele=> ele.teamRquestNumber==demandID);
    if(currentStatus=='Allocated'){
    for(let i=0; i<proposalBO.length; i++){
      if(proposalBO[i].status=='Proposed' || proposalBO[i].status=='Blocked/Client interview' || proposalBO[i].status=='Self Nominated'){
        let retpayload={};
    retpayload['id']=proposalBO[i].id;
    if(proposalBO[i].status=='Proposed'){
     retpayload['status']='Proposal Expired';
    }
    else if(proposalBO[i].status=='Blocked/Client interview'){
     retpayload['status']='NBD Block Expired';
    }
    // else if(proposalBO[i].status=='Self Nominated'){
    //  retpayload['status']='Self Nomination Expired';
    // }
    data.push(retpayload);
      }
    }}
    let employeeData=proposalBOdata.filter(ele=> ele.employeeID==employee);
    let indexToRemove=employeeData.findIndex(ele=> ele.teamRquestNumber==demandID);
    if (indexToRemove !== -1) {
      employeeData.splice(indexToRemove, 1);
     }
    var batchProcessingVariableArray = new Array();

    for (var i = 0; i < data.length; i++) {
      
      var data1 = '{"id": "part' + i + '","path": "/' + BOName + '/'+data[i].id +'","operation": "' + operation + '","payload":{"status":"'+data[i].status+'","proposalEndDate":"'+today+'", "remarks":"'+a+'"}}';
        
      batchProcessingVariableArray.push(data1);
    }

    
    for (var j = 0; j < employeeData.length; j++) {
      // var data2;
      if(currentStatus=='Blocked/Client interview'){
      var data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"availability":"No"}}';
      batchProcessingVariableArray.push(data2);
      }
      else if(currentStatus=='Allocated'){
        if(employeeData[j].status=='Proposed'){
         var data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"Proposal Expired","proposalEndDate":"'+today+'", "remarks":"'+b+'"}}';
         batchProcessingVariableArray.push(data2);
        }
        else if(employeeData[j].status=='Blocked/Client interview'){
          var data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"NBD Block Expired","proposalEndDate":"'+today+'", "remarks":"'+b+'"}}';
         batchProcessingVariableArray.push(data2);
        }
        // else if(employeeData[j].status=='Self Nominated'){
        //   let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"Self Nomination Expired"}}';
        //   batchProcessingVariableArray.push(data2);
        // }
      }
       else{
      var data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"availability":"Yes"}}';
      batchProcessingVariableArray.push(data2);
      }
      
    }
    if(batchProcessingVariableArray.length!==0){
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }
    else{
      return 0;
    }
  };

    PageModule.prototype.updateRecordsSubmit = function (proposalBOdata,BOName,operation,today,demandID,employee,currentStatus,currentTeamRequestNumber) {
    let data=[];
    let a='Alternate employee has allocated to Demand ID: '+currentTeamRequestNumber;
    let b='Allocated to alternate Demand ID: '+currentTeamRequestNumber;
    let proposalBO=proposalBOdata.filter(ele=> ele.teamRquestNumber==demandID);
    if(currentStatus=='Allocated'){
    for(let i=0; i<proposalBO.length; i++){
      if(proposalBO[i].status=='Proposed' || proposalBO[i].status=='Blocked/Client interview'){
        let retpayload={};
    retpayload['id']=proposalBO[i].id;
    if(proposalBO[i].status=='Proposed'){
     retpayload['status']='Proposal Expired';
    }
    else if(proposalBO[i].status=='Blocked/Client interview'){
     retpayload['status']='NBD Block Expired';
    }
    // else if(proposalBO[i].status=='Self Nominated'){
    //  retpayload['status']='Self Nomination Expired';
    // }
    data.push(retpayload);
      }
    }}
    let employeeData=proposalBOdata.filter(ele=> ele.employeeID==employee);
    let indexToRemove=employeeData.findIndex(ele=> ele.teamRquestNumber==demandID);
    if (indexToRemove !== -1) {
      employeeData.splice(indexToRemove, 1);
     }
    var batchProcessingVariableArray = new Array();

    for (var i = 0; i < data.length; i++) {
      
      var data1 = '{"id": "part' + i + '","path": "/' + BOName + '/'+data[i].id +'","operation": "' + operation + '","payload":{"status":"'+data[i].status+'","proposalEndDate":"'+today+'", "remarks":"'+a+'"}}';
        
      batchProcessingVariableArray.push(data1);
    }
    for (var j = 0; j < employeeData.length; j++) {
      // var data2;
      if(currentStatus=='Blocked/Client interview'){
      let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"availability":"No"}}';
      batchProcessingVariableArray.push(data2);
      }
      else if(currentStatus=='Allocated'){
        if(employeeData[j].status=='Proposed'){
         let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"Proposal Expired","proposalEndDate":"'+today+'", "remarks":"'+b+'"}}';
         batchProcessingVariableArray.push(data2);
        }
        else if(employeeData[j].status=='Blocked/Client interview'){
          let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"NBD Block Expired","proposalEndDate":"'+today+'", "remarks":"'+b+'"}}';
          batchProcessingVariableArray.push(data2);
        }
        // else if(employeeData[j].status=='Self Nominated'){
        //   let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"status":"Self Nomination Expired"}}';
        //   batchProcessingVariableArray.push(data2);
        // }
      }
      else{
      let data2 = '{"id": "part' + j + '","path": "/' + BOName + '/'+employeeData[j].id +'","operation": "' + operation + '","payload":{"availability":"Yes"}}';
      batchProcessingVariableArray.push(data2);
      }
    }
    if(batchProcessingVariableArray.length!==0){
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }
    else{
      return 0;
    }
  };
  
  PageModule.prototype.createHistory = function (proposalBOdata,BOName,operation,today,demandID,employee,currentStatus,createEmployee,currentTeamRequestNumber) {
    let data=[];
    let a='Alternate employee has allocated to Demand ID: '+currentTeamRequestNumber;
    let b='Allocated to alternate Demand ID: '+currentTeamRequestNumber;
    let proposalBO=proposalBOdata.filter(ele=> ele.teamRquestNumber==demandID);
    if(currentStatus=='Allocated'){
    for(let i=0; i<proposalBO.length; i++){
      if(proposalBO[i].status=='Proposed' || proposalBO[i].status=='Blocked/Client interview' || proposalBO[i].status=='Self Nominated'){
        let retpayload={};
    retpayload['id']=proposalBO[i].id;
    retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
    retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
     retpayload['percentageAllocation']=proposalBO[i].percentageAllocation;
      retpayload['tEApproverEmail']=proposalBO[i].tEApproverEmail;
    retpayload['lockEndDate']=proposalBO[i].lockEndDate;
    retpayload['loctType']=proposalBO[i].loctType;
    retpayload['nBDCode']=proposalBO[i].nBDCode;
    retpayload['projectCode']=proposalBO[i].projectCode;
    retpayload['proposalDate']=proposalBO[i].proposalDate;
    retpayload['proposalEndDate']=proposalBO[i].proposalEndDate;
    retpayload['rejectionNote']=proposalBO[i].rejectionNote;
    retpayload['rejectionReason']=proposalBO[i].rejectionReason;
    retpayload['remarks']=proposalBO[i].remarks;
    retpayload['teamRquestNumber']=proposalBO[i].teamRquestNumber;
    retpayload['employeeID']=proposalBO[i].employeeID;
    retpayload['updatedBY'] = createEmployee.updatedBY;
    retpayload['remarks'] = a;
    if(proposalBO[i].status=='Proposed'){
     retpayload['status']='Proposal Expired';
    }
    else if(proposalBO[i].status=='Blocked/Client interview'){
     retpayload['status']='NBD Block Expired';
    }
    // else if(proposalBO[i].status=='Self Nominated'){
    //  retpayload['status']='Self Nomination Expired';
    // }
    data.push(retpayload);
      }
    }}
    let employeeData=proposalBOdata.filter(ele=> ele.employeeID==employee);
    let indexToRemove=employeeData.findIndex(ele=> ele.teamRquestNumber==demandID);
    if (indexToRemove !== -1) {
      employeeData.splice(indexToRemove, 1);
     }
    
    if(currentStatus=='Allocated'){
    for (let i = 0; i < employeeData.length; i++) {
    if (employeeData[i].status == 'Proposed' || employeeData[i].status == 'Blocked/Client interview' || employeeData[i].status == 'Self Nominated') {
        let retpayload = {};
        retpayload['id'] = employeeData[i].id;
        retpayload['allocationStartDate'] = employeeData[i].allocationStartDate;
        retpayload['allocationEndDate'] = employeeData[i].allocationEndDate;
          retpayload['percentageAllocation']=proposalBO[i].percentageAllocation;
      retpayload['tEApproverEmail']=proposalBO[i].tEApproverEmail;
        retpayload['lockEndDate'] = employeeData[i].lockEndDate;
        retpayload['loctType'] = employeeData[i].loctType;
        retpayload['nBDCode'] = employeeData[i].nBDCode;
        retpayload['projectCode'] = employeeData[i].projectCode;
        retpayload['proposalDate'] = employeeData[i].proposalDate;
        retpayload['proposalEndDate'] = employeeData[i].proposalEndDate;
        retpayload['rejectionNote'] = employeeData[i].rejectionNote;
        retpayload['rejectionReason'] = employeeData[i].rejectionReason;
        retpayload['remarks'] = employeeData[i].remarks;
        retpayload['teamRquestNumber'] = employeeData[i].teamRquestNumber;
        retpayload['employeeID'] = employeeData[i].employeeID;
        retpayload['updatedBY'] = createEmployee.updatedBY;
        retpayload['remarks'] = b;
        retpayload['availability'] = currentStatus=='Blocked/Client interview'?'NO':'Yes';
        retpayload['status'] = employeeData[i].status=='Proposed'?'Proposal Expired':employeeData[i].status=='Blocked/Client interview'?'NBD Block Expired':employeeData[i].status;
        // retpayload['status'] = employeeData[i].status=='Blocked/Client interview'?'NBD Block Expired':employeeData[i].status;
        data.push(retpayload);
    }
}
    }
    var batchProcessingVariableArray = new Array();

    for (var i = 0; i < data.length; i++) {
      
      var data1 = '{"id": "part' + i + '","path": "/' + BOName + '/","operation": "' + operation + '","payload":'+JSON.stringify(data[i])+'}';
        
      batchProcessingVariableArray.push(data1);
    }
    if(batchProcessingVariableArray.length!==0){
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }
    else{
      return 0;
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.demandProposalStatus = function (BO,demandID) {
    let data={};
    let proposalBO=BO.filter(ele=>ele.teamRquestNumber==demandID);
    if(proposalBO.some(record => record.status === 'Allocated')){
     data['proposalStatus']='Internal Identified';
    }
    else if(proposalBO.some(record => record.status === 'Blocked/Client interview')){
     data['proposalStatus']='Blocked/Client interview';
    }
    else if(proposalBO.some(record => record.status === 'Proposed')){
        data['proposalStatus']='Proposed';
    }
    else{
      data['proposalStatus']='Open';
    }
    return data;
  };

  PageModule.prototype.employeeProposalStatus = function (BO,demandID,currentEmployee) {
    let data={};
    let employeedata=[];
    // let proposalBO=BO.filter(ele=>ele.teamRquestNumber==demandID);
    let employee=BO.filter(ele=> ele.employeeID==currentEmployee);
    
    for(let i=0; i<employee.length; i++){
      let retpayload={};
      retpayload['availability']='Yes';
      retpayload['id']=employee[i].id;
      employeedata.push(retpayload);
    }
    return employeedata;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.allocationDate = function (availableDateStr) {
    var availableDate = new Date(availableDateStr);

// Add one day to the available date
availableDate.setDate(availableDate.getDate() + 1);

// Convert the new date back to a string if needed
var oneDayAfterAvailableDateStr = availableDate.toISOString().substring(0, 10);

// Now you have the one day after the available date in the variable oneDayAfterAvailableDateStr
console.log("One day after available date:", oneDayAfterAvailableDateStr);
return oneDayAfterAvailableDateStr;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.taggingADPfunction = function (demandBO,proposalBO) {
    let data =[];
    
 for (let i = 0; i < demandBO.length; i++) {
  let employeeP=proposalBO.find(ele=> ele.teamRquestNumber==demandBO[i].id && ele.status=="Allocated");

        let retpayload = {};
        retpayload['teamRequestNumber'] = demandBO[i].teamRequestNumber;
          retpayload['roleStartDate'] = demandBO[i].roleStartDate;
        retpayload['proposalStatus'] = demandBO[i].proposalStatus;
        retpayload['demandType'] = demandBO[i].demandType;
        retpayload['globalPractice'] = demandBO[i].globalPracticeObject.items[0].name;
        retpayload['skillGroup'] = demandBO[i].skillGroupObject.items[0].skillGroupName;
        retpayload['sector'] = demandBO[i].sectorObject.items[0].name;
        retpayload['client'] = demandBO[i].clientObject.items[0].clientName;
        retpayload['projectName'] = demandBO[i].projectName;
        retpayload['status'] = demandBO[i].status;
        retpayload['selfNominated'] = demandBO[i].selfNominated;
        retpayload['id'] = demandBO[i].id;    
         retpayload['empid'] = employeeP.employeeIDObject.items[0].employeeID;
          retpayload['empName'] = employeeP.employeeIDObject.items[0].name;
         
           let startDate= employeeP.lastUpdateDate; 
            let formattedStartDate = formatDate(startDate);

             retpayload['allocationStartDate'] = formattedStartDate;
       
        data.push(retpayload);
    
 }
 return data;
};

function formatDate(dateString) {
    let date = new Date(dateString);
    let year = date.getFullYear();
    let month = (date.getMonth() + 1).toString().padStart(2, '0'); // January is 0!
    let day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

PageModule.prototype.taggingUpdate = function (data,BOName,operation) {
var batchProcessingVariableArray = new Array();

    for (var i = 0; i < data.length; i++) {
      
      var data1 = '{"id": "part' + i + '","path": "/' + BOName + '/'+data[i] +'","operation": "' + operation + '","payload":{"proposalStatus":"Tagged"}}';
        
      batchProcessingVariableArray.push(data1);
    }
    if(batchProcessingVariableArray.length!==0){
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }
    else{
      return 0;
    }
};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.buildqueruforDemandTagging = function (activeFlag, globalPractice, skillGroupName,teamRequestNumber) {

    let query = "activeFlag='" + activeFlag + "' AND proposalStatus ='Internal Identified'";
   
    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPracticeObject.name LIKE '%" + globalPractice + "%'";
    }

    if (skillGroupName !== undefined && skillGroupName !== null && skillGroupName !== '') {
        query += " and skillGroupObject.skillGroupName LIKE '%" + skillGroupName + "%'";
    }

    if (teamRequestNumber !== undefined && teamRequestNumber !== null && teamRequestNumber !== '') {
        query += " and teamRequestNumber = '" + teamRequestNumber + "'";
    }
  
    return query;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.downloadTag = function (adp,keys) {
    let data=[];
    for (let i=0; i<keys.length; i++){
      let a=adp.find(ele=>ele.id==keys[i]);
      data.push(a);
    }
    console.log('data',data);
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.MainBody = function (arg1,demandID,employeeID,capb,skillGroup) {
  let Body;
  Body="";

  let rejectionmsg="";
  let subject;
  if(arg1.status=='Rejected'){

 if(arg1.rejectionReason=='Client Interview Rejected - Skill Fitment'){
    rejectionmsg="Rejection reason – We received a feedback from the client that your profile was rejected in the client interview as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Client Interview Rejected - Role Fitment'){
    rejectionmsg="Rejection reason – We received a feedback from the client that your profile was rejected in the client interview as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Interview Rejected - Skill Fitment'){
    rejectionmsg="Rejection reason – We received a feedback from the project that your profile was rejected in the interview as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Interview Rejected - Role Fitment'){
    rejectionmsg="Rejection reason – We received a feedback from the project that your profile was rejected in the interview as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Screening Rejected - Skill Fitment'){
    rejectionmsg="Rejection reason – We received a feedback from the project that your profile was rejected in the screening as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Screening Rejected - Role Fitment'){
    rejectionmsg="Rejection reason –We received a feedback from the project that your profile was rejected in the screening as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Demand Cancelled'){
    rejectionmsg="Rejection reason – The demand has been cancelled and no longer accepting profile applications for this role ";
   }
    else if(arg1.rejectionReason=='Demand Moved out'){
    rejectionmsg="Rejection reason –The demand has been retagged to other business line and no longer accepting Oracle profile applications for this role";
   }
    else if(arg1.rejectionReason=='Alternate candidate already selected'){
    rejectionmsg="Rejection reason – Another candidate has already been selected for the position and role is closed.";
   }
    else if(arg1.rejectionReason=='Other'){
    rejectionmsg="Rejection reason –Please connect with the PSC team to inquire about the reason for rejection.";
   }

    subject="Notification: Not selected for demand (Demand ID - "+demandID.teamRequestNumber+", Employee ID - "+employeeID+")";
    Body+="Thank you for your interest in Demand ID - "+demandID.teamRequestNumber+" ("+capb+", "+skillGroup+") and for submitting your self-nomination in MY View.<br>After careful consideration by PSC team, we regret to inform you that your nomination has not been shortlisted this time.<br><br>"+rejectionmsg+"<br><br>We encourage you to continue exploring opportunities in ‘Open Demands for Self-Nominations’ in MyView, as new positions are continuously becoming available that can match your skills and experience.";
  }
  //  if(arg1.status=='Allocated'){
  //   subject="Status of your Self-Nomination on My View";
  //   Body+="We hope this email finds you well.<br><br>We are pleased to inform you that your nomination for ‘"+demandID.projectName+"’ in MY View has been reviewed by our PSC team, and we are delighted to confirm your profile for the same.<br><br><b>Next Step-</b> Your PDL/DM/PSC spoc will connect with you to initiate the tagging process.";
  // }
  //  if(arg1.status=='Blocked/Client interview'){
  //   Body+="<br><br><b>Lock End Date:</b> "+arg1.lockEndDate+"<br><br><b>NBD Code:</b> "+arg1.nBDCode;
  // }
  // if(arg1.status=='Proposal Expired' || arg1.status=='NBD Block Expired'){
  //   Body+="<br><br><b>Rejected reason:</b> "+arg1.rejectionReason;
  // }
  Body+="<br><br>Regards,<br>Oracle PSC Team";
  return {Body,subject};
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.expirationMail = function (proposalBOdata,demandID) {
    let employeeData=proposalBOdata.filter(ele=> ele.teamRquestNumber==demandID && ele.selfNominated=='Yes');

     let data=[];
     for(let i=0; i<employeeData.length; i++){
      if(employeeData[i].status=='Proposal Expired' || employeeData[i].status=='NBD Block Expired'){
     let email={};
     email['email']='ankush.rangrao-gurav@capgemini.com,pranav.shridhar-dhavale@capgemini.com';
     email['Subject']='Ragarding Self Nomination.';
     email['name']=employeeData[i].employeeIDObject.items[0].name;
     email['MailBody']="Your Self Nomination has been expired.<br><br>Please refer below details,<br><br><b>Demand ID: </b>"+employeeData[i].teamRquestNumberObject.items[0].teamRequestNumber+"<br><br><b>Status: </b>"+employeeData[i].status+"<br><br><b>Remarks: </b>"+(employeeData[i].remarks !== undefined ? employeeData[i].remarks : "NA")+"<br><br><br><br>Regards,";
     data.push(email);
      }
     }
     console.log('expireMaildata',data);
     return data;
     
  };

// PageModule.prototype.calculateAgeing = function (birthdate) {
//     // var today = new Date();
//     // var birthDate = new Date(birthdate);
//     // var timeDiff = birthDate.getTime() - today.getTime(); // Difference with respect to today
//     // var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24)); // Calculate days difference
//      var today = new Date();
//     var birthDate = new Date(birthdate);
//     var timeDiff = today.getTime() - birthDate.getTime(); // Subtract birthdate from today
//     var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24)); // Calculate days difference

//     return daysDiff;
// };

PageModule.prototype.calculateAgeing = function (birthdate) {
    // Ensure birthdate is a valid Date object or string
    const birthDate = new Date(birthdate);
    const today = new Date();

    // Check if the provided birthdate is valid
    if (isNaN(birthDate.getTime())) {
        throw new Error('Invalid birthdate');
    }

    // Calculate the time difference in milliseconds
    const timeDiff = today.getTime() - birthDate.getTime();
    
    // Calculate the difference in days
    const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));

    return daysDiff;
};



  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  // PageModule.prototype.demandBOData = function (proposalBO,demandBO,sectorBO,capabilityBO,clientBO,skillBO) {
  // let data=[];
  //  let count=0;
  // for(let i=0; i<demandBO.length; i++){
  //   let retpayload={};
  //   let proposal=proposalBO.filter(ele=>ele.teamRquestNumber==demandBO[i].id);
  //   let a=0;
  //   let b=0;
  //   let c=0;
  //    let z=0;

  //   for(let i=0; i<proposal.length; i++){
  //    let d=calculateAgeInPastDays(proposal[i].proposalDate);
  //   if(d >= 0 && d <= 7){
  //      z+=1;
  //    }
  //    else if(d>7 && d<15){
  //     a+=1;
  //    }
  //    else if(d>14 && d<22){
  //     b+=1;
  //    }
  //    else if(d>21){
  //     c+=1;
  //    }
  //   }
  //   let capability=capabilityBO.find(ele=> ele.id==demandBO[i].globalPractice);
  //   let sector=sectorBO.find(ele=> ele.id==demandBO[i].sector);
  //   let skill=skillBO.find(ele=> ele.id==demandBO[i].skillGroup);
  //   let client=clientBO.find(ele=> ele.id==demandBO[i].client);

  //   retpayload['0-7']=z;
  //   retpayload['8-14']=a;
  //   retpayload['15-22']=b;
  //   retpayload['>22']=c;
  //   count+=z+a+b+c;
  //   retpayload['teamRequestNumber']=demandBO[i].teamRequestNumber;
  //   retpayload['proposalStatus']=demandBO[i].proposalStatus;
  //   retpayload['projectName']=demandBO[i].projectName;
  //   retpayload['demandType']=demandBO[i].demandType;
  //   retpayload['globalPractice']=capability!=undefined?capability.name:'';
  //   retpayload['skillGroup']=skill!=undefined?skill.skillGroupName:'';
  //   retpayload['sector']=sector!=undefined?sector.name:'';
  //   retpayload['client']=client!=undefined?client.clientName:'';
  //   retpayload['status']=demandBO[i].status;
  //   retpayload['selfNominated']=demandBO[i].selfNominated;
  //   retpayload['id']=demandBO[i].id;
  //   data.push(retpayload);
  // }
  // function calculateAgeInPastDays(birthdate) {
  //   var today = new Date();
  //   var birthDate = new Date(birthdate);
  //   var timeDiff = today.getTime() - birthDate.getTime();
  //   var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
  //   return daysDiff;
  //  }
   
  //  console.log('age',data);
  //   console.log('activecount',count);
  //  return {
  //   data: data,
  //   activecount: count
  // };
  // };

  PageModule.prototype.demandBOData = function (proposalBO, demandBO, sectorBO, capabilityBO, clientBO, skillBO) {
  let data = [];
  let count = 0;
  let totalCounts = {
    '0-7': 0,
    '8-14': 0,
    '15-22': 0,
    '>22': 0
  };

  for (let i = 0; i < demandBO.length; i++) {
    let retpayload = {};
    let proposals = proposalBO.filter(ele => ele.teamRquestNumber == demandBO[i].id);
    let z = 0;
    let a = 0;
    let b = 0;
    let c = 0;

    for (let j = 0; j < proposals.length; j++) {
      let d = calculateAgeInPastDays(proposals[j].proposalDate);
      if (d >= 0 && d <= 7) {
        z += 1;
      } else if (d > 7 && d < 15) {
        a += 1;
      } else if (d > 14 && d < 22) {
        b += 1;
      } else if (d > 21) {
        c += 1;
      }
    }

    // Update total counts
    totalCounts['0-7'] += z;
    totalCounts['8-14'] += a;
    totalCounts['15-22'] += b;
    totalCounts['>22'] += c;

    let capability = capabilityBO.find(ele => ele.id == demandBO[i].globalPractice);
    let sector = sectorBO.find(ele => ele.id == demandBO[i].sector);
    let skill = skillBO.find(ele => ele.id == demandBO[i].skillGroup);
    let client = clientBO.find(ele => ele.id == demandBO[i].client);

    retpayload['0-7'] = z;
    retpayload['8-14'] = a;
    retpayload['15-22'] = b;
    retpayload['>22'] = c;
    count += z + a + b + c;
    retpayload['teamRequestNumber'] = demandBO[i].teamRequestNumber;
    retpayload['proposalStatus'] = demandBO[i].proposalStatus;
    retpayload['projectName'] = demandBO[i].projectName;
    retpayload['demandType'] = demandBO[i].demandType;
    retpayload['globalPractice'] = capability != undefined ? capability.name : '';
    retpayload['skillGroup'] = skill != undefined ? skill.skillGroupName : '';
    retpayload['sector'] = sector != undefined ? sector.name : '';
    retpayload['client'] = client != undefined ? client.clientName : '';
    retpayload['status'] = demandBO[i].status;
    retpayload['selfNominated'] = demandBO[i].selfNominated;
    retpayload['id'] = demandBO[i].id;
    data.push(retpayload);
  }

  // Add totals at the end of the data array
  let totalPayload = {
    '0-7': totalCounts['0-7'],
    '8-14': totalCounts['8-14'],
    '15-22': totalCounts['15-22'],
    '>22': totalCounts['>22'],
    teamRequestNumber: 'Total',
    proposalStatus: '',
    projectName: '',
    demandType: '',
    globalPractice: '',
    skillGroup: '',
    sector: '',
    client: '',
    status: '',
    selfNominated: '',
    id: ''
  };

  data.push(totalPayload);

  function calculateAgeInPastDays(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
  }

  console.log('age', data);
  console.log('activecount', count);
  return {
    data: data,
    activecount: count
  };
};


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.convertDateFormat = function (inputDate) {

    // Parse the input date string
    const date = new Date(inputDate);

    // Months array for mapping month index to month name abbreviation
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Extract day, month, and year components
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear().toString().substr(-2); // Get last 2 digits of the year

    // Extract hour, minute, and second components
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');
    const second = date.getSeconds().toString().padStart(2, '0');

    // Construct the formatted date string
    const formattedDate = `${day}-${month}-${year} ${hour}:${minute}:${second}`;

    return formattedDate;

};


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.updateProposalStatusIndemandBO = function (proposalBOData,employee,BOName,operation) {
    let data1=[];
    let proposalBO1=proposalBOData.filter(ele=>ele.employeeID==employee);
    for(let i=0; i<proposalBO1.length; i++){
    let demands=proposalBOData.filter(ele=> ele.teamRquestNumber==proposalBO1[i].teamRquestNumber);
    let data={};
    data['id']=proposalBO1[i].teamRquestNumber;
    data['proposalStatus']=status(demands);
    data1.push(data);
    }
    function status(proposalBO){
      let data;
     if(proposalBO.some(record => record.status === 'Allocated')){
     data='Internal Identified';
    }
    else if(proposalBO.some(record => record.status === 'Blocked/Client interview')){
     data='Blocked/Client interview';
    }
    else if(proposalBO.some(record => record.status === 'Proposed')){
        data='Proposed';
    }
    else{
      data='Open';
    }
    return data;
    }

    var batchProcessingVariableArray = new Array();

    for (var i = 0; i < data1.length; i++) {
      
      var payload = '{"id": "part' + i + '","path": "/' + BOName + '/'+data1[i].id +'","operation": "' + operation + '","payload":{"proposalStatus":"'+data1[i].proposalStatus+'"}}';
        
      batchProcessingVariableArray.push(payload);
    }
    if(batchProcessingVariableArray.length!==0){
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }
    else{
    return 0;
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.ageingDetails = function (proposalBO,demandBO,empBO,column) {

let data=[];


  for(let i=0; i<proposalBO.length; i++){

    let ageingg = calculateAgeInPastDayss(proposalBO[i].proposalDate);
    let retpayload={};
    if(column=="seven" && ageingg>7 && ageingg<15 ){
 let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=empdetails.employeeID;
    retpayload['empName']=empdetails.name;
    retpayload['localGrade']=empdetails.localGrade;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNotes']=proposalBO[i].rejectionNotes;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
               data.push(retpayload);
    }

    else if(column=="forteen" && ageingg>14 && ageingg<22){
       let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=empdetails.employeeID;
    retpayload['empName']=empdetails.name;
     retpayload['localGrade']=empdetails.localGrade;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNotes']=proposalBO[i].rejectionNotes;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
               data.push(retpayload);
      
    }
     else if(column=="twentyone" && ageingg>21){

       let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=empdetails.employeeID;
    retpayload['empName']=empdetails.name;
     retpayload['localGrade']=empdetails.localGrade;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNote']=proposalBO[i].rejectionNote;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['selfNominated']=proposalBO[i].selfNominated;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
                data.push(retpayload);
    }
     else if(column=="zerotoseven" && ageingg>= 0 && ageingg<= 7){

       let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=empdetails.employeeID;
    retpayload['empName']=empdetails.name;
     retpayload['localGrade']=empdetails.localGrade;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNote']=proposalBO[i].rejectionNote;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['selfNominated']=proposalBO[i].selfNominated;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
                data.push(retpayload);
    }
    
  }

  function calculateAgeInPastDayss(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
   console.log('age',data);
  return data;

  };

  PageModule.prototype.activeProposalADPfunction = function (proposalBO,demandBO,capabilityBO,sectorBO,skillBO,clientBO,loca,emp) {
    let data =[];
    
 for (let i = 0; i < proposalBO.length; i++) {

        let retpayload = {};

        //  let proposal=proposalBO.find(ele=>ele.teamRquestNumber==demandBO[i].id);
          // let demand=demandBO.find(ele=>ele.id==proposalBO[i].teamRquestNumber);
          let demand = demandBO.find(ele => ele.id == proposalBO[i].teamRquestNumber);
if(demand==undefined){
  continue;
}
    let capability=capabilityBO.find(ele=> ele.id==demand.globalPractice);
    let sector=sectorBO.find(ele=> ele.id==demand.sector);
    let skill=skillBO.find(ele=> ele.id==demand.skillGroup);
    let client=clientBO.find(ele=> ele.id==demand.client);
    let pdl=emp.find(ele=>ele.id==sector.businessUnitLeader);


       retpayload['empid']=proposalBO!=undefined? proposalBO[i].employeeIDObject.items[0].employeeID:'';
       let loc=loca.find(ele=> ele.id==proposalBO[i].employeeIDObject.items[0].location);
        retpayload['location']=loc!=undefined? loc.location:'';
          retpayload['empgrade']=proposalBO!=undefined ? proposalBO[i].employeeIDObject.items[0].localGrade:'';
    retpayload['empName']=proposalBO!=undefined? proposalBO[i].employeeIDObject.items[0].name:'';
    retpayload['teamRequestNumber']=demand!=undefined? demand.teamRequestNumber:'';
    retpayload['projectName']=demand!=undefined? demand.projectName:'';
    retpayload['demandType']=demand!=undefined? demand.demandType:'';
     retpayload['grade']=demand!=undefined? demand.localGrade:'';
       retpayload['demandCreationDate']=demand!=undefined? demand.demandCreationDate:'';
         retpayload['roleStartDate']=demand!=undefined? demand.roleStartDate:'';
           retpayload['status']=demand!=undefined? demand.status:'';
          retpayload['clientInterview']=demand!=undefined? demand.clientInterview:'';
          retpayload['cloud']=demand!=undefined? demand.cloud:'';
            retpayload['comments']=demand!=undefined? demand.comments:'';
            retpayload['proposalStatus']=demand!=undefined? demand.proposalStatus:'';
    retpayload['globalPractice']=capability!=undefined?capability.name:'';
    retpayload['skillGroup']=skill!=undefined?skill.skillGroupName:'';
    retpayload['sector']=sector!=undefined?sector.name:'';
    retpayload['client']=client!=undefined?client.clientName:'';
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
          retpayload['tEApproverEmail']=proposalBO[i].tEApproverEmail;
            retpayload['percentageAllocation']=proposalBO[i].percentageAllocation;           
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNote']=proposalBO[i].rejectionNote;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['selfNominated']=proposalBO[i].selfNominated;
                 retpayload['ageing']=calculateAgeInPastDayss1(proposalBO[i].proposalDate);
                 retpayload['pdlcontact']=pdl!=undefined?pdl.email:'';

        data.push(retpayload);
    
 }
  function calculateAgeInPastDayss1(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
 return data;
};
  


  PageModule.prototype.buildQueryforProposalAgeing = function (activeFlag, format, clientName, sectorName, status, globalPractice, skillGroupName,teamRequestNumber,demandType,proposalStatus,selfNominated) {

   
    let query = "activeFlag='" + activeFlag + "'";

    if (clientName !== undefined && clientName !== null && clientName !== '') {
        query += " and clientObject.clientName = '" + clientName + "'";
    }

    if (sectorName !== undefined && sectorName !== null && sectorName !== '') {
        query += " and sector = '" + sectorName + "'";
    }
    if (status !== undefined && status !== null && status !== '') {
        query += " and status LIKE '%" + status + "%'";
    }
    if (proposalStatus.length!=0) {
       var dateRanges = [];
       var queryString = "";
       for (var i = 0; i < proposalStatus.length; i++) {
      var BU = proposalStatus[i];
      dateRanges.push("(" + "proposalStatus = '" + BU + "' " + ")");
      }
       if (dateRanges.length == 1) {
         queryString = "AND " + dateRanges ;
       }
      else if (dateRanges.length > 1) {
        queryString = "AND (" + dateRanges.join(" OR ") + ")";
      }
      query+=queryString;
    }
    else{
        query +="and proposalStatus <> 'Tagged' and proposalStatus <> 'Open'";
    }
    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPracticeObject.name LIKE '%" + globalPractice + "%'";
    }

    if (skillGroupName !== undefined && skillGroupName !== null && skillGroupName !== '') {
        query += " and skillGroupObject.skillGroupName LIKE '%" + skillGroupName + "%'";
    }

    if (teamRequestNumber !== undefined && teamRequestNumber !== null && teamRequestNumber !== '') {
        query += " and teamRequestNumber = '" + teamRequestNumber + "'";
    }
    if (demandType !== undefined && demandType !== null && demandType !== '') {
     query += " and demandType = '" + demandType + "'";
    }
    if (selfNominated !== "No") {
     query += " and selfNominated = '" + selfNominated + "'";
    }
    return query;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.isDateBeforeToday = function (inputDate) {

     var today = new Date();
    var inputDateObj = new Date(inputDate);
    inputDateObj.setDate(inputDateObj.getDate() + 1);
     if (inputDateObj < today) {
        return true;
    } else {
        return false;
    }
  };

  PageModule.prototype.checkAgeing = function (ageinggg) {
    
     if (ageinggg > 30) {
        return true;
    } else {
        return false;
    }
  };

PageModule.prototype.dateFormat1 = function (dateStr) {
  // const dateStr = '2024-03-24';
const date = new Date(dateStr);
const day = date.getDate();
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
const monthIndex = date.getMonth();
const year = date.getFullYear();
const formattedDate = day + '-' + monthNames[monthIndex] + '-' + year;
console.log(formattedDate);

return formattedDate;
  }

   PageModule.prototype.dueDateFunction = function(month,currentYear) {
   var queryString = "";
 
    if(month!=''  && currentYear!=''){
      var startDate, endDate;
      if (month === 'Jan') {
      startDate = currentYear + '-01-01';
      endDate = currentYear + '-01-31';
    } else if (month === 'Feb') {
      startDate = currentYear + '-02-01';
      endDate = currentYear + '-02-28';
    } else if (month === 'Mar') {
      startDate = currentYear + '-03-01';
      endDate = currentYear + '-03-31';
    } else if (month === 'Apr') {
      startDate = currentYear + '-04-01';
      endDate = currentYear + '-04-30';
    } else if (month === 'May') {
      startDate = currentYear + '-05-01';
      endDate = currentYear + '-05-31';
    } else if (month === 'Jun') {
      startDate = currentYear + '-06-01';
      endDate = currentYear + '-06-30';
    } else if (month === 'Jul') {
      startDate = currentYear + '-07-01';
      endDate = currentYear + '-07-31';
    } else if (month === 'Aug') {
      startDate = currentYear + '-08-01';
      endDate = currentYear + '-08-31';
    } else if (month === 'Sep') {
      startDate = currentYear + '-09-01';
      endDate = currentYear + '-09-30';
    } else if (month === 'Oct') {
      startDate = currentYear + '-10-01';
      endDate = currentYear + '-10-31';
    } else if (month === 'Nov') {
      startDate = currentYear + '-11-01';
      endDate = currentYear + '-11-30';
    } else if (month === 'Dec') {
      startDate = currentYear + '-12-01';
      endDate = currentYear + '-12-31';
    }
    queryString="AND (" + "roleStartDate BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")";
    }
    else if(currentYear!= '' && month ==''){
      queryString="AND roleStartDate LIKE '%"+currentYear+"%'";
    }
    else{
      queryString=null;
    }
  console.log("4545",queryString);
  return queryString;
}
  


  PageModule.prototype.benchSearchADPforButton = function (P_Emp, P_Alloc,P_Skill,proposalBO,currentDemandBOID,pipBO,rollofRadarBO,skillBO,capbBO) {
     var retPayload = [];
//      let empCheck = {
//     employeeID: null,
//     teamRequestNumber: null,
//     status:null
// };
 retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
    retPayload['internalshadow'] = [];
    


       for(var i=0; i<P_Emp.length; i++){
         let capability=capbBO.find(ele=> ele.id==P_Emp[i].globalPractice);
           let capability1=capbBO.find(ele=> ele.id==P_Emp[i].suggestedCapabillity);
    let skill1=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup1);
     let skill2=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup2);
      let skill3=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup3);
      

   let pip=pipBO.find(ele=>ele.empID==P_Emp[i].id);
    let rolloff=rollofRadarBO.find(ele=>ele.employeeID==P_Emp[i].id);
         let proposal=proposalBO.find(ele=>ele.employeeID==P_Emp[i].id && ele.teamRquestNumber==currentDemandBOID);
           let proposal1=proposalBO.filter(ele=>ele.employeeID==P_Emp[i].id);
           let containsStatus = proposal1.some(record => record.status === 'Allocated' || record.status === 'Blocked/Client interview');
           let containsStatus12 = proposal1.some(record => record.status === 'Proposed' );
      let alloc=P_Alloc.filter(ele=> ele.employee==P_Emp[i].id);
      let latestRecord = alloc.sort((a, b) => new Date(b.allocationEndDate) - new Date(a.allocationEndDate))[0];
       let latestRecord1 = alloc.sort((a, b) => new Date(b.allocationStartDate) - new Date(a.allocationStartDate))[0];
      if(proposal1.length!==0){
      if (containsStatus) {
    continue;
       } else if (proposal !== undefined && currentDemandBOID === proposal.teamRquestNumber && proposal.status!=='Rejected' && proposal.status!=='Cancelled') {
           continue;
       }
      }
      if(latestRecord != undefined){
        var availableDate = new Date(latestRecord.allocationEndDate);
         var startDate = new Date(latestRecord1.allocationStartDate);
        availableDate.setDate(availableDate.getDate() + 1); 
        

        var temp = {};
        temp['id'] = P_Emp[i].employeeID;
        temp['name'] = P_Emp[i].name;
        temp['grade'] = P_Emp[i].localGrade;
         temp['billable'] = (containsStatus12 === true) ? (P_Emp[i].billable + " (Proposed)") : P_Emp[i].billable;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = capability==null?'':capability.name;
         temp['competency'] = capability1==null?'':capability1.name;
         temp['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp['skill'] = skill1==null?'':skill1.skillGroupName;
         temp['skill2'] = skill2==null?'':skill2.skillGroupName;
          temp['skill3'] = skill3==null?'':skill3.skillGroupName;
           temp['location'] = P_Emp[i].location==null?'':P_Emp[i].locationObject.items[0].location;
        // temp['type'] = P_Type;
        // temp['status'] = P_Emp[0].status;
         temp['BoID']=P_Emp[i].id;
          temp['status']=P_Emp[i].status;
           temp['pip']=pip!=undefined?true:false;
      
      
        // temp['loc'] = P_Emp[0].locationObject.items[0].location;
        // temp['demandSupplyBOId']=P_demandSupplyId;
        // temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      
        
      
    var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

if(rolloff!=undefined){
   var availableDateRolloff = new Date(rolloff.releaseDate);
              var avail_date11 = availableDateRolloff;
              var today11 = new Date();
              var curr_date11 = today11;
              var difference1= (avail_date11-curr_date11);

              var days1 = Math.round(difference1/(1000 * 3600 * 24));
}
            //     if(days <= 30 && days >=0){
            //     temp['available'] = changeFormat(availableDate);
            //     retPayload['internalb'].push(temp);
            //  }
            

             if(rolloff!=undefined && days1 <= 30 && days1 >=0){
                 temp['available'] = changeFormat(rolloff.releaseDate);
                  temp['category']='Non-Bench';
                 retPayload['internalb'].push(temp);
              }


            else if(temp['status']==="Bench - Deployable" ||  temp['status']==="Bench - Resigned"  ||  temp['status']==="Bench - Blocked"){
              temp['available'] = changeFormat(availableDate);
               temp['category']='Bench';
              retPayload['internalnb'].push(temp);             
            }

             else if(temp['status']==="Shadow "){
              temp['available1'] = changeFormat(startDate);
               temp['category']='Shadow';
              temp['ageing'] = calculateAgeInPastDayss122(temp['available1']);
             if (temp['ageing'] >= 60) {
        retPayload['internalshadow'].push(temp);
    }
              
            }
      }
        
      
       }

retPayload.internalbCount = retPayload['internalb'].length;
retPayload.internalnbCount = retPayload['internalnb'].length;
retPayload.internalshadowCount = retPayload['internalshadow'].length;

retPayload['internalnb'].sort((a, b) => {
    // First, sort by grade
    const gradeComparison = b.grade.localeCompare(a.grade);
    
    // If grades are equal, sort by id
    if (gradeComparison === 0) {
        return a.id - b.id;
    } else {
        return gradeComparison;
    }
});

retPayload['internalb'].sort((a, b) => new Date(a.available) - new Date(b.available));

  function calculateAgeInPastDayss122(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
       
    return retPayload;

   
  };

   PageModule.prototype.future7days = function (inputDate, selectedDate) {
    // Convert both dates to milliseconds
    let indate;
    if(inputDate==null || inputDate==undefined){
     indate= new Date();
    }else{
      indate= new Date(inputDate);
    }
    let selectdate= new Date(selectedDate);
    var inputDateInMs = indate.getTime();
    var selectedDateInMs = selectdate.getTime();

    // Calculate the difference in milliseconds
    var differenceInMs = Math.abs(inputDateInMs - selectedDateInMs);

    // Convert back to days and return true/false
    return differenceInMs / (1000 * 60 * 60 * 24) <= 7;
}

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.DownloadActiveProposals = function (headers,dataBO) {
     var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<headers.length;i++)
  {
      header.push(headers[i].headerText);
  }
  multidata.push(header);

  for (var i=0; i<dataBO.length; i++){
    let data=[];
    data.push(dataBO[i].teamRequestNumber);
    data.push(dataBO[i].proposalStatus);
    data.push(dataBO[i].globalPractice);
    data.push(dataBO[i].skillGroup);
    data.push(dataBO[i].sector);
    data.push(dataBO[i].client);
    data.push(dataBO[i].grade);
    data.push(dataBO[i].projectName);
    data.push(dataBO[i].demandType);
    data.push(dataBO[i].roleStartDate);
    data.push(dataBO[i].demandCreationDate);
    data.push(dataBO[i].comments);
    data.push(dataBO[i].cloud);
    data.push(dataBO[i].clientInterview);
    data.push(dataBO[i].empid);
    data.push(dataBO[i].empName);
     data.push(dataBO[i].empgrade);
    data.push(dataBO[i].location);
    data.push(dataBO[i].loctType);
    data.push(dataBO[i].status);
    data.push(dataBO[i].proposalDate);
    data.push(dataBO[i].ageing);
    data.push(dataBO[i].allocationStartDate);
    data.push(dataBO[i].allocationEndDate);
    data.push(dataBO[i].projectCode);
    data.push(dataBO[i].tEApproverEmail);
    data.push(dataBO[i].percentageAllocation);
    data.push(dataBO[i].lockEndDate);
    data.push(dataBO[i].nBDCode);
    data.push(dataBO[i].rejectionReason);
    data.push(dataBO[i].rejectionNote);
    data.push(dataBO[i].remarks);
    data.push(dataBO[i].selfNominated);
    data.push(dataBO[i].pdlcontact);
    multidata.push(data);
  console.log("multidata",multidata);
  }
  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Active Proposals File");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Active Proposals File"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
  }

  fileBytes=FileToBytes(fileBytes);

 var blob = new Blob([fileBytes],{type:'octet/stream'});
 var filename = "Active Proposals File_"+new Date().toISOString().split('T')[0]+".xlsx";

 
if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
} else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    //console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
 }
  };



 PageModule.prototype.dialogTitleUpdate = function (data) {

    let name;
    let client=(data.clientObject.items[0].clientName).substring(0, 25);
    let demand ;

    if ((data.demandType).endsWith("Project")) {
    
    demand= (data.demandType).slice(0, -"Project".length).trim();
  } else {
   demand=(data.demandType);
  }

    name=data.teamRequestNumber+' : '+data.globalPracticeObject.items[0].name+'-'+data.skillGroupObject.items[0].skillGroupName+' ('+data.localGrade+') '+'['+data.sectorObject.items[0].name+'-'+client+'..., '+demand+']';
    return  name;
  };

























// new code for compliance report



 

  PageModule.prototype.activeProposalsSectorWise=function (demandBo1,ProposalBO) {
      let demandBo=demandBo1.filter(ele=> ele.proposalStatus!=='Tagged' && ele.proposalStatus!=='Open'&& ele.proposalStatus!==null);
      let data=[];
    var arrayobj=Object.values(demandBo);
    const arrayUniqueByKey = [...new Map(demandBo.map(item =>  [item['sector'], item])).values()];
    
    let Total0=0; let Total7=0; let Total14=0; let Total21=0; let GrandTotal=0;
    for(let i=0; i<arrayUniqueByKey.length; i++){
    let sectorData=demandBo.filter(ele=> ele.sector===arrayUniqueByKey[i].sector);
    let a=0;
    let b=0;
    let c=0;
    let z=0;
      for(let x=0; x<sectorData.length; x++){
      let proposal=ProposalBO.filter(ele=>ele.teamRquestNumber===sectorData[x].id);
    for(let y=0; y<proposal.length; y++){
     let d=calculateAgeInPastDays(proposal[y].proposalDate);
    if(d >= 0 && d <= 7){
       z+=1;
     }
     else if(d>7 && d<15){
      a+=1;
     }
     else if(d>14 && d<22){
      b+=1;
     }
     else if(d>21){
      c+=1;
     }
     }
      }

      let retpayload={};
      retpayload['sector']=arrayUniqueByKey[i].sectorObject.items[0].name;
      retpayload['sectorID']=arrayUniqueByKey[i].sector;
      retpayload['client']=arrayUniqueByKey[i].clientObject.items[0].clientName;
      
      retpayload['0+']=z;
      Total0+=z;
      retpayload['7+']=a;
      Total7+=a;
      retpayload['14+']=b;
      Total14+=b;
      retpayload['21+']=c;
      Total21+=c;
      retpayload['total']=a+b+c+z;
      GrandTotal+=retpayload['total'];
      data.push(retpayload);
    }
    data.sort((a, b) => b.total - a.total);
    let reatpayload1={};
    reatpayload1['sector']='Total';
    reatpayload1['0+']=Total0;
    reatpayload1['7+']=Total7;
    reatpayload1['14+']=Total14;
    reatpayload1['21+']=Total21;
    reatpayload1['total']=GrandTotal;
    data.push(reatpayload1);
    console.log('sectorWiseData',data);
    function calculateAgeInPastDays(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
   
   return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.dataForProposalDetails=function (proposalBO,column) {
      let data=[];
      for(let i=0; i<proposalBO.length; i++){

    let ageingg = calculateAgeInPastDayss(proposalBO[i].proposalDate);
    let retpayload={};
    if(column=="all"){
//  let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=proposalBO[i].employeeIDObject.items[0].employeeID;
    retpayload['empName']=proposalBO[i].employeeIDObject.items[0].name;
    retpayload['teamRequestNumber']=proposalBO[i].teamRquestNumberObject.items[0].teamRequestNumber;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNotes']=proposalBO[i].rejectionNotes;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
               data.push(retpayload);
    }
    if(column=="seven" && ageingg>7 && ageingg<15 ){
//  let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=proposalBO[i].employeeIDObject.items[0].employeeID;
    retpayload['empName']=proposalBO[i].employeeIDObject.items[0].name;
    retpayload['teamRequestNumber']=proposalBO[i].teamRquestNumberObject.items[0].teamRequestNumber;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNotes']=proposalBO[i].rejectionNotes;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
               data.push(retpayload);
    }

    else if(column=="forteen" && ageingg>14 && ageingg<22){
      //  let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=proposalBO[i].employeeIDObject.items[0].employeeID;
    retpayload['empName']=proposalBO[i].employeeIDObject.items[0].name;
    retpayload['teamRequestNumber']=proposalBO[i].teamRquestNumberObject.items[0].teamRequestNumber;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNotes']=proposalBO[i].rejectionNotes;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
               data.push(retpayload);
      
    }
     else if(column=="twentyone" && ageingg>21){

      //  let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=proposalBO[i].employeeIDObject.items[0].employeeID;
    retpayload['empName']=proposalBO[i].employeeIDObject.items[0].name;
    retpayload['teamRequestNumber']=proposalBO[i].teamRquestNumberObject.items[0].teamRequestNumber;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNote']=proposalBO[i].rejectionNote;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['selfNominated']=proposalBO[i].selfNominated;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
                data.push(retpayload);
    }
     else if(column=="zerotoseven" && ageingg>= 0 && ageingg< 8){

      //  let empdetails=empBO.find(ele=>ele.id==proposalBO[i].employeeID);
    
    retpayload['empid']=proposalBO[i].employeeIDObject.items[0].employeeID;
    retpayload['empName']=proposalBO[i].employeeIDObject.items[0].name;
    retpayload['teamRequestNumber']=proposalBO[i].teamRquestNumberObject.items[0].teamRequestNumber;
    retpayload['status']=proposalBO[i].status;
     retpayload['loctType']=proposalBO[i].loctType;
      retpayload['proposalDate']=proposalBO[i].proposalDate;
       retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
        retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
         retpayload['projectCode']=proposalBO[i].projectCode;
          retpayload['lockEndDate']=proposalBO[i].lockEndDate;
           retpayload['nBDCode']=proposalBO[i].nBDCode;
            retpayload['rejectionReason']=proposalBO[i].rejectionReason;
             retpayload['rejectionNote']=proposalBO[i].rejectionNote;
              retpayload['remarks']=proposalBO[i].remarks;
               retpayload['selfNominated']=proposalBO[i].selfNominated;
               retpayload['ageing']=calculateAgeInPastDayss(proposalBO[i].proposalDate);
                data.push(retpayload);
    }
    
  }

  function calculateAgeInPastDayss(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
   console.log('age',data);
  return data;
  }


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.AllocationsNotTagged=function  (demandBO) {
      let data=[];
      
      let info=demandBO.filter(ele=>ele.proposalStatus=='Internal Identified');

       var arrayobj=Object.values(info);
    const arrayUniqueByKey = [...new Map(info.map(item =>  [item['globalPractice'], item])).values()];
     let total=0;
    for(let i=0; i<arrayUniqueByKey.length; i++){
      let retpayload={};
      retpayload['capability']=arrayUniqueByKey[i].globalPracticeObject.items[0].name;
      retpayload['gpID']=arrayUniqueByKey[i].globalPractice;
      retpayload['demands']=(info.filter(ele=>ele.globalPractice==arrayUniqueByKey[i].globalPractice)).length;
      total+=retpayload['demands'];
      data.push(retpayload);
    }
     data.sort((a, b) => b.demands - a.demands);
    let retpayload1={};
    retpayload1['capability']='Total';
    retpayload1['demands']=total;
    data.push(retpayload1);
    console.log('gpdata',data);
    return data;
      
    }

     PageModule.prototype.qualificationNotDone=function (demandBO) {
      let data=[];
      let info=demandBO.filter(ele=> (ele.globalPractice===180 || ele.skillGroup===563));
      let day1=0;
      let day2above=0;
      let day4above=0;
      let day6above=0;
      for(let i=0; i<info.length; i++){
      let age=calculateAgeInPastDayss(info[i].demandCreationDate);
      if(age<2){
        day1+=1;
      }
      else if(age>1 && age<4){
        day2above+=1;
      }
      else if(age>3 && age<6){
        day4above+=1;
      }
      else if(age>5){
        day6above+=1;
      }
      }
      let retpaylaod={};
      retpaylaod['age']='< 1 Days';
      retpaylaod['count']=day1;
      data.push(retpaylaod);
      let retpaylaod1={};
      retpaylaod1['age']='2-3 Days';
      retpaylaod1['count']=day2above;
      data.push(retpaylaod1);
      let retpaylaod2={};
      retpaylaod2['age']='4-5 Days';
      retpaylaod2['count']=day4above;
      data.push(retpaylaod2);
      let retpaylaod3={};
      retpaylaod3['age']='6+ Days';
      retpaylaod3['count']=day6above;
      data.push(retpaylaod3);
        // data.sort((a, b) => b.count - a.count);
      let retpaylaod4={};
      retpaylaod4['age']='Total';
      retpaylaod4['count']=day1+day2above+day4above+day6above;
      data.push(retpaylaod4);
      console.log('creationTBCAgeing',data);


       function calculateAgeInPastDayss(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
   return data;
    }

     PageModule.prototype.qualificationNotDoneHyperlink=function (demandBO,column) {
     
      let total=[];
      let data1=[];
      let data2=[];
      let data3=[];
      let data4=[];
       for(let i=0; i<demandBO.length; i++){
      let age=calculateAgeInPastDayss(demandBO[i].demandCreationDate);
      if(age<2){
        data1.push(demandBO[i]);
        total.push(demandBO[i]);
      }
      else if(age>1 && age<4){
        data2.push(demandBO[i]);
        total.push(demandBO[i]);
      }
      else if(age>3 && age<6){
        data3.push(demandBO[i]);
        total.push(demandBO[i]);
      }
      else if(age>5){
        data4.push(demandBO[i]);
        total.push(demandBO[i]);
      }
      }
      let finalData=[];
      if(column==0){
       finalData=showdata(data1);
      }
      else if(column==1){
        finalData=showdata(data2);
      }
      else if(column==2){
        finalData=showdata(data3);
      }
      else if(column==3){
        finalData=showdata(data4);
      }
      else if(column==4){
        finalData=showdata(demandBO);
      }

      function showdata(array){
         let data=[];
      for(let i=0; i<array.length; i++){
        let retpayload={};
         retpayload['demandID']=array[i].teamRequestNumber;
         retpayload['demandType']=array[i].demandType;
         retpayload['capability']=array[i].globalPracticeObject.items[0].name;
         retpayload['skillGroup']=array[i].skillGroupObject.items[0].skillGroupName;
         retpayload['sector']=array[i].sectorObject.items[0].name;
         retpayload['client']=array[i].clientObject.items[0].clientName;
         retpayload['demandCreationdate']=array[i].demandCreationDate;
        data.push(retpayload);
      }
      return data;
      }
      
    function calculateAgeInPastDayss(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }

   return finalData;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.allocationNotTaggedHyper=function (demandBO) {
      let data=[];
      for(let i=0; i<demandBO.length; i++){
        let retpayload={};
        retpayload['demandID']=demandBO[i].teamRequestNumber;
        retpayload['capability']=demandBO[i].globalPracticeObject.items[0].name;
        retpayload['skillGroup']=demandBO[i].skillGroupObject.items[0].skillGroupName;
        retpayload['sector']=demandBO[i].sectorObject.items[0].name;
        retpayload['client']=demandBO[i].clientObject.items[0].clientName;
        retpayload['demandType']=demandBO[i].demandType;
         retpayload['projectName']=demandBO[i].projectName;
        data.push(retpayload);
      }
      return data;
    }

      PageModule.prototype.load_data=function  (dem){
   var finalData=[];
   let dd=[];
  let row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0;
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec","Jan","Feb"];

for(let i=0;i<dem.length;i++){
var ret={};
 ret['capp']=dem[i].globalPracticeObject.items[0].name;
  ret['rolestartdate']= dem[i].roleStartDate;
  ret['team']=dem[i].teamRequestNumber;
dd.push(ret);
};
 var d = new Date();
    var curr_month = d.getMonth()+1;

    for (let i=0; i<dd.length; i++){
      
      var roleStartDate = new Date(dd[i]['rolestartdate']);
      var month = roleStartDate.getMonth()+1;

      var element  = finalData.find(function(data){return data.cap == dd[i].capp;})
      if(element == undefined){
      var temp= {};

      temp['cap'] = dd[i].capp;
      temp['curr'] =0;
      temp['next'] = 0;
      temp['future'] = 0;
      temp['past'] = 0;
      temp['total'] =0;
       if(month == curr_month){
            temp['curr'] = 1;
          }      
          else if(month == curr_month+1){
            temp['next'] = 1;
          }
          else if(month > curr_month+1){
            temp['future'] = 1;
          }
          else if(month < curr_month){
            temp['past'] = 1;
          }
          
          temp['total'] = temp['curr']+temp['next']+temp['future']+temp['past'];
     finalData.push(temp);
      }
     else{
          var index = finalData.findIndex(function(data){return data.cap == element.cap;})

           if(month == curr_month){
            finalData[index]['curr'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['next'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['future'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['past'] += 1;
          }
           finalData[index]['total'] = finalData[index]['curr'] + finalData[index]['next'] + finalData[index]['future']+finalData[index]['past'];
          
      }
    };
    for (let i=0; i<finalData.length; i++){
      row1 += finalData[i].past;
      row2 += finalData[i].curr;
      row3 += finalData[i].next;
      row4 += finalData[i].future;
      row5 += finalData[i].total;
    };
    finalData.sort((a, b) => b.total - a.total);
     let  tem = {};
    tem['cap'] = 'Total';
    tem['curr'] = row2;
    tem['next'] = row3;
    tem['future'] = row4;
    tem['past'] = row1;
  tem['total'] = row5;
  finalData.push(tem);

    finalData['currentMonth'] = monthNames[curr_month-1];
    finalData['nextMonth'] = monthNames[curr_month];
    finalData['future'] = monthNames[curr_month+1]+'+';
   
    console.log(finalData);
    return finalData;
  };

 PageModule.prototype.hypertable=function (dm,index){
  let finaldata=[];
  let dd=[]; 
  let aa=[]; 
  let bb=[]; 
  let cc=[];
  let ee=[];
  var d = new Date();
    var curr_month = d.getMonth()+1;
  for(let i=0;i<dm.length;i++){
    var cap=dm[i].globalPracticeObject.items[0].name;
     var roleStartDate = new Date(dm[i]['roleStartDate']);
        var month = roleStartDate.getMonth()+1;
      if(month < curr_month){
        dd.push(dm[i]);
      }else if(month === curr_month){
        aa.push(dm[i]);
      } else if(month === curr_month+1){
        bb.push(dm[i]);
      } else if (month > curr_month+1){
        cc.push(dm[i]);
      } //else {
    ee.push(dm[i]);
//}
       }
 if(index===1){
          for (let a =0;a<dd.length;a++){
            let t={};
    t['id']=dd[a].teamRequestNumber;
    t['propstatus']=dd[a].proposalStatus;
    t['type']=dd[a].demandType;
    t['cap']=dd[a].globalPracticeObject.items[0].name;
    t['skill']=dd[a].skillGroupObject.items[0].skillGroupName;
    t['sector']=dd[a].sectorObject.items[0].name;
    t['client']=dd[a].clientObject.items[0].clientName;
    t['project']=dd[a].projectName;
    t['status']=dd[a].status;
    finaldata.push(t);
          }
 }
    if(index === 2){
       for (let a =0;a<aa.length;a++){
            let t={};
    t['id']=aa[a].teamRequestNumber;
    t['propstatus']=aa[a].proposalStatus;
    t['type']=aa[a].demandType;
    t['cap']=aa[a].globalPracticeObject.items[0].name;
    t['skill']=aa[a].skillGroupObject.items[0].skillGroupName;
    t['sector']=aa[a].sectorObject.items[0].name;
    t['client']=aa[a].clientObject.items[0].clientName;
    t['project']=aa[a].projectName;
    t['status']=aa[a].status;
    finaldata.push(t);
          }
      }
  
            if(index===3){
              for (let a =0;a<bb.length;a++){
            let t={};
    t['id']=bb[a].teamRequestNumber;
    t['propstatus']=bb[a].proposalStatus;
    t['type']=bb[a].demandType;
    t['cap']=bb[a].globalPracticeObject.items[0].name;
    t['skill']=bb[a].skillGroupObject.items[0].skillGroupName;
    t['sector']=bb[a].sectorObject.items[0].name;
    t['client']=bb[a].clientObject.items[0].clientName;
    t['project']=bb[a].projectName;
    t['status']=bb[a].status;
    finaldata.push(t);
  }
            }
           if(index===4){
            for (let a =0;a<cc.length;a++){
            let t={};
             t['id']=cc[a].teamRequestNumber;
    t['propstatus']=cc[a].proposalStatus;
    t['type']=cc[a].demandType;
    t['cap']=cc[a].globalPracticeObject.items[0].name;
    t['skill']=cc[a].skillGroupObject.items[0].skillGroupName;
    t['sector']=cc[a].sectorObject.items[0].name;
    t['client']=cc[a].clientObject.items[0].clientName;
    t['project']=cc[a].projectName;
    t['status']=cc[a].status;
    finaldata.push(t);
          }
           }
         if(index===5){
           for (let a =0;a<ee.length;a++){
            let t={};
       t['id']=ee[a].teamRequestNumber;
    t['propstatus']=ee[a].proposalStatus;
    t['type']=ee[a].demandType;
    t['cap']=ee[a].globalPracticeObject.items[0].name;
    t['skill']=ee[a].skillGroupObject.items[0].skillGroupName;
    t['sector']=ee[a].sectorObject.items[0].name;
    t['client']=ee[a].clientObject.items[0].clientName;
    t['project']=ee[a].projectName;
    t['status']=ee[a].status;
    finaldata.push(t);
         }
         }
        
        return finaldata;
  };

   PageModule.prototype.formatDate= function(dateString) {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  // Parse the ISO 8601 date string into a Date object
  const date = new Date(dateString);
  
  // Get day, month, and year
  const day = date.getDate().toString().padStart(2, '0');
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  
  // Construct the formatted date string
  const formattedDate = `${day}-${month}-${year}`;
  
  return formattedDate;
}
PageModule.prototype.downloadFile = function(base64File, filename) {
        console.log('@@File Name' + filename);

        var fileBytes = atob(base64File);
        fileBytes = FileToBytes(fileBytes);
        console.log(fileBytes);
        // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
        //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        var blob = new Blob([fileBytes], {
            type: 'octet/stream'
        });
        //var filename = "CDE.xlsx";

        function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
  } 
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.setAttribute("target", "_blank");
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                console.log('Link' + JSON.stringify(link));
                // var win = window.open(url, "_blank");
                //  win.focus();
                document.body.removeChild(link);
            }
        }

    };
    PageModule.prototype.validateFile = function(extension) {
        var ext = extension.split('.').pop();
        //console.log('@@uu :' + extt);
        if (ext == "pdf" || ext == "docx") {
          // if (ext == "pdf") {
            return 'valid';
        }

        return 'non-valid';
    };
    PageModule.prototype.fileName = function (objectName,employeeID) {
    var fileName ;
    // fileName = objectName;
    fileName = 'OracleEmpResume/'+employeeID;
    var ext=objectName.split(".");
    fileName=fileName+'.'+ext[ext.length-1];
    return fileName;
  };
  PageModule.prototype.date = function () {
   let today = new Date().toISOString().slice(0, 10);
    return today;
  };

  PageModule.prototype.filePayload = function(fileObj, bucketName, fileName) {
        
        var form = new FormData();
        form.append('file', fileObj, fileName);
        form.append('json', '{"filename":"' + fileName + '", "bucket_name" : "' + bucketName + '"}');
    
        return form;
    };





    PageModule.prototype.rejectedMainBody = function (arg1,demandID,capb,skillGroup) {
  let Body="";
 

  if(arg1.status=='Rejected'){
    Body+="This is a notification about decision on proposal of your profile by PSC to Demand ID – "+demandID.teamRequestNumber+" ("+capb+", "+skillGroup+")<br><br>Your profile has not been selected for this demand.<br><br>";
  }
   if(arg1.rejectionReason=='Client Interview Rejected - Skill Fitment'){
    Body+="Rejection reason – We received a feedback from the client that your profile was rejected in the client interview as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Client Interview Rejected - Role Fitment'){
    Body+="Rejection reason – We received a feedback from the client that your profile was rejected in the client interview as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Interview Rejected - Skill Fitment'){
    Body+="Rejection reason – We received a feedback from the project that your profile was rejected in the interview as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Interview Rejected - Role Fitment'){
    Body+="Rejection reason – We received a feedback from the project that your profile was rejected in the interview as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Screening Rejected - Skill Fitment'){
    Body+="Rejection reason – We received a feedback from the project that your profile was rejected in the screening as your skills were not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Internal Screening Rejected - Role Fitment'){
    Body+="Rejection reason –We received a feedback from the project that your profile was rejected in the screening as it was not found to be suitable for the open role.";
   }
    else if(arg1.rejectionReason=='Demand Cancelled'){
    Body+="Rejection reason – The demand has been cancelled and no longer accepting profile applications for this role ";
   }
    else if(arg1.rejectionReason=='Demand Moved out'){
    Body+="Rejection reason –The demand has been retagged to other business line and no longer accepting Oracle profile applications for this role";
   }
    else if(arg1.rejectionReason=='Alternate candidate already selected'){
    Body+="Rejection reason – Another candidate has already been selected for the position and role is closed.";
   }
    else if(arg1.rejectionReason=='Other'){
    Body+="Rejection reason –Please connect with the PSC team to inquire about the reason for rejection.";
   }
  
  Body+="<br><br>We encourage you to continue exploring opportunities in ‘Open Demands for Self-Nominations’ in MyView, as new positions are continuously becoming available that can match your skills and experience.";
    Body+="<br><br><br>Regards<br>Oracle PSC Team";

  return Body;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.sdpCount = function (arg1) {

  // var data = arg1.getData();
  if (arg1 && arg1.data) {     // Get the count of data items in the SDP variablevar dataCount = sdpVariable.data.length;    
   console.log("Count of data items:", dataCount); } 
   else {     console.error("SDP variable is not loaded or is null."); }

// Calculate the count of records
var count = data.length;

return count;

  };



    PageModule.prototype.proposedandblockedMailbody = function (arg1,demandID,employee,clMailid,pdlMail) {
  let Body;
  let To;
    let pscDL="dimple.acharya@capgemini.com,satish.ekambaram@capgemini.com,tanzila-sultana.p@capgemini.com,kannamala.rajesh-babu@capgemini.com,jahnavi.pamanji@capgemini.com,anubhav.choudhary@capgemini.com,sureshri.gurav@capgemini.com,prasad.a.rao@capgemini.com,kajal.magar@capgemini.com,sufiya-fathima.b@capgemini.com";

 
  Body='';
  let subject='';
   const startDate = new Date(demandID.roleStartDate);
    const formattedStartDate = startDate.getDate() + '-' + 
                               new Intl.DateTimeFormat('en-US', { month: 'short' }).format(startDate) + '-' + 
                               startDate.getFullYear();

  if(arg1.status=='Proposed'){

  let employeeBO=employee.find(ele=> ele.id==arg1.employeeID);
  // let requester=employee.find(ele=> ele.name==demandID.requestedBy);
   let requester = demandID.requestedBy.includes('@') ? demandID.requestedBy : undefined;
  if (pdlMail!==undefined){
   To=requester!=undefined?requester+","+pdlMail+"," + pscDL+","+clMailid+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":clMailid+"," + pscDL+","+pdlMail+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
  }
  else {
  To=requester!=undefined?requester+"," + pscDL+ "," + clMailid+",-asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":clMailid+"," + pscDL+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
  }

    subject="Notification: Profile proposed for demand (Demand ID - "+demandID.teamRequestNumber+", Employee ID - "+employeeBO.employeeID+")";
    Body+="This is a notification for proposing "+employeeBO.name+" (Employee ID - "+employeeBO.employeeID+") for \""+demandID.projectName+"\" project. <br><br>Please confirm the decision for the proposed profile at the earliest.<br><br>Should you have any questions or need assistance with the above actions, please don't hesitate to reach out to us.<br><br><b>Note:</b> All multi-proposed profiles are also opened for other opportunities within Capgemini and available for allocation on “First Come First Serve (FCFS)” basis.<br>";
  }
  //  if(arg1.status=='Allocated'){
  //   Body+="<br><br>We are pleased to inform you that your nomination for ‘"+demandID.projectName+"’ in MY View has been reviewed by our PSC team, and we are delighted to confirm your profile for the same.<br><br><b>Next Step-</b> Your PDL/DM/PSC spoc will connect with you to initiate the tagging process.";
  // }
 const startDate1 = new Date(arg1.proposalDate);
const day = startDate1.getDate();
const month = new Intl.DateTimeFormat('en-US', { month: 'short' }).format(startDate1);
const year = startDate1.getFullYear();
const formattedStartDate1 = day + '-' + month + '-' + year;

    const lockendDate1 = new Date(arg1.lockEndDate);
    const formatedlockenddate = lockendDate1.getDate() + '-' + 
                               new Intl.DateTimeFormat('en-US', { month: 'short' }).format(lockendDate1) + '-' + 
                               lockendDate1.getFullYear();



   if(arg1.status=='Blocked/Client interview'){

  let employeeBO=employee.find(ele=> ele.id==arg1.employeeID);
  // let requester=employee.find(ele=> ele.name==demandID.requestedBy);
   let requester = demandID.requestedBy.includes('@') ? demandID.requestedBy : undefined;

   if (pdlMail!==undefined){
  To=requester!=undefined?requester+"," + pscDL+","+pdlMail+","+clMailid+","+employeeBO.email+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":employeeBO.email+"," + pscDL+","+pdlMail+","+clMailid+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
   }
   else {
     To=requester!=undefined?requester+"," + pscDL+","+clMailid+","+employeeBO.email+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":employeeBO.email+"," + pscDL+","+clMailid+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
   }
    subject="Notification: NBD blocking of profile for demand (Demand ID - "+demandID.teamRequestNumber+", Employee ID - "+employeeBO.employeeID+")";
    Body+="This is a notification for blocking of "+employeeBO.name+" (Employee ID - "+employeeBO.employeeID+") on NBD Code- "+arg1.nBDCode+" from "+formattedStartDate1+" to "+formatedlockenddate+". The timecards for the NBD blocked date range would be filled by the employee on NBD code.<br><br>Please confirm the decision for the proposed profile at the earliest.<br><br>Should you have any questions or need assistance with the above actions, please don't hesitate to reach out to us."
  }
  // if(arg1.status=='Proposal Expired' || arg1.status=='NBD Block Expired'){
  //   Body+="<br><br><b>Rejected reason:</b> "+arg1.rejectionReason;
  // }
  Body+="<br><br>Regards,<br>Oracle PSC Team";
  return {Body,subject,To};
  };








  
   PageModule.prototype.nbdBlockExpirymail = function (arg1,demandID,employee,clMailid,pdlMail) {
  let Body;
 
  Body='';
  let subject='';
  let To='';

 const startDate1 = new Date(arg1.proposalDate);
const day = startDate1.getDate();
const month = new Intl.DateTimeFormat('en-US', { month: 'short' }).format(startDate1);
const year = startDate1.getFullYear();
const formattedStartDate1 = day + '-' + month + '-' + year;

    const lockendDate1 = new Date(arg1.lockEndDate);
    const formatedlockenddate = lockendDate1.getDate() + '-' + 
                               new Intl.DateTimeFormat('en-US', { month: 'short' }).format(lockendDate1) + '-' + 
                               lockendDate1.getFullYear();



   if(arg1.status=='Blocked/Client interview'){

  let employeeBO=employee.find(ele=> ele.id==arg1.employeeID);
  let requester=employee.find(ele=> ele.name==demandID.requestedBy);
   if (pdlMail!==undefined){
  let To=requester!=undefined?requester.email+","+pdlMail+","+clMailid+","+employeeBO.email+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":employeeBO.email+","+pdlMail+","+clMailid+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
   }
   else {
      let To=requester!=undefined?requester.email+","+clMailid+","+employeeBO.email+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com":employeeBO.email+","+clMailid+",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
   }
    subject="Notification: NBD block Expiry (Demand ID - "+demandID.teamRequestNumber+", Employee ID - "+employeeBO.employeeID+")";

    Body+="This is a notification about the expiry of below NBD block for proposed profile. In absence of NBD block, the individual is available effective immediately,to be allocated to other demands on “First Come First Serve (FCFS)” basis.";
    Body+= "<br><br>Employee Name -"+employeeBO.name+" (Employee ID - "+employeeBO.employeeID+")";
    Body+="<br>Demand ID - "+demandID.teamRequestNumber; 
    Body+="<br>Blocking Start Date -"+formattedStartDate1;
    Body+="<br>Blocking Start Date -"+formatedlockenddate;
    Body+="<br><br>Please inform Oracle PSC team if an extension for the NBD block is required.";
  }
  
  Body+="<br><br>Regards,<br>Oracle PSC Team";
  return {Body,subject,To};
  };
  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.allocationMail = function (arg1 , requestor,empEmail,clMail,dmMail,pdlMail,requestorName) {

   let Body = "";
  let too;
  let pscDL="dimple.acharya@capgemini.com,satish.ekambaram@capgemini.com,tanzila-sultana.p@capgemini.com,kannamala.rajesh-babu@capgemini.com,jahnavi.pamanji@capgemini.com,anubhav.choudhary@capgemini.com,sureshri.gurav@capgemini.com,prasad.a.rao@capgemini.com,kajal.magar@capgemini.com,sufiya-fathima.b@capgemini.com";
if(requestorName === null){
  requestorName = "Not Available";
}
   let requesterMail = requestor.includes('@') ? requestor : undefined;
  if (pdlMail !== undefined) {
    too = requesterMail !== undefined ? requesterMail + "," + pdlMail + "," + empEmail + ","+ pscDL + "," + clMail + ",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com" : empEmail +","+ pscDL + "," + pdlMail + "," + clMail + ",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
  } else {
    too = requesterMail !== undefined ? requesterMail + "," + empEmail +","+ pscDL + "," + clMail + ",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com" : empEmail + ","+ pscDL +"," + clMail + ",asoblpsc.in@capgemini.com,pranav.shridhar-dhavale@capgemini.com";
  }

  if (arg1.status === 'Allocated') {
    // Convert allocation start date to desired format or assign "Not Available" if null or undefined
    let allocationStartDate = arg1.allocationStartDate ? new Date(arg1.allocationStartDate) : "Not Available";
    let formattedStartDate = allocationStartDate !== "Not Available" ? allocationStartDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: '2-digit'
    }).replace(/ /g, '-') : "Not Available";

    // Convert allocation end date to desired format or assign "Not Available" if null or undefined
    let allocationEndDate = arg1.allocationEndDate ? new Date(arg1.allocationEndDate) : "Not Available";
    let formattedEndDate = allocationEndDate !== "Not Available" ? allocationEndDate.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: '2-digit'
    }).replace(/ /g, '-') : "Not Available";

    // Assign "Not Available" if project code is null or undefined
    let projectCode = arg1.projectCode || "Not Available";
    
    // Assign "Not Available" if percentage allocation is null or undefined
    let percentageAllocation = arg1.percentageAllocation || "Not Available";

    Body += "<br>This is a notification to confirm your allocation to the below project.<br><br>Project ID - " + projectCode + "<br><br>Allocation start date - " + formattedStartDate + "<br><br>Allocation end date - " + formattedEndDate + "<br><br>Allocation % - " + percentageAllocation + "<br><br>Requestor Details - " + requestorName + "<br><br>Please connect with the requestor mentioned above for onboarding to the project.";
  }

  Body += "<br><br><br>Regards,<br>Oracle PSC Team";
   return {Body,too};
  };

   PageModule.prototype.weekstartdate = function() {
    const currentDate = new Date();
const dayOfWeek = currentDate.getDay();
const daysToMonday = dayOfWeek === 1 ? 0 : dayOfWeek === 0 ? 1 : 1 - dayOfWeek;
const startDateOfWeek = new Date(currentDate);
startDateOfWeek.setDate(currentDate.getDate() - daysToMonday);
const formattedStartDate = `${startDateOfWeek.getFullYear()}-${(startDateOfWeek.getMonth() + 1).toString().padStart(2, '0')}-${startDateOfWeek.getDate().toString().padStart(2, '0')}`;
return formattedStartDate;
};

  PageModule.prototype.prevMonday= function (arg1) {
        const today = new Date();
const year = today.getFullYear();
const mondays = [];

for (let i = 0; i < 10; i++) {
    const payload = {};
    const dayOfWeek = today.getDay();
    const diff = (dayOfWeek + 6) % 7;
    const monday = new Date(today);
    monday.setDate(today.getDate() - diff - (7 * i));
    const formattedDate = `${monday.getFullYear()}-${(monday.getMonth() + 1).toString().padStart(2, '0')}-${monday.getDate().toString().padStart(2, '0')}`;
    payload['Monday'] = formattedDate;
    mondays.push(payload);
}

return mondays;
    };


    PageModule.prototype.headings = function (weekstart){
    let data=[];
      let currentDate = new Date(weekstart);
      let mondayDate = new Date(currentDate);
      let tuesdayDate = new Date(currentDate);
      let wednesdayDate = new Date(currentDate);
      let thursdayDate = new Date(currentDate);
      let fridayDate = new Date(currentDate);

      tuesdayDate.setDate(mondayDate.getDate() + 1);
      wednesdayDate.setDate(mondayDate.getDate() + 2);
      thursdayDate.setDate(mondayDate.getDate() + 3);
      fridayDate.setDate(mondayDate.getDate() + 4);

  //  function formatDate(date) {
  //   const day = date.getDate().toString().padStart(2, '0');
  //   const month = (date.getMonth() + 1).toString().padStart(2, '0');
  //   const year = date.getFullYear();
  //   return `${day}-${month}-${year}`;
  //   }
  function formatDate(date) {
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${month}/${day}`;
}
    let monday = formatDate(mondayDate);
    let tuesday = formatDate(tuesdayDate);
    let wednesday = formatDate(wednesdayDate);
    let thursday = formatDate(thursdayDate);
    let friday = formatDate(fridayDate);

      data['monday']= monday;
      data['tuesday']= tuesday;
      data['wednesday']= wednesday;
      data['thursday']= thursday;
      data['friday']= friday;
    return data;
    };


PageModule.prototype.table = function (cap,weekstart,emppro,emp,rolloff,demand,roldate,emp1){
      let data=[];
      var final=[];
      var final1=[];
      var finaldata=[];
      let pp=[];
      let dem=[];
      let dd=[];
      let empp=[];
      var mergedData=[];
      let final2=[];
      let tem={};
      let row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0;

  let date = new Date(weekstart);
  var curdate =formatDate(new Date);
  let datee = weekstart;
let date1 = formatDate(new Date(date.setDate(date.getDate() + 1)));
let date2 = formatDate(new Date(date.setDate(date.getDate() + 1)));
let date3 = formatDate(new Date(date.setDate(date.getDate() + 1)));
let date4 = formatDate(new Date(date.setDate(date.getDate() + 1)));
function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}
for(let i=0;i<cap.length;i++){
  let pay={};
  let dema=demand.filter(ele=>ele.globalPractice===cap[i].id);
  let teamm=dema.filter(ele=>ele.proposalStatus==='Open').length;
  pay['capability']=cap[i].id;
  pay['tt']=teamm;
  dem.push(pay);
}

      for(let i=0;i<emppro.length;i++){
      let rett={};

      let cd=emppro[i].creationDate;
         let cdate = cd.substring(0, 10);
      let ud=emppro[i].lastUpdateDate;
         let udate = ud.substring(0, 10);
         rett['status']=emppro[i].status;
        //  rett['cap']=emppro[i].employeeIDObject.items[0].globalPractice !=undefined ?emppro[i].employeeIDObject.items[0].globalPractice:'';
        if (emppro[i].employeeIDObject.items && emppro[i].employeeIDObject.items.length > 0) {
    rett['cap'] = emppro[i].employeeIDObject.items[0].globalPractice !== undefined ? emppro[i].employeeIDObject.items[0].globalPractice : '';
} else {
    rett['cap'] = '';
}
         rett['cdate']=cdate;
         rett['udate']=udate;
        pp.push(rett);
      };
      for(let i=0;i<pp.length;i++){
       var element = final1.find(function(data){return data.cap == pp[i].cap;})
       if(element==undefined){
        var ret={};
        ret['cap']=pp[i].cap;
         ret['p1']=0;
         ret['p2']=0;
         ret['p3']=0;
         ret['p4']=0;
         ret['p5']=0;
         ret['r1']=0;
         ret['r2']=0;
         ret['r3']=0;
         ret['r4']=0;
         ret['r5']=0;
         ret['a1']=0;
         ret['a2']=0;
         ret['a3']=0;
         ret['a4']=0;
         ret['a5']=0;
         if(datee===pp[i].cdate){
          if(pp[i].status=='Proposed'){
                ret['p1']=1;
          }
 }
          if(date1==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                ret['p2']=1;
          }
         }
         if(date2==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                ret['p3']=1;
         }
		 }
         if(date3==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                ret['p4']=1;
          }
         }
         if(date4==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                ret['p5']=1;
          }
         }
	   if(datee===pp[i].udate){
          if(pp[i].status=='Rejected'){
                ret['r1']=1;
          }if(pp[i].status==='Allocated'){
			  ret['a1']=1;
          }	  
 }
          if(date1==pp[i].udate){
if(pp[i].status=='Rejected'){
                ret['r2']=1;
          }if(pp[i].status==='Allocated'){
			  ret['a2']=1;
         }
          }
         if(date2==pp[i].udate){
         if(pp[i].status=='Rejected'){
                ret['r3']=1;
          }if(pp[i].status==='Allocated'){
			  ret['a3']=1;
		 }
         }
         if(date3==pp[i].udate){
         if(pp[i].status=='Rejected'){
                ret['r4']=1;
          }if(pp[i].status==='Allocated'){
			  ret['a4']=1;
         }
         }
         if(date4==pp[i].udate){
         if(pp[i].status=='Rejected'){
                ret['r5']=1;
          }if(pp[i].status==='Allocated'){
			  ret['a5']=1;
         }
         }
          final1.push(ret);
       }    

         else{
          let ind = final1.findIndex(function(data){return data.cap == element.cap;})
          if(datee===pp[i].cdate){
          if(pp[i].status=='Proposed'){
                final1[ind]['p1']+=1;
          }
 }
          if(date1==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                final1[ind]['p2']+=1;
          }
         }
         if(date2==pp[i].cdate){
          if(pp[i].status=='Proposed'){
               final1[ind]['p3']+=1;
         }
		 }
         if(date3==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                final1[ind]['p4']+=1;
          }
         }
         if(date4==pp[i].cdate){
          if(pp[i].status=='Proposed'){
                final1[ind]['p5']+=1;
          }
         }
	   if(datee===pp[i].udate){
          if(pp[i].status=='Rejected'){
                final1[ind]['r1']+=1;
          }if(pp[i].status==='Allocated'){
			  final1[ind]['a1']+=1;
          }	  
 }
          if(date1==pp[i].udate){
if(pp[i].status=='Rejected'){
                final1[ind]['r2']+=1;
          }if(pp[i].status==='Allocated'){
			  final1[ind]['a2']+=1;
         }
          }
         if(date2==pp[i].udate){
         if(pp[i].status=='Rejected'){
                final1[ind]['r3']+=1;
          }if(pp[i].status==='Allocated'){
			  final1[ind]['a3']+=1;
		 }
         }
         if(date3==pp[i].udate){
         if(pp[i].status=='Rejected'){
                final1[ind]['r4']+=1;
          }if(pp[i].status==='Allocated'){
			  final1[ind]['a4']+=1;
         }
         }
         if(date4==pp[i].udate){
         if(pp[i].status=='Rejected'){
                final1[ind]['r5']+=1;
          }if(pp[i].status==='Allocated'){
			  final1[ind]['a5']+=1;
         }
         }
         }
      } 
      
      for(let i=0;i<emp.length;i++){
 let rett={};
 let rr;
  let roll=rolloff.find(ele=>ele.employeeID==emp[i].id);
let capp=cap.find(ele=>ele.id==emp[i].globalPractice);
 rett['capab']=capp!=undefined?capp.name:'';
 rett['capid']=capp!=undefined?capp.id:'';
rett['cap1']=capp!=undefined?capp.subPractice:'';
rett['contact1']= capp !== undefined ? (emp.find(ele => ele.id === capp.pscLeadContact)?.name || '') : '';
rett['remp']=roll!=undefined?roll.employeeID:'';
rett['rdate']=roll!=undefined?roll.releaseDate:'';
rett['eid']=emp[i].id;
rett['name']=emp[i].name;
rett['status']=emp[i].status;
rett['localGrade']=emp[i].localGrade;
empp.push(rett);
};
for(let i=0;i<empp.length;i++){
   let ret={};
    var elem = final.find(function(data){return data.cap == empp[i].capab;})
      if(elem == undefined){
      let tem= {};
      tem['cap'] = empp[i].capab;
      tem['capid']=empp[i].capid;
      tem['capp']=empp[i].cap1;
      tem['contact']=empp[i].contact1;
      tem['lateral'] =0;
      tem['rolloff'] = 0;
      tem['fresher'] = 0;
      tem['shadow'] = 0;
      if(empp[i].contact1!==''){
        tem['contact']=empp[i].contact1;
      }
       if(empp[i].status==='Bench - Deployable' && empp[i].localGrade !== 'A4' && empp[i].localGrade !== 'A5' && empp[i].localGrade !== 'A3'){
            tem['lateral'] = 1;
          }      
          if(empp[i].status==='Bench - Deployable' && (empp[i].localGrade=='A4' ||empp[i].localGrade=='A5' )){
            tem['fresher'] = 1;
          }
           if(empp[i].status==='Shadow ' && (empp[i].localGrade=='A4' ||empp[i].localGrade=='A5' )){
            tem['shadow'] = 1;
          }if(empp[i].remp!='' && !emp1.find(ele => ele.employeeID === empp[i].remp)){
            if((empp[i].rdate>curdate &&empp[i].rdate<roldate)){
            tem['rolloff'] = 1; 
            }
          }
     final.push(tem);
      }
     else{
          let ind = final.findIndex(function(data){return data.cap == elem.cap;})

           if(empp[i].status==='Bench - Deployable'&&  empp[i].localGrade !== 'A4' && empp[i].localGrade !== 'A5' && empp[i].localGrade !== 'A3'){
            final[ind]['lateral'] += 1;
          }  
          if(empp[i].contact1!==''){
        final[ind]['contact']=empp[i].contact1;
      }    
            if(empp[i].status==='Bench - Deployable' && (empp[i].localGrade=='A4' ||empp[i].localGrade=='A5' )){
            final[ind]['fresher'] += 1;
          }
          if(empp[i].status==='Shadow ' && (empp[i].localGrade=='A4' ||empp[i].localGrade=='A5' )){
            final[ind]['shadow'] += 1;
          }
          if(empp[i].remp!='' && !emp1.find(ele => ele.employeeID === empp[i].remp)){
            if( (empp[i].rdate>curdate &&empp[i].rdate<roldate) ){
          final[ind]['rolloff'] += 1; 
            }
          }   

      }
    };

mergedData = final.map(item => {
    let match = final1.find(subItem => subItem.cap === item.capid);
    let demMatch = dem.find(demItem => demItem.capability === item.capid);
    if (match) {
        let mergedItem = {
            ...match,
            cap: item.cap,
            capp: item.capp,
            contact: item.contact,
            lateral: item.lateral,
            rolloff: item.rolloff,
            fresher:item.fresher,
            shadow: item.shadow,
        };
     if (demMatch) {
            mergedItem.tt = demMatch.tt;
        }
        return mergedItem;
    } else {
        if (item.cap !== "" || item.capp !== "") {
            let newItem = {
                cap: item.cap,
                capp: item.capp,
                contact: item.contact,
                lateral: item.lateral,
                rolloff: item.rolloff,
                fresher:item.fresher,
                shadow: item.shadow,
                p1: 0,
                p2: 0,
                p3: 0,
                p4: 0,
                p5: 0,
                a1: 0,
                a2: 0,
                a3: 0,
                a4: 0,
                a5: 0,
                r1: 0,
                r2: 0,
                r3: 0,
                r4: 0,
                r5: 0,
            };
           if (demMatch) {
                newItem.tt = demMatch.tt;
            }
            return newItem;
        }
    }
}).filter(Boolean);

mergedData.sort((a, b) => {
    if (a.capp === "" || a.capp === null || a.capp === undefined) return -1;
    if (b.capp === "" || b.capp === null || b.capp === undefined) return 1;
    if (a.capp > b.capp) return -1;
    if (a.capp < b.capp) return 1;
    if (a.capp === b.capp) {
        if (a.cap < b.cap) return -1;
        if (a.cap > b.cap) return 1;
        return 0;
    }
});

return mergedData;
}

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.hyperemp=function(emp,index,rolloff,skg,cap,rodate,emp1) {
      var data2=[];
       
       var cdate =formatDate(new Date);
       function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}  

      for(var k=0;k<emp.length;k++){
        var temp2={};
          var capp=cap.find(ele=>ele.id==emp[k].globalPractice);
        var group1=skg.find(ele=>ele.id==emp[k].skillGroup1);
        var group2=skg.find(ele=>ele.id==emp[k].skillGroup2);
        var group3=skg.find(ele=>ele.id==emp[k].skillGroup3);
       
        if(index===3){
        if(emp[k].status==='Bench - Deployable' && emp[k].localGrade !== 'A4' && emp[k].localGrade !== 'A5' && emp[k].localGrade !== 'A3'){
        temp2['employeeId']=emp[k].employeeID;
          temp2['name']=emp[k].name;
          temp2['email']=emp[k].email;
          temp2['localGrade']=emp[k].localGrade;
          temp2['capability']=capp!=undefined?capp.name:'';
          temp2['sucap']=capp!=undefined?capp.subPractice:'';
          temp2['sg1']=group1!=undefined?group1.skillGroupName:'';
          temp2['sg2']=group2!=undefined?group2.skillGroupName:'';
          temp2['sg3']=group3!=undefined?group3.skillGroupName:'';
          data2.push(temp2);
        }
      }
      if(index===4){
        let ro=rolloff.find(ele=>ele.employeeID==emp[k].id);
          let roemp=ro!=undefined?ro.employeeID:'';
          let rolldate=ro!=undefined?ro.releaseDate:'';
          if(roemp!='' && !emp1.find(ele => ele.employeeID === roemp)){   
            if(  (rolldate>cdate &&rolldate<rodate)){
            temp2['employeeId']=emp[k].employeeID;
          temp2['name']=emp[k].name;
          temp2['email']=emp[k].email;
          temp2['localGrade']=emp[k].localGrade;
          temp2['capability']=capp!=undefined?capp.name:'';
          temp2['sucap']=capp!=undefined?capp.subPractice:'';
          temp2['sg1']=group1!=undefined?group1.skillGroupName:'';
          temp2['sg2']=group2!=undefined?group2.skillGroupName:'';
          temp2['sg3']=group3!=undefined?group3.skillGroupName:'';
          data2.push(temp2);
            }
          
          }
      }
      if(index===6){
            if(emp[k].status==='Shadow ' && (emp[k].localGrade=='A4' ||emp[k].localGrade=='A5' )){
               temp2['employeeId']=emp[k].employeeID;
               temp2['name']=emp[k].name;
               temp2['email']=emp[k].email;
             temp2['localGrade']=emp[k].localGrade;
            temp2['capability']=capp!=undefined?capp.name:'';
          temp2['sucap']=capp!=undefined?capp.subPractice:'';
          temp2['sg1']=group1!=undefined?group1.skillGroupName:'';
          temp2['sg2']=group2!=undefined?group2.skillGroupName:'';
          temp2['sg3']=group3!=undefined?group3.skillGroupName:'';
          data2.push(temp2);   
            }
      }
       if(index===5){
            if(emp[k].status==='Bench - Deployable' && (emp[k].localGrade=='A4' ||emp[k].localGrade=='A5' ||emp[k].localGrade=='A3' )){
               temp2['employeeId']=emp[k].employeeID;
               temp2['name']=emp[k].name;
               temp2['email']=emp[k].email;
             temp2['localGrade']=emp[k].localGrade;
            temp2['capability']=capp!=undefined?capp.name:'';
          temp2['sucap']=capp!=undefined?capp.subPractice:'';
          temp2['sg1']=group1!=undefined?group1.skillGroupName:'';
          temp2['sg2']=group2!=undefined?group2.skillGroupName:'';
          temp2['sg3']=group3!=undefined?group3.skillGroupName:'';
          data2.push(temp2);   
            }
      }
      }
      return data2;
    }


             PageModule.prototype. Dateset= function() {
      var rollOfDate = new Date();
      var currentDate = new Date();
      
      //setting the rollof date to 30 days from current date
      rollOfDate.setDate(currentDate.getDate()+30);
       var dd = String(rollOfDate.getDate()).padStart(2, '0');
            var mm = String(rollOfDate.getMonth() + 1).padStart(2, '0');
            var yyyy = rollOfDate.getFullYear();

            rollOfDate = yyyy + '-' + mm + '-' + dd;
      return rollOfDate;
    };


      PageModule.prototype.demandhyper=function(index,skg,cap,dem,bu) {
    var dataa=[];
    if(index==2){
    for(var i=0;i<dem.length;i++){
      var rettpay={};
        let capp=cap.find(ele=>ele.id==dem[i].globalPractice);
        let group1=skg.find(ele=>ele.id==dem[i].skillGroup);
        let buname=bu.find(ele=>ele.id==dem[i].sector);
          rettpay['demandid']=dem[i].teamRequestNumber;
          rettpay['sector']=buname!=undefined?buname.name:'';
          rettpay['capability']=capp.name;
          rettpay['group1']=group1.skillGroupName;
          rettpay['projectname']=dem[i].projectName;
          rettpay['client']=dem[i].clientObject.items[0].clientName;
          rettpay['local']=dem[i].localGrade;
          dataa.push(rettpay);
    }
    return dataa;

  }
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
 PageModule.prototype.allresourcesADP = function (P_Emp, pipBO) {
    var retPayload = {
        allResources: []
    };

    for (var i = 0; i < P_Emp.length; i++) {
        let pip = pipBO.find(ele => ele.empID == P_Emp[i].id);
        var temp1 = {};

        temp1['id'] = P_Emp[i].employeeID;
        temp1['name'] = P_Emp[i].name;
        temp1['grade'] = P_Emp[i].localGrade == null ? '' : P_Emp[i].localGrade ;
        temp1['billable'] = P_Emp[i].billable == null ? '': P_Emp[i].billable ;
        temp1['capab'] = P_Emp[i].globalPracticeObject.items[0] ? P_Emp[i].globalPracticeObject.items[0].name : '';
        temp1['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp1['skill'] = P_Emp[i].skillGroup1 == null ? '' : P_Emp[i].skillGroup1Object.items[0].skillGroupName;
        temp1['skill2'] = P_Emp[i].skillGroup2 == null ? '' : P_Emp[i].skillGroup2Object.items[0].skillGroupName;
        temp1['skill3'] = P_Emp[i].skillGroup3 == null ? '' : P_Emp[i].skillGroup3Object.items[0].skillGroupName;
        temp1['location'] = P_Emp[i].location == null ? '' : P_Emp[i].locationObject.items[0].location;
        temp1['BoID'] = P_Emp[i].id;
        temp1['status'] = P_Emp[i].status == null ? '' : P_Emp[i].status;
        temp1['pip'] = pip !== undefined ? true : false;

        retPayload.allResources.push(temp1);
    }

    retPayload.allResourcesCount = retPayload.allResources.length;

    // retPayload.allResources.sort((a, b) => {
    //     // First, sort by grade
    //     const gradeComparison1 = b.grade.localeCompare(a.grade);

    //     // If grades are equal, sort by id
    //     if (gradeComparison1 === 0) {
    //         return a.id - b.id;
    //     } else {
    //         return gradeComparison1;
    //     }
    // });

    return retPayload; // Return the corrected retPayload object
};

  PageModule.prototype.empprocheck = function (emppro,emp) {
    let empproposal =emppro.find(ele=>ele.employeeID===emp);
    if(empproposal){
      if(empproposal.status=='Allocated' || empproposal.status =='Blocked/Client interview'){
        return true;
      }
    }
    return false;
  };
   return PageModule;
   
});