define(['ojs/ojarraytreedataprovider', 'vb/BusinessObjectsTransforms'], function(ArrayTreeDataProvider, BOTransforms) {
  'use strict';

  var PageModule = function PageModule() {};
PageModule.prototype.updateCertificationCategory = function(certificationCategory){
     var retPayload = {};
     retPayload['id']=certificationCategory.id;
     retPayload['approverId'] = certificationCategory.approverIdObject.items.length>0  ?certificationCategory.approverIdObject.items[0].name :'';
     retPayload['category'] = certificationCategory.category;   
     console.log('@10'+JSON.stringify(retPayload));

     return retPayload;   
  }; 

    PageModule.prototype.updateCertification = function(certificate){
     var retPayload = {};
     retPayload['id']=certificate.id;   
     retPayload['certificationCode'] = certificate.certificationCode;  
     retPayload['certificationName'] = certificate.certificationName;  
     retPayload['certificationType'] = certificate.certificationType;  
     retPayload['subCategory'] = certificate.subCategory;
     retPayload['cloudNon'] = certificate.cloudNon;  
     retPayload['examStatus'] = certificate.examStatus.trim();  
     retPayload['newAreas'] = certificate.newAreas;  
     retPayload['openForVoucherRequest'] = certificate.openForVoucherRequest;  
     retPayload['validity'] = certificate.validity;  
     retPayload['version'] = certificate.version;
     retPayload['cost'] = certificate.cost;     
     console.log(retPayload);
     console.log('@10'+JSON.stringify(retPayload)); 
     return retPayload;   
  };

   PageModule.prototype.getName = function (context) {
    return context.data.name;
  };

  PageModule.prototype.processFilter = function (configuration, options, transformsContext) {
    var textValue = options && options.text;

    if (transformsContext && transformsContext['vb-textFilterAttributes']) {
      console.log(transformsContext['vb-textFilterAttributes'][3]);
      var options_new = {
        op: '$or',
        criteria: [
        ]
      };

      for (var i = 0; i < transformsContext['vb-textFilterAttributes'].length; i++) {
        var itemCriterion = {};
        itemCriterion.attribute = transformsContext['vb-textFilterAttributes'][i];
        itemCriterion.op = '$co';
        itemCriterion.value = textValue;
        options_new.criteria.push(itemCriterion);
        console.log(itemCriterion);
        
      }

        
        
        
 
      // - NOTE -
      // below assignment override any existing FilterCriterion set on SDP.
      // proper solution is to merge options_new into existing conditions
      options = options_new;
    }

    return BOTransforms.request.filter(configuration, options);
  };
       
  PageModule.prototype.downloadFunction = function (cert) {
    var multArray = new Array();
   for(var i=0; i<=cert.length;i++){
      
      var payloadArray = new Array();
      if(i == 0) {
      payloadArray.push('Certification Type');
      payloadArray.push('Sub Category');
      payloadArray.push('Certification Code');
      payloadArray.push('Certification Name');
      payloadArray.push('Exam Status');
      payloadArray.push('Version');
      payloadArray.push('Validity (In Months)');

      }
     // else if(cert[i].Category==categoryID)
      else {
      payloadArray.push(cert[i-1].certificationType);
      payloadArray.push(cert[i-1].subCategory);
      payloadArray.push(cert[i-1].certificationCode);
      payloadArray.push(cert[i-1].certificationName);
      payloadArray.push(cert[i-1].examStatus);
      payloadArray.push(cert[i-1].version);
      payloadArray.push(cert[i-1].validity);
    }
      
      multArray.push(payloadArray);
       }
    console.log("#",multArray);
    return multArray;

  };

 function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.writeToExcelFunction = function (innerArray) {
    var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Certification");
  var ws = XLSX.utils.aoa_to_sheet(innerArray);
  wb.Sheets["Certification"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});
    //console.log("##",innerArray[0]);

    // const wb = { Sheets: { 'Training': ws }, SheetNames: ['Training'] };
    // const excelBuffer = XLSX.write(wb, { bookType:'xlsx' , type: 'array', cellStyles:true });
    // const finalData = new Blob([excelBuffer], { type: 'octet/stream' });
   //FileSaver.saveAs(finalData, "Data.xlsx")
    //XLSX.utils.book_append_sheet(wb, ws, 'Training');
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "CertificationMaster_" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };
  

  return PageModule;
});
