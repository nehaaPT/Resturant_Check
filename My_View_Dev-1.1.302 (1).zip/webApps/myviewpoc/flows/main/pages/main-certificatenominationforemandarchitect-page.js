define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getEmployeeID(context) {
      return context.data.employeeID;
    }
    getEmployeeName(context) {
      return context.data.name;
    }
    getEmail(context) {
      return context.data.email;
    }
    getCertification(context) {
      return context.data.certificationCode+'-'+context.data.certificationName;
    }
  }
  
  return PageModule;
});
