define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
  
  getData(pursuit,revenueBO,inputPillar,inputSummary) {
  const quarters = {
    Q1: ['Jan', 'Feb', 'Mar'],
    Q2: ['Apr', 'May', 'Jun'],
    Q3: ['Jul', 'Aug', 'Sep'],
    Q4: ['Oct', 'Nov', 'Dec']
  };

  const payload = {
    'Won (Booked till date)': {
      Q1: 0,
      Q2: 0,
      Q3: 0,
      Q4: 0
    },
    'New Business': {
      Q1Nbus: 0,
      Q2Nbus: 0,
      Q3Nbus: 0,
      Q4Nbus: 0
    },
    'Recurring': {
      Q1Ebus: 0,
      Q2Ebus: 0,
      Q3Ebus: 0,
      Q4Ebus: 0
    },
    'Forecast / Named Likely': {
      Q1: 0,
      Q2: 0,
      Q3: 0,
      Q4: 0
    },
    'New Business2': {
      Q1Nbus: 0,
      Q2Nbus: 0,
      Q3Nbus: 0,
      Q4Nbus: 0
    },
    'Recurring2': {
      Q1Ebus: 0,
      Q2Ebus: 0,
      Q3Ebus: 0,
      Q4Ebus: 0
    },
    'UnWt. Upside': {
      Q1: 0,
      Q2: 0,
      Q3: 0,
      Q4: 0
    },
    'New Business3': {
      Q1Nbus: 0,
      Q2Nbus: 0,
      Q3Nbus: 0,
      Q4Nbus: 0
    },
    'Recurring3': {
      Q1Ebus: 0,
      Q2Ebus: 0,
      Q3Ebus: 0,
      Q4Ebus: 0
    },
    'Wt. Upside': {
      Q1: 0,
      Q2: 0,
      Q3: 0,
      Q4: 0
    },
    'New Business4': {
      Q1Nbus: 0,
      Q2Nbus: 0,
      Q3Nbus: 0,
      Q4Nbus: 0
    },
    'Recurring4': {
      Q1Ebus: 0,
      Q2Ebus: 0,
      Q3Ebus: 0,
      Q4Ebus: 0
    },
    
  };

  for (const item of pursuit) {
    const dateToCheck = new Date(item.manClosemonth);
    const month = dateToCheck.toLocaleString('default', { month: 'short' });
    const isEbus = item.bus === 'E-BUS(renewals)' ;
    const isNbus = item.bus === 'N-BUS(NewLogo)'|| item.bus === 'E-BUS(NetNew)';
    const isSold = item.manStageGrp === 'SOLD';
    const ispipeN = item.manStageGrp === 'PIPE' && (item.manNLCategory == 'N-Deal Rev. LP (NL Cat. B) 10%' || item.manNLCategory == 'N-Extensions LP (NL Cat. A) 30%')
    const ispipeY = item.manStageGrp === 'PIPE' && (item.manNLCategory == 'Y-Extensions HP (NL Cat. A) 99%' || item.manNLCategory == 'Y-Extensions MP (NL Cat. A) 80%' || item.manNLCategory == 'Y-Deal Rev. HP (NL Cat. B) 90%' || item.manNLCategory == 'Y-Deal Rev. MP (NL Cat. B) 60%' || item.manNLCategory== 'Y-Firm')
    const ispipe =item.manStageGrp==='PIPE';
    
    const wtbkg=(Number(item.manTCVoracle)*Number(item.manProb))/100;

    const amount = Number(item.manTCVoracle);

    if (isSold) {
      for (const [q, months] of Object.entries(quarters)) {
        if (months.includes(month)) {
          payload['Won (Booked till date)'][q] += amount;
          if (isEbus) payload['Recurring'][q + 'Ebus'] += amount;
          if (isNbus) payload['New Business'][q + 'Nbus'] += amount;
        }
      }
    }
     if (ispipeN) {
      for (const [q, months] of Object.entries(quarters)) {
        if (months.includes(month)) {
          payload['UnWt. Upside'][q] += amount;
          if (isEbus) payload['Recurring2'][q + 'Ebus'] += amount;
          if (isNbus) payload['New Business2'][q + 'Nbus'] += amount;
        }
      }
    }
     if (ispipeY) {
      for (const [q, months] of Object.entries(quarters)) {
        if (months.includes(month)) {
          payload['Forecast / Named Likely'][q] += amount;
          if (isEbus) payload['Recurring3'][q + 'Ebus'] += amount;
          if (isNbus) payload['New Business3'][q + 'Nbus'] += amount;
        }
      }
    }
     if (ispipe) {
      for (const [q, months] of Object.entries(quarters)) {
        if (months.includes(month)) {
          payload['Wt. Upside'][q] += wtbkg;
          if (isEbus) payload['Recurring4'][q + 'Ebus'] += wtbkg;
          if (isNbus) payload['New Business4'][q + 'Nbus'] += wtbkg;
        }
      }
    }

    
  }
  console.log(">>",payload);
  
 

const data = [];
var payload01={};
var payload02={};
for(var i=0; i<revenueBO.length; i++){
if(inputPillar==''){
  inputPillar='All';
}

if(revenueBO[i].summary=='Ambition Assignment' && revenueBO[i].pillar==inputPillar){
payload01['Summary']='Ambition Assignment';
payload01['Q1']=(revenueBO[i].jan+revenueBO[i].feb+revenueBO[i].mar)/1000000;
payload01['Q2']=(revenueBO[i].apr+revenueBO[i].may+revenueBO[i].jun)/1000000;
payload01['H1']=Number(payload01['Q1'])+Number(payload01['Q2']);
payload01['Q3']=(revenueBO[i].jul+revenueBO[i].aug+revenueBO[i].sep)/1000000;
payload01['Q4']=(revenueBO[i].oct+revenueBO[i].nov+revenueBO[i].dec1)/1000000;
payload01['H2']=Number(payload01['Q3'])+Number(payload01['Q4']);
payload01['FY']=Number(payload01['H1'])+Number(payload01['H2']);
data.push(payload01);
}
else if(revenueBO[i].summary=='Budget' && revenueBO[i].pillar==inputPillar){

payload02['Summary']='Budget';
payload02['Q1']=(revenueBO[i].jan+revenueBO[i].feb+revenueBO[i].mar)/1000000;
payload02['Q2']=(revenueBO[i].apr+revenueBO[i].may+revenueBO[i].jun)/1000000;
payload02['H1']=Number(payload02['Q1'])+Number(payload02['Q2']);
payload02['Q3']=(revenueBO[i].jul+revenueBO[i].aug+revenueBO[i].sep)/1000000;
payload02['Q4']=(revenueBO[i].oct+revenueBO[i].nov+revenueBO[i].dec1)/1000000;
payload02['H2']=Number(payload02['Q3'])+Number(payload02['Q4']);
payload02['FY']=Number(payload02['H1'])+Number(payload02['H2']);
data.push(payload02);
}
}
var payload2={};
payload2['Summary']='Won (Booked till date)';
payload2['Q1']=(payload['Won (Booked till date)'].Q1)/1000000;
payload2['Q2']=(payload['Won (Booked till date)'].Q2)/1000000;
payload2['H1']=Number(payload2['Q1'])+Number(payload2['Q2']);
payload2['Q3']=(payload['Won (Booked till date)'].Q3)/1000000;
payload2['Q4']=(payload['Won (Booked till date)'].Q4)/1000000;
payload2['H2']=Number(payload2['Q3'])+Number(payload2['Q4']);
payload2['FY']=Number(payload2['H1'])+Number(payload2['H2']);
data.push(payload2);
var payload3={};
payload3['Summary']='New Business';
payload3['Q1']=(payload['New Business'].Q1Nbus)/1000000;
payload3['Q2']=(payload['New Business'].Q2Nbus)/1000000;
payload3['H1']=Number(payload3['Q1'])+Number(payload3['Q2']);
payload3['Q3']=(payload['New Business'].Q3Nbus)/1000000;
payload3['Q4']=(payload['New Business'].Q4Nbus)/1000000;
payload3['H2']=Number(payload3['Q3'])+Number(payload3['Q4']);
payload3['FY']=Number(payload3['H1'])+Number(payload3['H2']);
data.push(payload3);
var payload4={};
payload4['Summary']='Recurring';
payload4['Q1']=(payload['Recurring'].Q1Ebus)/1000000;
payload4['Q2']=(payload['Recurring'].Q2Ebus)/1000000;
payload4['H1']=Number(payload4['Q1'])+Number(payload4['Q2']);
payload4['Q3']=(payload['Recurring'].Q3Ebus)/1000000;
payload4['Q4']=(payload['Recurring'].Q4Ebus)/1000000;
payload4['H2']=Number(payload4['Q3'])+Number(payload4['Q4']);
payload4['FY']=Number(payload4['H1'])+Number(payload4['H2']);
data.push(payload4);

var payload5={};
payload5['Summary']='Forecast / Named Likely';
payload5['Q1']=(payload['Forecast / Named Likely'].Q1)/1000000;
payload5['Q2']=(payload['Forecast / Named Likely'].Q2)/1000000;
payload5['H1']=Number(payload5['Q1'])+Number(payload5['Q2']);
payload5['Q3']=(payload['Forecast / Named Likely'].Q3)/1000000;
payload5['Q4']=(payload['Forecast / Named Likely'].Q4)/1000000;
payload5['H2']=Number(payload5['Q3'])+Number(payload5['Q4']);
payload5['FY']=Number(payload5['H1'])+Number(payload5['H2']);
data.push(payload5);

var payload6={};
payload6['Summary']='New Business';
payload6['Q1']=(payload['New Business3'].Q1Nbus)/1000000;
payload6['Q2']=(payload['New Business3'].Q2Nbus)/1000000;
payload6['H1']=Number(payload6['Q1'])+Number(payload6['Q2']);
payload6['Q3']=(payload['New Business3'].Q3Nbus)/1000000;
payload6['Q4']=(payload['New Business3'].Q4Nbus)/1000000;
payload6['H2']=Number(payload6['Q3'])+Number(payload6['Q4']);
payload6['FY']=Number(payload6['H1'])+Number(payload6['H2']);

data.push(payload6);
var payload7={};
payload7['Summary']='Recurring';
payload7['Q1']=(payload['Recurring3'].Q1Ebus)/1000000;
payload7['Q2']=(payload['Recurring3'].Q2Ebus)/1000000;
payload7['H1']=Number(payload7['Q1'])+Number(payload7['Q2']);
payload7['Q3']=(payload['Recurring3'].Q3Ebus)/1000000;
payload7['Q4']=(payload['Recurring3'].Q4Ebus)/1000000;
payload7['H2']=Number(payload7['Q3'])+Number(payload7['Q4']);
payload7['FY']=Number(payload7['H1'])+Number(payload7['H2']);
data.push(payload7);

var payload11={};
payload11['Summary']='Total (Won+Forecast)';
payload11['Q1']=Number(payload2['Q1'])+Number(payload5['Q1']);
payload11['Q2']=Number(payload2['Q2'])+Number(payload5['Q2']);
payload11['H1']=Number(payload11['Q1'])+Number(payload11['Q2']);
payload11['Q3']=Number(payload2['Q3'])+Number(payload5['Q3']);
payload11['Q4']=Number(payload2['Q4'])+Number(payload5['Q4']);
payload11['H2']=Number(payload11['Q3'])+Number(payload11['Q4']);
payload11['FY']=Number(payload11['H1'])+Number(payload11['H2']);
data.push(payload11);

var payload12={};
if(inputSummary=="Ambition Assignment"){
payload12['Summary']='Attainment against Ambition';
payload12['Q1']=Number(payload11['Q1'])/Number(payload01['Q1']);
payload12['Q2']=Number(payload11['Q2'])/Number(payload01['Q2']);
payload12['H1']=Number(payload11['H1'])/Number(payload01['H1']);
payload12['Q3']=Number(payload11['Q3'])/Number(payload01['Q3']);
payload12['Q4']=Number(payload11['Q4'])/Number(payload01['Q4']);
payload12['H2']=Number(payload11['H2'])/Number(payload01['H2']);
payload12['FY']=Number(payload11['FY'])/Number(payload01['FY']);
data.push(payload12);
}
else if(inputSummary=="Budget"){
payload12['Summary']='Attainment against Budget';
payload12['Q1']=Number(payload11['Q1'])/Number(payload02['Q1']);
payload12['Q2']=Number(payload11['Q2'])/Number(payload02['Q2']);
payload12['H1']=Number(payload11['H1'])/Number(payload02['H1']);
payload12['Q3']=Number(payload11['Q3'])/Number(payload02['Q3']);
payload12['Q4']=Number(payload11['Q4'])/Number(payload02['Q4']);
payload12['H2']=Number(payload11['H2'])/Number(payload02['H2']);
payload12['FY']=Number(payload11['FY'])/Number(payload02['FY']);
data.push(payload12);
}

var payload13={};
if(inputSummary=="Ambition Assignment"){
payload13['Summary']='Gap to Ambition';
payload13['Q1']=Number(payload11['Q1'])-Number(payload01['Q1']);
payload13['Q2']=Number(payload11['Q2'])-Number(payload01['Q2']);
payload13['H1']=Number(payload11['H1'])-Number(payload01['H1']);
payload13['Q3']=Number(payload11['Q3'])-Number(payload01['Q3']);
payload13['Q4']=Number(payload11['Q4'])-Number(payload01['Q4']);
payload13['H2']=Number(payload11['H2'])-Number(payload01['H2']);
payload13['FY']=Number(payload11['FY'])-Number(payload01['FY']);
data.push(payload13);
}
else if(inputSummary=="Budget"){
payload13['Summary']='Gap to Budget';
payload13['Q1']=Number(payload11['Q1'])-Number(payload02['Q1']);
payload13['Q2']=Number(payload11['Q2'])-Number(payload02['Q2']);
payload13['H1']=Number(payload11['H1'])-Number(payload02['H1']);
payload13['Q3']=Number(payload11['Q3'])-Number(payload02['Q3']);
payload13['Q4']=Number(payload11['Q4'])-Number(payload02['Q4']);
payload13['H2']=Number(payload11['H2'])-Number(payload02['H2']);
payload13['FY']=Number(payload11['FY'])-Number(payload02['FY']);
data.push(payload13);
}
var payloadGap1={};
payloadGap1['Summary']='';
payloadGap1['Q1']='';
payloadGap1['Q2']='';
payloadGap1['H1']='';
payloadGap1['Q3']='';
payloadGap1['Q4']='';
payloadGap1['H2']='';
payloadGap1['FY']='';
data.push(payloadGap1);



var payload20={};
payload20['Summary']='Wt. Upside';
payload20['Q1']=(payload['Wt. Upside'].Q1)/1000000;
payload20['Q2']=(payload['Wt. Upside'].Q2)/1000000;
payload20['H1']=Number(payload20['Q1'])+Number(payload20['Q2']);
payload20['Q3']=(payload['Wt. Upside'].Q3)/1000000;
payload20['Q4']=(payload['Wt. Upside'].Q4)/1000000;
payload20['H2']=Number(payload20['Q3'])+Number(payload20['Q4']);
payload20['FY']=Number(payload20['H1'])+Number(payload20['H2']);

data.push(payload20);
var payload21={};
payload21['Summary']='New Business';
payload21['Q1']=(payload['New Business4'].Q1Nbus)/1000000;
payload21['Q2']=(payload['New Business4'].Q2Nbus)/1000000;
payload21['H1']=Number(payload21['Q1'])+Number(payload21['Q2']);
payload21['Q3']=(payload['New Business4'].Q3Nbus)/1000000;
payload21['Q4']=(payload['New Business4'].Q4Nbus)/1000000;
payload21['H2']=Number(payload21['Q3'])+Number(payload21['Q4']);
payload21['FY']=Number(payload21['H1'])+Number(payload21['H2']);

data.push(payload21);
var payload22={};
payload22['Summary']='Recurring';
payload22['Q1']=(payload['Recurring4'].Q1Ebus)/1000000;
payload22['Q2']=(payload['Recurring4'].Q2Ebus)/1000000;
payload22['H1']=Number(payload22['Q1'])+Number(payload22['Q2']);
payload22['Q3']=(payload['Recurring4'].Q3Ebus)/1000000;
payload22['Q4']=(payload['Recurring4'].Q4Ebus)/1000000;
payload22['H2']=Number(payload22['Q3'])+Number(payload22['Q4']);
payload22['FY']=Number(payload22['H1'])+Number(payload22['H2']);

data.push(payload22)
var payload23={};
payload23['Summary']='Projected Landing';
payload23['Q1']=payload11['Q1']+payload20['Q1']
payload23['Q2']=payload11['Q2']+payload20['Q2']
payload23['H1']=payload11['H1']+payload20['H1']
payload23['Q3']=payload11['Q3']+payload20['Q3']
payload23['Q4']=payload11['Q4']+payload20['Q4']
payload23['H2']=payload11['H2']+payload20['H2']
payload23['FY']=payload11['FY']+payload20['FY']

data.push(payload23);
var payload24={};
if(inputSummary=="Ambition Assignment"){
payload24['Summary']='Attainment against Ambition';
payload24['Q1']=Number(payload23['Q1'])/Number(payload01['Q1']);
payload24['Q2']=Number(payload23['Q2'])/Number(payload01['Q2']);
payload24['H1']=Number(payload23['H1'])/Number(payload01['H1']);
payload24['Q3']=Number(payload23['Q3'])/Number(payload01['Q3']);
payload24['Q4']=Number(payload23['Q4'])/Number(payload01['Q4']);
payload24['H2']=Number(payload23['H2'])/Number(payload01['H2']);
payload24['FY']=Number(payload23['FY'])/Number(payload01['FY']);

data.push(payload24);
}
else if(inputSummary=="Budget"){
payload24['Summary']='Attainment against Budget';
payload24['Q1']=Number(payload23['Q1'])/Number(payload02['Q1']);
payload24['Q2']=Number(payload23['Q2'])/Number(payload02['Q2']);
payload24['H1']=Number(payload23['H1'])/Number(payload02['H1']);
payload24['Q3']=Number(payload23['Q3'])/Number(payload02['Q3']);
payload24['Q4']=Number(payload23['Q4'])/Number(payload02['Q4']);
payload24['H2']=Number(payload23['H2'])/Number(payload02['H2']);
payload24['FY']=Number(payload23['FY'])/Number(payload02['FY']);

data.push(payload24);

}
var payload25={};
if(inputSummary=="Ambition Assignment"){
payload25['Summary']='Gap to Ambition';
payload25['Q1']=Number(payload23['Q1'])-Number(payload01['Q1']);
payload25['Q2']=Number(payload23['Q2'])-Number(payload01['Q2']);
payload25['H1']=Number(payload23['H1'])-Number(payload01['H1']);
payload25['Q3']=Number(payload23['Q3'])-Number(payload01['Q3']);
payload25['Q4']=Number(payload23['Q4'])-Number(payload01['Q4']);
payload25['H2']=Number(payload23['H2'])-Number(payload01['H2']);
payload25['FY']=Number(payload23['FY'])-Number(payload01['FY']);
data.push(payload25)
}
else if(inputSummary=="Budget"){
payload25['Summary']='Gap to Budget';
payload25['Q1']=Number(payload23['Q1'])-Number(payload02['Q1']);
payload25['Q2']=Number(payload23['Q2'])-Number(payload02['Q2']);
payload25['H1']=Number(payload23['H1'])-Number(payload02['H1']);
payload25['Q3']=Number(payload23['Q3'])-Number(payload02['Q3']);
payload25['Q4']=Number(payload23['Q4'])-Number(payload02['Q4']);
payload25['H2']=Number(payload23['H2'])-Number(payload02['H2']);
payload25['FY']=Number(payload23['FY'])-Number(payload02['FY']);
data.push(payload25)
}
var payloadGap2={};
payloadGap2['Summary']='';
payloadGap2['Q1']=''
payloadGap2['Q2']=''
payloadGap2['H1']=''
payloadGap2['Q3']=''
payloadGap2['Q4']=''
payloadGap2['H2']=''
payloadGap2['FY']=''
data.push(payloadGap2)


var payload8={};
payload8['Summary']='UnWt. Upside';
payload8['Q1']=(payload['UnWt. Upside'].Q1)/1000000;
payload8['Q2']=(payload['UnWt. Upside'].Q2)/1000000;
payload8['H1']=Number(payload8['Q1'])+Number(payload8['Q2']);
payload8['Q3']=(payload['UnWt. Upside'].Q3)/1000000;
payload8['Q4']=(payload['UnWt. Upside'].Q4)/1000000;
payload8['H2']=Number(payload8['Q3'])+Number(payload8['Q4']);
payload8['FY']=Number(payload8['H1'])+Number(payload8['H2']);

data.push(payload8)
var payload9={};
payload9['Summary']='New Business';
payload9['Q1']=(payload['New Business2'].Q1Nbus)/1000000;
payload9['Q2']=(payload['New Business2'].Q2Nbus)/1000000;
payload9['H1']=Number(payload9['Q1'])+Number(payload9['Q2']);
payload9['Q3']=(payload['New Business2'].Q3Nbus)/1000000;
payload9['Q4']=(payload['New Business2'].Q4Nbus)/1000000;
payload9['H2']=Number(payload9['Q3'])+Number(payload9['Q4']);
payload9['FY']=Number(payload9['H1'])+Number(payload9['H2']);

data.push(payload9)
var payload10={};
payload10['Summary']='Recurring';
payload10['Q1']=(payload['Recurring2'].Q1Ebus)/1000000;
payload10['Q2']=(payload['Recurring2'].Q2Ebus)/1000000;
payload10['H1']=Number(payload10['Q1'])+Number(payload10['Q2']);
payload10['Q3']=(payload['Recurring2'].Q3Ebus)/1000000;
payload10['Q4']=(payload['Recurring2'].Q4Ebus)/1000000;
payload10['H2']=Number(payload10['Q3'])+Number(payload10['Q4']);
payload10['FY']=Number(payload10['H1'])+Number(payload10['H2']);

data.push(payload10)
var payload14={};
payload14['Summary']='Projected Landing';
payload14['Q1']=payload11['Q1']+payload8['Q1'];
payload14['Q2']=payload11['Q2']+payload8['Q2'];
payload14['H1']=payload11['H1']+payload8['H1'];
payload14['Q3']=payload11['Q3']+payload8['Q3'];
payload14['Q4']=payload11['Q4']+payload8['Q4'];
payload14['H2']=payload11['H2']+payload8['H2'];
payload14['FY']=payload11['FY']+payload8['FY'];

data.push(payload14)
var payload15={};
if(inputSummary=="Ambition Assignment"){
payload15['Summary']='Attainment against Ambition';
payload15['Q1']=Number(payload14['Q1'])/Number(payload01['Q1']);
payload15['Q2']=Number(payload14['Q2'])/Number(payload01['Q2']);
payload15['H1']=Number(payload14['H1'])/Number(payload01['H1']);
payload15['Q3']=Number(payload14['Q3'])/Number(payload01['Q3']);
payload15['Q4']=Number(payload14['Q4'])/Number(payload01['Q4']);
payload15['H2']=Number(payload14['H2'])/Number(payload01['H2']);
payload15['FY']=Number(payload14['FY'])/Number(payload01['FY']);

data.push(payload15);
}
else if(inputSummary=="Budget"){
payload15['Summary']='Attainment against Budget';
payload15['Q1']=Number(payload14['Q1'])/Number(payload02['Q1']);
payload15['Q2']=Number(payload14['Q2'])/Number(payload02['Q2']);
payload15['H1']=Number(payload14['H1'])/Number(payload02['H1']);
payload15['Q3']=Number(payload14['Q3'])/Number(payload02['Q3']);
payload15['Q4']=Number(payload14['Q4'])/Number(payload02['Q4']);
payload15['H2']=Number(payload14['H2'])/Number(payload02['H2']);
payload15['FY']=Number(payload14['FY'])/Number(payload02['FY']);

data.push(payload15);
}
var payload16={};
if(inputSummary=="Ambition Assignment"){
payload16['Summary']='Gap to Ambition';
payload16['Q1']=Number(payload14['Q1'])+Number(payload01['Q1']);
payload16['Q2']=Number(payload14['Q2'])+Number(payload01['Q2']);
payload16['H1']=Number(payload14['H1'])+Number(payload01['H1']);
payload16['Q3']=Number(payload14['Q3'])+Number(payload01['Q3']);
payload16['Q4']=Number(payload14['Q4'])+Number(payload01['Q4']);
payload16['H2']=Number(payload14['H2'])+Number(payload01['H2']);
payload16['FY']=Number(payload14['FY'])+Number(payload01['FY']);
data.push(payload16);
}
else if(inputSummary=="Budget"){
payload16['Summary']='Gap to Budget';
payload16['Q1']=Number(payload14['Q1'])+Number(payload02['Q1']);
payload16['Q2']=Number(payload14['Q2'])+Number(payload02['Q2']);
payload16['H1']=Number(payload14['H1'])+Number(payload02['H1']);
payload16['Q3']=Number(payload14['Q3'])+Number(payload02['Q3']);
payload16['Q4']=Number(payload14['Q4'])+Number(payload02['Q4']);
payload16['H2']=Number(payload14['H2'])+Number(payload02['H2']);
payload16['FY']=Number(payload14['FY'])+Number(payload02['FY']);
data.push(payload16);

}
console.log("22#",data);
return data;

  }
  }

  PageModule.prototype.revenue=function(revenueObject,total){
   total.totalRevenue=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar)+parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun)+parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep)+parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
   total.Q1=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar);
   total.Q2=parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun);
   total.Q3=parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep);
   total.Q4=parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
   total.H1=total.Q1+total.Q2;
   total.H2=total.Q3+total.Q4;

   return total;
  };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
  PageModule.prototype.AllrevenueAmbition=function(revenueObject,Bo){
  for(var i=0; i<Bo.length; i++){
  if (Bo[i].summary=='Ambition Assignment'){
    revenueObject.jan+=Bo[i].jan;
    revenueObject.feb+=Bo[i].feb;
    revenueObject.mar+=Bo[i].mar;
    revenueObject.apr+=Bo[i].apr;
    revenueObject.may+=Bo[i].may;
    revenueObject.jun+=Bo[i].jun;
    revenueObject.jul+=Bo[i].jul;
    revenueObject.aug+=Bo[i].aug;
    revenueObject.sep+=Bo[i].sep;
    revenueObject.oct+=Bo[i].oct;
    revenueObject.nov+=Bo[i].nov;
    revenueObject.dec1+=Bo[i].dec1;
  }
  
  }
  console.log("44#",revenueObject);
  };
  PageModule.prototype.AllrevenueBudget=function(revenueObject,Bo){
  for(var i=0; i<Bo.length; i++){
  if (Bo[i].summary=='Budget'){
    revenueObject.jan+=Bo[i].jan;
    revenueObject.feb+=Bo[i].feb;
    revenueObject.mar+=Bo[i].mar;
    revenueObject.apr+=Bo[i].apr;
    revenueObject.may+=Bo[i].may;
    revenueObject.jun+=Bo[i].jun;
    revenueObject.jul+=Bo[i].jul;
    revenueObject.aug+=Bo[i].aug;
    revenueObject.sep+=Bo[i].sep;
    revenueObject.oct+=Bo[i].oct;
    revenueObject.nov+=Bo[i].nov;
    revenueObject.dec1+=Bo[i].dec1;
  }
  
  }
  console.log("44#",revenueObject);
  };
  
  return PageModule;
});
