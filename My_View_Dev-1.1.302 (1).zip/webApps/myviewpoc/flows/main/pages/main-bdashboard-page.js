define([], () => {
  'use strict';

  let PageModule = function PageModule() { };

  PageModule.prototype.trainingfun = function (trainingbo) {
    let retpayload = {}
    let data = [];
    let trn = trainingbo.filter(ele => ele.l1Certified == 'yes').length;    //trn    tn
    let tn = trainingbo.filter(ele => ele.l2Certified == 'yes').length;     //trn1   tn1

    retpayload['status'] = 'Completed';
    retpayload['L1'] = trn;
    retpayload['L2'] = tn;
    data.push(retpayload);
    retpayload = {};

    let trn1 = trainingbo.filter(ele => ele.l1Certified == 'No').length;
    let tn1 = trainingbo.filter(ele => ele.l2Certified == 'No').length;
    retpayload['status'] = 'Not Completed';
    retpayload['L1'] = trn1;
    retpayload['L2'] = tn1;
    data.push(retpayload);
    retpayload = {};

    let trn2 = Math.round((trn / (trn1 + trn)) * 100);
    let tn2 = Math.round((tn / (tn1 + tn)) * 100);
    retpayload['status'] = '% Completed'
    retpayload['L1'] = `${trn2}%`;
    retpayload['L2'] = `${tn2}%`;
    data.push(retpayload);
    retpayload = {};

    let trn3 = Math.round((trn1 / (trn1 + trn)) * 100);
    let tn3 = Math.round((tn1 / (tn + tn1)) * 100);
    retpayload['status'] = '% Not Completed';
    retpayload['L1'] = `${trn3}%`;
    retpayload['L2'] = `${tn3}%`;
    data.push(retpayload);
    retpayload = {};

    retpayload['status'] = 'total';
    retpayload['L1'] = trn + trn1;
    retpayload['L2'] = tn + tn1;
    data.push(retpayload);
    return data;



  };




  return PageModule;
});
