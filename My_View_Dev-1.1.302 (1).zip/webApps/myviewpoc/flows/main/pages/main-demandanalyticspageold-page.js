define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  //CHANGING DATE FORMAT TO YYYY-MM-DD
  function changeFormat(currentDate) {
    try{
   
      var now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
   
    }
    catch(err){
       console.log('#131'+currentDate);
      return currentDate;
    }
  }

  PageModule.prototype.demandAnalyticsDataCreate = function(P_demandBO){
    // console.log(P_demandBO);
    var initData = [];
    var finalData = [];
        finalData['Total'] = [];
        
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0, row11=0, row12=0, row13=0, row14=0, row15=0, row16=0;

    for(var i=0; i<P_demandBO.length; i++){
      var row = {};
      
      // P_demandBO[0].roleStartDate
      var net_total=0, sold_total=0, pursuit_total=0, strategic_total=0;
      row['capability'] = P_demandBO[i].globalPracticeObject.items[0].name;
      row['skillGroups'] = P_demandBO[i].skillGroupObject.items[0].skillGroupName;
      row['roleStartDate'] = P_demandBO[i].roleStartDate;
      row['demandType'] = P_demandBO[i].demandType;

      initData.push(row);
    }
    var d = new Date();
    var curr_month = d.getMonth()+1;

    for (i=0; i<initData.length; i++){
      
      var roleStartDate = new Date(initData[i]['roleStartDate']);
      var month = roleStartDate.getMonth()+1;
      
      var element  = finalData.find(function(data){return data.capability == initData[i].capability && data.skillGroups == initData[i].skillGroups;});
    
      if(element == undefined){
        console.log("Insert");

        var temp = {};

        temp['capability'] = initData[i].capability;
        temp['skillGroups'] = initData[i].skillGroups;
        temp['sold_current_due'] = 0;
        temp['sold_next_due'] = 0;
        temp['sold_future_due'] = 0;
        temp['sold_past_due'] = 0;
        temp['sold_total'] = 0;
        temp['pursuit_current_due'] = 0;
        temp['pursuit_next_due'] = 0;
        temp['pursuit_future_due'] = 0;
        temp['pursuit_past_due'] = 0;
        temp['pursuit_total'] = 0;
        temp['strategic_current_due'] = 0;
        temp['strategic_next_due'] = 0;
        temp['strategic_future_due'] = 0;
        temp['strategic_past_due'] = 0;
        temp['strategic_total'] = 0;
        

        


        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month){
            temp['sold_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['sold_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['sold_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['sold_past_due'] = 1;
          }
          
          temp['sold_total'] = 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            temp['pursuit_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['pursuit_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['pursuit_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['pursuit_past_due'] = 1;
          }
          
          temp['pursuit_total'] = 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            temp['strategic_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['strategic_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['strategic_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['strategic_past_due'] = 1;
          }
           
          temp['strategic_total'] = 1;
        }

        temp['net_demands'] = temp['sold_total'] + temp['pursuit_total'] + temp['strategic_total'];
        finalData.push(temp);
      }
        
      else{
        console.log("Update");
        var index = finalData.findIndex(function(data){return data.capability == element.capability && data.skillGroups == element.skillGroups;});
       

        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month){
            finalData[index]['sold_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['sold_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['sold_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['sold_past_due'] += 1;
          }
          
          finalData[index]['sold_total'] += 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            finalData[index]['pursuit_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['pursuit_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['pursuit_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['pursuit_past_due'] += 1;
          }
          
          finalData[index]['pursuit_total'] += 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            finalData[index]['strategic_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['strategic_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['strategic_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['strategic_past_due'] += 1;
          }
          
          finalData[index]['strategic_total'] += 1;
        }

        finalData[index]['net_demands'] = finalData[index]['sold_total'] + finalData[index]['pursuit_total'] + finalData[index]['strategic_total'];
      }
      // if(P_demandBO[0].demandType)
    }

    for (var i=0; i<finalData.length; i++){
      row1 += finalData[i].sold_past_due;
      row2 += finalData[i].sold_current_due;
      row3 += finalData[i].sold_next_due;
      row4 += finalData[i].sold_future_due;
      row5 += finalData[i].sold_total;
      row6 += finalData[i].pursuit_past_due;
      row7 += finalData[i].pursuit_current_due;
      row8 += finalData[i].pursuit_next_due;
      row9 += finalData[i].pursuit_future_due;
      row10 += finalData[i].pursuit_total;
      row11 += finalData[i].strategic_past_due;
      row12 += finalData[i].strategic_current_due;
      row13 += finalData[i].strategic_next_due;
      row14 += finalData[i].strategic_future_due;
      row15 += finalData[i].strategic_total;
      row16 += finalData[i].net_demands;
    }

    var temp = {};
    temp['capability'] = "";
    temp['skillGroups'] = "Total";
    temp['sold_current_due'] = row2;
    temp['sold_next_due'] = row3;
    temp['sold_future_due'] = row4;
    temp['sold_past_due'] = row1;
    temp['sold_total'] = row5;
    temp['pursuit_current_due'] = row7;
    temp['pursuit_next_due'] = row8;
    temp['pursuit_future_due'] = row9;
    temp['pursuit_past_due'] = row6;
    temp['pursuit_total'] = row10;
    temp['strategic_current_due'] = row12;
    temp['strategic_next_due'] = row13;
    temp['strategic_future_due'] = row14;
    temp['strategic_past_due'] = row11;
    temp['strategic_total'] = row15;
    temp['net_demands'] = row16;

    finalData['Total'].push(temp);

    finalData['currentMonth'] = monthNames[curr_month-1];
    finalData['nextMonth'] = monthNames[curr_month];
    finalData['future'] = monthNames[curr_month+1]+'+';
   
    console.log(finalData);
    return finalData;
  };
  
  PageModule.prototype.analyticsReportData = function(P_BUSearch, P_ClientSearch, P_StatusSearch, P_CapabSearch, P_SkillSearch){
    var retPayload = {};

    if(P_BUSearch == undefined || P_BUSearch == 'Oic.user'){
      retPayload['bu'] = '';
    }
    else{
      retPayload['bu'] = P_BUSearch;
    }

    if(P_ClientSearch == undefined){
      retPayload['client'] = '';
    }
    else{
      retPayload['client'] = P_ClientSearch;
    }

    if(P_StatusSearch == undefined){
      retPayload['status'] = '';
    }
    else{
      retPayload['status'] = P_StatusSearch;
    }

    if(P_CapabSearch == undefined){
      retPayload['capab'] = '';
    }
    else{
      retPayload['capab'] = P_CapabSearch;
    }

    if(P_SkillSearch == undefined){
      retPayload['skill'] = '';
    }
    else{
      retPayload['skill'] = P_SkillSearch;
    }

    return retPayload;
  };

  PageModule.prototype.selectedAnalyticsData = function (P_Data, P_type, P_Capab, P_Skill){
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    var d = new Date();
    var curr_month = d.getMonth();

    var finalData=[];

    for(var i=0; i<P_Data.length; i++){

      if(P_Data[i].globalPracticeObject.items[0].name == P_Capab && P_Data[i].skillGroupObject.items[0].skillGroupName == P_Skill){
        var roleStartDate = new Date(P_Data[i]['roleStartDate']);
        var month = roleStartDate.getMonth();
        var temp={};

        finalData['capability'] = P_Capab;
        finalData['skillGroup'] = P_Skill;
        

        switch(P_type){
          case 's_past':
            if(P_Data[i]['demandType'] == 'Sold Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
              
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;
              
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'net_demands':
            temp['trn'] = P_Data[i].teamRequestNumber;
            temp['sector'] = P_Data[i].sectorObject.items[0].name;
            temp['client'] = P_Data[i].clientObject.items[0].clientName;
            temp['project'] = P_Data[i].projectName;
            temp['position'] = P_Data[i].positionName;
            temp['roleNotes'] = P_Data[i].roleNotes;
            temp['status'] = P_Data[i].status;

            finalData['role'] = 'All';
            finalData.push(temp);
          
        }
      }
      else if(P_Skill == 'Total'){
        var roleStartDate1 = new Date(P_Data[i]['roleStartDate']);
        var month1 = roleStartDate1.getMonth();
        var temp1 = {};

        finalData['capability'] = 'All'
        finalData['skillGroup'] = 'All';

        switch(P_type){
          case 's_past':

            console.log(P_Data[i].demandType);
            console.log(month1);


            if(P_Data[i]['demandType'] == 'Sold Project' && month1 < curr_month){
              console.log('Inside');
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
              
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;
              
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'net_demands':
            temp1['trn'] = P_Data[i].teamRequestNumber;
            temp1['sector'] = P_Data[i].sectorObject.items[0].name;
            temp1['client'] = P_Data[i].clientObject.items[0].clientName;
            temp1['project'] = P_Data[i].projectName;
            temp1['position'] = P_Data[i].positionName;
            temp1['roleNotes'] = P_Data[i].roleNotes;
            temp1['status'] = P_Data[i].status;

            finalData['role'] = 'All';
            finalData.push(temp1);
          
        }
      }
    }
    console.log(finalData);
    return finalData;
  };

  PageModule.prototype.internalSupplyData = function(P_Emp, P_Alloc, P_Type, P_Skill){
    var retPayload = [];
    if(P_Alloc.length >0){
      var alloc = P_Alloc.reduce((p, c) => p.value > c.value ? p : c);

      if(alloc != undefined){
        var availableDate = new Date(alloc.allocationEndDate);
        availableDate.setDate(availableDate.getDate() + 1); 

        var temp = {};
        temp['id'] = P_Emp[0].employeeID;
        temp['name'] = P_Emp[0].name;
        temp['grade'] = P_Emp[0].localGrade;
        temp['type'] = P_Type;
        temp['status'] = P_Emp[0].status;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[0].globalPracticeObject.items[0].name;
        temp['skill'] = P_Skill;
        temp['loc'] = P_Emp[0].locationObject.items[0].location;

        retPayload.push(temp);
      }
    }

    return retPayload;
  };

  PageModule.prototype.externalSupplyData = function(P_SupplyData, P_Type, P_Skill){
    var retPayload = [];
    var temp1 = {};

    temp1['pID'] = P_SupplyData[0].profileID;
    temp1['pName'] = P_SupplyData[0].name;
    temp1['pGrade'] = P_SupplyData[0].recommendedGrade ? P_SupplyData.recommendedGrade : '';
    temp1['pType'] = P_Type;
    temp1['pStatus'] = P_SupplyData[0].status;
    temp1['doj'] = P_SupplyData[0].doj;
    temp1['pCapab'] = P_SupplyData[0].capabilityObject.items[0].name;
    temp1['pSkill'] = P_Skill;
    temp1['pLoc'] = P_SupplyData[0].location;

    retPayload.push(temp1);

    return retPayload;
  };

  PageModule.prototype.checkAvailabilityData = function(P_DemandLinkBO, P_EmployeeBO, P_AllocationBO, P_SupplyBO, P_Skill){
    var retPayload = [];

    retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
    retPayload['external'] = [];

    for(var i=0; i<P_EmployeeBO.length; i++){
      var link = P_DemandLinkBO.find(function(link){return link.employeeID != null && link.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID;});
      // var link = P_DemandLinkBO.find(ln => ln.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
      if(link != undefined){
        if(link.allocationType != 'LOCKED'){
          var allocArray = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
          
          if(allocArray.length >0){
            var alloc = allocArray.reduce((p, c) => p.value > c.value ? p : c);

            if(alloc != undefined){
              var availableDate = new Date(alloc.allocationEndDate);
              availableDate.setDate(availableDate.getDate() + 1); 

              var temp = {};

              temp['globalID'] = P_EmployeeBO[i].globalEmployeeID;
              temp['employeeID'] = P_EmployeeBO[i].employeeID;
              temp['name'] = P_EmployeeBO[i].name;
              temp['grade'] = P_EmployeeBO[i].localGrade;
              temp['billable'] = P_EmployeeBO[i].billable;
              temp['status'] = P_EmployeeBO[i].status;
              temp['sector'] = P_EmployeeBO[i].buObject.items[0].name;
              temp['client'] = alloc.clientObject.items[0].clientName;
              temp['project'] = alloc.projectObject.items[0].projectCode;
              temp['pName'] = alloc.projectObject.items[0].projectName;
              temp['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
              temp['skill'] = P_Skill;

              if(temp.billable == 'Billable'){
                var avail_date = availableDate.getDate();
                var today = new Date();
                var curr_date = today.getDate();

                if(avail_date - curr_date <= 31){
                  temp['available'] = changeFormat(availableDate);
                  retPayload['internalb'].push(temp);
                }
              }
              else{
                temp['available'] = changeFormat(availableDate);
                retPayload['internalnb'].push(temp);
              }
            }
          }
        }
      }
      else{
        var allocArray1 = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
        
        if(allocArray1.length > 0){
          var alloc1 = allocArray1.reduce((p, c) => p.lastUpdateDate > c.lastUpdateDate ? p : c);

          if(alloc1 != undefined){
            var availableDate1 = new Date(alloc1.allocationEndDate);
            availableDate1.setDate(availableDate1.getDate() + 1);

            var temp1 = {};

            temp1['globalID'] = P_EmployeeBO[i].globalEmployeeID;
            temp1['employeeID'] = P_EmployeeBO[i].employeeID;
            temp1['name'] = P_EmployeeBO[i].name;
            temp1['grade'] = P_EmployeeBO[i].localGrade;
            temp1['billable'] = P_EmployeeBO[i].billable;
            temp1['status'] = P_EmployeeBO[i].status;
            temp1['sector'] = P_EmployeeBO[i].buObject.items[0].name;
            temp1['client'] = alloc1.clientObject.items[0].clientName;
            temp1['project'] = alloc1.projectObject.items[0].projectCode;
            temp1['pName'] = alloc1.projectObject.items[0].projectName;
            temp1['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
            temp1['skill'] = P_Skill;

            if(temp1.billable == 'Billable'){
              var avail_date1 = availableDate1.getDate();
              var today1 = new Date();
              var curr_date1 = today1.getDate();

              if(avail_date1 - curr_date1 <= 30){
                temp1['available'] = changeFormat(availableDate1);
                retPayload['internalb'].push(temp1);
              }
            }
            else{
              temp1['available'] = changeFormat(availableDate1);
              retPayload['internalnb'].push(temp1);
            }
          }
        }
      }
    }

    for(var j=0; j<P_SupplyBO.length; j++){
      var link1 = P_DemandLinkBO.find(function(link){return link.supplyID != null && link.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID});
      // var link1 = P_DemandLinkBO.find(ln => ln.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID);
      if(link1 != undefined){
        if(link1.allocationType != 'LOCKED'){
          var st = P_SupplyBO[j].status;
          if(!(st.includes('Rejected') || st.includes('Declined') || st.includes('Drop'))){
            var temp2 = {};
            temp2['pID'] = P_SupplyBO[j].profileID;
            temp2['pName'] = P_SupplyBO[j].name;
            temp2['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
            temp2['pStatus'] = P_SupplyBO[j].status;
            temp2['doj'] = P_SupplyBO[j].doj;
            temp2['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
            temp2['pSkill'] = P_Skill;
            temp2['pLoc'] = P_SupplyBO[j].location;

            retPayload['external'].push(temp2);
          }
        }
      }
      else{
        var st1 = P_SupplyBO[j].status;
        if(!(st1.includes('Rejected') || st1.includes('Declined') || st1.includes('Drop'))){
          var temp3 = {};
          temp3['pID'] = P_SupplyBO[j].profileID;
          temp3['pName'] = P_SupplyBO[j].name;
          temp3['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
          temp3['pStatus'] = P_SupplyBO[j].status;
          temp3['doj'] = P_SupplyBO[j].doj;
          temp3['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
          temp3['pSkill'] = P_Skill;
          temp3['pLoc'] = P_SupplyBO[j].location;

          retPayload['external'].push(temp3);
        }
      }
    }

    console.log(retPayload);

    return retPayload;
  };

  // PageModule.prototype.reset = function(){
  //   var retPayload = [];

  //   retPayload['internal'] = [];
  //   retPayload['external'] = [];
    
  //   retPayload['internalb'] = [];
  //   retPayload['internalnb'] = [];
  //   retPayload['checkExternal'] = [];

  //   return retPayload;
  // };

  return PageModule;
});
