define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
   PageModule.prototype.returnVisibillity=function(roleAccessArray,screen,type){
      var data=roleAccessArray.find(element=>element.functionality==screen)
      if(data.accessType==type)
      {
        return false;
      }
      else{
      return true;
      }

  }
 PageModule.prototype.downloadDetails=function(employeeData,metaDataArray,bu){
  
  var multidata = new Array();

  for(let i = 0;i<=employeeData.length;i++)
  {
    var instanceArray = []; 
    if(i == 0) {
      instanceArray.push('BusinessUnit');
      instanceArray.push('Client Name');
      instanceArray.push('Geo');
      multidata.push(instanceArray);
    }
    else {
      let buItem = bu.find(element => element.id == employeeData[i - 1].businessUnitID);
      let buname = buItem ? buItem.name : "Unknown Business Unit";

       instanceArray.push(buname);
        instanceArray.push(employeeData[i-1].clientName);
       instanceArray.push(employeeData[i-1].geo);
       multidata.push(instanceArray);
   }
   
   }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Client Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Client Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
console.log(fileBytes);
var blob = new Blob([fileBytes],{type:'octet/stream'});
var filename = "Client_Details"+new Date().toISOString().split('T')[0]+".xlsx";

 
if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
} else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
 }
  function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
  }
  return PageModule;
});
