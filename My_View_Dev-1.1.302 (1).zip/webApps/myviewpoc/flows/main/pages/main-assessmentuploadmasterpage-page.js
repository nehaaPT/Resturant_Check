define([], () => {
  'use strict';

 var PageModule = function PageModule() {};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uploadXL = function (excelData,topicBO,testMasterType,courseBO,curBO,curTypeBO) {
    var readExcelPromise = new Promise(resolve=> {
      var excelFile = excelData[0];
      var size;
      var reader = new FileReader();
      reader.onload = function (e) {
        var data = e.target.result;
        // var excelPayloadArray = new Array();
        var workBook = XLSX.read(data, { type: 'binary'});
        var allSheets = workBook.SheetNames;
        size = allSheets.size;
        for (var i = 0; i < allSheets.length; i++) {
          var sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);
          var metadata; 
          for (var index = 0; index < sheetRows.length; index++) {
              var parsedSheetRows=sheetRows[index];
          // var innerArray = [];
          
                var retpayload={};
                 var status = Boolean;
                
                 if(parsedSheetRows['Category'] == undefined) {
                  retpayload['category'] = null;
                  testMasterType.failureArray.push(retpayload);
                };
                 if(parsedSheetRows['Correct Answer'] == undefined) {
                  retpayload['correctAnswer'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Level'] == undefined) {
                  retpayload['qLevel'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Q type '] == undefined) {
                  retpayload['qType'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Q text'] == undefined) {
                  retpayload['qtext'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Skill'] == undefined) {
                  retpayload['skill'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['SubSkill'] == undefined) {
                  retpayload['subSkill'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Sub Topic'] == undefined) {
                  retpayload['subTopic'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Topic'] == undefined) {
                  retpayload['topic'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Course'] == undefined) {
                  retpayload['course'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Curriculum'] == undefined) {
                  retpayload['curriculum'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Curriculum Type'] == undefined) { 
                  retpayload['curriculumType'] = null;
                  testMasterType.failureArray.push(retpayload);
                  status = true;
                };
                if(status != true) {
                retpayload['category'] = parsedSheetRows['Category'];
                 retpayload['correctAnswer'] = parsedSheetRows['Correct Answer'];
                 retpayload['option1'] = parsedSheetRows['Option/ Answer 1'];
                 retpayload['option2'] = parsedSheetRows['Option/ Answer 2'];
                 retpayload['option3'] = parsedSheetRows['Option/ Answer 3'];
                 retpayload['option4'] = parsedSheetRows['Option/ Answer 4'];
                 retpayload['qLevel'] = parsedSheetRows['Level'];
                 retpayload['qType'] = parsedSheetRows['Q type '];
                 retpayload['qText'] = parsedSheetRows['Q text'];
                 retpayload['skill'] = parsedSheetRows['Skill'];
                 retpayload['subSkill'] = parsedSheetRows['SubSkill'];
                 retpayload['subTopic'] = parsedSheetRows['Sub Topic'];
                 var topic=parsedSheetRows['Topic'].replace(/[\r\n|\n|\r|\\"]/g,'').trim();
                 retpayload['topic'] = topicBO.find(ele=>ele.topic==topic)?topicBO.find(ele=>ele.topic==topic).id:'';
                 var course=parsedSheetRows['Course'];
                 retpayload['course'] = courseBO.find(ele=>ele.course==course)?courseBO.find(ele=>ele.course==course).id:'';
                 var curriculum=parsedSheetRows['Curriculum'];
                 retpayload['curriculum'] = curBO.find(ele=>ele.curriculum==curriculum)?curBO.find(ele=>ele.curriculum==curriculum).id:'';
                 var curriculumType=parsedSheetRows['Curriculum Type'];
                 retpayload['curriculumType'] = curTypeBO.find(ele=>ele.curriculumType==curriculumType)?curTypeBO.find(ele=>ele.curriculumType==curriculumType).id:'';
                 testMasterType.successArray.push(retpayload);
                //  excelPayloadArray.push(retpayload);
                
                };
             //console.log('JSON'+JSON.stringify(sheetRows[index]));
             console.log("!!!",testMasterType);
          };
        };
        
        resolve(testMasterType);
      };
      reader.readAsBinaryString(excelFile);
      console.log(size);
   });
    
   //console.log("!!!",readExcelPromise);
   //console.log("!!!",excelPayloadArray);
    return testMasterType;
  };

PageModule.prototype.uploadXLforCategory = function (excelData,topicBO,testCategory,courseBO,curBO,curTypeBO,testCatBO) {
    console.log("!!!",excelData);
    var readExcelPromise = new Promise(resolve=> {
      var excelFile = excelData[0];
      var size;
      var reader = new FileReader();
      reader.onload = function (e) {
        var data = e.target.result;
        // var excelPayloadArray = new Array();
        var workBook = XLSX.read(data, { type: 'binary'});
        var allSheets = workBook.SheetNames;
        size = allSheets.size;
        for (var i = 0; i < allSheets.length; i++) {
          var sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);
          var metadata; 
          for (var index = 0; index < sheetRows.length; index++) {
              var parsedSheetRows=sheetRows[index];
          // var innerArray = [];
          
                var retpayload={};
                 var status = Boolean;
                 var cor=parsedSheetRows['Course'].replace(/[\r\n|\n|\r|\\"]/g,'').trim();
                 console.log("!!!",cor);
                 var cour = courseBO.find(ele=>ele.course==cor).id;
                 console.log("!!!",cour);
                 if(testCatBO.find(ele=>ele.course==cour)) {
                   retpayload['alreadyExist'] = null;
                   testCategory.failureArray.push(retpayload);
                   continue;
                 }
                 if(parsedSheetRows['Simple (%)'] == undefined) {
                  retpayload['simplePercentage'] = null;
                  testCategory.failureArray.push(retpayload);
                };
                 if(parsedSheetRows['Medium (%)'] == undefined) {
                  retpayload['mediumPercentage'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Complex (%)'] == undefined) {
                  retpayload['complexPercentage'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['No. of Questions'] == undefined) {
                  retpayload['noOfQuestions'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Marks per Questions'] == undefined) {
                  retpayload['marksPerQuestions'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Passing Percentage'] == undefined) {
                  retpayload['passingPercentage'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(100 > parsedSheetRows['Simple (%)'] + parsedSheetRows['Medium (%)'] + parsedSheetRows['Complex (%)'] > 100) {
                  retpayload['total'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                // if(parsedSheetRows['Sub Topic'] == undefined) {
                //   retpayload['subTopic'] = null;
                //   testMasterType.failureArray.push(retpayload);
                //   status = true;
                // };
                if(parsedSheetRows['Topic'] == undefined) {
                  retpayload['topic'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Course'] == undefined) {
                  retpayload['course'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Curriculum'] == undefined) {
                  retpayload['curriculum'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(parsedSheetRows['Curriculum Type'] == undefined) { 
                  retpayload['curriculumType'] = null;
                  testCategory.failureArray.push(retpayload);
                  status = true;
                };
                if(status != true) {
                retpayload['simplePercentage'] = parsedSheetRows['Simple (%)'];
                 retpayload['mediumPercentage'] = parsedSheetRows['Medium (%)'];
                 retpayload['complexPercentage'] = parsedSheetRows['Complex (%)'];
                 retpayload['noOfQuestions'] = parsedSheetRows['No. of Questions'];
                 retpayload['marksPerQuestions'] = parsedSheetRows['Marks per Questions'];
                 retpayload['passingPercentage'] = parsedSheetRows['Passing Percentage'];
                //  retpayload['qLevel'] = parsedSheetRows['Level'];
                //  retpayload['qType'] = parsedSheetRows['Q type '];
                //  retpayload['qText'] = parsedSheetRows['Q text'];
                //  retpayload['skill'] = parsedSheetRows['Skill'];
                //  retpayload['subSkill'] = parsedSheetRows['SubSkill'];
                //  retpayload['subTopic'] = parsedSheetRows['Sub Topic'];
                 var topic=parsedSheetRows['Topic'].replace(/[\r\n|\n|\r|\\"]/g,'').trim();
                 retpayload['testName'] = topicBO.find(ele=>ele.topic==topic)?topicBO.find(ele=>ele.topic==topic).id:'';
                 var course=parsedSheetRows['Course'];
                 retpayload['course'] = courseBO.find(ele=>ele.course==course)?courseBO.find(ele=>ele.course==course).id:'';
                 var curriculum=parsedSheetRows['Curriculum'];
                 retpayload['curriculum'] = curBO.find(ele=>ele.curriculum==curriculum)?curBO.find(ele=>ele.curriculum==curriculum).id:'';
                 var curriculumType=parsedSheetRows['Curriculum Type'];
                 retpayload['curriculumType'] = curTypeBO.find(ele=>ele.curriculumType==curriculumType)?curTypeBO.find(ele=>ele.curriculumType==curriculumType).id:'';
                 testCategory.successArray.push(retpayload);
                //  excelPayloadArray.push(retpayload);
                
                };
             //console.log('JSON'+JSON.stringify(sheetRows[index]));
             //console.log("!!!",testCategory);
          };
        };
        
        resolve(testCategory);
      };
      reader.readAsBinaryString(excelFile);
      console.log(size);
   });
    
   //console.log("!!!",readExcelPromise);
   //console.log("!!!",excelPayloadArray);
   console.log("!!!",testCategory);
    return testCategory;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.logBOFunction = function (uploadUser,uploadedsuccessArray,uploadederrorArray,uploadType) {
    //console.log("!!!",uploadedsuccessArray);
    //console.log("!!!",uploadederrorArray);
    var returnObj = {};
    returnObj['failureCount'] = uploadederrorArray.length;
    returnObj['succesCount'] = uploadedsuccessArray.length;
    returnObj['totalCount'] = uploadederrorArray.length + uploadedsuccessArray.length;
    returnObj['uploadType'] = uploadType;
    returnObj['uploadUser'] = uploadUser;

  //console.log("!!!",returnObj);
  return returnObj;
 };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.errorLogFunctionForTrainingTestMaster = function (errorLogArray,uploadLog) {
    var returnArray = [];
    for(var i = 0; i < errorLogArray.length; i++) {
      var innerObj = {};
      if(errorLogArray[i].alreadyExist == null) {
        innerObj['errorDetails'] = "Course Assessment already exist";
        innerObj['errorType'] = "Data already exist, please update it manually";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].category == null) {
        innerObj['errorDetails'] = "Category is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].correctAnswer == null) {
        innerObj['errorDetails'] = "Correct Answer is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].qLevel == null) {
        innerObj['errorDetails'] = "Question level (Simple/Intermediate/Complex) is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].qType == null) {
        innerObj['errorDetails'] = "Question Type is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
       if(errorLogArray[i].qtext == null) {
        innerObj['errorDetails'] = "Question is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].skill == null) {
        innerObj['errorDetails'] = "Skill is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].subSkill == null) {
        innerObj['errorDetails'] = "Sub Skill is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].subTopic == null) {
        innerObj['errorDetails'] = "Sub Topic is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].topic == null) {
        innerObj['errorDetails'] = "Topic is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].course == null) {
        innerObj['errorDetails'] = "Course is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].curriculum == null) {
        innerObj['errorDetails'] = "Curriculum is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].curriculumType == null) {
        innerObj['errorDetails'] = "Curriculum Type is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
    }
    return returnArray;
  };
  
  PageModule.prototype.errorLogFunctionForTestCategory = function (errorLogArray,uploadLog) {
    console.log("!!!",errorLogArray);
    var returnArray = [];
    for(var i = 0; i < errorLogArray.length; i++) {
      var innerObj = {};
      if(errorLogArray[i].alreadyExist == null) {
        innerObj['errorDetails'] = "Course Assessment already exist";
        innerObj['errorType'] = "Data already exist, please update it manually";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].simplePercentage == "null") {
        innerObj['errorDetails'] = "Simple (%) missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].mediumPercentage == "null") {
        innerObj['errorDetails'] = "Medium (%) is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].complexPercentage == "null") {
        innerObj['errorDetails'] = "Complex (%) is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].noOfQuestions == "null") {
        innerObj['errorDetails'] = "No. of Questions is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
       if(errorLogArray[i].marksPerQuestions == "null") {
        innerObj['errorDetails'] = "Marks per Questions is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].passingPercentage == "null") {
        innerObj['errorDetails'] = "Passing Percentage is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].total == "null") {
        innerObj['errorDetails'] = "Sum of Simple (%) + Medium (%) + Complex (%) is not 100";
        innerObj['errorType'] = "Not sum of 100(%)";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].topic == "null") {
        innerObj['errorDetails'] = "Topic is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].course == "null") {
        innerObj['errorDetails'] = "Course is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].curriculum == "null") {
        innerObj['errorDetails'] = "Curriculum is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
      if(errorLogArray[i].curriculumType == "null") {
        innerObj['errorDetails'] = "Curriculum Type is missing";
        innerObj['errorType'] = "Missing data";
        innerObj['uploadLog'] = uploadLog;
        returnArray.push(innerObj);
      }
    }
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnValue = function (arg1) {
  };

  return PageModule;
});
