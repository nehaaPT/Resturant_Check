define(['ojs/ojarraytreedataprovider', 'vb/BusinessObjectsTransforms'], function (ArrayTreeDataProvider, BOTransforms) {
  'use strict';

  var PageModule = function PageModule() { };


  PageModule.prototype.downloadSkillMatrixData = function (capaBO, skillBO, skillGroupBO, skillMetadata) {
   var multArray = new Array();
    var headerArray = new Array();
    // capabilityMetadata.forEach(element => headerArray.push(element.headerName));
    // skillGroupMetadata.forEach(element => headerArray.push(element.headerName));
    skillMetadata.forEach(element => headerArray.push(element.headerName));
    multArray.push(headerArray);



      var skillgrp;
      var skill;
    for (var i = 0; i< capaBO.length; i++) {
      skillgrp = skillGroupBO.filter(ele1=>ele1.capability == capaBO[i].id);
      if(skillgrp != undefined){
        for ( var j =0;j<skillgrp.length; j++){
          skill = skillBO.filter(ele2=>ele2.skillGroup == skillgrp[j].id);
          if( skill != undefined){
            for (var k =0; k<skill.length;k++){

              var innerArray = new Array();
              // innerArray.push(capaBO[i].id);
              innerArray.push(capaBO[i].name);
     
              // innerArray.push(skillgrp[j].skillGroupCode);
              innerArray.push(skillgrp[j].skillGroupName);
              // innerArray.push(skillgrp[j].category !== null ? skillgrp[j].category : 'NA');
              // innerArray.push(skillgrp[j].fulfillmentStrategy !== null ? skillgrp[j].fulfillmentStrategy :'NA');
              // innerArray.push(skillgrp[j].growthStrategy !== null ? skillgrp[j].growthStrategy : 'NA');
              // innerArray.push(skillgrp[j].trainingStrategy !== null ? skillgrp[j].trainingStrategy : 'NA');
              // innerArray.push(skill[k].skillName !== null ? skill[k].id : 'NA');
              innerArray.push(skill[k].skillName !== null ? skill[k].skillName : 'NA');
              // innerArray.push(skill[k].attribute1 !== null ? skill[k].attribute1 : 'NA');
              // innerArray.push(skill[k].attribute2 !== null ? skill[k].attribute2 :'NA');
              // innerArray.push(skill[k].attribute3 !== null  ? skill[k].attribute3 : 'NA'); 

              multArray.push(innerArray);

            }
          }
        }
      }
 
    }

    // dataArray.push(capaBO[capId].name);



    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Skill Matrix");
    var ws = XLSX.utils.aoa_to_sheet(multArray);
    wb.Sheets["Skill Matrix"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



    fileBytes = FileToBytes(fileBytes);
    console.log(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Skill Matrix_" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }









  }






  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }












  PageModule.prototype.currentCapabilityPopulate = function (P_Current) {
    var retPayload = {};
    retPayload['id'] = P_Current.id;
    retPayload['capabilityName'] = P_Current.name;
    retPayload['activeFlag'] = P_Current.activeFlag;
    retPayload['subPractice'] = P_Current.subPractice;
    retPayload['lead1'] = P_Current.lead1Object.items.length > 0 ? P_Current.lead1Object.items[0].name : '';
    retPayload['lead2'] = P_Current.lead2Object.items.length > 0 ? P_Current.lead2Object.items[0].name : '';
    retPayload['uSCapabilityLead1'] = P_Current.uSCapabilityLead1Object.items.length > 0 ? P_Current.uSCapabilityLead1Object.items[0].name : '';
    retPayload['uSCapabilityLead2'] = P_Current.uSCapabilityLead2Object.items.length > 0 ? P_Current.uSCapabilityLead2Object.items[0].name : '';

    console.log(retPayload);

    return retPayload;
  };

  PageModule.prototype.returnVisibillity = function (roleAccessArray, screen, type) {
    var data = roleAccessArray.find(element => element.functionality == screen)
    if (data.accessType == type) {
      return false;
    }
    else {
      return true;
    }

  }

  PageModule.prototype.updateCapabilityPayload = function (P_Cap, P_Emp) {
    var retPayload = {};
    retPayload['id'] = P_Cap.id;
    retPayload['name'] = P_Cap.capabilityName;
    retPayload['activeFlag'] = P_Cap.activeFlag;
    retPayload['subPractice'] = P_Cap.subPractice;
    if (P_Cap['lead1'] != '') {
      var element = P_Emp.find(element => element.name === P_Cap['lead1']);
      if (element != undefined) {
        retPayload['lead1'] = element.id;
      }
    }
    else {
      retPayload['lead1'] = null;
    }

    if (P_Cap['lead2'] != '') {
      var element = P_Emp.find(element => element.name === P_Cap['lead2']);
      if (element != undefined) {
        retPayload['lead2'] = element.id;
      }
    }
    else {
      retPayload['lead2'] = null;
    }

    if (P_Cap['uSCapabilityLead1'] != '') {
      var element = P_Emp.find(element => element.name === P_Cap['uSCapabilityLead1']);
      if (element != undefined) {
        retPayload['uSCapabilityLead1'] = element.id;
      }
    }
    else {
      retPayload['uSCapabilityLead1'] = null;
    }

    if (P_Cap['uSCapabilityLead2'] != '') {
      var element = P_Emp.find(element => element.name === P_Cap['uSCapabilityLead2']);
      if (element != undefined) {
        retPayload['uSCapabilityLead2'] = element.id;
      }
    }
    else {
      retPayload['uSCapabilityLead2'] = null;
    }
     if (P_Cap['pscLeadContact'] != '') {
      var element = P_Emp.find(element => element.name === P_Cap['pscLeadContact']);
      if (element != undefined) {
        retPayload['pscLeadContact'] = element.id;
      }
    }
    else {
      retPayload['pscLeadContact'] = null;
    }

    console.log(retPayload);

    return retPayload;

  };

  PageModule.prototype.updateCapabilityPayload1 = function (P_Cap) {
    var retPayload = {};
    retPayload['id'] = P_Cap.id;
    retPayload['name'] = P_Cap.capabilityName;
    retPayload['activeFlag'] = P_Cap.activeFlag;

    console.log(retPayload);

    return retPayload;
  };

  PageModule.prototype.getName = function (context) {
    return context.data.name;
  };

  PageModule.prototype.processFilter = function (configuration, options, transformsContext) {
    var textValue = options && options.text;

    if (transformsContext && transformsContext['vb-textFilterAttributes']) {
      console.log(transformsContext['vb-textFilterAttributes'][3]);
      var options_new = {
        op: '$or',
        criteria: [
        ]
      };

      for (var i = 0; i < transformsContext['vb-textFilterAttributes'].length; i++) {
        var itemCriterion = {};
        itemCriterion.attribute = transformsContext['vb-textFilterAttributes'][i];
        itemCriterion.op = '$co';
        itemCriterion.value = textValue;
        options_new.criteria.push(itemCriterion);
        console.log(itemCriterion);

      }

      var options_new1 = {
        op: '$and',
        criteria: [
        ]
      };

      options_new1.criteria.push(options_new);

      var itemCriterion1 = {};
      itemCriterion1.attribute = 'format';
      itemCriterion1.op = '$eq';
      itemCriterion1.value = 'India';
      options_new1.criteria.push(itemCriterion1);

      var itemCriterion2 = {};
      itemCriterion2.attribute = 'activeFlag';
      itemCriterion2.op = '$eq';
      itemCriterion2.value = 'Y';
      options_new1.criteria.push(itemCriterion2);

      // - NOTE -
      // below assignment override any existing FilterCriterion set on SDP.
      // proper solution is to merge options_new into existing conditions
      options = options_new1;
    }

    return BOTransforms.request.filter(configuration, options);
  };

  PageModule.prototype.getName1 = function (context) {
    return context.data.name;
  };

  PageModule.prototype.processFilter1 = function (configuration, options, transformsContext) {
    var textValue = options && options.text;

    if (transformsContext && transformsContext['vb-textFilterAttributes']) {
      console.log(transformsContext['vb-textFilterAttributes'][3]);
      var options_new = {
        op: '$or',
        criteria: [
        ]
      };

      for (var i = 0; i < transformsContext['vb-textFilterAttributes'].length; i++) {
        var itemCriterion = {};
        itemCriterion.attribute = transformsContext['vb-textFilterAttributes'][i];
        itemCriterion.op = '$co';
        itemCriterion.value = textValue;
        options_new.criteria.push(itemCriterion);
        console.log(itemCriterion);

      }

      var options_new1 = {
        op: '$and',
        criteria: [
        ]
      };

      options_new1.criteria.push(options_new);

      var itemCriterion1 = {};
      itemCriterion1.attribute = 'format';
      itemCriterion1.op = '$eq';
      itemCriterion1.value = 'US';
      options_new1.criteria.push(itemCriterion1);

      var itemCriterion2 = {};
      itemCriterion2.attribute = 'activeFlag';
      itemCriterion2.op = '$eq';
      itemCriterion2.value = 'Y';
      options_new1.criteria.push(itemCriterion2);

      // - NOTE -
      // below assignment override any existing FilterCriterion set on SDP.
      // proper solution is to merge options_new into existing conditions
      options = options_new1;
    }

    return BOTransforms.request.filter(configuration, options);
  };

  return PageModule;
});
