define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    uploadData(file,employeeBO,excelpayload) {


      let readExcelPromise = new Promise(function (resolve) {
      let excelFile = file[0];
      console.log(excelFile);
      let size;

      let reader = new FileReader();

      reader.onload = function (e) {

        let excelPayloadArray = new Array();
        let data = e.target.result;
        let workBook = XLSX.read(data, { type: 'binary'});
        let allSheets = workBook.SheetNames;
        size = allSheets.size;
        for (let i = 0; i < allSheets.length; i++) {

          let sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);
          let metadata;  

         for (let index = 0; index < sheetRows.length; index++) {
             if(index==0)
            {
              metadata=sheetRows[index];
            }
            
            else{
            
            let parsedSheetRows=parseRowToMetadata(sheetRows[index],metadata);

                 parsedSheetRows['employeeID']=parsedSheetRows['employeeID'] ? parsedSheetRows['employeeID'].toString():parsedSheetRows['employeeID'];
                 parsedSheetRows['globalEmployeeID']=parsedSheetRows['globalEmployeeID'] ? parsedSheetRows['globalEmployeeID'].toString():parsedSheetRows['globalEmployeeID'];
                 parsedSheetRows['name']=parsedSheetRows['name'] ? parsedSheetRows['name'].toString():parsedSheetRows['name'];
                 parsedSheetRows['localGrade']=parsedSheetRows['localGrade'] ? parsedSheetRows['localGrade'].toString():parsedSheetRows['localGrade'];
                 parsedSheetRows['email']=parsedSheetRows['email'] ? parsedSheetRows['email'].toString():parsedSheetRows['email'];
                 parsedSheetRows['region']=parsedSheetRows['region'] ? parsedSheetRows['region'].toString():parsedSheetRows['region'];
                 parsedSheetRows['grade']=parsedSheetRows['grade'] ? parsedSheetRows['grade'].toString():parsedSheetRows['grade'];
                // parsedSheetRows['joiningDate']=parsedSheetRows['joiningDate'] ? parsedSheetRows['joiningDate'].toString():parsedSheetRows['joiningDate'];
                 parsedSheetRows.joiningDate = changeFormat(parsedSheetRows.joiningDate);

                 let creds = {
                   format: 'India',
                      activeFlag: 'Y',
                      password: CryptoJS.AES.encrypt(parsedSheetRows.employeeID.toString(), parsedSheetRows.employeeID.toString()).toString()
    };

    let empCheck = employeeBO.find(ele => ele.employeeID === parsedSheetRows.employeeID);

    let empCheck2 = employeeBO.find(ele => ele.globalEmployeeID === parsedSheetRows.globalEmployeeID);

    let flag1,flag2;

 flag1 = empCheck && empCheck.globalEmployeeID === parsedSheetRows.globalEmployeeID;
 flag2 = empCheck2 && empCheck2.employeeID === parsedSheetRows.employeeID;

 
if (flag1 && flag2) {
  excelpayload.update.push({
    "employeeID": parsedSheetRows.employeeID,
    "id": empCheck.id,
    "name": parsedSheetRows.name,
    "email": parsedSheetRows.email,
    "globalEmployeeID": parsedSheetRows.globalEmployeeID,
    "format": creds.format,
    "activeFlag": creds.activeFlag,
    "localGrade": parsedSheetRows.localGrade,
    "joiningDate": parsedSheetRows.joiningDate,
    "grade": parsedSheetRows.grade,
    "region": parsedSheetRows.region

    
  });
} 

 else if (!empCheck && !empCheck2) {
  excelpayload.create.push({
    "employeeID": parsedSheetRows.employeeID,
    "name": parsedSheetRows.name,
    "email": parsedSheetRows.email,
    "globalEmployeeID": parsedSheetRows.globalEmployeeID,
    "format": creds.format,
    "activeFlag": creds.activeFlag,
    "password": creds.password,
   "localGrade": parsedSheetRows.localGrade,
    "joiningDate": parsedSheetRows.joiningDate,
    "grade": parsedSheetRows.grade,
    "region": parsedSheetRows.region
  });
}

            
             }
          }
          console.log(">>",excelpayload);
        }
        resolve(excelpayload);
      };
      reader.readAsBinaryString(excelFile);
      console.log(size);
    });
    
    console.log(">>>",readExcelPromise);
    return readExcelPromise;
  
  
  };
  }

 function changeFormat(currentDate) {
    try {

     let now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);

    }
    catch (err) {
      // console.log('#131'+currentDate);
      return currentDate;
    }
  }
  
PageModule.prototype.BatchProcessingEmployeeBO1 = function (employeeDataArray, operation, BOName, EmpBO, batchSize) {
    let batchProcessingVariableArray = [];

   

   const today = new Date();
const year = today.getFullYear();
const month = String(today.getMonth() + 1).padStart(2, '0'); // Month is zero-based, so add 1
const day = String(today.getDate()).padStart(2, '0');

const formattedDate = `${year}-${month}-${day}`;



const todayDate = new Date(year, month - 1, day);
    
    for (let batchStart = 0; batchStart < employeeDataArray.length; batchStart += batchSize) {
        let batchEnd = Math.min(batchStart + batchSize, employeeDataArray.length);
        let batchData = employeeDataArray.slice(batchStart, batchEnd);

        for (let index = 0; index < batchData.length; index++) {
            let data;
            let employee = EmpBO.find(ele => ele.globalEmployeeID == batchData[index].globalEmployeeID);
            if (employee == undefined) {
                data = {
                    "id": "part" + index,
                    "path": "/" + BOName + "/",
                    "operation": operation,
                    "payload": {
                        "name": batchData[index].name,
                        "email": batchData[index].email,
                        "employeeID": batchData[index].employeeID,
                        "globalEmployeeID": batchData[index].globalEmployeeID,
                        "joiningDate":batchData[index].joiningDate,
                        "activeFlag":batchData[index].activeFlag,
                        "format":batchData[index].format,
                        "localGrade":batchData[index].localGrade,
                        "password":batchData[index].password,
                        "grade": batchData[index].grade,
                        "lastUploadedDate":formattedDate,
                        "region":batchData[index].region
                        
                    }
                };
                batchProcessingVariableArray.push(data);
            }
        }
    }

    return { parts: batchProcessingVariableArray };
};

  

  PageModule.prototype.BatchProcessingEmployeeBO2 = function (employeeDataArray, operation, BOName, batchSize) {
    let batchProcessingVariableArray = [];

      const today = new Date();
const year = today.getFullYear();
const month = String(today.getMonth() + 1).padStart(2, '0'); // Month is zero-based, so add 1
const day = String(today.getDate()).padStart(2, '0');

const formattedDate = `${year}-${month}-${day}`;



const todayDate = new Date(year, month - 1, day);

    
    for (let batchStart = 0; batchStart < employeeDataArray.length; batchStart += batchSize) {
        let batchEnd = Math.min(batchStart + batchSize, employeeDataArray.length);
        let batchData = employeeDataArray.slice(batchStart, batchEnd);
        let employeeDataMap = new Map();
        for (let index = 0; index < batchData.length; index++) {
            let data;
            let employeeID = batchData[index].employeeID;
           

                data = {
                    "id": "part" + index,
                    "path": "/" + BOName + "/" +batchData[index].id,
                    "operation": operation,
                    "payload": {
                        "name": batchData[index].name,
                        "email": batchData[index].email,
                        "employeeID": batchData[index].employeeID,
                        "globalEmployeeID": batchData[index].globalEmployeeID,
                        "grade": batchData[index].grade,
                        "activeFlag":batchData[index].activeFlag,
                        "joiningDate":batchData[index].joiningDate,
                        "format":batchData[index].format,
                        "localGrade":batchData[index].localGrade,
                        "lastUploadedDate":formattedDate,
                        "region":batchData[index].region
                        
                       
                    }
                
            }

            batchProcessingVariableArray.push(data);
        }
    }

    return { parts: batchProcessingVariableArray };
};


  function parseRowToMetadata(currentExcelObject, metadata) {

    let dataSet = {};
    let dataKeys = Object.keys(metadata);
    for (let keyIndex = 0; keyIndex < dataKeys.length; keyIndex++) {

      dataSet[metadata[dataKeys[keyIndex]]] = currentExcelObject[dataKeys[keyIndex]];
      

    }
    console.log(Object.keys(dataSet));
    dataSet=attachSkillSurveyDate(dataSet,Object.keys(dataSet))
    console.log(dataSet);

    return dataSet;

  }
function attachSkillSurveyDate(dataSet,metaDataSet)
{
  if(metaDataSet.includes('skillSurveyDate'))
  {
    dataSet.skillSurveyDate=dataSet.skillSurveyDate==undefined?'':dataSet.skillSurveyDate;
  }

  return dataSet;
}
  return PageModule;
});
