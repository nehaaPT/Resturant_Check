define([], () => {
  'use strict';

 var PageModule = function PageModule() { };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.TableData = function (EmpCertBO1,CertMasterBO,Year,EmpCertBO2) {
      var data=[];
      var empData =[];
      var empData2 =[];
      var empData3 =[];
      var certMaster =[];
      var compEmpData=[];

       
                        //certMaster=CertMasterBO.filter(Element=>Element.Category=='1');
                        // certMaster =EmpCertBO.filter(Element=>Element.certificationNamerObject.Category == 1);
                        // for (let p = 0; p < empData.length; p++) {
                        //    var newData={};
                        //    //var empData1 =empData[p]

                        //   for (let m = 0; m < certMaster.length; m++) {
                        //    if (empData[p].certification == certMaster[m].id) {
                        //      newData =empData[p].find(Element=>Element.certification==certMaster[m].id);
                        //    compEmpData.push(newData);
                        //   }
                        
                        //   }
                        // }

                        //  compEmpData =empData.filter(Element=>Element.certification==certMaster.id);

                        // console.log('ppp',certMaster);
                        // console.log("rrr",empData);
                        // console.log("qqq",compEmpData);

      empData=EmpCertBO1;//.filter(Element=>Element.status=='Completed');
      var payload2={};
      var payload3={};
      var date;
      var payload4=[0,0,0,0,0,0,0,0,0,0,0,0];

       for(var l=0;l<empData.length;l++)
        {  
            date =new Date(empData[l].examDate);
                        //console.log('sss',date);
            var year =date.getFullYear();
            if (year==Year) {
            var mon= date.getMonth();
            payload4[mon]=payload4[mon]+1;
            }

        }


       payload2['cert']='Oracle Certifications';
       payload2['Jan']=payload4[0];
       payload2['Feb']=payload4[1];
       payload2['Mar']=payload4[2];
       payload2['Apr']=payload4[3];
       payload2['May']=payload4[4];
       payload2['Jun']=payload4[5];
       payload2['Jul']=payload4[6];
       payload2['Aug']=payload4[7];
       payload2['Sept']=payload4[8];
       payload2['Oct']=payload4[9];
       payload2['Nov']=payload4[10];
       payload2['Dec']=payload4[11];
      payload2['total']=payload4[0]+payload4[1]+payload4[2]+payload4[3]+payload4[4]+payload4[5]+payload4[6]+payload4[7]+payload4[8]+payload4[9]+payload4[10]+payload4[11];

   data.push(payload2);

      empData2=(EmpCertBO2.filter(Element=>Element.status=='Completed')).filter(Element=>Element.certification != 1081);
      var date2;
      var payload5=[0,0,0,0,0,0,0,0,0,0,0,0];

       for(var k=0;k<empData2.length;k++)
        {  
            date2 =new Date(empData2[k].examDate);
                  //console.log('sss',date);
            var year1 =date2.getFullYear();
            if (year1==Year) {
            var mont= date2.getMonth(); 
            payload5[mont]=payload5[mont]+1;
          }
                  //console.log("66",mainfilter[j].roleStartDate,payload4[mon]);
        }

       payload3['cert']='Agile Certifications';
       payload3['Jan']=payload5[0];
       payload3['Feb']=payload5[1];
       payload3['Mar']=payload5[2];
       payload3['Apr']=payload5[3];
       payload3['May']=payload5[4];
       payload3['Jun']=payload5[5];
       payload3['Jul']=payload5[6];
       payload3['Aug']=payload5[7];
       payload3['Sept']=payload5[8];
       payload3['Oct']=payload5[9];
       payload3['Nov']=payload5[10];
       payload3['Dec']=payload5[11];
      payload3['total']=payload5[0]+payload5[1]+payload5[2]+payload5[3]+payload5[4]+payload5[5]+payload5[6]+payload5[7]+payload5[8]+payload5[9]+payload5[10]+payload5[11];

   data.push(payload3);

        var payload6={};
        empData3=EmpCertBO2.filter(Element=>Element.status=='Completed');
        var empData4 =empData3.filter(Element=>Element.certification == 1081);
        var date3;
        var payload7=[0,0,0,0,0,0,0,0,0,0,0,0];

          for(var j=0;j<empData4.length;j++)
        {  
            date3 =new Date(empData4[j].examDate);
                  //console.log('sss',date);
            var year2 =date3.getFullYear();
            if (year2==Year) {
            var month= date3.getMonth(); 
            payload7[month]=payload7[month]+1;
          }
                  //console.log("66",mainfilter[j].roleStartDate,payload4[mon]);
        }

         payload6['cert']='ASD Certifications';
       payload6['Jan']=payload7[0];
       payload6['Feb']=payload7[1];
       payload6['Mar']=payload7[2];
       payload6['Apr']=payload7[3];
       payload6['May']=payload7[4];
       payload6['Jun']=payload7[5];
       payload6['Jul']=payload7[6];
       payload6['Aug']=payload7[7];
       payload6['Sept']=payload7[8];
       payload6['Oct']=payload7[9];
       payload6['Nov']=payload7[10];
       payload6['Dec']=payload7[11];
      payload6['total']=payload7[0]+payload7[1]+payload7[2]+payload7[3]+payload7[4]+payload7[5]+payload7[6]+payload7[7]+payload7[8]+payload7[9]+payload7[10]+payload7[11];

   data.push(payload6);



   return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

   PageModule.prototype.currentMonth = function (index) 
    {
        var today = new Date();
        var mm = String(today.getMonth() + 1);
     if(index<10)
     {
        return mm;
     }

     else 
     { 
         mm = String(today.getMonth() + 1).padStart(2, '0'); 
        return mm;
     }
        
      };

PageModule.prototype.buildQFormat = function () {
    var qparameter;
    if (format=="Both")
    qparameter="('US' or 'India')";

    else if(format=="US") {
      qparameter="'US'";
    }
    else{
      qparameter="'India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };
  
      PageModule.prototype.currentMonth2 = function (index, year) 
      {
      var today = new Date();
        var mm = String(today.getMonth() + 1);
  var yyyy = today.getFullYear();
    if(year==yyyy)
    {
     if(index<10)
     {
       
        
        return mm;
     }

     else 
     { 
       mm = String(today.getMonth() + 1).padStart(2, '0'); 
        return mm;
     }}
     else
     return mm;
        
      };



  
  PageModule.prototype.ForecastTableData = function (EmpCertBO1,Year,EmpCertBO2,CurrentDate) {

      var data=[];
      var empData3 =[];
      var empData4 =[];
      var payload2={};
      var payload3={};


// examPlannedDate
      //empData3=EmpCertBO1.filter(Element=>Element.status== 'Credit_requested' || 'Voucher_requested' ||'Cl_approved' ||'credit_approved' || 'voucher_approved') ;
      empData3=EmpCertBO1;   //.filter(Element=>Element.status== 'Completed') ;
      var date;
      var payload4=[0,0,0,0,0,0,0,0,0,0,0,0];
      console.log('ssss',empData3);
     
            for(var l=0;l<empData3.length;l++)
             {  
                   if (CurrentDate < empData3[l].examPlannedDate) {
                  var curDate =new Date(CurrentDate);
                  var curMon= curDate.getMonth();
                  var curYear = curDate.getFullYear();
                  date =new Date(empData3[l].examPlannedDate);
                   var mon= date.getMonth();
                   var year =date.getFullYear();
                  if(curMon<= mon  && curYear == year ){     // && curYear 
                  //date =new Date(empData3[l].examPlannedDate);
                              
                  //var year =date.getFullYear();
                  if (year==Year) {
                  //var mon= date.getMonth();
                  payload4[mon]=payload4[mon]+1;
                  }
                  }
                  }
            }
       

       payload2['cert']='Oracle Certifications';
       payload2['Jan']=payload4[0];
       payload2['Feb']=payload4[1];
       payload2['Mar']=payload4[2];
       payload2['Apr']=payload4[3];
       payload2['May']=payload4[4];
       payload2['Jun']=payload4[5];
       payload2['Jul']=payload4[6];
       payload2['Aug']=payload4[7];
       payload2['Sept']=payload4[8];
       payload2['Oct']=payload4[9];
       payload2['Nov']=payload4[10];
       payload2['Dec']=payload4[11];
       payload2['total']=payload4[0]+payload4[1]+payload4[2]+payload4[3]+payload4[4]+payload4[5]+payload4[6]+payload4[7]+payload4[8]+payload4[9]+payload4[10]+payload4[11];
      data.push(payload2);

     // empData4=EmpCertBO2.filter(Element=>Element.status=='Completed');
     empData4=EmpCertBO2;
      var date2;
      var payload5=[0,0,0,0,0,0,0,0,0,0,0,0];

       for(var k=0;k<empData4.length;k++)
        {  
            if (CurrentDate < empData4[k].examPlannedDate) {
            var curDate1 =new Date(CurrentDate);
            var curMon1= curDate1.getMonth();
            var curYear1 =curDate1.getFullYear();
            date2 =new Date(empData4[k].examPlannedDate);
            var mont= date2.getMonth(); 
            var year1 =date2.getFullYear();
                  if(curMon1<= mont && curYear1 == year1){
                        //console.log('sss',date);
                        
                        if (year1==Year) {      
                        payload5[mont]=payload5[mont]+1;
                        }
                  }
                  }
                  //console.log("66",mainfilter[j].roleStartDate,payload4[mon]);
        }

       payload3['cert']='Agile Certifications';
      payload3['Jan']=payload5[0];
       payload3['Feb']=payload5[1];
       payload3['Mar']=payload5[2];
       payload3['Apr']=payload5[3];
       payload3['May']=payload5[4];
       payload3['Jun']=payload5[5];
       payload3['Jul']=payload5[6];
       payload3['Aug']=payload5[7];
       payload3['Sept']=payload5[8];
       payload3['Oct']=payload5[9];
       payload3['Nov']=payload5[10];
       payload3['Dec']=payload5[11];
      payload3['total']=payload5[0]+payload5[1]+payload5[2]+payload5[3]+payload5[4]+payload5[5]+payload5[6]+payload5[7]+payload5[8]+payload5[9]+payload5[10]+payload5[11];
      data.push(payload3);

   return data;
  };



  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.TotalData = function (ActualOracle,ForecastOracle,ActualAgile,ForecastAgile,EmpCertBO1,Year,EmpCertBO2,CurrentDate) {
    
      var data=[];
      var empData3 =[];
      var empData4 =[];
      var payload2={};
      var payload3={};

      // var oracleTotal = ActualOracle.total + ForecastOracle.total;
      // var agileTotal = ActualAgile.total + ForecastAgile.total;
      // console.log('jjjj',ActualOracle);
      // console.log('jjjjj',oracleTotal);

      empData3=EmpCertBO1;   
      var date;
      var date1;
      var payload4=[0,0,0,0,0,0,0,0,0,0,0,0];
      //console.log('ssss',empData3);
       for(var l=0;l<empData3.length;l++)
        {  
           
            var mon;
            if (empData3[l].examDate == undefined) {
                  var curDate =new Date(CurrentDate);
                  var curMon= curDate.getMonth();
                  var curYear =curDate.getFullYear();
                  date1 =new Date(empData3[l].examPlannedDate);
                  mon= date1.getMonth();
                //if(curMon <= mon){ 
                  if (CurrentDate < empData3[l].examPlannedDate) {                                                
                          
                var year1 =date1.getFullYear();
                //var mon1;
                if (year1==Year && curYear == year1) {
                payload4[mon]=payload4[mon]+1;
                }
            }
            } else {
              if (empData3[l].status == 'Completed') {
              date =new Date(empData3[l].examDate);
               var year =date.getFullYear();
               if (CurrentDate >= empData3[l].examDate) {
               if (year==Year) {
                mon= date.getMonth();
                payload4[mon]=payload4[mon]+1;
                }
              }
            }
            }
         
        }

       payload2['cert']='Oracle Certifications';
       payload2['Jan']=payload4[0];
       payload2['Feb']=payload4[1];
       payload2['Mar']=payload4[2];
       payload2['Apr']=payload4[3];
       payload2['May']=payload4[4];
       payload2['Jun']=payload4[5];
       payload2['Jul']=payload4[6];
       payload2['Aug']=payload4[7];
       payload2['Sept']=payload4[8];
       payload2['Oct']=payload4[9];
       payload2['Nov']=payload4[10];
       payload2['Dec']=payload4[11];
      // payload2['total']=oracleTotal;
      payload2['total']=payload4[0]+payload4[1]+payload4[2]+payload4[3]+payload4[4]+payload4[5]+payload4[6]+payload4[7]+payload4[8]+payload4[9]+payload4[10]+payload4[11];
       
        data.push(payload2);


        empData4=EmpCertBO2;   
      var date2;
      var date3;
      var payload5=[0,0,0,0,0,0,0,0,0,0,0,0];
      //console.log('ssss',empData4);
       for(var m=0;m<empData4.length;m++)
        {  
           
            var mon1;
            if (empData4[m].examDate == undefined) {
                                                                       //if (CurrentDate <= empData4[m].examPlannedDate) {
                  var curDate1 =new Date(CurrentDate);
                  var curMon1= curDate1.getMonth();
                   var curYear1 =curDate1.getFullYear();
                  date3 =new Date(empData4[m].examPlannedDate);
                   mon1= date3.getMonth();
                //if(curMon1 <= mon1){ 
                  if (CurrentDate < empData4[m].examPlannedDate) { 
                  if (empData4[m].status == ('Credit_requested' || 'Voucher_requested' || 'Cl_approved' || 'credit_approved' || 'voucher_approved' || 'Certificate_Uploaded_Approval_Pending'  )) {  //AND (status = 'Credit_requested' or status = 'Voucher_requested' or status ='Cl_approved' or status = 'credit_approved' or status ='voucher_approved' or status ='Certificate_Uploaded_Approval_Pending')
                        //date3 =new Date(empData4[m].examPlannedDate);          
                        var year3 =date3.getFullYear();
                        //var mon1;
                        if (year3==Year && curYear1 == year3) {
                        // mon1= date3.getMonth();
                        payload5[mon1]=payload5[mon1]+1;
                        }
                  }
            }
            } else {
                if (empData4[m].status == 'Completed' ) {
                  if (CurrentDate >= empData4[m].examDate) { 
                  date2 =new Date(empData4[m].examDate);
                  var year2 =date2.getFullYear();
                  if (year2==Year) {
                  mon1= date2.getMonth();
                  payload5[mon1]=payload5[mon1]+1;
                }
                }
                }
              
            }
         
        }

       payload3['cert']='(Agile + ASD) Certifications';
       payload3['Jan']=payload5[0];
       payload3['Feb']=payload5[1];
       payload3['Mar']=payload5[2];
       payload3['Apr']=payload5[3];
       payload3['May']=payload5[4];
       payload3['Jun']=payload5[5];
       payload3['Jul']=payload5[6];
       payload3['Aug']=payload5[7];
       payload3['Sept']=payload5[8];
       payload3['Oct']=payload5[9];
       payload3['Nov']=payload5[10];
       payload3['Dec']=payload5[11];
      // payload3['total']=agileTotal;
       payload3['total']=payload5[0]+payload5[1]+payload5[2]+payload5[3]+payload5[4]+payload5[5]+payload5[6]+payload5[7]+payload5[8]+payload5[9]+payload5[10]+payload5[11];
        data.push(payload3);

   return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.BuildDate = function (year,month) {
      
      var days=[31,28,31,30,31,30,31,31,30,31,30,31];
      if ((year % 4 == 0) && (year % 100 != 0)|| (year % 400 == 0))
      {
         days[1]=29;
      }
      var retpayload=[];
      if (month<10)
      {
        retpayload['startDate']="'"+year+'-0'+month+'-01'+"'";
        retpayload['endDate']="'"+year+'-0'+month+'-'+days[month-1]+"'";
      }
      else
      {
        retpayload['startDate']="'"+year+'-'+month+'-01'+"'";
        retpayload['endDate']="'"+year+'-'+month+'-'+days[month-1]+"'";
      }      
      return retpayload;
      

  };

    PageModule.prototype.BDDD = function (year,month) {
      
      var today = new Date();
        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
      var days=[31,28,31,30,31,30,31,31,30,31,30,31];
      if ((year % 4 == 0) && (year % 100 != 0)|| (year % 400 == 0))
      {
         days[1]=29;
      }
      var retpayload=[];
      
        {
        retpayload['startDate']="'"+year+'-'+mm+"-01'";
        retpayload['endDate']="'"+year+"-12-31'";
      }      
      return retpayload;
      

  };


   //if (month<10)
     // {
       // retpayload['startDate']="'"+year+'-0'+mm+'-01'+"'";
       // retpayload['endDate']=year+'-12-31';
      //}
      //else
      //{

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.BuildYear = function (year) {
    
      var retpayload=[];
      
        retpayload['startDate']="'"+year+'-01-01'+"'";
        retpayload['endDate']="'"+year+'-12-31'+"'";
       
      return retpayload;
  };

   PageModule.prototype.months = function (yyyy,mm) {

      
    var retpayload=[];
       var today = new Date();
        
        var mm = String(today.getMonth() + 1).padStart(2, '0'); 
         var yyyy = today.getFullYear();
        retpayload['startmonth']=yyyy+'-'+mm+'-01';
        retpayload['endmonth']=yyyy+'12-31';
       
      return retpayload;
  };
   


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.todaysDate = function () {
       var retpayload=[];
      var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();

        //today = yyyy + '-' + mm + '-' + dd; //10/12/2021  YYYY-MM-DD 2021-10-30
        console.log("@today 11:" + today);
         retpayload['today']="'"+yyyy + '-' + mm + '-' + dd+"'";
          retpayload['today1']=yyyy + '-' + mm + '-' + dd;
       // return today;
        return retpayload;
  };



PageModule.prototype.presentDate = function () {
       var retpayload=[];
      var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
           var yyyy = today.getFullYear();

       
        retpayload['today1']=dd + '-' + mm + '-' + yyyy;
        
        return retpayload;
  };







 PageModule.prototype.PendingTableData = function (EmpCertBO1,Year,EmpCertBO2,CurrentDate) {

      var data=[];
      var empData3 =[];
      var empData4 =[];
      var payload2={};
      var payload3={};


// examPlannedDate
      //empData3=EmpCertBO1.filter(Element=>Element.status== 'Credit_requested' || 'Voucher_requested' ||'Cl_approved' ||'credit_approved' || 'voucher_approved') ;
      empData3=EmpCertBO1;   //.filter(Element=>Element.status== 'Completed') ;
      var date;
      var payload4=[0,0,0,0,0,0,0,0,0,0,0,0];
      console.log('ssss',empData3);
     
            for(var l=0;l<empData3.length;l++)
             {  
                  var curDate =new Date(CurrentDate);
                  var curMon= curDate.getMonth();
                  var curYear = curDate.getFullYear();
                  date =new Date(empData3[l].examPlannedDate);
                  var mon= date.getMonth();
                  var year =date.getFullYear();
                  if (CurrentDate >= empData3[l].examPlannedDate) {
                if(curMon >= mon && curYear >= year){ 
                      
                      //date =new Date(empData3[l].examPlannedDate);
                      if (year==Year) {
                      //var mon= date.getMonth();
                      payload4[mon]=payload4[mon]+1;
                      }

                 }else if (curMon <= mon && curYear > year){
                      if (year==Year) {
                      //var mon= date.getMonth();
                      payload4[mon]=payload4[mon]+1;
                      }
                  }
                  }
            }
       
    //var today = new Date();
    //var monc = String(today.getMonth() + 1).padStart(2, '0');
  // console.log('jjj',monc);
       payload2['cert']='Oracle Certifications';
       
       payload2['Jan']=payload4[0];
       payload2['Feb']=payload4[1];
       payload2['Mar']=payload4[2];
       payload2['Apr']=payload4[3];
       payload2['May']=payload4[4];
     // if (monc!=5) { payload2['May']=payload4[4];} else{payload2['May']='0';}
       payload2['Jun']=payload4[5];
       payload2['Jul']=payload4[6];
       payload2['Aug']=payload4[7];
       payload2['Sept']=payload4[8];
       payload2['Oct']=payload4[9];
       payload2['Nov']=payload4[10];
       payload2['Dec']=payload4[11];
      payload2['total']=payload4[0]+payload4[1]+payload4[2]+payload4[3]+payload4[4]+payload4[5]+payload4[6]+payload4[7]+payload4[8]+payload4[9]+payload4[10]+payload4[11];
      
      data.push(payload2);

     // empData4=EmpCertBO2.filter(Element=>Element.status=='Completed');
     empData4=EmpCertBO2;
      var date2;
      var payload5=[0,0,0,0,0,0,0,0,0,0,0,0];

       for(var k=0;k<empData4.length;k++)
        {  
                  var curDate1 =new Date(CurrentDate);
                  var curMon1= curDate1.getMonth();
                  var curYear1 = curDate1.getFullYear();
                  date2 =new Date(empData4[k].examPlannedDate);
                  var mont= date2.getMonth(); 
                  var year1 =date2.getFullYear();
                  if (CurrentDate >= empData4[k].examPlannedDate) {
                 if(curMon1 >= mont && curYear1 >= year1){ 
                              
                              //date2 =new Date(empData4[k].examPlannedDate);
                              //console.log('sss',date);
                  
                  if (year1==Year) {
                              //var mont= date2.getMonth(); 
                  payload5[mont]=payload5[mont]+1;
                }
            }else if (curMon1 < mont && curYear1 > year1){
                  if (year1==Year) {
                              //var mont= date2.getMonth(); 
                  payload5[mont]=payload5[mont]+1;
                }
            }
                  }
                  //console.log("66",mainfilter[j].roleStartDate,payload4[mon]);
        }

       payload3['cert']='Agile Certifications';
      payload3['Jan']=payload5[0];
       payload3['Feb']=payload5[1];
       payload3['Mar']=payload5[2];
       payload3['Apr']=payload5[3];
       payload3['May']=payload5[4];
       payload3['Jun']=payload5[5];
       payload3['Jul']=payload5[6];
       payload3['Aug']=payload5[7];
       payload3['Sept']=payload5[8];
       payload3['Oct']=payload5[9];
       payload3['Nov']=payload5[10];
       payload3['Dec']=payload5[11];
      payload3['total']=payload5[0]+payload5[1]+payload5[2]+payload5[3]+payload5[4]+payload5[5]+payload5[6]+payload5[7]+payload5[8]+payload5[9]+payload5[10]+payload5[11];
      data.push(payload3);

   return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.PresentStartDate = function (StartDate,CurrentDate,EndDate) {
     var retpayload=[];
     if (StartDate >= CurrentDate) {
            var date =new Date(StartDate);
            var mon= date.getMonth();
            var date1 =new Date(CurrentDate);
            var mon1 =date1.getMonth();
            
            if (mon>mon1) {
              retpayload['startDate']=StartDate;
              retpayload['endDate']=EndDate;
            } else{
              retpayload['startDate']=CurrentDate;
              retpayload['endDate']=EndDate;
            }

     }else if (StartDate < CurrentDate){
              var date2 =new Date(StartDate);
            var mon2= date2.getMonth();
            var year2= date2.getFullYear();
            var date3 =new Date(CurrentDate);
            var mon3 =date3.getMonth();
            var year3 = date3.getFullYear();

              if (mon2==mon3 && year2 == year3) {
              retpayload['startDate']=CurrentDate;
              retpayload['endDate']=EndDate;
            } else{
              retpayload['startDate']=CurrentDate;
              retpayload['endDate']=EndDate;
            }
     } 
     else {
       retpayload['startDate']=undefined;
       retpayload['endDate']=undefined;
     }
     return retpayload;
  };

   PageModule.prototype.PresentStartDate2 = function (StartDate,CurrentDate,EndDate) {
     var retpayload=[];
                              //  if (StartDate <= CurrentDate) {
            var date =new Date(StartDate);
            var mon= date.getMonth();
            var year= date.getFullYear();
            var date1 =new Date(CurrentDate);
            var mon1 =date1.getMonth();
            var year1 = date1.getFullYear();

            if (mon<mon1 && year == year1) {
              retpayload['startDate']=StartDate;
              retpayload['endDate']=EndDate;
            } else if (mon==mon1 && year == year1){
            retpayload['startDate']=StartDate;
            retpayload['endDate']=CurrentDate;
            } else if (mon >= mon1 && year !=year1){
              retpayload['startDate']=StartDate;
              retpayload['endDate']=EndDate;
            }else if (mon < mon1 && year !=year1){
              retpayload['startDate']=StartDate;
              retpayload['endDate']=EndDate;
            } else {
              retpayload['startDate']=undefined;
              retpayload['endDate']=undefined;
            }

                            //  }else if (StartDate > CurrentDate){
                            //         //     var date2 =new Date(StartDate);
                            //         //     var mon2= date2.getMonth();
                            //         //     var year2= date2.getFullYear();
                            //         //     var date3 =new Date(CurrentDate);
                            //         //     var mon3 =date3.getMonth();
                            //         //     var year3 = date3.getFullYear();
                            //         //   if (mon2<mon3 && year2 == year3) {
                            //         //   retpayload['startDate']=StartDate;
                            //         //   retpayload['endDate']=EndDate;
                            //         // } else{
                            //         //   retpayload['startDate']=CurrentDate;
                            //         //   retpayload['endDate']=EndDate;
                            //         // }
                            //  } 
                            //  else {
                            //    retpayload['startDate']=undefined;
                            //    retpayload['endDate']=undefined;
                            //  }
     return retpayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.PresentStartDateTotal = function (StartDate,CurrentDate,EndDate) {
    var retpayload=[];
                   
                            var date =new Date(StartDate);
                            var mon= date.getMonth();
                            var year =date.getFullYear();
                            var date1 =new Date(CurrentDate);
                            var mon1 =date1.getMonth();
                            var year1 =date1.getFullYear();
                            
                            if (mon>mon1) {
                              retpayload['startDate']=StartDate;
                              retpayload['endDate']=EndDate;
                            } else if (mon == mon1){
                              retpayload['startDate']=StartDate;
                              retpayload['endDate']=EndDate;
                            }else{
                              retpayload['startDate']=StartDate;
                              retpayload['endDate']=EndDate;
                            }
                            retpayload['mon']=mon;
                            retpayload['currentMonth']=mon1;
                            retpayload['year']=year;
                            retpayload['currentYear']=year1;

                    // else if (StartDate < CurrentDate){
                    //             var date2 =new Date(StartDate);
                    //             var mon2= date2.getMonth();
                    //             var date3 =new Date(CurrentDate);
                    //             var mon3 =date3.getMonth();
                    //           if (mon2<mon3) {
                    //           retpayload['startDate']=StartDate;
                    //           retpayload['endDate']=EndDate;
                    //         } else{
                    //           retpayload['startDate']=CurrentDate;
                    //           retpayload['endDate']=EndDate;
                    //         }
                    // }







    //  if (StartDate >= CurrentDate) {
    //         var date =new Date(StartDate);
    //         var mon= date.getMonth();
    //         var date1 =new Date(CurrentDate);
    //         var mon1 =date1.getMonth();
            
    //         if (mon>mon1) {
    //           retpayload['startDate']=StartDate;
    //           retpayload['endDate']=EndDate;
    //         } else{
    //           retpayload['startDate']=CurrentDate;
    //           retpayload['endDate']=EndDate;
    //         }

    //  }else if (StartDate < CurrentDate){
    //             var date2 =new Date(StartDate);
    //             var mon2= date2.getMonth();
    //             var date3 =new Date(CurrentDate);
    //             var mon3 =date3.getMonth();
    //           if (mon2<mon3) {
    //           retpayload['startDate']=StartDate;
    //           retpayload['endDate']=EndDate;
    //         } else{
    //           retpayload['startDate']=CurrentDate;
    //           retpayload['endDate']=EndDate;
    //         }
    //  } 
    //  else {
    //    retpayload['startDate']=undefined;
    //    retpayload['endDate']=undefined;
    //  }
     return retpayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.BuildYearForecastTotal = function (year,CurrentDate) {
        

       var retpayload=[];

        var date1 =new Date(CurrentDate);
        var mon1 =date1.getMonth() +1;
        var year1=date1.getFullYear();
        if (year == year1) {
                  if (mon1 <10){
                retpayload['startDate']=CurrentDate;     //"'"+year1+'-0'+mon1+'-01'+"'";
                retpayload['endDate']="'"+year1+'-12-31'+"'";
                }else{
                  retpayload['startDate']=CurrentDate;                //"'"+year1+'-'+mon1+'-01'+"'";
                retpayload['endDate']="'"+year1+'-12-31'+"'";
                }
        }
        
      return retpayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.BuildYearPendingTotal = function (year,CurrentDate) {
            var days=[31,28,31,30,31,30,31,31,30,31,30,31];
          if ((year % 4 == 0) && (year % 100 != 0)|| (year % 400 == 0))
          {
            days[1]=29;
          }


        var retpayload=[];

        var date1 =new Date(CurrentDate);
        var mon1 =date1.getMonth() +1;   //5
        var mon2 = mon1-1;               //4
        var year1=date1.getFullYear();
        if (year == year1) {
                  if (mon2 <10){
                  retpayload['startDate']="'"+year+'-01-01'+"'";
                  retpayload['endDate']=CurrentDate;             //"'"+year+'-0'+mon2+'-'+days[mon2-1]+"'";
                }else{
                  retpayload['startDate']="'"+year+'-01-01'+"'";
                  retpayload['endDate']=CurrentDate;                        //"'"+year+'-'+mon2+'-'+days[mon2-1]+"'";
                }
        }else if(year<year1){
                  retpayload['startDate']="'"+year+'-01-01'+"'";
                  retpayload['endDate']="'"+year+'-12-31'+"'";
        }
        
      return retpayload;
  };

  //PageModule.prototype.currentMonth = function () 
    //  {
      //var today = new Date();
        //var mm = String(today.getMonth() + 1); 
       //return mm;

      //};
      
   PageModule.prototype.download = function (down)  {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('EmployeeID');
        retpayload.push('Employee Name');
        retpayload.push('Certification');
        retpayload.push('Certification Code');
        retpayload.push('Status');
        retpayload.push('Exam Date');
        retpayload.push('scoreCard');
        retpayload.push('Capablity');
        
      }
      else{
        retpayload.push(down[i-1].employeeIdObject.items[0].employeeID);
        retpayload.push(down[i-1].employeeIdObject.items[0].name); //certificationNamerObject,employeeIdObject
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationName);
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationCode);
        retpayload.push(down[i-1].status);
        retpayload.push(down[i-1].examDate);
        retpayload.push(down[i-1].scoreCard);
         retpayload.push(down[i-1].capabilityObject.items[0]!=null?down[i-1].capabilityObject.items[0].name:'');
       
      }
      data.push(retpayload);
    }
     return data;
  };
    PageModule.prototype.download1 = function (down)  {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('EmployeeID');
        retpayload.push('Employee Name');
        retpayload.push('Certification');
        retpayload.push('Certification Code');
        retpayload.push('Exam Date');
        retpayload.push('Status');
        retpayload.push('Capablity');
        
      }
      else{
        retpayload.push(down[i-1].employeeIdObject.items[0].employeeID);
        retpayload.push(down[i-1].employeeIdObject.items[0].name); //certificationNamerObject,employeeIdObject
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationName);
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationCode);
        retpayload.push(down[i-1].examPlannedDate);
        retpayload.push(down[i-1].status);
        retpayload.push(down[i-1].capabilityObject.items[0].name);
       
      }
      data.push(retpayload);
    }
     return data;
  };
    PageModule.prototype.download2 = function (down)  {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('EmployeeID');
        retpayload.push('Employee Name');
        retpayload.push('Certification');
        retpayload.push('Certification Code');
        retpayload.push('Status');
        retpayload.push('Actual Exam Date');
        retpayload.push('Forecast Exam Date')
        retpayload.push('scoreCard');
        retpayload.push('Capablity');
        
      }
      else{
        retpayload.push(down[i-1].employeeIdObject.items[0].employeeID);
        retpayload.push(down[i-1].employeeIdObject.items[0].name); //certificationNamerObject,employeeIdObject
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationName);
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationCode);
        retpayload.push(down[i-1].status);
        retpayload.push(down[i-1].examDate);
        retpayload.push(down[i-1].examPlannedDate);
        retpayload.push(down[i-1].scoreCard);
         retpayload.push(down[i-1].capabilityObject.items[0].name);
       
      }
      data.push(retpayload);
    }
     return data;
  };
      PageModule.prototype.download3 = function (down)  {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('EmployeeID');
        retpayload.push('Employee Name');
        retpayload.push('Certification');
        retpayload.push('Certification Code');
        retpayload.push('Status');
        retpayload.push('Planned Exam Date');
        retpayload.push('Capablity');
        
      }
      else{
        retpayload.push(down[i-1].employeeIdObject.items[0].employeeID);
        retpayload.push(down[i-1].employeeIdObject.items[0].name); //certificationNamerObject,employeeIdObject
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationName);
        retpayload.push(down[i-1].certificationNamerObject.items[0].certificationCode);
        retpayload.push(down[i-1].status);
        retpayload.push(down[i-1].examPlannedDate);
         retpayload.push(down[i-1].capabilityObject.items[0].name);
       
      }
      data.push(retpayload);
    }
     return data;
  };
   PageModule.prototype.XL = function (innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" Certification Data");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" Certification Data"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Certification Data_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };
  function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    



  return PageModule;
});
