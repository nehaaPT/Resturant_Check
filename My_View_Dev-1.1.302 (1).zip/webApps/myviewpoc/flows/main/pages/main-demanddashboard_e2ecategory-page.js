define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    tabledata(BU,DMD,CBO) {
    var data=[];
    var completedata=[];
    completedata=DMD.filter(Element=>Element.format=='India' || Element.format=='US');  
   
       for(var i=0;i<completedata.length;i++)
      {
       var payload={};
       payload['bu'] = completedata[i].sector!=undefined ? BU.find(ele=>ele.id==completedata[i].sector).name:'NA';
       payload['client']=completedata[i].client!=undefined ? CBO.find(ele=>ele.id==completedata[i].client).clientName:'NA';
       payload['format']=completedata[i].format;
       payload['catA']=(completedata.filter(ele=>ele.sector==completedata[i].sector && ele.format==completedata[i].format && ele.client==completedata[i].client)).filter(Element=>Element.category=='Category A').length;
       payload['catB']=(completedata.filter(ele=>ele.sector==completedata[i].sector && ele.format==completedata[i].format && ele.client==completedata[i].client)).filter(Element=>Element.category=='Category B').length;
       payload['catC']=(completedata.filter(ele=>ele.sector==completedata[i].sector && ele.format==completedata[i].format && ele.client==completedata[i].client)).filter(Element=>Element.category=='Category C').length;
       payload['unmarked']=(completedata.filter(ele=>ele.sector==completedata[i].sector && ele.format==completedata[i].format && ele.client==completedata[i].client)).filter(Element=>Element.category=='Unmarked Category').length;
       payload['grandtotal']=payload['catA']+ payload['catB']+ payload['catC']+ payload['unmarked'];

       if (payload['grandtotal']>0 && data.length>0 && data.filter(Element=>Element.bu==payload['bu'] && Element.client==payload['client'] && Element.format==payload['format']).length==0)
                {
           
                data.push(payload);  
                console.log("pp",data);
                }
                else if(payload['grandtotal']>0 && data.length==0)
               {

               data.push(payload);  
               console.log("pp",data);
               }

 
         
       }
      
       console.log("@@@",data);
   // sorting of tabledata
     data.sort((a, b) => {let fa = a.bu,fb = b.bu; 
      if (fa < fb) 
      {
        return -1;
        } 
      else if (fa > fb) 
      {
        return 1;
        } 
      return 0; 
      }); 
      
       return data;
        
      
    }

    addTotal(data)
      {
      var payload2={};
      payload2['bu']='Grand Total';
      var tot=0;
      for(var i=0;i<data.length;i++)
      {
        tot += data[i].catA;
      }
      payload2['catA']=tot;
      tot=0;
      for(var i=0;i<data.length;i++)
      {
        tot += data[i].catB;
      }
      payload2['catB']=tot;
      tot=0;
      for(var i=0;i<data.length;i++)
      {
        tot += data[i].catC;
      }
      payload2['catC']=tot;
      tot=0;
      for(var i=0;i<data.length;i++)
      {
        tot += data[i].unmarked;
      }
      payload2['unmarked']=tot;
      tot=0;
      for(var i=0;i<data.length;i++)
      {
        tot += data[i].grandtotal;
      }
      payload2['grandtotal']=tot;

      data.push(payload2);
      return data;
    }
         
         getColor(bu){
            
            
            if (bu=='Grand Total') {
              return{"background-color":"yellow"}
            }
         }



      dataHiding(previousData) {
      console.log("135", previousData.length, JSON.stringify(previousData));
      var payload2=[];
      var temp=[];
      for (var i=0;i<previousData.length;i++)
      {    
           if (temp!=undefined ? temp.filter(Element=>Element.bu==previousData[i].bu).length==0 : true)
           {
           var tempD={};
           tempD['bu']=previousData[i].bu;
          //  tempD['client']=previousData[i].client;
           
           var data=[];
           data=previousData.filter(Element=>Element.bu==tempD.bu);
           console.log("test1", JSON.stringify(data[0]));
           payload2.push(data[0]);
           
           temp.push(tempD);

           for (var j=1;j<data.length;j++)
           {
               var retpayload={};               
               
              
              retpayload['bu']='';
              retpayload['client']=data[j].client;
              retpayload['format']=data[j].format;
              retpayload['catA']=data[j].catA;
              retpayload['catB']=data[j].catB;   
              retpayload['catC']=data[j].catC;
              retpayload['unmarked']=data[j].unmarked;
              retpayload['grandtotal']=retpayload['catA']+ retpayload['catB']+ retpayload['catC']+ retpayload['unmarked'];
              
              payload2.push(retpayload);
               
           }
        }

      }
          console.log("164", JSON.stringify(payload2));          
          return payload2;


    }




    /**
     *
     * @param {String} arg1
     * @return {String}
     */
     hyperlinkData(rowData,rowIndex,tableData)
    {
        // console.log("195", rowIndex, JSON.stringify(rowData.data));
        // console.log("195", rowIndex, JSON.stringify(tableData));
        var payload={};
        payload['bu']='NA';
        if(rowData.data.bu.length==0)
        {
          for(var i=rowIndex-1;i>=0;i--)
          {
            if(tableData[i].client.length>0)
            {
              payload['bu']=tableData[i].bu;
              // payload['client']=tableData[i].client;
               payload['client']=rowData.data.client;
              payload['format']=rowData.data.format;
              payload['catA']=rowData.data.catA;
              payload['catB']=rowData.data.catB;   
              payload['catC']=rowData.data.catC;
              payload['unmarked']=rowData.data.unmarked;
              payload['grandtotal']=rowData.data.grandtotal;
              break;
            }
          }        
        }
        console.log("!!",payload);
        return payload.bu=='NA'?rowData.data:payload;
    }


  

  }
  
  return PageModule;
});
