define([], () => {
  'use strict';

  class PageModule {
  }

   // let arrayobj=Object.values(); 
    // const arrayUniqueByKey = [...new Map(pursuit.map(item =>  [item['manPursuitgovernance'], item])).values()];   
    // var uni=arrayUniqueByKey;


  PageModule.prototype.Report = function (AllBoData,employeeData,CategoryBo,year) {
    let array=[];
    let TotalHrs=0;
    let TotJanHrs=0,TotFebHrs=0,TotMarHrs=0,TotAprHrs=0,TotMayHrs=0,TotJunHrs=0,TotJulHrs=0,TotAugHrs=0,TotSepHrs=0,TotOctHrs=0,TotNovHrs=0,TotDecHrs=0;
    for(let i=0;i<CategoryBo.length;i++){
    let BoData=AllBoData.filter(e=>e.category===CategoryBo[i].id);
    
    let JanHrs=0,FebHrs=0,MarHrs=0,AprHrs=0,MayHrs=0,JunHrs=0,JulHrs=0,AugHrs=0,SepHrs=0,OctHrs=0,NovHrs=0,DecHrs=0;
    let JanArray=[],FebArray=[],MarArray=[],AprArray=[],MayArray=[],JunArray=[],JulArray=[],AugArray=[],SepArray=[],OctArray=[],NovArray=[],DecArray=[];
    let date=new Date(year);
    let JanTotal=0,FebTotal=0,MarTotal=0,AprTotal=0,MayTotal=0,JunTotal=0,JulTotal=0,AugTotal=0,SepTotal=0,OctTotal=0,NovTotal=0,DecTotal=0;

    let arrayobj=Object.values(BoData); 
    const arrayUniqueByKey = [...new Map(BoData.map(item =>  [item['employee'], item])).values()];   
    let uni=arrayUniqueByKey;

    for(let a=0;a<uni.length;a++){
      let employeeWiseData=BoData.filter(e=>e.employee===uni[a].employee);
      let name=employeeData.find(e=>e.id===uni[a].employee);
      let janemployeeHrs=0,febemployeeHrs=0,maremployeeHrs=0,apremployeeHrs=0,mayemployeeHrs=0,junemployeeHrs=0,julemployeeHrs=0,augemployeeHrs=0,sepemployeeHrs=0,octemployeeHrs=0,novemployeeHrs=0,decemployeeHrs=0;
      let janemployeeArray=[],febemployeeArray=[],maremployeeArray=[],apremployeeArray=[],mayemployeeArray=[],junemployeeArray=[],julemployeeArray=[],augemployeeArray=[],sepemployeeArray=[],octemployeeArray=[],novemployeeArray=[],decemployeeArray=[];
      let month=0;
      let montharray=[];
      for(let c=0;c<employeeWiseData.length;c++){

      if(new Date(employeeWiseData[c].weekEnding).getFullYear()===new Date(date).getFullYear());{

        month=new Date(employeeWiseData[c].weekEnding).getMonth()+1;
        if(montharray.includes(month)){
          let dummy=1
        }
        else{
          montharray.push(month)
        }

       let weekEndHrs=Number(employeeWiseData[c].day1)+Number(employeeWiseData[c].day2)+Number(employeeWiseData[c].day3)+Number(employeeWiseData[c].day4)+Number(employeeWiseData[c].day5)+Number(employeeWiseData[c].day6)+Number(employeeWiseData[c].day7);
      //  employeeHrs+=Number(weekEndHrs);
      //  employeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});

        switch(month){
        case 1:
          janemployeeHrs+=Number(weekEndHrs);
          janemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          JanHrs+=Number(weekEndHrs);
          JanTotal+= Number(weekEndHrs);
          TotJanHrs+=Number(weekEndHrs);
          break;
        case 2:
          febemployeeHrs+=Number(weekEndHrs);
          febemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          FebHrs+=Number(weekEndHrs);
          FebTotal+=Number(weekEndHrs) ;
          TotFebHrs+=Number(weekEndHrs);
          break;
        case 3:
          maremployeeHrs+=Number(weekEndHrs);
          maremployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          MarHrs+=Number(weekEndHrs);
          MarTotal+=Number(weekEndHrs) ;
          TotMarHrs+=Number(weekEndHrs);
          break;
        case 4:
          apremployeeHrs+=Number(weekEndHrs);
          apremployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          AprHrs+=Number(weekEndHrs);
          AprTotal+=Number(weekEndHrs) ;
          TotAprHrs+=Number(weekEndHrs);
          break;
        case 5:
          mayemployeeHrs+=Number(weekEndHrs);
          mayemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          MayHrs+=Number(weekEndHrs);
          MayTotal+=Number(weekEndHrs) ;
          TotMayHrs+=Number(weekEndHrs);
          break;
        case 6:
          junemployeeHrs+=Number(weekEndHrs);
          junemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          JunHrs+=Number(weekEndHrs);
          JunTotal+=Number(weekEndHrs) ;
          TotJunHrs+=Number(weekEndHrs);
          break;
        case 7:
          julemployeeHrs+=Number(weekEndHrs);
          julemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          JulHrs+=Number(weekEndHrs);
          JulTotal+=Number(weekEndHrs) ;
          TotJulHrs+=Number(weekEndHrs);
          break;
        case 8:
          augemployeeHrs+=Number(weekEndHrs);
          augemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          AugHrs+=Number(weekEndHrs);
          AugTotal+=Number(weekEndHrs);
          TotAugHrs+=Number(weekEndHrs);
          break;
        case 9:
          sepemployeeHrs+=Number(weekEndHrs);
          sepemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          SepHrs+=Number(weekEndHrs);
          SepTotal+=Number(weekEndHrs) ;
          TotSepHrs+=Number(weekEndHrs);
          break;
        case 10:
          octemployeeHrs+=Number(weekEndHrs);
          octemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          OctHrs+=Number(weekEndHrs);
          OctTotal+=Number(weekEndHrs) ;
          TotOctHrs+=Number(weekEndHrs);
          break;
        case 11:
          novemployeeHrs+=Number(weekEndHrs);
          novemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          NovHrs+=Number(weekEndHrs);
          NovTotal+=Number(weekEndHrs) ;
          TotNovHrs+=Number(weekEndHrs);
          break;
        case 12:
          decemployeeHrs+=Number(weekEndHrs);
          decemployeeArray.push({weekEnding:employeeWiseData[c].weekEnding ?employeeWiseData[c].weekEnding:'',  hrs:weekEndHrs, data:employeeWiseData[c], id:employeeWiseData[c].id});
          DecHrs+=Number(weekEndHrs);
          DecTotal+=Number(weekEndHrs) ;
          TotDecHrs+=Number(weekEndHrs);
          break;

      }
      }}
      // employeeArray.push({weekEnding:'Total',  hrs:employeeHrs});
     for(let e=0;e<montharray.length;e++){
     switch(montharray[e]){
        case 1:
          janemployeeArray.push({weekEnding:'Total',  hrs:janemployeeHrs});
          JanArray.push({name: name.name?name.name:'',  hrs:janemployeeHrs, data:janemployeeArray});
          break;
        case 2:
          febemployeeArray.push({weekEnding:'Total',  hrs:febemployeeHrs});
          FebArray.push({name: name.name?name.name:'',  hrs:febemployeeHrs, data:febemployeeArray});
          break;
        case 3:
          maremployeeArray.push({weekEnding:'Total',  hrs:maremployeeHrs});
          MarArray.push({name: name.name?name.name:'',  hrs:maremployeeHrs, data:maremployeeArray});
          break;
        case 4:
          apremployeeArray.push({weekEnding:'Total',  hrs:apremployeeHrs});
          AprArray.push({name: name.name?name.name:'',  hrs:apremployeeHrs, data:apremployeeArray});
          break;
        case 5:
          mayemployeeArray.push({weekEnding:'Total',  hrs:mayemployeeHrs});
          MayArray.push({name: name.name?name.name:'',  hrs:mayemployeeHrs, data:mayemployeeArray});
          break;
        case 6:
          junemployeeArray.push({weekEnding:'Total',  hrs:junemployeeHrs});
          JunArray.push({name: name.name?name.name:'',  hrs:junemployeeHrs, data:junemployeeArray});
          break;
        case 7:
          julemployeeArray.push({weekEnding:'Total',  hrs:julemployeeHrs});
          JulArray.push({name: name.name?name.name:'',  hrs:julemployeeHrs, data:julemployeeArray});
          break;
        case 8:
          augemployeeArray.push({weekEnding:'Total',  hrs:augemployeeHrs});
          AugArray.push({name: name.name?name.name:'',  hrs:augemployeeHrs, data:augemployeeArray});
          break;
        case 9:
          sepemployeeArray.push({weekEnding:'Total',  hrs:sepemployeeHrs});
          SepArray.push({name: name.name?name.name:'',  hrs:sepemployeeHrs, data:sepemployeeArray});
          break;
        case 10:
          octemployeeArray.push({weekEnding:'Total',  hrs:octemployeeHrs});
          OctArray.push({name: name.name?name.name:'',  hrs:octemployeeHrs, data:octemployeeArray});
          break;
        case 11:
          novemployeeArray.push({weekEnding:'Total',  hrs:novemployeeHrs});
          NovArray.push({name: name.name?name.name:'',  hrs:novemployeeHrs, data:novemployeeArray});
          break;
        case 12:
          decemployeeArray.push({weekEnding:'Total',  hrs:decemployeeHrs});
          DecArray.push({name: name.name?name.name:'',  hrs:decemployeeHrs, data:decemployeeArray});
          break;

      }}
      // CategoryArray.push({name: name.name?name.name:'',  hrs:employeeHrs, data:employeeArray});
    }
       JanArray.push({name: 'Total',  hrs:JanTotal});
       FebArray.push({name: 'Total',  hrs:FebTotal});
       MarArray.push({name: 'Total',  hrs:MarTotal});
       AprArray.push({name: 'Total',  hrs:AprTotal});
       MayArray.push({name: 'Total',  hrs:MayTotal});
       JunArray.push({name: 'Total',  hrs:JunTotal});
       JulArray.push({name: 'Total',  hrs:JulTotal});
       AugArray.push({name: 'Total',  hrs:AugTotal});
       SepArray.push({name: 'Total',  hrs:SepTotal});
       OctArray.push({name: 'Total',  hrs:OctTotal});
       NovArray.push({name: 'Total',  hrs:NovTotal});
       DecArray.push({name: 'Total',  hrs:DecTotal});

       TotalHrs = Number(TotalHrs)+ Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);
        let object={};
        object['category']= CategoryBo[i].listOfCategory;
        object['JanHrs']= JanHrs;
        object['janData']= JanArray;
        object['FebHrs']= FebHrs;
        object['febData']= FebArray;
        object['MarHrs']= MarHrs;
        object['marData']= MarArray;
        object['AprHrs']= AprHrs;
        object['aprData']= AprArray;
        object['MayHrs']= MayHrs;
        object['mayData']= MayArray;
        object['JunHrs']= JunHrs;
        object['junData']= JunArray;
        object['JulHrs']= JulHrs;
        object['julData']= JulArray;
        object['AugHrs']= AugHrs;
        object['augData']= AugArray;
        object['SepHrs']= SepHrs;
        object['sepData']= SepArray;
        object['OctHrs']= OctHrs;
        object['octData']= OctArray;
        object['NovHrs']= NovHrs;
        object['novData']= NovArray;
        object['DecHrs']= DecHrs;
        object['decData']= DecArray;
        object['total']=Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);;
        object['percentage']='';
        array.push(object);

        // let object1={};
        // object1['category']= 'Design Authority';
        // object1['janHrs']= DesignAuthorityHrs;
        // object1['Data']= DesignArray;
        // object1['total']=DesignAuthorityHrs;
        // object1['percentage']=((Number(DesignAuthorityHrs)*100)/(Number(TotalHrs)===0?1:Number(TotalHrs))).toFixed(2)+'%';
        // array.push(object1);

        // let object2={};
        // object2['category']= 'Pursuit Response and Offers';
        // object2['janHrs']= PursuitResponseHrs;
        // object2['Data']= PursuitArray;
        // object2['total']=PursuitResponseHrs;
        // object2['percentage']=((Number(PursuitResponseHrs)*100)/(Number(TotalHrs)===0?1:Number(TotalHrs))).toFixed(2)+'%';
        // array.push(object2);
    }
    for(let x=0;x<array.length;x++){

      array[x].percentage=((Number(array[x].total)*100)/(Number(TotalHrs)===0?1:Number(TotalHrs))).toFixed(2)+'%';
    }
   
        let object3={};
        object3['category']= 'Grand Total';
        object3['JanHrs']= TotJanHrs;
        object3['FebHrs']= TotFebHrs;
        object3['MarHrs']= TotMarHrs;
        object3['AprHrs']= TotAprHrs;
        object3['MayHrs']= TotMayHrs;
        object3['JunHrs']= TotJunHrs;
        object3['JulHrs']= TotJulHrs;
        object3['AugHrs']= TotAugHrs;
        object3['SepHrs']= TotSepHrs;
        object3['OctHrs']= TotOctHrs;
        object3['NovHrs']= TotNovHrs;
        object3['DecHrs']= TotDecHrs;
        object3['total']=TotalHrs;
        object3['percentage']=TotalHrs===0?0:100+'%';
        array.push(object3);
      return array;
    };

    PageModule.prototype.exportToPDF = function () {

    // var images = document.querySelectorAll("#downloadImage")
    // for (var i = 0, len = images.length; i < len; i++) {
    //   images[i].removeAttribute(":src");
    // }
    domtoimage.toPng(document.getElementById('table-id-to-export'))
      .then(function (blob) {
        var pdf = new jsPDF('l', 'pt', [$('#table-id-to-export').width(), $('#table-id-to-export').height()]);
        pdf.addImage(blob, 'PNG', 0, 0, $('#table-id-to-export').width(), $('#table-id-to-export').height());
        pdf.save("Employees.pdf");


      });
  };
    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.TableHeading = function (month) {
    let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b});
    }

    let innerString = '';
    innerString = innerString + '[{' + '"headerText":' + '"Category",' + '"field":' + '"category",'+'"template":'+'"Others",'+'"width":'+'"211",'+'"headerStyle":'+'"text-align: left;"' + '},';
                              
    for(let i = 0; i < month.length; i++) {
      let x=HeadArray[month[i]];
      // if(i === month.length-1) {
        
      //   innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"width":'+'"83",' + '"field":' + '"'+x + '",'+'"template":'+'"'+x + '"' + '}';
      //   break;
      // }
      innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"style":'+'"text-align: center;",'+'"width":'+'"84",' + '"field":' + '"'+x + 'Hrs",'+'"template":'+'"'+x + '"' + '},';
    }

    innerString = innerString + '{' + '"headerText":' + '"Total",' + '"field":' + '"total",'+'"template":'+'"Others",'+'"width":'+'"90",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"%",' + '"field":' + '"percentage",'+'"template":'+'"Others",'+'"width":'+'"80",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '}';
    innerString = innerString + ']';

    let columns=JSON.parse(innerString);
    return columns;
    };
    /**
     *
     * @param {String} arg1
     * @return {String}
     */

    // if (maxValue === undefined) {
    //   maxValue = month[0];
    //   month.forEach(e => {
    //     if (e > maxValue){
    //      maxValue = e;}
    //   });}
    
    // if (minValue === undefined) {
    //   minValue = month[0];
    //   month.forEach(e => {
    //     if (e < minValue){
    //      minValue = e;}
    //   });}

    PageModule.prototype.date = function (month,year) {
    let maxValue, minValue;
    let queryString = "";
    let queryString1 = "";
    let dateRanges = [];
    let array=[];
    let y= year;
    if(month.includes("ALL")===false){
      for(let i=0;i<month.length;i++){
        let m = month[i];
        let firstDay = new Date(y, Number(m), 1);
        let lastDay = new Date(y, Number(m) + 1, 0);

        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
        dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    }
      else{
        maxValue=11,minValue=0;
        let firstDay = new Date(y, Number(minValue), 1);
        let lastDay = new Date(y, Number(maxValue) + 1, 0);
       
        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
       dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    
      
      if (dateRanges.length === 1) {
      queryString =   "AND "+dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString = "AND(" + dateRanges.join(" OR ") + ")";
      }

      if (dateRanges.length === 1) {
      queryString1 =   dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString1 = "(" + dateRanges.join(" OR ") + ")";
      }
      array.push(queryString);
      array.push(queryString1);

       return array;        
   };

PageModule.prototype.currentdate = function () {

let date = new Date().getFullYear();
// date.push(new Date().getMonth());
// date.push(new Date().getFullYear());
return date;
};

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.employeeLOV = function (data) {

      let object={},array=[];
      for(let i=0;i<data.length;i++){
        object['name']=data[i].name+'-'+data[i].emploeeID;
        object['id']=data[i].id;
        array.push(object);
      }
      return array;

    };

    PageModule.prototype.getemployeeLOV = function(context) {
        return context.data.name + '-' + context.data.employeeID;
    };

    PageModule.prototype.getDates = function (date) {
    // var innerArray =  ["01-Apr-2023","02-Apr-2023","03-Apr-2023","04-Apr-2023","05-Apr-2023","06-Apr-2023","07-Apr-2023"];
    var returndate = `${new Date(date).getFullYear()}-${(new Date(date).getMonth())<9?'0'+(new Date(date).getMonth()+1):''+(new Date(date).getMonth()+1)}-${(new Date(date).getDate())<10?'0'+(new Date(date).getDate()):''+(new Date(date).getDate())}`;
    

    
    return returndate;
  };

  PageModule.prototype.createTableColumns = function (date) {
    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
      }
    }}
    
    innerArray=innerArray.reverse();
    
    // let array=[];
    // for(let i = innerArray.length; i > 0; i--){
    // let obj={};
    // obj["Category"]=''
    // }
    

    let innerString = '';
    innerString = innerString + '[{' + '"headerText":' + '"Category",' +'"headerStyle":'+'"text-align: center;",'+'"template":'+'"category",' + '"field":' + '"categoryObject",'+'"width":'+'"170"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Week Ending",' + '"field":' + '"weekEnding",'+'"width":'+'"140"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Project Details",' + '"field":' + '"projectDetails",'+'"width":'+'"150"' + '},';
                              
    for(let i = 1; i <= innerArray.length; i++) {
      if(i === innerArray.length) {
        innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
    }
    innerString = innerString + '{' + '"headerText":' + '"Comments",' + '"field":' + '"comment1",'+'"template":'+'"comments",'+'"width":'+'"130"' + '}';
    innerString = innerString + ']';
    console.log("!!!",JSON.parse(innerString));
    let returnarray=[];
    returnarray.push(JSON.parse(innerString));
    returnarray.push(innerArray);
    return returnarray;
  };

    PageModule.prototype.bardata = function (data,month,type) {
      let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
     if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b;});
    }

     let info=[];
     let info2=[];
     for(let i=0; i<data.length; i++){
      if(type=='Summary' || (type!='Summary' && type==data[i].category)){
      // let namePayload=[];
      // namePayload.push(data[i].name);
      for(let j=0; j<month.length; j++){
        let x=HeadArray[month[j]];
        
     let retpayload={};
    
    //  if(type=="Capabiltiy Initiatives"){
    //   retpayload['name']="Capabiltiy Initiatives";
    //  }
    //   else if(type=="Enterprise Design/Design Authority"){
    //   retpayload['name']="Enterprise Design/Design Authority";
    //  }
     
    //  else if(type=="Pursuit Response and Offers"){
    //    retpayload['name']="Pursuit Response and Offers";
    //  }
    //  else if(type=="Project Work"){
    //   retpayload['name']="Project Work";
    //  }
    //  else if(type=="Summary"){
      retpayload['name']=data[i].category;
     
     retpayload['month']=x;
     retpayload['value']= Number(data[i][x+'Hrs']);
     if(retpayload['name']!=='Grand Total'){
     info.push(retpayload);}
        
      }

      let retpayload1={};
     retpayload1['name']=data[i].category;
     retpayload1['month']='All';
     retpayload1['value']= Number(((Number(data[i]['total'])/Number(data[data.length-1]['total']))*100).toFixed(2));
     if(retpayload1['name']!=='Grand Total'){
     info2.push(retpayload1);}
      
     }}

let final=[];
   final.push(info);
   final.push(info2);
     return final;
    };
  return PageModule;
});
