define([], () => {
  'use strict';

  var PageModule = function PageModule() {};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.category = function (cat) {
  var data;
    if (cat<=2){
      data = "Short Term Training";
    }
    else if(cat>2 && cat<=5){
      data = "Medium Term Training";
    }
    else if (cat>5){
      data = "Long Term training";
    }
    //console.log('22##',data);
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.writtenvalues = function (arg1) {

    console.log('33##',arg1);
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  PageModule.prototype.searchCap=function(capabilityID,empBOID,lead1,lead2,uslead1,uslead2){
    
    
  if(empBOID==lead1){

   return true;
  }
  
  else if(empBOID==lead2){

   return true;
  }
  else if(empBOID==uslead1){

   return true;
  }
  else if(empBOID==uslead2){

   return true;

  }
  else {
    return false;
  }
  // console.log("@1",capabilityID);
  };

  PageModule.prototype.search = function (training,Capability) {
    console.log("!!!",training);
     console.log("!!!",Capability);
    //  var com= user[0].globalPracticeObject.items[0].name;
    // console.log("11!!",com);
    // var data=[];
    // var ff=[];
    // for(var j=0; j<Capability.length; j++){
    //   var pp=Capability[j].lead1;
    //   var tt=Capability[j].lead2;
    //   //console.log("00##", pp);
    //   console.log("77##",tt);
    //   ff.push(pp);
    //   ff.push(tt);
    //   console.log("00##", ff);
    // }
    var data=[];
    for (var i=0; i<training.length; i++){
    var retpayload={};
     
    // var emp = empBO.find(ele => ele.id == training[i].employeeID);
    //console.log("!!!",emp);
    //console.log("!!!",empBO);
    //var cap = Capability.find(ele => ele.id==emp.globalPractice);
    //var ccc= Capability.lead1;
    //var ppp= Capability.lead2;
    //console.log('##',cap.name);
    //if(ccc||ppp!=undefined){
    //if(com==cap.name){
    // for(var j = 0; j < empBO.length; j++) {
      if(training[i].employeeIDObject.items[0].globalPractice == Capability) {
    retpayload['id']=training[i].id;
    retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID;
    //retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID
    retpayload['trainer']=training[i].trainer;
    if(training[i].coTrainer1 != null){
    retpayload['trainer1']=training[i].coTrainer1Object.items[0].name;
    }
    if (training[i].coTrainer2 != null){
    retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    }
    //retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    //retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
     if (training[i].coTrainer3 != null ){
    retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
    }
    //training[i].coTrainer1Object.items[0].name != undefined ? retpayload['trainer1']=training[i].coTrainer1Object.items[0].name:retpayload['trainer1']=" ";
    //training[i].coTrainer2Object.items[0].name != undefined ? retpayload['trainer2']=training[i].coTrainer2Object.items[0].name:retpayload['trainer2']=" ";
    //training[i].coTrainer3Object.items[0].name != undefined ? retpayload['trainer3']=training[i].coTrainer3Object.items[0].name:retpayload['trainer3']="none";
    retpayload['category']=training[i].category;
    retpayload['hours']=training[i].hours;
    retpayload['fromDate']=training[i].fromDate;
    retpayload['toDate']=training[i].toDate;
    retpayload['topic']=training[i].topic;
    retpayload['type1']=training[i].type1;
    retpayload['status']=training[i].status;
    retpayload['comments']=training[i].comments;
    retpayload['nicheSkills']=training[i].nicheSkills;
    retpayload['numberOfAttendees']=training[i].numberOfAttendees;
   retpayload['comPorRoj']=training[i].comProRoj;
    data.push(retpayload);
      }
    //console.log('99##',emp);
    }
    // }
   // }
    
    //console.log('55##',data);
    return data;
  };

PageModule.prototype.searchForAdmin = function (training) {
    console.log("!!!",training);
    //  var com= user[0].globalPracticeObject.items[0].name;
    // console.log("11!!",com);
    // var data=[];
    // var ff=[];
    // for(var j=0; j<Capability.length; j++){
    //   var pp=Capability[j].lead1;
    //   var tt=Capability[j].lead2;
    //   //console.log("00##", pp);
    //   console.log("77##",tt);
    //   ff.push(pp);
    //   ff.push(tt);
    //   console.log("00##", ff);
    // }
    var data=[];
    for (var i=0; i<training.length; i++){
    var retpayload={};
     
    // var emp = empBO.find(ele => ele.id == training[i].employeeID);
    //console.log("!!!",emp);
    //console.log("!!!",empBO);
    //var cap = Capability.find(ele => ele.id==emp.globalPractice);
    //var ccc= Capability.lead1;
    //var ppp= Capability.lead2;
    //console.log('##',cap.name);
    //if(ccc||ppp!=undefined){
    //if(com==cap.name){
    // for(var j = 0; j < empBO.length; j++) {
      // if(training[i].employeeIDObject.items[0].globalPractice == Capability) {
    retpayload['id']=training[i].id;
    retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID;
    //retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID
    retpayload['trainer']=training[i].trainer;
    if(training[i].coTrainer1 != null){
    retpayload['trainer1']=training[i].coTrainer1Object.items[0].name;
    }
    if (training[i].coTrainer2 != null){
    retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    }
    //retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    //retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
     if (training[i].coTrainer3 != null ){
    retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
    }
    //training[i].coTrainer1Object.items[0].name != undefined ? retpayload['trainer1']=training[i].coTrainer1Object.items[0].name:retpayload['trainer1']=" ";
    //training[i].coTrainer2Object.items[0].name != undefined ? retpayload['trainer2']=training[i].coTrainer2Object.items[0].name:retpayload['trainer2']=" ";
    //training[i].coTrainer3Object.items[0].name != undefined ? retpayload['trainer3']=training[i].coTrainer3Object.items[0].name:retpayload['trainer3']="none";
    retpayload['category']=training[i].category;
    retpayload['hours']=training[i].hours;
    retpayload['fromDate']=training[i].fromDate;
    retpayload['toDate']=training[i].toDate;
    retpayload['topic']=training[i].topic;
    retpayload['type1']=training[i].type1;
    retpayload['status']=training[i].status;
    retpayload['comments']=training[i].comments;
    retpayload['nicheSkills']=training[i].nicheSkills;
    retpayload['numberOfAttendees']=training[i].numberOfAttendees;
     retpayload['comProRoj']=training[i].comPorRoj;
  
    data.push(retpayload);
      }
    //console.log('99##',emp);
   // }
    // }
   // }
    
    //console.log('55##',data);
    return data;
  };


    PageModule.prototype.Newsearch = function (training,empBO) {
    var com= empBO[0].globalPracticeObject.items[0].name;
    //console.log("11!!",com);
    //console.log('##',training);
    var data=[];
  
    for (var i=0; i<training.length; i++){
    var retpayload={};
    var emp = emp.find(ele => ele.id == training[i].employeeID);
    
    retpayload['id']=training[i].id;
    retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID;
    retpayload['Trainer']=training[i].trainer;
    retpayload['trainer1']=training[i].coTrainer1Object.items[0].name;
    if (training[i].coTrainer2 != null){
    retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    }
    //retpayload['trainer2']=training[i].coTrainer2Object.items[0].name;
    //retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
     if (training[i].coTrainer3 != null ){
    retpayload['trainer3']=training[i].coTrainer3Object.items[0].name;
    }
    //training[i].coTrainer1Object.items[0].name != undefined ? retpayload['trainer1']=training[i].coTrainer1Object.items[0].name:retpayload['trainer1']=" ";
    //training[i].coTrainer2Object.items[0].name != undefined ? retpayload['trainer2']=training[i].coTrainer2Object.items[0].name:retpayload['trainer2']=" ";
    //training[i].coTrainer3Object.items[0].name != undefined ? retpayload['trainer3']=training[i].coTrainer3Object.items[0].name:retpayload['trainer3']="none";
    retpayload['category']=training[i].category;
    retpayload['hours']=training[i].hours;
    retpayload['fromDate']=training[i].fromDate;
    retpayload['toDate']=training[i].toDate;
    retpayload['topic']=training[i].topic;
    retpayload['type1']=training[i].type1;
    retpayload['status']=training[i].status;
    retpayload['comments']=training[i].comments;
    retpayload['nicheSkills']=training[i].nicheSkills;
    retpayload['numberOfAttendees']=training[i].numberOfAttendees;
  
    data.push(retpayload);
    }
    //console.log('55##',data);
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.allTrainers = function (coVar1, coVar2, coVar3) {

    var arg1,arg2,arg3=1,total;
    
    arg1 =parseInt(coVar1);
    arg2 = parseInt(coVar2);
    arg3 = parseInt(coVar3);

    total =arg1+arg2+arg3+1;

    return total;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.appendEmpIds = function (P_CapabilityDetails, P_Format) {
    var retPayload=[];
    if(P_Format=="India")
    {
      P_CapabilityDetails.lead1 != null ? retPayload.push(P_CapabilityDetails['lead1Object'].items[0].employeeID) : null;
      P_CapabilityDetails.lead2 != null ? retPayload.push(P_CapabilityDetails['lead2Object'].items[0].employeeID) : null;
    }
    else if(P_Format=="US")
    {
      P_CapabilityDetails.uSCapabilityLead1 != null ? retPayload.push(P_CapabilityDetails['uSCapabilityLead1Object'].items[0].employeeID) : null;
      P_CapabilityDetails.uSCapabilityLead2 != null ? retPayload.push(P_CapabilityDetails['uSCapabilityLead2Object'].items[0].employeeID) : null;
    }

    //console.log("23##",retPayload);
    return retPayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  function changeFormat(currentDate) {
		try{
			var now = new Date(currentDate);
			return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
		}
		catch(err){
			//console.log('#131'+currentDate);
			return currentDate;
		}
	};
  
  PageModule.prototype.createTrainingTask = function (TaskBO, CategoryBO, Details, Token, TaskID, CreatedBy, AssignmentEmpBO, EmpBO ) {

    var retpayload = [];
    retpayload['Task'] ={};
    retpayload['TaskAssignmentdetails'] = {};

    var taskID = TaskID+1;
    var currentTask = '';

    for (var i=0; i<AssignmentEmpBO.length; i++)
    {
      var Emp = EmpBO.find(ele => ele.employeeID = AssignmentEmpBO[i]);
       if(CategoryBO[0].allocationType == 'Single')
       {
         if(Token==undefined)
         {
           currentTask = TaskBO.find(ele => ele.TaskAssignmentdetailsCollect.items[0].employeeID == Emp.id);
         }
         else
         {
           currentTask = TaskBO.find(function(data){return data.categoryID == CategoryBO.id  && data.data.token == Token && data.taskAssignmentBOCollect.items[0].employeeID == Emp.id;});
         }
        }
         else
         {
           currentTask = TaskBO.find(function(data){return data.categoryID == CategoryBO.id && data.token == Token;});
         }

         if(currentTask != undefined)
         {
           retpayload['TaskAssignmentdetails']['taskID'] = currentTask.id;
           retpayload['TaskAssignmentdetails']['status'] = 'True';
         }
         else{
           retpayload['Task']['taskID'] = taskID;
           retpayload['Task']['categoryID'] = CategoryBO[0].id;
           retpayload['Task']['details'] = Details;
           retpayload['Task']['token'] = Token ? Token : null;
           retpayload['Task']['assignedDate'] = changeFormat(new Date());
           retpayload['Task']['createdBy'] = CreatedBy;
           retpayload['TaskAssignmentdetails']['status'] = 'False';
         }
       }
      //console.log("13##",retpayload);
      return retpayload;
    };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.assignValue = function (arg1) {

    console.log("!!!",arg1);
    
  };


  PageModule.prototype.checkRoles = function (roleArray, currentRowData, globalPractiseData, currentUserId) {

     var roles={var1:false}; 
     //console.log(JSON.stringify(roleArray)+'#176');
     //console.log(JSON.stringify(roleArray.whitepapers));
//if(roleArray.whitepapers.find(element=>element.functionality=='White Paper Masters').accessType=='N')
//{
      // if(roleArray.trainertracking.find(element=>element.functionality=='Trainer Tracking').accessType=='W' && currentRowData.status=='CL APPROVAL REQUESTED' )
       
      //   {
      //   roles.var1=true;
        
      //   }
//CLs
for(var i = 0; i < globalPractiseData.length; i++) {
      if(chkCLBOId(globalPractiseData[i],currentUserId) && currentRowData.status=='CL APPROVAL REQUESTED'){
        roles.var1=true;
        break;
       // roles.var2=false;
      }
}
    console.log('!!!'+JSON.stringify(roles));
    //console.log('#29'+JSON.stringify(currentRowData));
    return roles;
  };

  PageModule.prototype.checkRolesforSearch = function (globalPractiseData, currentUserId) {

     var roles={var1:false,var2:null}; 
     //console.log(JSON.stringify(roleArray)+'#176');
     //console.log(JSON.stringify(roleArray.whitepapers));
//if(roleArray.whitepapers.find(element=>element.functionality=='White Paper Masters').accessType=='N')
//{
      // if(roleArray.trainertracking.find(element=>element.functionality=='Trainer Tracking').accessType=='W' && currentRowData.status=='CL APPROVAL REQUESTED' )
       
      //   {
      //   roles.var1=true;
        
      //   }
//CLs
for(var i = 0; i < globalPractiseData.length; i++) {
      if(chkCLBOId(globalPractiseData[i],currentUserId)){
        roles.var1=true;
        roles.var2=globalPractiseData[i].id;
       // roles.var2=false;
      }
}
    console.log('!!!'+JSON.stringify(roles));
    //console.log('#29'+JSON.stringify(currentRowData));
    return roles;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createMail = function (topic,sessions,user,status,name) {
     var body = "";
    var myViewlink="https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/";
    
    var columnStyle = "text-align: center; vertical-align: middle;";
    body += "<head> <style>.sty{text-align: center; vertical-align: middle;} .center {margin-left:75; margin-right: 100px;} table { font-family: arial, sans-serif; border-collapse: collapse; width: 60%;} td, th { border: 1px solid; text-align:left; padding: 10px; font-size: 12px;} th { background-color: #ADD8E6; text-align:center; } </style> </head> <br>";
    //body += "</body>";
    //body += "name";
    body += "<br>The Conducted training on topic <b>" +topic+ "</b> has been <b>"+status+"</b> . Please refer the below table for more details: <br><br>";
    body += "<table class = center><tr> <th>Status</th> <th>Comments</th> <th>Action By</th> <th>Action Date</th> </tr>";
    

    for(var i = 0; i < sessions.length; i++) {
     
       
      //     var date = new Date(sessions[i].creationDate);
      //  const formattedDate = date.toLocaleDateString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).replace(/[/]/g, '-');
    var formattedDate = dateFormatJS(sessions[i].creationDate);
       //console.log("))",formattedDate);
      
        body += "<tr><td>"+sessions[i].currentStatus+"</td><td>"+sessions[i].comments+"</td><td>"+sessions[i].workflowCreatedBy+"</td><td class = sty>"+formattedDate+"</td></tr>";
         
    
    }
    body += "</table><br><br>";

    body += "For more details, please <a href="+myViewlink+"><b>click here</b></a> and login to My View and navigate to My Conducted Training";
    
   
    body += "<br><br>Regards,<br>"+user+"</body>";
    
  

    return body;
  };

  function dateFormatJS (bo_date){
    const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var date = new Date(bo_date);
    var reqd_date = (date.getDate()<10?'0'+date.getDate():''+date.getDate())+'-'+months[date.getMonth()]+'-'+date.getFullYear();
    return reqd_date;
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTrainersData = function (trainer,cotrainer1,cotrainer2,cotrainer3) {
    //console.log("!!!",cotrainer1);
    var data = [];
    if((cotrainer1==null || cotrainer1=="")&& (cotrainer2==null ||cotrainer2== "") && (cotrainer3==null || cotrainer3=="")){
     data = [trainer];
     return data;}

     else if(cotrainer1!=null && (cotrainer2==null || cotrainer2=="") && (cotrainer3==null || cotrainer3=="" )){
       data=[trainer,cotrainer1];}
       else if(cotrainer1!=null && cotrainer2!=null && (cotrainer3==null || cotrainer3 =="" )){
          data=[trainer,cotrainer1,cotrainer2];}
          else if(cotrainer1!=null && cotrainer2!=null && cotrainer3!=null){
            data=[trainer,cotrainer1,cotrainer2,cotrainer3];
            }
       //console.log("!!!",data);
       return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getCategory = function (noOfTrainers,category) {
    if(category == "Short Term Training") {
      if(noOfTrainers == 4)
    {
      return 30;
    }
    else if (noOfTrainers==3){
      return 30;
    }
    else if (noOfTrainers==2)
  {
    return 30;
  }
  else if(noOfTrainers==1){
    return 31;
  }
}
else if(category == "Medium Term Training") {
      if(noOfTrainers == 4)
    {
      return 25;
    }
    else if (noOfTrainers==3){
      return 25;
    }
    else if (noOfTrainers==2)
  {
    return 25;
  }
  else if(noOfTrainers==1){
    return 26;
  }
}
else if(category == "Long Term training") {
      if(noOfTrainers == 4)
    {
      return 28;
    }
    else if (noOfTrainers==3){
      return 28;
    }
    else if (noOfTrainers==2)
  {
    return 28;
  }
  else if(noOfTrainers==1){
    return 27;
  }
}
else if(category == "Niche skill") {
   return 29;
}
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.updateEmployeeCredit = function (totalCredits,pointOfIntensity,hours,category,billable) {
 //var point;
  // if( billable == 'Billable'){
    totalCredits+= pointOfIntensity * hours;
  //}
  // else if (billable != 'Billable'){
  //   //point = pointOfIntensity * 0.5;
  //   totalCredits += pointOfIntensity * hours * 0.5;
  // }
  //console.log('!!!',totalCredits);
  //console.log('!!!',pointOfIntensity);
   //console.log('!!!',hours);
    //console.log('!!!',category);
  return totalCredits;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.updateEmployeeUnit = function (units) {
    units =parseInt(units)+1;
    return units;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.CreateEmployeeCredit = function (billable,category,empBOID,pointOfIntensity,topic,hours) {
     var data = [];
     var retpayload = {};
     const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
     const d = new Date();
     var mon = d.getMonth();
     var year = d.getFullYear();
     var month = months[mon];  
     var date2 = new Date();
     const date = date2.toISOString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).substring(0,10).replace(/[/]/g, '-');
    //  if(billable =='Billable')
    //   {
        retpayload['billable']='Billable';
        retpayload['employee']=empBOID;
        retpayload['category']= category;
        retpayload['totalCredit']= hours;
        // retpayload['totalCredit']= pointOfIntensity;
        retpayload['detail']= "Topic: " + topic;
        retpayload['detail2']= "Training Duration(Hours): " + hours;
        retpayload['units']=1;
        retpayload['month'] = month;
        retpayload['year'] = year;
        retpayload['date1'] = date;
     // }
      // else if (billable !='Billable'){
      //   //var point = pointOfIntensity * 0.5;
      //   var intensity = pointOfIntensity * 0.5;
      //   retpayload['billable']="Non Billable";
      //   retpayload['category']= category;
      //   retpayload['employee']=empBOID;
      //   retpayload['totalCredit']= intensity;
      //   retpayload['detail']= "Topic: " + topic;
      //   retpayload['detail2']= "Duration(Hours): " + hours;
      //   retpayload['units']=1;
      //   retpayload['month']=month;
      //   retpayload['year'] = year;
      //   retpayload['date1'] = date;
      // }
      data.push(retpayload);
      //console.log("!!!",data);
      //console.log('!!!',totalCredits);
      //console.log('!!!',pointOfIntensity);
      //console.log('!!!',hours);
      //console.log('!!!',category);
    
    
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTrainerID = function (t_emp,trainerArray) {
    var returnArray = [];
    for(var i = 0; i < trainerArray.length; i++) {
      for(var j = 0; j < t_emp.length; j++) {
        if(trainerArray[i] == t_emp[j].id) {
          returnArray.push(t_emp[j].id);
          //break;
        }
      }
    }
    //console.log("!!!",returnArray);
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.WorkFlowBoADP = function (workflow,current) {
    var data = [];
    for(var i=0; i<workflow.length; i++){
    var retpayload={};
    if(current==workflow[i].referenceID){
    retpayload['priorStatus']=workflow[i].priorStatus;
    retpayload['comments']=workflow[i].comments;
    retpayload['workflowCreatedBy']=workflow[i].workflowCreatedBy;
    retpayload['creationDate']=workflow[i].creationDate;
    retpayload['currentStatus']=workflow[i].currentStatus;
    data.push(retpayload);
    }
    }
    //console.log("6767##",data);
    return data;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.fetchupdate = function (training) {
     var data=[];

    for (var i=0; i<training.length; i++){
    var retpayload={};
    retpayload['id']=training[i].id;
    retpayload['employeeID']=training[i].employeeIDObject.items[0].employeeID;
    retpayload['Trainer']=training[i].trainer;
    //retpayload['coTrainer1']=training[i].coTrainer1Object.items[0].name;
    //retpayload['coTrainer2']=training[i].coTrainer2Object.items[0].name;
    if (training[i].coTrainer1 != null){
    retpayload['coTrainer1']=training[i].coTrainer1Object.items[0].name;
    }
     if (training[i].coTrainer2 != null){
    retpayload['coTrainer2']=training[i].coTrainer2Object.items[0].name;
    }
    //retpayload['coTrainer3']=training[i].coTrainer3Object.items[0].name;
    if (training[i].coTrainer3 != null){
    retpayload['coTrainer3']=training[i].coTrainer3Object.items[0].name;
    }
    retpayload['category']=training[i].category;
    retpayload['hours']=training[i].hours;
    retpayload['fromDate']=training[i].fromDate;
    retpayload['toDate']=training[i].toDate;
    retpayload['topic']=training[i].topic;
    //retpayload['type1']=training[i].type1;
    retpayload['status']=training[i].status;
    //retpayload['comments']=training[i].comments;
    retpayload['nicheSkills']=training[i].nicheSkills;
    retpayload['numberOfAttendees']=training[i].numberOfAttendees;
    data.push(retpayload);
    }
    //console.log('54##',data);
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.ViewcoTrainer = function (Emp,tracking) {
    var data=[];
    for(var i=0; i<tracking.length; i++){
      for (var j=0; j<Emp.length; j++){
      var retpayload={};
      if(tracking[i].id==Emp[j].id){
          retpayload['coTrainer1']=Emp[j].name;
         
      }
      data.push(retpayload);
    }
    
    }
    
    //console.log('1234##',data);
    return data;


  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.NewTopicReplaceFun = function (NewTopic) {
   
   var data=NewTopic;

   //data.push(Topic1); 
   //console.log("123##",data);
    return data; 
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.fetchTopic = function (t_topic) {
    var returnArray = [];
    for(var i = 0; i < t_topic.length; i++) {
      var innerObj = {};
      innerObj['topic'] = t_topic[i].topic;
      returnArray.push(innerObj);
    }
    //console.log("!!!",returnArray);
    return returnArray;
  };

PageModule.prototype.fetchEmployeeName = function (t_emp) {
    var returnArray = [];
    for(var i = 0; i < t_emp.length; i++) {
      var innerObj = {};
      innerObj['name'] = t_emp[i].name;
      returnArray.push(innerObj);
    }
    //console.log("!!!",returnArray);
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getIndexofcoTrainer = function (coTrainer,t_emp) {
    var index;
    for(var i = 0; i < t_emp.length; i++) {
      if(coTrainer == t_emp[i].name) {
        index = i;
        break;
      }
    }
    //console.log("!!!",coTrainer);
    //console.log("!!!",t_emp);
    //console.log("!!!",index);
    return index;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.MailForCL = function (topic,user,name) {

    var body = "";
    body += "Hello, "+name+"</body>";
    
    body += "<br><br>Conducted Training Approval Request on <b>" +topic+ "</b>has been submitted by Trainer. Awaiting CL approval.<br><br>";

    body += "<br><br>Regards,<br>"+user+"</body>";

    return body;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.GetDataForMail = function (capability) {
    
    var data =[];
    
      var retpayload = {};
     
      retpayload['name']=capability.lead1Object.items[0].name;
      retpayload['name2']=capability.lead2Object.items[0].name;
      
      retpayload['email']=capability.lead1Object.items[0].email;
      retpayload['email2']=capability.lead2Object.items[0].email;
      data.push(retpayload);
    
    //console.log('9090##',data);
    return data;
      
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.roleBase = function (empBO) {
    var com= empBO[0].globalPracticeObject.items[0].name;
    //console.log("11!!",com);
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.checkCL = function (capability,user) {
    var com= user[0].id;
    var data=[];
    
    for(var i=0; i<capability.length; i++){
      if(capability[i].lead1==com || capability[i].lead2==com){
        data='true';
      }
      else{
       data='false';
      }
      //console.log("22##",data);
      return data;
    }

  };


 function chkCLBOId(globalPractiseData,userId)
  {
     var metaDataArray = ['lead1', 'lead2', 'uSCapabilityLead1', 'uSCapabilityLead2'];
     var data=false;
     //console.log("!!!",globalPractiseData,userId);
     for(var index=0;metaDataArray.length>index;index++)
     {
       if(globalPractiseData[metaDataArray[index]]!=null)
       {
          var  chk=globalPractiseData[metaDataArray[index]]==userId?true:false;
          if(chk){
            data=chk;
            break;
          }
       }
     }
     //console.log('#221'+data);

     return data;
     
  }
    

     PageModule.prototype.downloadFile = function (base64File, filename) {
    console.log('@@File Name' + filename);

        var fileBytes = atob(base64File);
        fileBytes = FileToBytes(fileBytes);
        console.log(fileBytes);
        // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
        //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        var blob = new Blob([fileBytes], {
            type: 'octet/stream'
        });
        //var filename = "CDE.xlsx";


        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.setAttribute("target", "_blank");
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                console.log('Link' + JSON.stringify(link));
                // var win = window.open(url, "_blank");
                //  win.focus();
                document.body.removeChild(link);
            }
        }

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.dateFunction = function () {
    var date2 = new Date();
    
     const date = date2.toISOString('en-GB', {month: 'numeric', day: 'numeric', year: 'numeric'}).substring(0,10).replace(/[/]/g, '-');
     //console.log("#112",date);
     return date;
     

  };

  

  function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }
  return PageModule;
});