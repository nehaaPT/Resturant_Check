define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    data(catp, emp, client) {
  var data = [];

  // Calculate total hours per unique account-employee combination
  var totalHoursPerAccountEmployee = {};


  // Populate totalHoursPerAccountEmployee
  catp.forEach(entry => {
    let key = entry.client + '-' + entry.employee;
    if (!totalHoursPerAccountEmployee[key]) {
      totalHoursPerAccountEmployee[key] = {
        accountName: client.find(c => c.id === entry.client)?.clientName || '',
        name: emp.find(e => e.id === entry.employee)?.name || '', // Get employee name
        hours: 0,
        jan: 0,
        feb: 0,
        mar: 0,
        apr: 0,
        may: 0,
        jun: 0,
        jul: 0,
        aug: 0,
        sept: 0,
        oct: 0,
        nov: 0,
        dec: 0
      };
    }
    // Accumulate hours per specific month
    let monthIndex = new Date(entry.weekEnding).getMonth();
    switch (monthIndex) {
      case 0: totalHoursPerAccountEmployee[key].jan += entry.hours; break;
      case 1: totalHoursPerAccountEmployee[key].feb += entry.hours; break;
      case 2: totalHoursPerAccountEmployee[key].mar += entry.hours; break;
      case 3: totalHoursPerAccountEmployee[key].apr += entry.hours; break;
      case 4: totalHoursPerAccountEmployee[key].may += entry.hours; break;
      case 5: totalHoursPerAccountEmployee[key].jun += entry.hours; break;
      case 6: totalHoursPerAccountEmployee[key].jul += entry.hours; break;
      case 7: totalHoursPerAccountEmployee[key].aug += entry.hours; break;
      case 8: totalHoursPerAccountEmployee[key].sept += entry.hours; break;
      case 9: totalHoursPerAccountEmployee[key].oct += entry.hours; break;
      case 10: totalHoursPerAccountEmployee[key].nov += entry.hours; break;
      case 11: totalHoursPerAccountEmployee[key].dec += entry.hours; break;
      default: break;
    }
    // Accumulate total hours
    totalHoursPerAccountEmployee[key].hours += entry.hours;
  });

  // Build data array based on total hours per unique account-employee combination
  Object.values(totalHoursPerAccountEmployee).forEach(entry => {
    var temp = {
      account: entry.accountName,
      name: entry.name,
      hrs: entry.hours,
      per: '0%', // Initialize percentage
      jan: entry.jan,
      feb: entry.feb,
      mar: entry.mar,
      apr: entry.apr,
      may: entry.may,
      jun: entry.jun,
      jul: entry.jul,
      aug: entry.aug,
      sept: entry.sept,
      oct: entry.oct,
      nov: entry.nov,
      dec: entry.dec
    };

    // Calculate total hours for this account-employee combination
    temp.hrs = temp.jan + temp.feb + temp.mar + temp.apr + temp.may +
               temp.jun + temp.jul + temp.aug + temp.sept + temp.oct +
               temp.nov + temp.dec;

    // Calculate percentage of total hours for this account
    if (entry.hours > 0) {
      let percentage = ((temp.hrs / entry.hours) * 100).toFixed(2);
      temp.per = percentage + '%';
    } else {
      temp.per = '0%'; // Handle division by zero case
    }
    

    // Add temp object to data array
    data.push(temp);
  });

  return data;
}

Downloaddata(catp, cat, emp, client) {
  var data = [];
  var seen = new Set(); // Set to track unique combinations

  // Calculate total hours per employee per month per project per category
  var totalHoursPerEmployeeMonthProjectCategory = {};

  catp.forEach(entry => {
    let key = entry.employee + '-' + new Date(entry.weekEnding).getMonth() + '-' + entry.client + '-' + entry.category;
    if (!totalHoursPerEmployeeMonthProjectCategory[key]) {
      totalHoursPerEmployeeMonthProjectCategory[key] = {
        hrs: 0,
        month: new Date(entry.weekEnding).getMonth(),
        category: entry.category
      };
    }
    totalHoursPerEmployeeMonthProjectCategory[key].hrs += entry.hours;
  });

  var monthNames = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];

  // Iterate through catp array and build data array
  for (var i = 0; i < catp.length; i++) {
    let key = catp[i].employee + '-' + new Date(catp[i].weekEnding).getMonth() + '-' + catp[i].client + '-' + catp[i].category;

    // Check if this combination has been processed already
    let existingKey = catp[i].employee + '-' + new Date(catp[i].weekEnding).getMonth() + '-' + catp[i].client + '-' + catp[i].category;

    if (!seen.has(existingKey)) {
      seen.add(existingKey); // Mark this combination as seen

      var temp = {};
      let employee = emp.find(ele => ele.id == catp[i].employee);
      let clie = client.find(ele => ele.id == catp[i].client);
      let cate = cat.find(ele => ele.id == catp[i].category); // Get category details
      let d = new Date(catp[i].weekEnding);
      
      temp['category'] = cate !== undefined ? cate.listOfCategory : ''; // Use category name
      temp['name'] = employee !== undefined ? employee.name : '';
      temp['project'] = clie !== undefined ? clie.clientName : '';
      temp['hrs'] = totalHoursPerEmployeeMonthProjectCategory[key].hrs; // Use aggregated hours
      temp['month'] = monthNames[d.getMonth()]; // Get month name

      // Calculate percentage of hours for this employee in this month, project, and category
      if (totalHoursPerEmployeeMonthProjectCategory[key].hrs > 0) {
        let percentage = ((temp['hrs'] / totalHoursPerEmployeeMonthProjectCategory[key].hrs) * 100).toFixed(2);
        temp['per'] = percentage + '%';
      } else {
        temp['per'] = '0%'; // Handle division by zero case
      }

      data.push(temp);
    }
  }

  // Sort data by employee name, month, project, and category
  data.sort((a, b) => {
    // Compare by employee name
    if (a.name < b.name) return -1;
    if (a.name > b.name) return 1;

    // If employee names are the same, compare by month
    if (monthNames.indexOf(a.month) < monthNames.indexOf(b.month)) return -1;
    if (monthNames.indexOf(a.month) > monthNames.indexOf(b.month)) return 1;

    // If months are the same, compare by project
    if (a.project < b.project) return -1;
    if (a.project > b.project) return 1;

    // If projects are the same, compare by category
    if (a.category < b.category) return -1;
    if (a.category > b.category) return 1;

    return 0;
  });

  return data;
}



// function data(catp, emp, client) {
//   var data = [];

//   // Calculate total hours per account-employee combination
//   var totalHoursPerAccountEmployee = {};

//   // Populate totalHoursPerAccountEmployee
//   catp.forEach(entry => {
//     let key = entry.client + '-' + entry.employee;
//     if (!totalHoursPerAccountEmployee[key]) {
//       totalHoursPerAccountEmployee[key] = {
//         hours: 0,
//         accountName: client.find(c => c.id === entry.client)?.clientName || '',
//         name: '', // Placeholder for employee name
//         category: '', // Placeholder for client category
//         jan: 0, // Initialize hours for each month
//         feb: 0,
//         mar: 0,
//         apr: 0,
//         may: 0,
//         jun: 0,
//         jul: 0,
//         aug: 0,
//         sept: 0,
//         oct: 0,
//         nov: 0,
//         dec: 0
//       };
//     }
//     totalHoursPerAccountEmployee[key].hours += entry.hours;
//     // Accumulate hours per specific month
//     let monthIndex = new Date(entry.weekEnding).getMonth();
//     switch (monthIndex) {
//       case 0: totalHoursPerAccountEmployee[key].jan += entry.hours; break;
//       case 1: totalHoursPerAccountEmployee[key].feb += entry.hours; break;
//       case 2: totalHoursPerAccountEmployee[key].mar += entry.hours; break;
//       case 3: totalHoursPerAccountEmployee[key].apr += entry.hours; break;
//       case 4: totalHoursPerAccountEmployee[key].may += entry.hours; break;
//       case 5: totalHoursPerAccountEmployee[key].jun += entry.hours; break;
//       case 6: totalHoursPerAccountEmployee[key].jul += entry.hours; break;
//       case 7: totalHoursPerAccountEmployee[key].aug += entry.hours; break;
//       case 8: totalHoursPerAccountEmployee[key].sept += entry.hours; break;
//       case 9: totalHoursPerAccountEmployee[key].oct += entry.hours; break;
//       case 10: totalHoursPerAccountEmployee[key].nov += entry.hours; break;
//       case 11: totalHoursPerAccountEmployee[key].dec += entry.hours; break;
//       default: break;
//     }
//   });

//   // Build data array based on total hours per account-employee combination
//   Object.keys(totalHoursPerAccountEmployee).forEach(key => {
//     let entry = totalHoursPerAccountEmployee[key];

//     var temp = {};
//     temp['account'] = entry.accountName;
//     temp['name'] = emp.find(e => e.id === key.split('-')[1])?.name || ''; // Extract employee id from key
//     temp['hrs'] = entry.hours;
//     temp['per'] = '0%'; // Initialize percentage

//     // Assign hours for each specific month
//     temp['jan'] = entry.jan || 0;
//     temp['feb'] = entry.feb || 0;
//     temp['mar'] = entry.mar || 0;
//     temp['apr'] = entry.apr || 0;
//     temp['may'] = entry.may || 0;
//     temp['jun'] = entry.jun || 0;
//     temp['jul'] = entry.jul || 0;
//     temp['aug'] = entry.aug || 0;
//     temp['sept'] = entry.sept || 0;
//     temp['oct'] = entry.oct || 0;
//     temp['nov'] = entry.nov || 0;
//     temp['dec'] = entry.dec || 0;

//     // Calculate total hours for this account-employee combination
//     temp['hrs'] = temp['jan'] + temp['feb'] + temp['mar'] + temp['apr'] + temp['may'] +
//                   temp['jun'] + temp['jul'] + temp['aug'] + temp['sept'] + temp['oct'] +
//                   temp['nov'] + temp['dec'];

//     // Add temp object to data array
//     data.push(temp);
//   });

//   return data;
// }


// Example usage:
// var processedData = processData(catp, emp, client);
// console.log(processedData);

// Example usage:
// Assuming catp, cat, emp, client are provided somewhere in your environment or passed as arguments.

// Test the function
// console.log(data(catp, cat, emp, client));


// Example usage:
// Assuming catp, cat, emp, client are provided somewhere in your environment or passed as arguments.

// Test the function
// console.log(data(catp, cat, emp, client));



//  data(catp, cat, emp, client) {
//   var data = [];

//   // Sort catp by category (assuming category IDs are numeric and sequential)
//   catp.sort((a, b) => a.category - b.category);

//   // Calculate total hours per category
//   var totalHoursPerCategory = {};
//   catp.forEach(entry => {
//     if (totalHoursPerCategory[entry.category] === undefined) {
//       totalHoursPerCategory[entry.category] = 0;
//     }
//     totalHoursPerCategory[entry.category] += entry.hours;
//   });

//  var monthNames = [
//     "Jan", "Feb", "Mar", "Apr", "May", "Jun",
//     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
//   ];
//   // Iterate through sorted catp array and build data array
//   for (var i = 0; i < catp.length; i++) {
//     var temp = {};
//     let cate = cat.find(ele => ele.id == catp[i].category);
//     let employee = emp.find(ele => ele.id == catp[i].employee);
//     let clie = client.find(ele => ele.id == catp[i].client);
//     let d= new Date(catp[i].weekEnding);

    
//     temp['category'] = cate !== undefined ? cate.listOfCategory : '';
//     temp['name'] = employee !== undefined ? employee.name : '';
//     temp['project'] = clie !== undefined ? clie.clientName : '';
//     temp['hrs'] = catp[i].hours;
//     temp['month']=monthNames[d.getMonth()+1];
    
//     // Calculate percentage of hours for this employee in this category
//     if (totalHoursPerCategory[catp[i].category] > 0) {
//       let percentage=((catp[i].hours / totalHoursPerCategory[catp[i].category]) * 100).toFixed(2);
//       temp['per'] = percentage + '%';
//     } else {
//       temp['per'] = 0; // Handle division by zero case
//     }
    
//     data.push(temp);
//   }

//   return data;



// }
downloadreport(down) {
  var data = [];

  // Create a map to store total hours per employee per month
  var totalHoursPerEmployeeMonth = new Map();

  // Iterate over the input data
  down.forEach(entry => {
    // Generate a key to identify each employee-month combination
    let key = entry.name + '-' + entry.month;

    // Initialize the entry in the map if it doesn't exist
    if (!totalHoursPerEmployeeMonth.has(key)) {
      totalHoursPerEmployeeMonth.set(key, {
        name: entry.name,
        month: entry.month,
        totalHours: 0,
        details: []  // To store detailed data for each project-category
      });
    }

    // Add the hours for this project-category to the total for this employee-month
    totalHoursPerEmployeeMonth.get(key).totalHours += entry.hrs;

    // Store detailed data for each project-category under this employee-month
    totalHoursPerEmployeeMonth.get(key).details.push({
      project: entry.project,
      category: entry.category,
      hours: entry.hrs
    });
  });

  // Convert the map to an array format suitable for output
  totalHoursPerEmployeeMonth.forEach(entry => {
    // Add detailed data for each project-category under this employee-month
    entry.details.forEach(detail => {
      var detailPayload = [
        entry.name,
        entry.month,
        detail.project,
        detail.category,
        detail.hours
      ];
      data.push(detailPayload);
    });

    // Add total hours for this employee-month combination
    var totalPayload = [
      '',
      entry.month +'(Total)',
      '',  // Placeholder for project (optional)
      '',  // Placeholder for category (optional)
      entry.totalHours
    ];
    data.push(totalPayload);
  });

  // Insert header row
  var header = ['Employee', 'Month', 'Project', 'Category', 'Hours'];
  data.unshift(header);

  return data;
}






  //   downloadreport(down)  {
  //   var data=new Array();
  //   for(var i=0;i<=down.length;i++){
  //     var retpayload=new Array();
  //     if(i==0){
        
  //       retpayload.push('CDE');
  //       retpayload.push('Month');
  //       retpayload.push('Project');
  //       retpayload.push('Category');
  //       retpayload.push('Hours');
        
  //       // retpayload.push('Percentage');
       

  //     }
  //     else{
        
  //       retpayload.push(down[i-1].name);
  //        retpayload.push(down[i-1].month);
  //       retpayload.push(down[i-1].project);
  //       retpayload.push(down[i-1].category);
  //       retpayload.push(down[i-1].hrs);
  //       // retpayload.push(down[i-1].per);
       

  //     }
  //     data.push(retpayload);
  //   }
  //    return data;
  // };

downloadreportxL(innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" CDE Projectwise Report");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" CDE Projectwise Report"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
      function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "CDE Projectwise Report_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };

  
date(month, year) {
  let dateRanges = [];
  let array = [];
  let y = year;

  if (!month.includes("ALL")) {
    month.forEach(m => {
      // Constructing the first day of the selected month
      let firstDay = new Date(y, m - 1, 1); // m - 1 to adjust from 1-based to 0-based index
      // Constructing the last day of the selected month
      let lastDay = new Date(y, m, 0); // Automatically handles end of month correctly

      // Formatting start and end dates in YYYY-MM-DD format
      let startDate = `${firstDay.getFullYear()}-${(firstDay.getMonth() < 9 ? '0' : '') + (firstDay.getMonth() + 1)}-${(firstDay.getDate() < 10 ? '0' : '') + firstDay.getDate()}`;
      let endDate = `${lastDay.getFullYear()}-${(lastDay.getMonth() < 9 ? '0' : '') + (lastDay.getMonth() + 1)}-${(lastDay.getDate() < 10 ? '0' : '') + lastDay.getDate()}`;

      // Pushing formatted date range into dateRanges array
      dateRanges.push(`(weekEnding BETWEEN '${startDate}' AND '${endDate}')`);
    });
  } else {
    // If "ALL" months are selected, cover the entire year
    let firstDay = new Date(y, 0, 1); // January 1st
    let lastDay = new Date(y, 11, 31); // December 31st

    // Formatting start and end dates in YYYY-MM-DD format
    let startDate = `${firstDay.getFullYear()}-${(firstDay.getMonth() < 9 ? '0' : '') + (firstDay.getMonth() + 1)}-${(firstDay.getDate() < 10 ? '0' : '') + firstDay.getDate()}`;
    let endDate = `${lastDay.getFullYear()}-${(lastDay.getMonth() < 9 ? '0' : '') + (lastDay.getMonth() + 1)}-${(lastDay.getDate() < 10 ? '0' : '') + lastDay.getDate()}`;

    // Pushing formatted date range into dateRanges array
    dateRanges.push(`(weekEnding BETWEEN '${startDate}' AND '${endDate}')`);
  }

  // Building query strings
  let queryString = "";
  let queryString1 = "";

  if (dateRanges.length === 1) {
    queryString = "AND " + dateRanges[0];
    queryString1 = dateRanges[0];
  } else if (dateRanges.length > 1) {
    queryString = "AND (" + dateRanges.join(" OR ") + ")";
    queryString1 = "(" + dateRanges.join(" OR ") + ")";
  }

  array.push(queryString);
  array.push(queryString1);

  return array;
}

    download(down)  {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        
        retpayload.push('CDE');
        retpayload.push('Project');
        retpayload.push('Jan');
        retpayload.push('Feb');
        retpayload.push('Mar');
        retpayload.push('Apr');
        retpayload.push('May');
        retpayload.push('Jun');
        retpayload.push('Jul');
        retpayload.push('Aug');
        retpayload.push('Sept');
        retpayload.push('Oct');
        retpayload.push('Nov');
        retpayload.push('Dec');
        retpayload.push('Total Hours');

      }
      else{
       
        retpayload.push(down[i-1].name);
        retpayload.push(down[i-1].account);
        retpayload.push(down[i-1].jan);
        retpayload.push(down[i-1].feb);
        retpayload.push(down[i-1].mar);
        retpayload.push(down[i-1].apr);
        retpayload.push(down[i-1].may);
        retpayload.push(down[i-1].jun);
        retpayload.push(down[i-1].jul);
        retpayload.push(down[i-1].aug);
        retpayload.push(down[i-1].sept);
        retpayload.push(down[i-1].oct);
        retpayload.push(down[i-1].nov);
        retpayload.push(down[i-1].dec);
        retpayload.push(down[i-1].hrs);
        

      }
      data.push(retpayload);
    }
     return data;
  };
xL(innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" CDE Report");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" CDE Report"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
      function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "CDE Report_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };

    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    gethyper(cp,category,key) {
      var da=[];
      for(var i=0;i<cp.length;i++){
        var catt=category.find(ele=>ele.id==cp[i].category);
        var d = new Date(cp[i].weekEnding);
        var date=d.getMonth()+1;
        var rt={};
        if(date==1 && key==2){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==2 && key==3){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==3 && key==4){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==4 && key==5){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==5 && key==6){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==6 && key==7){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==7 && key ==8){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==8 && key ==9){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==9 && key ==10){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==10 && key ==11){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==11 && key==12){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
        if(date==12 && key ==13){
        rt['category']=catt!=undefined?catt.listOfCategory:'';
        rt['hrs']=cp[i].hours;
        da.push(rt);
        }
      }
      return da;
    }
  }
  
  return PageModule;
});
