define([], () => {
  'use strict';
let PageModule = function PageModule() {};

PageModule.prototype.capSearch = function (cap, date) {
   var query = "";
   var qparameter='';
   if(cap!="")
   {
     
  query = "(employeeObject.globalPractice = "+cap+")";
   } 
   return query;
   };

PageModule.prototype.currentdate = function () {
let date = new Date().getFullYear();
return date;
};

PageModule.prototype.getDates = function (date) {
   
    var returndate = `${new Date(date).getFullYear()}-${(new Date(date).getMonth())<9?'0'+(new Date(date).getMonth()+1):''+(new Date(date).getMonth()+1)}-${(new Date(date).getDate())<10?'0'+(new Date(date).getDate()):''+(new Date(date).getDate())}`;
    

    
    return returndate;
  };

   PageModule.prototype.createTableColumns = function (date) {
    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
       innerArray.push(date5);
       
      }
    }
    
    innerArray=innerArray.reverse();
    
    // let array=[];
    // for(let i = innerArray.length; i > 0; i--){
    // let obj={};
    // obj["Category"]=''
    // }
    

    let innerString = '';
    
    innerString = innerString + '[{' + '"headerText":' + '"Category",' +'"headerStyle":'+'"text-align: center;",'+'"template":'+'"category",' + '"field":' + '"categoryObject",'+'"width":'+'"170"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Week Ending",' + '"field":' + '"weekEnding",'+'"width":'+'"140"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Project Details",' + '"field":' + '"projectDetails",'+'"width":'+'"150"' + '},';
    
     
                              
    for(let i = 1; i <= innerArray.length; i++) {
      if(i === innerArray.length) {
        innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
    }
    innerString = innerString + '{' + '"headerText":' + '"Comments",' + '"field":' + '"comment1",'+'"template":'+'"comments",'+'"width":'+'"130"' + '}';
    innerString = innerString + ']';
    console.log("!!!",JSON.parse(innerString));
    let returnarray=[];
    returnarray.push(JSON.parse(innerString));
    returnarray.push(innerArray);
    return returnarray;
  };

PageModule.prototype.date = function (month,year) {
    let maxValue, minValue;
    let queryString = "";
    let queryString1 = "";
    let dateRanges = [];
    let array=[];
    let y= year;
    if(month.includes("ALL")===false){
      for(let i=0;i<month.length;i++){
        let m = month[i];
        let firstDay = new Date(y, Number(m), 1);
        let lastDay = new Date(y, Number(m) + 1, 0);

        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
        dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    }
      else{
        maxValue=11,minValue=0;
        let firstDay = new Date(y, Number(minValue), 1);
        let lastDay = new Date(y, Number(maxValue) + 1, 0);
       
        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
       dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    
      
      if (dateRanges.length === 1) {
      queryString =   "AND "+dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString = "AND(" + dateRanges.join(" OR ") + ")";
      }

      if (dateRanges.length === 1) {
      queryString1 =   dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString1 = "(" + dateRanges.join(" OR ") + ")";
      }
      array.push(queryString);
      array.push(queryString1);

       return array;        
   };

PageModule.prototype.tableHeading = function (month) {
    let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b});
    }

    let innerString = '';
     innerString = innerString + '[{' + '"headerText":' + '"Employee",' + '"field":' + '"name",'+'"template":'+'"Others",'+'"width":'+'"254",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;"' + '},';
   innerString = innerString + '{' + '"headerText":' + '"Capability",' + '"field":' + '"capability",'+'"template":'+'"Others",'+'"width":'+'"140",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;"' + '},';
                              
    for(let i = 0; i < month.length; i++) {
      let x=HeadArray[month[i]];
      if(i === month.length-1) {
        
        innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"style":'+'"text-align: center;",'+'"width":'+'"84",' + '"field":' + '"'+x + 'Hrs",'+'"template":'+'"'+x + '"' + '}';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"style":'+'"text-align: center;",'+'"width":'+'"84",' + '"field":' + '"'+x + 'Hrs",'+'"template":'+'"'+x + '"' + '},';
    }

    // innerString = innerString + '{' + '"headerText":' + '"Total",' + '"field":' + '"total",'+'"template":'+'"Others",'+'"width":'+'"87",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '},';
    // innerString = innerString + '{' + '"headerText":' + '"%",' + '"field":' + '"percentage",'+'"template":'+'"Others",'+'"width":'+'"75",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '}';
    innerString = innerString + ']';

    let columns=JSON.parse(innerString);
    return columns;
    };

    PageModule.prototype.employeeLOV = function (data) {

      let object={},array=[];
      for(let i=0;i<data.length;i++){
        object['id']=data[i].id;
        object['name']=data[i].name+'-'+data[i].employeeID;
        object['capability']=data[i].globalPractice;
        array.push(object);
      }
      return array;

    };

//     function isLeapYear(year) {
//     return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
// }


//    let years = year.map(range => {
//     let matches = range.match(/\d{4}-\d{2}/g); // Extracts all year-month pairs from the string
//     let year = parseInt(matches[0].substr(0, 4)); // Extract year from the first match
//     let months = matches.map(match => parseInt(match.substr(5, 2))); // Extract months from all matches
//     return { year, months };
// });

// let yearspecific = isLeapYear.year

// function totalWorkingHours(month, yearspecific) {
//     let totalWorkingHours = 0;

//     years.forEach(yearData => {
//         yearData.months.forEach(yearMonth => {
//             if (yearMonth === month) {
//                 let daysInMonth;
//                 if (month === 1 && isLeapYear(yearData.year)) {
//                     // February in a leap year has 29 days
//                     daysInMonth = 29;
//                 } else {
//                     daysInMonth = new Date(yearData.year, month + 1, 0).getDate();
//                 }

//                 let weekdays = 0;

//                 for (let d = 1; d <= daysInMonth; d++) {
//                     let currentDate = new Date(yearData.year, month, d);
//                     if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
//                         weekdays++;
//                     }
//                 }

//                 totalWorkingHours += weekdays * 9; // Assuming 9 working hours per day
//             }
//         });
//     });

//     return totalWorkingHours;
// }


    PageModule.prototype.capReport = function (AllBoData,empData,year,capBO) {
       let array=[];
       let TotalHrs=0;
       let TotJanHrs=0,TotFebHrs=0,TotMarHrs=0,TotAprHrs=0,TotMayHrs=0,TotJunHrs=0,TotJulHrs=0,TotAugHrs=0,TotSepHrs=0,TotOctHrs=0,TotNovHrs=0,TotDecHrs=0;



       for(var i=0;i<capBO.length;i++){
   
         let BoData = empData.filter(ele => ele.employeeIdObject.items[0].globalPractice === capBO[i].id);
         
      

        
         let JanHrs=0,FebHrs=0,MarHrs=0,AprHrs=0,MayHrs=0,JunHrs=0,JulHrs=0,AugHrs=0,SepHrs=0,OctHrs=0,NovHrs=0,DecHrs=0;
         let JanArray=[],FebArray=[],MarArray=[],AprArray=[],MayArray=[],JunArray=[],JulArray=[],AugArray=[],SepArray=[],OctArray=[],NovArray=[],DecArray=[];
         let date=new Date(year);
         let JanTotal=0,FebTotal=0,MarTotal=0,AprTotal=0,MayTotal=0,JunTotal=0,JulTotal=0,AugTotal=0,SepTotal=0,OctTotal=0,NovTotal=0,DecTotal=0;
         
        //  let arrayobj=Object.values(BoData); 
        //  const arrayUniqueByKey = [...new Map(BoData.map(item =>  [item['employee'], item])).values()];   
        //  let uni=arrayUniqueByKey;

         let validateLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0?true:false;
         let totalDaysOfMonth;
         if(validateLeapYear===true){
           totalDaysOfMonth=[31,29,31,30,31,30,31,31,30,31,30,31];
         }else{
           totalDaysOfMonth=[31,28,31,30,31,30,31,31,30,31,30,31]
         }

         

      for(let a=0;a<BoData.length;a++){
        let employeeWiseData=AllBoData.filter(ele=>ele.employee===BoData[a].employeeIdObject.items[0].id);

        let arrayobj2=Object.values(employeeWiseData); 
         const arrayUniqueByKey2 = [...new Map(employeeWiseData.map(item =>  [item['weekEnding'], item])).values()];   
         let uni2=arrayUniqueByKey2;

      let name=BoData[a].employeeIdObject.items[0];
      // find(ele=>ele.id===uni[a].employee);
      // let totalEmpHours = 0;
      // let janemployeeHrs=0,febemployeeHrs=0,maremployeeHrs=0,apremployeeHrs=0,mayemployeeHrs=0,junemployeeHrs=0,julemployeeHrs=0,augemployeeHrs=0,sepemployeeHrs=0,octemployeeHrs=0,novemployeeHrs=0,decemployeeHrs=0;
      let janemployeeNonCompHrs=0,febemployeeNonCompHrs=0,maremployeeNonCompHrs=0,apremployeeNonCompHrs=0,mayemployeeNonCompHrs=0,junemployeeNonCompHrs=0,julemployeeNonCompHrs=0,augemployeeNonCompHrs=0,sepemployeeNonCompHrs=0,octemployeeNonCompHrs=0,novemployeeNonCompHrs=0,decemployeeNonCompHrs=0;
      // let totalJanHours =0,totalFebHours=0,totalMarHours=0,totalAprHours=0,totalMayHours=0,totalJunHours=0,totalJulHours=0,totalAugHours=0,totalSepHours=0,totalOctHours=0,totalNovHours=0,totalDecHours=0;
      let janemployeeArray=[],febemployeeArray=[],maremployeeArray=[],apremployeeArray=[],mayemployeeArray=[],junemployeeArray=[],julemployeeArray=[],augemployeeArray=[],sepemployeeArray=[],octemployeeArray=[],novemployeeArray=[],decemployeeArray=[];
      let janAvailabilityPercentage=0,febAvailabilityPercentage=0,marAvailabilityPercentage=0,aprAvailabilityPercentage=0,mayAvailabilityPercentage=0,junAvailabilityPercentage=0,julAvailabilityPercentage=0,augAvailabilityPercentage=0,sepAvailabilityPercentage=0,octAvailabilityPercentage=0,novAvailabilityPercentage=0,decAvailabilityPercentage=0;
      let janMaximumHours=0,febMaximumHours=0,marMaximumHours=0,aprMaximumHours=0,mayMaximumHours=0,junMaximumHours=0,julMaximumHours=0,augMaximumHours=0,sepMaximumHours=0,octMaximumHours=0,novMaximumHours=0,decMaximumHours=0;
      let months=[1,2,3,4,5,6,7,8,9,10,11,12];
    
         let weekdays;
         let workday;
         let weekMax;
         let currentDate;
         let weekEnds;
         for(let m=0;m<months.length;m++){
         let month=months[m]
        switch(month){
        case 1:
          

          weekdays=0;
          
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;
               
              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
               
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        janemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 janemployeeNonCompHrs+=Number(workday)*9
            }else{
              janemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          janMaximumHours = (Number(weekdays)*9);
           janAvailabilityPercentage = (janemployeeNonCompHrs / janMaximumHours) * 100;
          break;
        case 2:
          

          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;
             
              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        febemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 febemployeeNonCompHrs+=Number(workday)*9
            }else{
              febemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
         febMaximumHours = (Number(weekdays)*9);
          febAvailabilityPercentage = (febemployeeNonCompHrs / febMaximumHours) * 100;
          break;
        case 3:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        maremployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 maremployeeNonCompHrs+=Number(workday)*9
            }else{
              maremployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           marMaximumHours = (Number(weekdays)*9);
          marAvailabilityPercentage = (maremployeeNonCompHrs / marMaximumHours) * 100;
          break;
        case 4:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        apremployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 apremployeeNonCompHrs+=Number(workday)*9
            }else{
              apremployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          aprMaximumHours = (Number(weekdays)*9);
          aprAvailabilityPercentage = (apremployeeNonCompHrs / aprMaximumHours) * 100;
          break;
        case 5:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        mayemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 mayemployeeNonCompHrs+=Number(workday)*9
            }else{
              mayemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          mayMaximumHours = (Number(weekdays)*9);
          mayAvailabilityPercentage = (mayemployeeNonCompHrs / mayMaximumHours) * 100;
          break;
        case 6:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        junemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 junemployeeNonCompHrs+=Number(workday)*9
            }else{
              junemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          junMaximumHours = (Number(weekdays)*9);
          junAvailabilityPercentage = (junemployeeNonCompHrs / junMaximumHours) * 100;
          break;
        case 7:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        julemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 julemployeeNonCompHrs+=Number(workday)*9
            }else{
              julemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           julMaximumHours = (Number(weekdays)*9);
          julAvailabilityPercentage = (julemployeeNonCompHrs / julMaximumHours) * 100;
          break;
        case 8:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        augemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 augemployeeNonCompHrs+=Number(workday)*9
            }else{
              augemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           augMaximumHours = (Number(weekdays)*9);
          augAvailabilityPercentage = (augemployeeNonCompHrs / augMaximumHours) * 100;
          break;
        case 9:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        sepemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 sepemployeeNonCompHrs+=Number(workday)*9
            }else{
              sepemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           sepMaximumHours  = (Number(weekdays)*9);
          sepAvailabilityPercentage = (sepemployeeNonCompHrs / sepMaximumHours) * 100;
          break;
        case 10:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        octemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 octemployeeNonCompHrs+=Number(workday)*9
            }else{
              octemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           octMaximumHours = (Number(weekdays)*9);
          octAvailabilityPercentage = (octemployeeNonCompHrs / octMaximumHours) * 100;
          break;
        case 11:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        novemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 novemployeeNonCompHrs+=Number(workday)*9
            }else{
              novemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           novMaximumHours = (Number(weekdays)*9);
          novAvailabilityPercentage = (novemployeeNonCompHrs / novMaximumHours) * 100;
          break;
        case 12:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        decemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 decemployeeNonCompHrs+=Number(workday)*9
            }else{
              decemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           decMaximumHours  = (Number(weekdays)*9);
          decAvailabilityPercentage = (decemployeeNonCompHrs / decMaximumHours) * 100;
          break;

      }}

      let object={};
let validateCurrentMonth=new Date().getMonth();
       object['name'] = name.name?name.name:'';
       object['capability']=capBO[i].name?capBO[i].name:'NA';
        object['JanHrs']= (0>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(janAvailabilityPercentage)).toFixed(2);
        object['janData']= janemployeeArray;
        object['FebHrs']= (1>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(febAvailabilityPercentage)).toFixed(2);
        object['febData']= febemployeeArray;
        object['MarHrs']= (2>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(marAvailabilityPercentage)).toFixed(2);
        object['marData']= maremployeeArray;
        object['AprHrs']= (3>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(aprAvailabilityPercentage)).toFixed(2);
        object['aprData']= apremployeeArray;
        object['MayHrs']= (4>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(mayAvailabilityPercentage)).toFixed(2);
        object['mayData']= mayemployeeArray;
        object['JunHrs']= (5>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(junAvailabilityPercentage)).toFixed(2);
        object['junData']= junemployeeArray;
        object['JulHrs']= (6>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(julAvailabilityPercentage)).toFixed(2);
        object['julData']= julemployeeArray;
        object['AugHrs']= (7>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(augAvailabilityPercentage)).toFixed(2);
        object['augData']= augemployeeArray;
        object['SepHrs']= (8>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(sepAvailabilityPercentage)).toFixed(2);
        object['sepData']= sepemployeeArray;
        object['OctHrs']= (9>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(octAvailabilityPercentage)).toFixed(2);
        object['octData']= octemployeeArray;
        object['NovHrs']= (10>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(novAvailabilityPercentage)).toFixed(2);
        object['novData']= novemployeeArray;
        object['DecHrs']= (11>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(decAvailabilityPercentage)).toFixed(2);
        object['decData']= decemployeeArray;

        array.push(object);
      }}
      return array;
      };
      
   
        

    function weekends(month,year) {
       let array=[];
      var date = new Date(), y = Number(year), m = Number(month)-1;
    var firstDay = new Date(y, m, 1);
    var lastDay = new Date(y, m + 1, 0);

    let day = firstDay.getDay();
    let count=7-Number(day);
    let baseDate;
    
    const date1 = new Date(firstDay);
    date1.setDate(firstDay.getDate()+(Number(count-1)));
    baseDate=date1;
    // const options = {year: 'numeric', day: '2-digit', month: '2-digit'  };
    const formattedDate = `${(date1.getFullYear())}-${(date1.getMonth()<9?'0'+(date1.getMonth()+1):''+(date1.getMonth()+1))}-${(date1.getDate()<10?'0'+date1.getDate():date1.getDate())}`;
    array.includes(formattedDate)===false?array.push(formattedDate):'';

    let week=7;
      baseDate.setDate(baseDate.getDate()+7);
    for(let i=baseDate;i.getMonth()===m;i.setDate(baseDate.getDate()+Number(week))){
      
      const date2 = new Date(i);
    const formattedDate1 =`${(date2.getFullYear())}-${(date2.getMonth()<9?'0'+(date2.getMonth()+1):''+(date2.getMonth()+1))}-${(date2.getDate()<10?'0'+date2.getDate():date2.getDate())}`;
    array.includes(formattedDate1)===false?array.push(formattedDate1):'';
    }

    const date3 = new Date(lastDay);
    const formattedDate3 = `${(date3.getFullYear())}-${(date3.getMonth()<9?'0'+(date3.getMonth()+1):''+(date3.getMonth()+1))}-${(date3.getDate()<10?'0'+date3.getDate():date3.getDate())}`;
    array.includes(formattedDate3)===false?array.push(formattedDate3):'';

    return array;

    }
 
   PageModule.prototype.capReport2 = function (AllBoData,empData,year,capBO,employeeFilter) {
       let array=[];
       let TotalHrs=0;
       let TotJanHrs=0,TotFebHrs=0,TotMarHrs=0,TotAprHrs=0,TotMayHrs=0,TotJunHrs=0,TotJulHrs=0,TotAugHrs=0,TotSepHrs=0,TotOctHrs=0,TotNovHrs=0,TotDecHrs=0;



       for(var i=0;i<capBO.length;i++){
   
         let BoData = empData.filter(ele => ele.employeeIdObject.items[0].globalPractice === capBO[i].id);
         
      

        
         let JanHrs=0,FebHrs=0,MarHrs=0,AprHrs=0,MayHrs=0,JunHrs=0,JulHrs=0,AugHrs=0,SepHrs=0,OctHrs=0,NovHrs=0,DecHrs=0;
         let JanArray=[],FebArray=[],MarArray=[],AprArray=[],MayArray=[],JunArray=[],JulArray=[],AugArray=[],SepArray=[],OctArray=[],NovArray=[],DecArray=[];
         let date=new Date(year);
         let JanTotal=0,FebTotal=0,MarTotal=0,AprTotal=0,MayTotal=0,JunTotal=0,JulTotal=0,AugTotal=0,SepTotal=0,OctTotal=0,NovTotal=0,DecTotal=0;
         
        //  let arrayobj=Object.values(BoData); 
        //  const arrayUniqueByKey = [...new Map(BoData.map(item =>  [item['employee'], item])).values()];   
        //  let uni=arrayUniqueByKey;

         let validateLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0?true:false;
         let totalDaysOfMonth;
         if(validateLeapYear===true){
           totalDaysOfMonth=[31,29,31,30,31,30,31,31,30,31,30,31];
         }else{
           totalDaysOfMonth=[31,28,31,30,31,30,31,31,30,31,30,31]
         }

         

      for(let a=0;a<BoData.length;a++){
        if((employeeFilter==null || employeeFilter==undefined || employeeFilter=='' ) || employeeFilter==BoData[a].employeeIdObject.items[0].id){
        let employeeWiseData=AllBoData.filter(ele=>ele.employee===BoData[a].employeeIdObject.items[0].id);

        let arrayobj2=Object.values(employeeWiseData); 
         const arrayUniqueByKey2 = [...new Map(employeeWiseData.map(item =>  [item['weekEnding'], item])).values()];   
         let uni2=arrayUniqueByKey2;

      let name=BoData[a].employeeIdObject.items[0];
      // find(ele=>ele.id===uni[a].employee);
      // let totalEmpHours = 0;
      // let janemployeeHrs=0,febemployeeHrs=0,maremployeeHrs=0,apremployeeHrs=0,mayemployeeHrs=0,junemployeeHrs=0,julemployeeHrs=0,augemployeeHrs=0,sepemployeeHrs=0,octemployeeHrs=0,novemployeeHrs=0,decemployeeHrs=0;
      let janemployeeNonCompHrs=0,febemployeeNonCompHrs=0,maremployeeNonCompHrs=0,apremployeeNonCompHrs=0,mayemployeeNonCompHrs=0,junemployeeNonCompHrs=0,julemployeeNonCompHrs=0,augemployeeNonCompHrs=0,sepemployeeNonCompHrs=0,octemployeeNonCompHrs=0,novemployeeNonCompHrs=0,decemployeeNonCompHrs=0;
      // let totalJanHours =0,totalFebHours=0,totalMarHours=0,totalAprHours=0,totalMayHours=0,totalJunHours=0,totalJulHours=0,totalAugHours=0,totalSepHours=0,totalOctHours=0,totalNovHours=0,totalDecHours=0;
      let janemployeeArray=[],febemployeeArray=[],maremployeeArray=[],apremployeeArray=[],mayemployeeArray=[],junemployeeArray=[],julemployeeArray=[],augemployeeArray=[],sepemployeeArray=[],octemployeeArray=[],novemployeeArray=[],decemployeeArray=[];
      let janAvailabilityPercentage=0,febAvailabilityPercentage=0,marAvailabilityPercentage=0,aprAvailabilityPercentage=0,mayAvailabilityPercentage=0,junAvailabilityPercentage=0,julAvailabilityPercentage=0,augAvailabilityPercentage=0,sepAvailabilityPercentage=0,octAvailabilityPercentage=0,novAvailabilityPercentage=0,decAvailabilityPercentage=0;
      let janMaximumHours=0,febMaximumHours=0,marMaximumHours=0,aprMaximumHours=0,mayMaximumHours=0,junMaximumHours=0,julMaximumHours=0,augMaximumHours=0,sepMaximumHours=0,octMaximumHours=0,novMaximumHours=0,decMaximumHours=0;
      let months=[1,2,3,4,5,6,7,8,9,10,11,12];
    
         let weekdays;
         let workday;
         let weekMax;
         let currentDate;
         let weekEnds;
         for(let m=0;m<months.length;m++){
         let month=months[m]
        switch(month){
        case 1:
          

          weekdays=0;
          
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;
               
              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
               
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        janemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 janemployeeNonCompHrs+=Number(workday)*9
            }else{
              janemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          janMaximumHours = (Number(weekdays)*9);
           janAvailabilityPercentage = (janemployeeNonCompHrs / janMaximumHours) * 100;
          break;
        case 2:
          

          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;
             
              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        febemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 febemployeeNonCompHrs+=Number(workday)*9
            }else{
              febemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
         febMaximumHours = (Number(weekdays)*9);
          febAvailabilityPercentage = (febemployeeNonCompHrs / febMaximumHours) * 100;
          break;
        case 3:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        maremployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 maremployeeNonCompHrs+=Number(workday)*9
            }else{
              maremployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           marMaximumHours = (Number(weekdays)*9);
          marAvailabilityPercentage = (maremployeeNonCompHrs / marMaximumHours) * 100;
          break;
        case 4:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        apremployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 apremployeeNonCompHrs+=Number(workday)*9
            }else{
              apremployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          aprMaximumHours = (Number(weekdays)*9);
          aprAvailabilityPercentage = (apremployeeNonCompHrs / aprMaximumHours) * 100;
          break;
        case 5:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        mayemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 mayemployeeNonCompHrs+=Number(workday)*9
            }else{
              mayemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          mayMaximumHours = (Number(weekdays)*9);
          mayAvailabilityPercentage = (mayemployeeNonCompHrs / mayMaximumHours) * 100;
          break;
        case 6:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        junemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 junemployeeNonCompHrs+=Number(workday)*9
            }else{
              junemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
          junMaximumHours = (Number(weekdays)*9);
          junAvailabilityPercentage = (junemployeeNonCompHrs / junMaximumHours) * 100;
          break;
        case 7:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        julemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 julemployeeNonCompHrs+=Number(workday)*9
            }else{
              julemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           julMaximumHours = (Number(weekdays)*9);
          julAvailabilityPercentage = (julemployeeNonCompHrs / julMaximumHours) * 100;
          break;
        case 8:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        augemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 augemployeeNonCompHrs+=Number(workday)*9
            }else{
              augemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           augMaximumHours = (Number(weekdays)*9);
          augAvailabilityPercentage = (augemployeeNonCompHrs / augMaximumHours) * 100;
          break;
        case 9:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        sepemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 sepemployeeNonCompHrs+=Number(workday)*9
            }else{
              sepemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
           
          }
           sepMaximumHours  = (Number(weekdays)*9);
          sepAvailabilityPercentage = (sepemployeeNonCompHrs / sepMaximumHours) * 100;
          break;
        case 10:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        octemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 octemployeeNonCompHrs+=Number(workday)*9
            }else{
              octemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           octMaximumHours = (Number(weekdays)*9);
          octAvailabilityPercentage = (octemployeeNonCompHrs / octMaximumHours) * 100;
          break;
        case 11:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        novemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 novemployeeNonCompHrs+=Number(workday)*9
            }else{
              novemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           novMaximumHours = (Number(weekdays)*9);
          novAvailabilityPercentage = (novemployeeNonCompHrs / novMaximumHours) * 100;
          break;
        case 12:
          

          weekdays=0;
          workday=0;
           for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
           weekEnds=weekends(month,year);
          for(let n=0;n<weekEnds.length;n++){
            let checkNonComp=employeeWiseData.filter(e=>e.weekEnding==weekEnds[n]);
            if(checkNonComp.length==0){
             workday=0;

              let endDate =new Date(weekEnds[n]);
              let innerArray =  [];
              let date6=new Date(endDate);
              innerArray.push(date6);
              if(date6.getDay() != 0){
              for (let i=0; i<6;i++){
      
               let date5=new Date(endDate.setDate(endDate.getDate()-1));
               if(new Date(endDate).getMonth()=== new Date(weekEnds[n]).getMonth()){
               innerArray.push(date5);
               if(date5.getDay() == 0){
                 break;
               }
                }}}
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
                if(workday>0){
                        decemployeeArray.push({weekEnding:weekEnds[n],status:'Not Entered'});}
                 decemployeeNonCompHrs+=Number(workday)*9
            }else{
              decemployeeArray.push({weekEnding:weekEnds[n],status:'Entered'});}
            
           
          }
           decMaximumHours  = (Number(weekdays)*9);
          decAvailabilityPercentage = (decemployeeNonCompHrs / decMaximumHours) * 100;
          break;

      }}

      let object={};
let validateCurrentMonth=new Date().getMonth();
       object['name'] = name.name?name.name:'';
       object['capability']=capBO[i].name?capBO[i].name:'NA';
        object['JanHrs']= (0>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(janAvailabilityPercentage)).toFixed(2);
        object['janData']= janemployeeArray;
        object['FebHrs']= (1>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(febAvailabilityPercentage)).toFixed(2);
        object['febData']= febemployeeArray;
        object['MarHrs']= (2>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(marAvailabilityPercentage)).toFixed(2);
        object['marData']= maremployeeArray;
        object['AprHrs']= (3>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(aprAvailabilityPercentage)).toFixed(2);
        object['aprData']= apremployeeArray;
        object['MayHrs']= (4>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(mayAvailabilityPercentage)).toFixed(2);
        object['mayData']= mayemployeeArray;
        object['JunHrs']= (5>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(junAvailabilityPercentage)).toFixed(2);
        object['junData']= junemployeeArray;
        object['JulHrs']= (6>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(julAvailabilityPercentage)).toFixed(2);
        object['julData']= julemployeeArray;
        object['AugHrs']= (7>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(augAvailabilityPercentage)).toFixed(2);
        object['augData']= augemployeeArray;
        object['SepHrs']= (8>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(sepAvailabilityPercentage)).toFixed(2);
        object['sepData']= sepemployeeArray;
        object['OctHrs']= (9>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(octAvailabilityPercentage)).toFixed(2);
        object['octData']= octemployeeArray;
        object['NovHrs']= (10>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(novAvailabilityPercentage)).toFixed(2);
        object['novData']= novemployeeArray;
        object['DecHrs']= (11>Number(validateCurrentMonth))?Number(0).toFixed(2):(100-Number(decAvailabilityPercentage)).toFixed(2);
        object['decData']= decemployeeArray;

        array.push(object);
      }}}
      return array;
      };   

  PageModule.prototype.bardata = function (data,month) {
      let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
     if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b;});
    }

     let info=[];
     for(let i=0; i<data.length; i++){
      // let namePayload=[];
      // namePayload.push(data[i].name);
      for(let j=0; j<month.length; j++){
        let x=HeadArray[month[j]];
     let retpayload={};
      retpayload['name']=data[i].name;
     retpayload['month']=x;
     retpayload['value']= Number(data[i][x+'Hrs']);
     if(retpayload['value']<100){}
     info.push(retpayload);
      }
      
     }

     return info;
    };
    PageModule.prototype.capSearch1 = function (cap, date) {
   var query = "";
   var qparameter='';
   if(cap!="")
   {
     
  query = "(employeeObject.globalPractice = "+cap+" ) ";
   } 
   return query;
   };
PageModule.prototype.capSearch2 = function ( date,name) {
   var query = "";
   var qparameter='';
   
   
     
  query = "( employee="+name+") ";
   
   return query;
   };

       PageModule.prototype.exportToPDF = function () {

    // var images = document.querySelectorAll("#downloadImage")
    // for (var i = 0, len = images.length; i < len; i++) {
    //   images[i].removeAttribute(":src");
    // }
    domtoimage.toPng(document.getElementById('table-id-to-export'))
      .then(function (blob) {
        var pdf = new jsPDF('l', 'pt', [$('#table-id-to-export').width(), $('#table-id-to-export').height()]);
        pdf.addImage(blob, 'PNG', 0, 0, $('#table-id-to-export').width(), $('#table-id-to-export').height());
        pdf.save("Employees.pdf");


      });
  };
 return PageModule;
});
 