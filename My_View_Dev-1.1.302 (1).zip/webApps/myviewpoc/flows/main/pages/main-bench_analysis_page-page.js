define([], () => {
  'use strict';

  let PageModule = function PageModule() { };

  PageModule.prototype.benchfun = function (empbo, skillgrpbo, skgrp, capability) {
    let data = [];

    let gradeAtotallt30 = 0;
    let gradeAtotalgt30lt60 = 0;
    let gradeAtotalgt60 = 0;

    let gradeBtotallt30 = 0;
    let gradeBtotalgt30lt60 = 0;
    let gradeBtotalgt60 = 0;

    let gradeCtotallt30 = 0;
    let gradeCtotalgt30lt60 = 0;
    let gradeCtotalgt60 = 0;

    let gradeDtotallt30 = 0;
    let gradeDtotalgt30lt60 = 0;
    let gradeDtotalgt60 = 0;



    let skillgrpbodata = skillgrpbo.filter(ele => ele.activeFlag == 'Y');



    if ((skgrp != undefined || skgrp != null || skgrp != '') && (capability == undefined || capability == null || capability == '')) {

      let retpayload = {};
      retpayload['skillGroupName'] = skillgrpbo.find(ele => ele.id == skgrp).skillGroupName;
      retpayload['skillGroupId'] = skgrp;
      retpayload['capabilityId'] = skillgrpbo.find(ele => ele.id == skgrp).capability;

      retpayload['gradeA_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup < 30).length;
      retpayload['gradeA_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeA_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup > 60).length;

      retpayload['gradeB_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup < 30).length;
      retpayload['gradeB_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeB_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup > 60).length;

      retpayload['gradeC_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup < 30).length;
      retpayload['gradeC_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeC_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup > 60).length;

      retpayload['gradeD_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup < 30).length;
      retpayload['gradeD_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeD_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup > 60).length;


      data.push(retpayload);

      gradeAtotallt30 = gradeAtotallt30 + retpayload['gradeA_l_30']
      gradeAtotalgt30lt60 = gradeAtotalgt30lt60 + retpayload['gradeA_30_60'];
      gradeAtotalgt60 = gradeAtotalgt60 + retpayload['gradeA_g_60'];

      gradeBtotallt30 = gradeBtotallt30 + retpayload['gradeB_l_30']
      gradeBtotalgt30lt60 = gradeBtotalgt30lt60 + retpayload['gradeA_30_60'];
      gradeBtotalgt60 = gradeBtotalgt60 + retpayload['gradeB_g_60'];

      gradeCtotallt30 = gradeCtotallt30 + retpayload['gradeC_l_30']
      gradeCtotalgt30lt60 = gradeCtotalgt30lt60 + retpayload['gradeC_30_60'];
      gradeCtotalgt60 = gradeCtotalgt60 + retpayload['gradeC_g_60'];


      gradeDtotallt30 = gradeDtotallt30 + retpayload['gradeD_l_30']
      gradeDtotalgt30lt60 = gradeDtotalgt30lt60 + retpayload['gradeD_30_60'];
      gradeDtotalgt60 = gradeDtotalgt60 + retpayload['gradeD_g_60'];

    }


    if ((skgrp != undefined && skgrp != null && skgrp != '') && (capability != undefined && capability != null && capability != '')) {
      let retpayload = {};
      retpayload['skillGroupName'] = skillgrpbo.find(ele => ele.id == skgrp)?.skillGroupName;
      retpayload['skillGroupId'] = skgrp;
      retpayload['capabilityId'] = skillgrpbo.find(ele => ele.id == skgrp).capability;

      retpayload['gradeA_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup < 30).length;
      retpayload['gradeA_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeA_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'A' && ele.employeeSubgroup > 60).length;

      retpayload['gradeB_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup < 30).length;
      retpayload['gradeB_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeB_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'B' && ele.employeeSubgroup > 60).length;

      retpayload['gradeC_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup < 30).length;
      retpayload['gradeC_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeC_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'C' && ele.employeeSubgroup > 60).length;

      retpayload['gradeD_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup < 30).length;
      retpayload['gradeD_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup >= 30 && ele.employeeSubgroup <= 60).length;
      retpayload['gradeD_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skgrp && ele.grade == 'D' && ele.employeeSubgroup > 60).length;


      data.push(retpayload);
      gradeAtotallt30 = gradeAtotallt30 + retpayload['gradeA_l_30']
      gradeAtotalgt30lt60 = gradeAtotalgt30lt60 + retpayload['gradeA_30_60'];
      gradeAtotalgt60 = gradeAtotalgt60 + retpayload['gradeA_g_60'];

      gradeBtotallt30 = gradeBtotallt30 + retpayload['gradeB_l_30']
      gradeBtotalgt30lt60 = gradeBtotalgt30lt60 + retpayload['gradeA_30_60'];
      gradeBtotalgt60 = gradeBtotalgt60 + retpayload['gradeB_g_60'];

      gradeCtotallt30 = gradeCtotallt30 + retpayload['gradeC_l_30']
      gradeCtotalgt30lt60 = gradeCtotalgt30lt60 + retpayload['gradeC_30_60'];
      gradeCtotalgt60 = gradeCtotalgt60 + retpayload['gradeC_g_60'];


      gradeDtotallt30 = gradeDtotallt30 + retpayload['gradeD_l_30']
      gradeDtotalgt30lt60 = gradeDtotalgt30lt60 + retpayload['gradeD_30_60'];
      gradeDtotalgt60 = gradeDtotalgt60 + retpayload['gradeD_g_60'];


    }


    if ((skgrp == undefined || skgrp == null || skgrp == '') && (capability != undefined && capability != null && capability != '')) {

      for (let i = 0; i < skillgrpbodata.length; i++) {
        let retpayload = {};


        retpayload['skillGroupName'] = skillgrpbodata[i].skillGroupName;
        retpayload['skillGroupId'] = skillgrpbodata[i].id;
        retpayload['capabilityId'] = skillgrpbodata[i].capability;

        retpayload['gradeA_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'A' && Number(ele.employeeSubgroup) < 30).length;
        retpayload['gradeA_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'A' && Number(ele.employeeSubgroup) >= 30 && Number(ele.employeeSubgroup) <= 60).length;
        retpayload['gradeA_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'A' && Number(ele.employeeSubgroup) > 60).length;

        retpayload['gradeB_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'B' && Number(ele.employeeSubgroup) < 30).length;
        retpayload['gradeB_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'B' && Number(ele.employeeSubgroup) >= 30 && Number(ele.employeeSubgroup) <= 60).length;
        retpayload['gradeB_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'B' && Number(ele.employeeSubgroup) > 60).length;

        retpayload['gradeC_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'C' && Number(ele.employeeSubgroup) < 30).length;
        retpayload['gradeC_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'C' && Number(ele.employeeSubgroup) >= 30 && Number(ele.employeeSubgroup) <= 60).length;
        retpayload['gradeC_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'C' && Number(ele.employeeSubgroup) > 60).length;

        retpayload['gradeD_l_30'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'D' && Number(ele.employeeSubgroup) < 30).length;
        retpayload['gradeD_30_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'D' && Number(ele.employeeSubgroup) >= 30 && Number(ele.employeeSubgroup) <= 60).length;
        retpayload['gradeD_g_60'] = empbo.filter(ele => ele.CapabilitySkillGroup == skillgrpbodata[i].id && ele.grade == 'D' && Number(ele.employeeSubgroup) > 60).length;


        data.push(retpayload);

        gradeAtotallt30 = gradeAtotallt30 + retpayload['gradeA_l_30']
        gradeAtotalgt30lt60 = gradeAtotalgt30lt60 + retpayload['gradeA_30_60'];
        gradeAtotalgt60 = gradeAtotalgt60 + retpayload['gradeA_g_60'];

        gradeBtotallt30 = gradeBtotallt30 + retpayload['gradeB_l_30']
        gradeBtotalgt30lt60 = gradeBtotalgt30lt60 + retpayload['gradeA_30_60'];
        gradeBtotalgt60 = gradeBtotalgt60 + retpayload['gradeB_g_60'];

        gradeCtotallt30 = gradeCtotallt30 + retpayload['gradeC_l_30']
        gradeCtotalgt30lt60 = gradeCtotalgt30lt60 + retpayload['gradeC_30_60'];
        gradeCtotalgt60 = gradeCtotalgt60 + retpayload['gradeC_g_60'];


        gradeDtotallt30 = gradeDtotallt30 + retpayload['gradeD_l_30']
        gradeDtotalgt30lt60 = gradeDtotalgt30lt60 + retpayload['gradeD_30_60'];
        gradeDtotalgt60 = gradeDtotalgt60 + retpayload['gradeD_g_60'];

      }


    }

    data.push({ 'skillGroupName': 'total',
     'gradeA_l_30': gradeAtotallt30,'gradeA_30_60':gradeAtotalgt30lt60,'gradeA_g_60':gradeAtotalgt60,
     'gradeB_l_30': gradeBtotallt30,'gradeB_30_60':gradeBtotalgt30lt60,'gradeB_g_60':gradeBtotalgt60,
     'gradeC_l_30': gradeCtotallt30,'gradeC_30_60':gradeCtotalgt30lt60,'gradeC_g_60':gradeCtotalgt60,
     'gradeD_l_30': gradeDtotallt30,'gradeD_30_60':gradeDtotalgt30lt60,'gradeD_g_60':gradeDtotalgt60,
    });

    return data;

  };


  PageModule.prototype.downloadfun = function (BenchArray) {
    let multidata = new Array();

    for (let i = 0; i <= BenchArray.length; i++) {
      let instanceArray = [];
      if (i == 0) {

        // instanceArray.push('');
        // instanceArray.push('');
        // instanceArray.push('A');
        // instanceArray.push('');
        // instanceArray.push('');
        // instanceArray.push('B');
        // instanceArray.push('');
        // instanceArray.push('');
        // instanceArray.push('C');
        // instanceArray.push('');
        // instanceArray.push('');
        // instanceArray.push('D');
        // instanceArray.push('');

        // multidata.push(instanceArray);
        // instanceArray = [];


        instanceArray.push('SkillGroupName');
        instanceArray.push('<30 count of GradeA');
        instanceArray.push('between 30-60 count of GradeA');
        instanceArray.push('> 60 count of GradeA');
        instanceArray.push('<30 count of GradeB');
        instanceArray.push('between 30-60 count of GradeB');
        instanceArray.push('> 60 count of GradeB');
        instanceArray.push('<30 count of GradeC');
        instanceArray.push('between 30-60 count of GradeC');
        instanceArray.push('> 60 count of GradeC');
        instanceArray.push('<30 count of GradeD');
        instanceArray.push('between 30-60 count of GradeD');
        instanceArray.push('> 60 count of GradeD');

        multidata.push(instanceArray);
      }
      else {
        instanceArray.push(BenchArray[i - 1]['skillGroupName']);
        instanceArray.push(BenchArray[i - 1]['gradeA_l_30']);
        instanceArray.push(BenchArray[i - 1]['gradeA_30_60']);
        instanceArray.push(BenchArray[i - 1]['gradeA_g_60']);
        instanceArray.push(BenchArray[i - 1]['gradeB_l_30']);
        instanceArray.push(BenchArray[i - 1]['gradeB_30_60']);
        instanceArray.push(BenchArray[i - 1]['gradeB_g_60']);

        instanceArray.push(BenchArray[i - 1]['gradeC_l_30']);
        instanceArray.push(BenchArray[i - 1]['gradeC_30_60']);
        instanceArray.push(BenchArray[i - 1]['gradeC_g_60']);
        instanceArray.push(BenchArray[i - 1]['gradeD_l_30']);
        instanceArray.push(BenchArray[i - 1]['gradeD_30_60']);
        instanceArray.push(BenchArray[i - 1]['gradeD_g_60']);

        multidata.push(instanceArray);
      }

    }
    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Bench Ageing Analysis Details");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Bench Ageing Analysis Details"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Bench Ageing Analysis Details_" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, filename);
    }
    else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        // console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.hyperlinkfun = function (empbo, empsubgrp1, empsubgrp2,skillgrpbo,capbo) {
    let data = [];

    if (empsubgrp1 && empsubgrp2) {
      for (let i = 0; i < empbo.length; i++) {
        let retpayload = {};
        if (Number(empbo[i].employeeSubgroup) >= 30 && Number(empbo[i].employeeSubgroup) <= 60) {
          retpayload['employeeId'] = empbo[i].employeeID;
          retpayload['grade'] = empbo[i].grade;
          retpayload['localGrade'] = empbo[i].localGrade;
          retpayload['Employee Name'] = empbo[i].name;
          retpayload['Capability'] = capbo.find(ele => ele.id == empbo[i].globalPractice).name;
          retpayload['skillGroup'] = skillgrpbo.find(ele => ele.id == empbo[i].CapabilitySkillGroup).skillGroupName;
          data.push(retpayload);

        }
      }
    }

    if (!empsubgrp2 && empsubgrp1) {
      for (let i = 0; i < empbo.length; i++) {
        let retpayload = {};
        if (Number(empbo[i].employeeSubgroup) < 30) {
          retpayload['employeeId'] = empbo[i].employeeID;
          retpayload['grade'] = empbo[i].grade;
          retpayload['localGrade'] = empbo[i].localGrade;
          retpayload['Employee Name'] = empbo[i].name;
          retpayload['Capability'] = capbo.find(ele => ele.id == empbo[i].globalPractice).name;
          retpayload['skillGroup'] = skillgrpbo.find(ele => ele.id == empbo[i].CapabilitySkillGroup).skillGroupName;
          data.push(retpayload);

        }
      }

    }
    if (!empsubgrp1 && empsubgrp2) {
      for (let i = 0; i < empbo.length; i++) {
        let retpayload = {};
        if (Number(empbo[i].employeeSubgroup) > 60) {
          retpayload['employeeId'] = empbo[i].employeeID;
          retpayload['grade'] = empbo[i].grade;
          retpayload['Employee Name'] = empbo[i].name;
          retpayload['Capability'] = capbo.find(ele => ele.id == empbo[i].globalPractice).name;
          retpayload['skillGroup'] = skillgrpbo.find(ele => ele.id == empbo[i].CapabilitySkillGroup).skillGroupName;
          data.push(retpayload);

        }
      }

    }


    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.querygen = function (grade, skillgrp) {
    let queryString = '';
    queryString = `activeFlag='Y' AND status='Bench - Deployable' AND grade='${grade}' AND CapabilitySkillGroup=${skillgrp}`;
    return queryString;

  };


  

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.downloadhyperlink = function (BenchArray) {
    let multidata = new Array();

    for (let i = 0; i <= BenchArray.length; i++) {
      let instanceArray = [];
      if (i == 0) {
        instanceArray.push('employeeId');
        instanceArray.push('grade');
        instanceArray.push('localGrade');
        instanceArray.push('Employee Name');
        instanceArray.push('Capability');
        instanceArray.push('skillGroup');

        multidata.push(instanceArray);
      }
      else {
        instanceArray.push(BenchArray[i - 1]['employeeId']);
        instanceArray.push(BenchArray[i - 1]['grade']);
        instanceArray.push(BenchArray[i - 1]['localGrade']);
        instanceArray.push(BenchArray[i - 1]['Employee Name']);
        instanceArray.push(BenchArray[i - 1]['Capability']);
        instanceArray.push(BenchArray[i - 1]['skillGroup']);


        multidata.push(instanceArray);
      }

    }
    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Hyperlink Details");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Hyperlink Details"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Hyperlink Details_" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, filename);
    }
    else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        // console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.titlefun = function (skillgrpbo,capbo,skgrpid,capid) {
    let skillgroupname = skillgrpbo.find(ele => ele.id == skgrpid).skillGroupName;
    let capname = capbo.find(ele => ele.id == capid).name;
    return [skillgroupname,capname];
  };

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  };



  return PageModule;
});
