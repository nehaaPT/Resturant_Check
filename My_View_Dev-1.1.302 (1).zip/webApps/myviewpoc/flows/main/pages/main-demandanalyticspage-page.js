define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

PageModule.prototype.empIDArr=function(employeeBO)
{
  var a = new Array();
  for(var i = 0; i<employeeBO.length;i++)
  {
    a.push(employeeBO[i].id);
  }
  return a;
};
  PageModule.prototype.buildQFormat = function (format) {
    var qparameter=''
    if (format=="Both")
    qparameter="(employeeBOObject.format='US' or employeeBOObject.format='India')";

    else if(format=="US") {
      qparameter="employeeBOObject.format='US'";
    }
    else{
      qparameter="employeeBOObject.format='India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };
 PageModule.prototype.createEmployeeSkillArray=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     var empSkillArray=new Array(); 

    for(var index=0;index<empSkillBO.length;index++){

     var skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
      var skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      var capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      var empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}';
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
    }
    
return empSkillArray;

  };

  PageModule.prototype.pushData=function(demandSupplyBO,demandBO,employeeBo){
    var demandArray=new Array();
      console.log(JSON.stringify(demandBO));

    for(var index=0;index<demandSupplyBO.length;index++)
    {
      var demandFound=demandBO.find(element=>element.id==demandSupplyBO[index].demandID);
      if(demandFound){
      var data={"demandEmployeeId":demandSupplyBO[index].employeeID,"trn":demandFound.teamRequestNumber,"sector":demandFound.sectorObject.items[0].name,"clientName":demandFound.clientObject.items[0].clientName,"projectName":demandFound.projectName,"positionName":demandFound.positionName,"demandStatus":demandFound.status,"employeeId":demandSupplyBO[index].employeeIDObject.items[0] != undefined ? demandSupplyBO[index].employeeIDObject.items[0].employeeID:'NA',"employeeName":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].name : 'NA',"nominationStatus":demandSupplyBO[index].allocationType,"nominationComments":demandSupplyBO[index].allocationComments,"employeeGrade":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].localGrade : 'NA',"employeeGeography":demandSupplyBO[index].employeeIDObject.items[0] != undefined? demandSupplyBO[index].employeeIDObject.items[0].format : 'NA'};
      demandArray.push(data);
      }
      

    }

    return demandArray;




  }

   PageModule.prototype.dateValidation = function (resignationDate,withdrawalDate,lastWorkingDate,demandId) {
     var notification = {
       }
     var resignation_Date = new Date(resignationDate);
     var withdrawal_Date = new Date(withdrawalDate);
     var lastWorking_Date = new Date(lastWorkingDate); 
     console.log('@1'+resignationDate);
     console.log('@2'+withdrawal_Date);
     console.log('@3'+lastWorkingDate);
    if ((demandId !=null || demandId != undefined) && isNaN(demandId)){
      notification.status=false;
      notification.message='Demand Id should be a Number';
      return notification;
    }
    if (withdrawalDate !=null || withdrawalDate != undefined ){
      console.log(lastWorking_Date.getTime()> withdrawal_Date.getTime()>resignation_Date.getTime());
      notification.status=(lastWorking_Date.getTime() > withdrawal_Date.getTime() && withdrawal_Date.getTime() > resignation_Date.getTime());
      notification.message='Withdrawal Date should be between Last Working Date and Resignation Date';
      console.log(JSON.stringify(notification));
      return notification;
      }
    else
     console.log(lastWorking_Date.getTime()>resignation_Date.getTime());
     notification.status=(lastWorking_Date.getTime()>resignation_Date.getTime());
     notification.message='Last Working Date should be greater than Resignation Date';
     console.log(JSON.stringify(notification));
      return notification;
         
  };

  PageModule.prototype.createQParameter=function(nominationVar){
   var qParam='';
   
        var qArray=[];
        if(nominationVar.bu!='')
         {qArray.push('demandIDObject.sector='+nominationVar.bu);}
        if(nominationVar.capability!='')
        qArray.push('demandIDObject.globalPractice='+nominationVar.capability);
        if(nominationVar.client!='')
        qArray.push('demandIDObject.client='+nominationVar.client);
        if(nominationVar.demandStatus!='')
        qArray.push("demandIDObject.status='"+nominationVar.demandStatus+"'");
        if(nominationVar.location!='')
        qArray.push("demandIDObject.format='"+nominationVar.location+"'");
        if( nominationVar.nominationStatus!='')
        qArray.push("allocationType='"+nominationVar.nominationStatus+"'");
        if(nominationVar.skillGroup!='')
        qArray.push('demandIDObject.skillGroup='+nominationVar.skillGroup);

        for(var i=0;i<qArray.length;i++)
        {
           if(i==qArray.length-1)
          {
            qParam=qParam+" "+qArray[i];
          }
          else{
              qParam=qParam+" "+qArray[i]+" and";
       
          }
        }

        console.log('QParam'+qParam)

       return qParam;
  }






   PageModule.prototype.getAgeing=function(plannedDate){
    const date1 = new Date(plannedDate);
const date2 = new Date();
const diffTime = Math.abs(date2 - date1);
const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
console.log('@12'+plannedDate);
  if(plannedDate == null || date1>date2)
  {
    return 0;
  }
  else
  {
    return diffDays-1;
  }


  };
  
function changeFormat(currentDate) {
    try{
   
      var now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
   
    }
    catch(err){
       console.log('#131'+currentDate);
      return currentDate;
    }
  }

PageModule.prototype.demandAnalyticsDataCreate = function(P_demandBO){
    // console.log(P_demandBO);
    var initData = [];
    var finalData = [];
        finalData['Total'] = [];
        
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec","Jan","Feb"];
    var row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0, row11=0, row12=0, row13=0, row14=0, row15=0, row16=0;

    for(var i=0; i<P_demandBO.length; i++){
      var row = {};
      
      // P_demandBO[0].roleStartDate
      var net_total=0, sold_total=0, pursuit_total=0, strategic_total=0;
      row['capability'] = P_demandBO[i].globalPracticeObject.items[0].name;
      row['skillGroups'] = P_demandBO[i].skillGroup != undefined ? P_demandBO[i].skillGroupObject.items[0].skillGroupName  : '';
      row['roleStartDate'] = P_demandBO[i].roleStartDate;
      row['demandType'] = P_demandBO[i].demandType.trim();

      initData.push(row);
    };
    var d = new Date();
    var curr_month = d.getMonth()+1;

    for (i=0; i<initData.length; i++){
      
      var roleStartDate = new Date(initData[i]['roleStartDate']);
      var month = roleStartDate.getMonth()+1;
      
      var element  = finalData.find(function(data){return data.capability == initData[i].capability && data.skillGroups == initData[i].skillGroups;});
    
      if(element == undefined){
        console.log("Insert");

        var temp = {};

        temp['capability'] = initData[i].capability;
        temp['skillGroups'] = initData[i].skillGroups;
        temp['sold_current_due'] = 0;
        temp['sold_next_due'] = 0;
        temp['sold_future_due'] = 0;
        temp['sold_past_due'] = 0;
        temp['sold_total'] = 0;
        temp['pursuit_current_due'] = 0;
        temp['pursuit_next_due'] = 0;
        temp['pursuit_future_due'] = 0;
        temp['pursuit_past_due'] = 0;
        temp['pursuit_total'] = 0;
        temp['strategic_current_due'] = 0;
        temp['strategic_next_due'] = 0;
        temp['strategic_future_due'] = 0;
        temp['strategic_past_due'] = 0;
        temp['strategic_total'] = 0;
        

        


        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month){
            temp['sold_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['sold_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['sold_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['sold_past_due'] = 1;
          }
          
          temp['sold_total'] = 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            temp['pursuit_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['pursuit_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['pursuit_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['pursuit_past_due'] = 1;
          }
          
          temp['pursuit_total'] = 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            temp['strategic_current_due'] = 1;
          }      
          else if(month == curr_month+1){
            temp['strategic_next_due'] = 1;
          }
          else if(month > curr_month+1){
            temp['strategic_future_due'] = 1;
          }
          else if(month < curr_month){
            temp['strategic_past_due'] = 1;
          }
           
          temp['strategic_total'] = 1;
        }

        temp['net_demands'] = temp['sold_total'] + temp['pursuit_total'] + temp['strategic_total'];
        finalData.push(temp);
      }
        
      else{
        console.log("Update");
        var index = finalData.findIndex(function(data){return data.capability == element.capability && data.skillGroups == element.skillGroups;});
       

        if(initData[i].demandType == 'Sold Project'){
          if(month == curr_month){
            finalData[index]['sold_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['sold_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['sold_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['sold_past_due'] += 1;
          }
          
          finalData[index]['sold_total'] += 1;
        }
        else if(initData[i].demandType == 'Pursuit Project'){
          if(month == curr_month){
            finalData[index]['pursuit_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['pursuit_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['pursuit_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['pursuit_past_due'] += 1;
          }
          
          finalData[index]['pursuit_total'] += 1;
        }
        else if(initData[i].demandType == 'Strategic'){
          if(month == curr_month){
            finalData[index]['strategic_current_due'] += 1;
          }      
          else if(month == curr_month+1){
            finalData[index]['strategic_next_due'] += 1;
          }
          else if(month > curr_month+1){
            finalData[index]['strategic_future_due'] += 1;
          }
          else if(month < curr_month){
            finalData[index]['strategic_past_due'] += 1;
          }
          
          finalData[index]['strategic_total'] += 1;
        }

        finalData[index]['net_demands'] = finalData[index]['sold_total'] + finalData[index]['pursuit_total'] + finalData[index]['strategic_total'];
      }
      // if(P_demandBO[0].demandType)
    };

    for (var i=0; i<finalData.length; i++){
      row1 += finalData[i].sold_past_due;
      row2 += finalData[i].sold_current_due;
      row3 += finalData[i].sold_next_due;
      row4 += finalData[i].sold_future_due;
      row5 += finalData[i].sold_total;
      row6 += finalData[i].pursuit_past_due;
      row7 += finalData[i].pursuit_current_due;
      row8 += finalData[i].pursuit_next_due;
      row9 += finalData[i].pursuit_future_due;
      row10 += finalData[i].pursuit_total;
      row11 += finalData[i].strategic_past_due;
      row12 += finalData[i].strategic_current_due;
      row13 += finalData[i].strategic_next_due;
      row14 += finalData[i].strategic_future_due;
      row15 += finalData[i].strategic_total;
      row16 += finalData[i].net_demands;
    };

    var temp = {};
    temp['capability'] = "";
    temp['skillGroups'] = "Total";
    temp['sold_current_due'] = row2;
    temp['sold_next_due'] = row3;
    temp['sold_future_due'] = row4;
    temp['sold_past_due'] = row1;
    temp['sold_total'] = row5;
    temp['pursuit_current_due'] = row7;
    temp['pursuit_next_due'] = row8;
    temp['pursuit_future_due'] = row9;
    temp['pursuit_past_due'] = row6;
    temp['pursuit_total'] = row10;
    temp['strategic_current_due'] = row12;
    temp['strategic_next_due'] = row13;
    temp['strategic_future_due'] = row14;
    temp['strategic_past_due'] = row11;
    temp['strategic_total'] = row15;
    temp['net_demands'] = row16;

    finalData['Total'].push(temp);

    finalData['currentMonth'] = monthNames[curr_month-1];
    finalData['nextMonth'] = monthNames[curr_month];
    finalData['future'] = monthNames[curr_month+1]+'+';
   
    console.log(finalData);
    return finalData;
  };

PageModule.prototype.analyticsReportData = function(P_BUSearch, P_ClientSearch, P_StatusSearch, P_CapabSearch, P_SkillSearch){
    var retPayload = {};

    if(P_BUSearch == undefined || P_BUSearch == 'Oic.user'){
      retPayload['bu'] = '';
    }
    else{
      retPayload['bu'] = P_BUSearch;
    }

    if(P_ClientSearch == undefined){
      retPayload['client'] = '';
    }
    else{
      retPayload['client'] = P_ClientSearch;
    }

    if(P_StatusSearch == undefined){
      retPayload['status'] = '';
    }
    else{
      retPayload['status'] = P_StatusSearch;
    }

    if(P_CapabSearch == undefined){
      retPayload['capab'] = '';
    }
    else{
      retPayload['capab'] = P_CapabSearch;
    }

    if(P_SkillSearch == undefined){
      retPayload['skill'] = '';
    }
    else{
      retPayload['skill'] = P_SkillSearch;
    }

    return retPayload;
  };

    PageModule.prototype.selectedAnalyticsData1 = function (P_Data,P_DemandSupplyLinkBO,P_Emp,P_Supply){

    console.log(P_Data);
    var finalData=[];
    for(var i=0; i<P_Data.length; i++)
    {
      var temp={};
      var demandSup = P_DemandSupplyLinkBO.find(eledemand => eledemand.demandID == P_Data[i].id);
      // var empid= employeeBO.find(ele =>ele.id==empCertData[i].employeeId);
      // instanceArray.push(empid.location!=undefined?locatBo.find(element=>element.id==empid.location).location:'NA');
      //var supply = demandSup != undefined?P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID).profileID:'NA';
     //* var supply = demandSup != undefined?P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID):'NA';
      //var emp = demandSup != undefined?P_Emp.find(empele => empele.id == demandSup.employeeID).employeeID:'NA';
      //console.log('@421'+JSON.stringify(emp));
      if(demandSup != undefined)
      {
        if(demandSup.supplyID != undefined )
        {
         if(demandSup.employeeID == null)
         {
          var supply = P_Supply.find(eleSupply => eleSupply.id == demandSup.supplyID);
          // temp['profileID'] = demandSup != undefined?demandSup.supplyID:'NA';
          temp['profileID'] = supply != null?supply.profileID:'NA';
          temp['doj'] = supply != null?supply.doj:'NA';
         }
        }

        else if(demandSup.employeeID != undefined )
        {
         if(demandSup.supplyID == null)
         {
          var emp = P_Emp.find(empele => empele.id == demandSup.employeeID);
          // temp['profileID'] = demandSup != undefined?demandSup.employeeID:'NA';
          temp['profileID'] = emp != null?emp.employeeID:'NA';
          temp['doj'] = 'NA';
         }
        }
      }
      else
      {
        temp['profileID'] = 'NA';
        temp['doj'] = 'NA';
      }
      console.log('@417'+JSON.stringify(P_Emp));
      console.log('@418'+JSON.stringify(P_Supply));
      console.log('@419'+JSON.stringify(demandSup));
      console.log('@423'+JSON.stringify(supply));
      temp['format'] = P_Data[i].format;
      temp['teamRequestNumber'] = P_Data[i].teamRequestNumber;
      temp['positionId'] = P_Data[i].positionId;
      temp['recruitingID'] = P_Data[i].recruitingID;
      temp['demandStatus'] = P_Data[i].demandStatus;
      temp['sector'] = P_Data[i].sectorObject.items[0].name;
      temp['subSector'] = P_Data[i].subSector;
      temp['teamRequestName'] = P_Data[i].teamRequestName;
      temp['fulfillmentChannel'] = P_Data[i].fulfillmentChannel;
      temp['status'] = P_Data[i].status;
      temp['additionalNotes'] = P_Data[i].additionalNotes;
      temp['client'] = P_Data[i].clientObject.items[0].clientName;
      temp['demandType'] = P_Data[i].demandType;
      temp['demandTypeUpdated'] = P_Data[i].demandTypeUpdated;
      temp['projectCode'] = P_Data[i].projectCodeObject.items.length> 0?P_Data[i].projectCodeObject.items[0].projectCode:'NA';
      temp['project'] = P_Data[i].projectName;
      temp['position'] = P_Data[i].positionName;
      temp['localGrade'] = P_Data[i].localGrade;
      temp['roleNotes'] = P_Data[i].roleNotes;
      temp['roleType'] = P_Data[i].roleType;
      temp['backFillReason'] = P_Data[i].backFillReason;
      temp['roleStartDate'] = P_Data[i].roleStartDate;
      temp['roleEndDate'] = P_Data[i].roleEndDate;
      temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
      temp['demandCreationDate'] = P_Data[i].demandCreationDate;
      temp['weekByStatus'] = P_Data[i].weekByStatus;
      temp['leadtime'] = P_Data[i].leadtime;
      temp['ageing'] = P_Data[i].ageing;
      temp['bUSPHandler'] = P_Data[i].bUSPHandler;
      temp['pSPHandler'] = P_Data[i].pSPHandler;
      temp['recruiter'] = P_Data[i].recruiter;
      temp['requestedBy'] = P_Data[i].requestedBy;
      temp['deliveryType'] = P_Data[i].deliveryType;
      temp['primaryCity'] = P_Data[i].primaryCity;
      temp['primaryState'] = P_Data[i].primaryState;      
      temp['location'] = P_Data[i].location;
      temp['thorStage'] = P_Data[i].thorStage;
      temp['revenueStatus'] = P_Data[i].revenueStatus;
      //temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
      temp['skillGroup'] = P_Data[i].skillGroupObject.items.length>0 ?P_Data[i].skillGroupObject.items[0].skillGroupName:'NA';
      temp['newStatus'] = P_Data[i].newStatus;
      temp['comments'] = P_Data[i].comments;
      temp['cloud']=P_Data[i].cloud;
      temp['clientInterview']=P_Dara[i].clientInterview;
     // temp['profileID'] = demandSup != undefined?supply:'NA';
      //temp['profileID'] = demandSup != undefined?demandSup.supplyID:'NA';
      //*temp['doj'] = supply != undefined?supply.id:'NA';
      //console.log('@456'+JSON.stringify(P_Data[i].demandSupplyLinkBOColle.items>0 ? P_Data[i].demandSupplyLinkBOColle.items[0].employeeID:'NA'));
      
     
      finalData.push(temp);
      console.log('@465'+JSON.stringify(temp));
    } 
    return finalData;
  };

  PageModule.prototype.selectedAnalyticsData = function (P_Data, P_type, P_Capab, P_Skill){
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    var d = new Date();
    var curr_month = d.getMonth();

    var finalData=[];

    for(var i=0; i<P_Data.length; i++){
    if(P_Data[i].skillGroup != undefined && P_Data[i].skillGroup !='' ){
      if(P_Data[i].globalPracticeObject.items[0].name == P_Capab && P_Data[i].skillGroupObject.items[0].skillGroupName == P_Skill){
        var roleStartDate = new Date(P_Data[i]['roleStartDate']);
        var month = roleStartDate.getMonth();
        var temp={};

        finalData['capability'] = P_Capab;
        finalData['skillGroup'] = P_Skill;
        temp['demandType'] == P_Data[i].demandType;
        //console.log('427'+P_Data[i].demandType);

        switch(P_type){
          case 's_past':
          
            if(P_Data[i]['demandType'] == 'Sold Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              console.log(1);
              console.log(P_Data[i].demandType);

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              
              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;
              
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
               temp['demandType'] == P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
               temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month < curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month == curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month > curr_month+1){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month];
              finalData.push(temp);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp['trn'] = P_Data[i].teamRequestNumber;
              temp['sector'] = P_Data[i].sectorObject.items[0].name;
              temp['client'] = P_Data[i].clientObject.items[0].clientName;
              temp['project'] = P_Data[i].projectName;
              temp['position'] = P_Data[i].positionName;
              temp['roleNotes'] = P_Data[i].roleNotes;
              temp['status'] = P_Data[i].status;

              temp['localGrade'] = P_Data[i].localGrade;
              temp['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp['roleStartDate'] = P_Data[i].roleStartDate;
              temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp);
            }
            break;
          
          case 'net_demands':
            temp['trn'] = P_Data[i].teamRequestNumber;
            temp['sector'] = P_Data[i].sectorObject.items[0].name;
            temp['client'] = P_Data[i].clientObject.items[0].clientName;
            temp['project'] = P_Data[i].projectName;
            temp['position'] = P_Data[i].positionName;
            temp['roleNotes'] = P_Data[i].roleNotes;
            temp['status'] = P_Data[i].status;

            temp['localGrade'] = P_Data[i].localGrade;
            temp['demandCreationDate'] = P_Data[i].demandCreationDate;
            temp['roleStartDate'] = P_Data[i].roleStartDate;
            temp['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
            temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
            temp['demandType'] = P_Data[i].demandType;


            finalData['role'] = 'All';
            finalData.push(temp);
          
        }
      }
    }
      else if(P_Skill == 'Total'){
        var roleStartDate1 = new Date(P_Data[i]['roleStartDate']);
        var month1 = roleStartDate1.getMonth();
        var temp1 = {};

        finalData['capability'] = 'All'
        finalData['skillGroup'] = 'All';

        switch(P_type){
          case 's_past':

            console.log(P_Data[i].demandType);
            console.log(month1);


            if(P_Data[i]['demandType'] == 'Sold Project' && month1 < curr_month){
              console.log('Inside');
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            
            break;
            
          case 's_current':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              
              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_next':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_future':
            if(P_Data[i]['demandType'] == 'Sold Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 's_total':
            if(P_Data[i]['demandType'] == 'Sold Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;
              
              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'p_past':
             if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'p_current':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_next':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }           
            break;
          
          case 'p_future':
            if(P_Data[i]['demandType'] == 'Pursuit Project' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'p_total':
            if(P_Data[i]['demandType'] == 'Pursuit Project'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
               temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }           
            break;
          
          case 'st_past':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 < curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = 'Before ' + monthNames[curr_month];
              finalData.push(temp1);
            }
            break;
            
          case 'st_current':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_next':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 == curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_future':
            if(P_Data[i]['demandType'] == 'Strategic' && month1 > curr_month+1){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              temp1['demandType'] = P_Data[i].demandType;

              finalData['role'] = monthNames[month1];
              finalData.push(temp1);
            }
            break;
          
          case 'st_total':
            if(P_Data[i]['demandType'] == 'Strategic'){
              temp1['trn'] = P_Data[i].teamRequestNumber;
              temp1['sector'] = P_Data[i].sectorObject.items[0].name;
              temp1['client'] = P_Data[i].clientObject.items[0].clientName;
              temp1['project'] = P_Data[i].projectName;
              temp1['position'] = P_Data[i].positionName;
              temp1['roleNotes'] = P_Data[i].roleNotes;
              temp1['status'] = P_Data[i].status;

              temp1['localGrade'] = P_Data[i].localGrade;
              temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
              temp1['roleStartDate'] = P_Data[i].roleStartDate;
              temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
              temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
              //temp1['demandType'] == P_Data[i].demandType;

              finalData['role'] = monthNames[curr_month-1] + ', ' + monthNames[curr_month] + ', ' + monthNames[curr_month+1] + ', ' + monthNames[curr_month+2] + '+';
              finalData.push(temp1);
            }
            break;
          
          case 'net_demands':
            temp1['trn'] = P_Data[i].teamRequestNumber;
            temp1['sector'] = P_Data[i].sectorObject.items[0].name;
            temp1['client'] = P_Data[i].clientObject.items[0].clientName;
            temp1['project'] = P_Data[i].projectName;
            temp1['position'] = P_Data[i].positionName;
            temp1['roleNotes'] = P_Data[i].roleNotes;
            temp1['status'] = P_Data[i].status;

            temp1['localGrade'] = P_Data[i].localGrade;
            temp1['demandCreationDate'] = P_Data[i].demandCreationDate;
            temp1['roleStartDate'] = P_Data[i].roleStartDate;
            temp1['globalPractice'] = P_Data[i].globalPracticeObject.items[0].name;
            temp1['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
            temp1['demandType'] = P_Data[i].demandType;

            finalData['role'] = 'All';
            finalData.push(temp1);
          
        }
      }
    
    }
    console.log(finalData);
    return finalData;
  };


PageModule.prototype.internalSupplyData = function(P_Emp, P_Alloc, P_Type, P_Skill,P_Comments,P_demandSupplyId){
    var retPayload = [];
    if(P_Alloc.length >0){
      var alloc = P_Alloc.reduce((p, c) => p.value > c.value ? p : c);

      if(alloc != undefined){
        var availableDate = new Date(alloc.allocationEndDate);
        availableDate.setDate(availableDate.getDate() + 1); 

        var temp = {};
        temp['id'] = P_Emp[0].employeeID;
        temp['BoID']=P_Emp[0].id;
        temp['name'] = P_Emp[0].name;
        temp['grade'] = P_Emp[0].localGrade;
        temp['type'] = P_Type;
        temp['status'] = P_Emp[0].status;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[0].globalPracticeObject.items[0].name;
        temp['skill'] = P_Skill;
        temp['loc'] = P_Emp[0].locationObject.items[0].location;
        temp['demandSupplyBOId']=P_demandSupplyId;
        temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      }
    }

    return retPayload;
  };

  PageModule.prototype.externalSupplyData = function(P_SupplyData, P_Type, P_Skill){
    var retPayload = [];
    var temp1 = {};

    temp1['pID'] = P_SupplyData[0].profileID;
    temp1['pName'] = P_SupplyData[0].name;
    temp1['pGrade'] = P_SupplyData[0].recommendedGrade ? P_SupplyData.recommendedGrade : '';
    temp1['pType'] = P_Type;
    temp1['pStatus'] = P_SupplyData[0].status;
    if( P_SupplyData[0].doj != null &&  P_SupplyData[0].doj != undefined &&  P_SupplyData[0].doj !="" &&  P_SupplyData[0].doj !=" "&&  P_SupplyData[0].doj!=''&&  P_SupplyData[0].doj!=' '){
                     var date1 =  P_SupplyData[0].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyData[0].doj = date1;
      }
    temp1['doj'] = P_SupplyData[0].doj;
    temp1['pCapab'] = P_SupplyData[0].capabilityObject.items[0].name;
    temp1['pSkill'] = P_Skill;
    temp1['pLoc'] = P_SupplyData[0].location;

    retPayload.push(temp1);
   console.log('@1203'+JSON.stringify(retPayload));
    return retPayload;
  };



  PageModule.prototype.checkAvailabilityData = function(P_DemandLinkBO, P_EmployeeBO, P_AllocationBO, P_SupplyBO, P_Skill,P_Ret,P_Pip){
    var retPayload = [];

    retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
    retPayload['external'] = [];

    for(var i=0; i<P_EmployeeBO.length; i++){
      var link = P_DemandLinkBO.find(function(link){return link.employeeID != null && link.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID;});
      // var link = P_DemandLinkBO.find(ln => ln.employeeIDObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
      if(link != undefined){
        if(link.allocationType != 'LOCKED'){
          var allocArray = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
          
          if(allocArray.length >0){
            var alloc = allocArray.reduce((p, c) => p.value > c.value ? p : c);

            if(alloc != undefined){
              var availableDate = new Date(alloc.allocationEndDate);
              availableDate.setDate(availableDate.getDate() + 1); 

              var temp = {};

              temp['globalID'] = P_EmployeeBO[i].globalEmployeeID;
              temp['employeeID'] = P_EmployeeBO[i].employeeID;
              temp['name'] = P_EmployeeBO[i].name;
              temp['grade'] = P_EmployeeBO[i].localGrade;
              temp['billable'] = P_EmployeeBO[i].billable;
              temp['status'] = P_EmployeeBO[i].status;
              temp['sector'] = P_EmployeeBO[i].buObject.items[0].name;
              temp['client'] = alloc.clientObject.items[0].clientName;
              temp['project'] = alloc.projectObject.items[0].projectCode;
              temp['pName'] = alloc.projectObject.items[0].projectName;
              temp['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
              temp['skill'] = P_Skill;

               var retention = [];
              retention = P_Ret.filter(ele => ele.employeeID == P_EmployeeBO[i].id);
              retention.sort(function(a,b) {
                const nameA = a.id; 
                const nameB = b.id; 
                if (nameA < nameB) {
                  return 1;
                }
                if (nameA > nameB) {
                  return -1;
                }
                
              })


              //console.log(P_Emp[i].name+' '+JSON.stringify(retention));
              var color=false;
              if (retention.length>0) {
                color=retention[0].withdrawlDate==null?true:false;
              }  
              temp['color'] = color;

               var pip=[];
               var pip2=[];
              pip=P_Pip.filter(ele => ele.empID== P_EmployeeBO[i].id);
              pip2=P_Pip.find(ele => ele.empID== P_EmployeeBO[i].id);
              if(pip2!=undefined)
              {  
              temp['MH']= pip2.category;
             
              }
              else{
              temp['MH']=false;
                
              }

              temp['BgColor']=pip.length>0?true:false;


              if(temp.billable == 'Billable'){
              var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

                if(days <= 30 && days >=0){
                temp['available'] = changeFormat(availableDate);
                retPayload['internalb'].push(temp);
             }
            }
            else{
              temp['available'] = changeFormat(availableDate);
              retPayload['internalnb'].push(temp);
            }
          }
          }
        }
      }
      else{
        var allocArray1 = P_AllocationBO.filter(alloc => alloc.employeeObject.items[0].employeeID == P_EmployeeBO[i].employeeID);
       // console.log('#858'+JSON.stringify(allocArray1));
        if(allocArray1.length > 0){
          var alloc1 = allocArray1.reduce((p, c) => p.lastUpdateDate > c.lastUpdateDate ? p : c);

          if(alloc1 != undefined){
            var availableDate1 = new Date(alloc1.allocationEndDate);
            availableDate1.setDate(availableDate1.getDate() + 1);

            var temp1 = {};

            temp1['globalID'] = P_EmployeeBO[i].globalEmployeeID;
            temp1['employeeID'] = P_EmployeeBO[i].employeeID;
            temp1['name'] = P_EmployeeBO[i].name;
            temp1['grade'] = P_EmployeeBO[i].localGrade;
            temp1['billable'] = P_EmployeeBO[i].billable;
            temp1['status'] = P_EmployeeBO[i].status;
            temp1['sector'] = P_EmployeeBO[i].buObject.items[0].name;
            temp1['client'] = alloc1.clientObject.items[0].clientName;
            temp1['project'] = alloc1.projectObject.items[0].projectCode;
            temp1['pName'] = alloc1.projectObject.items[0].projectName;
            temp1['capab'] = P_EmployeeBO[i].globalPracticeObject.items[0].name;
            temp1['skill'] = P_Skill;

           var retention = [];
              retention = P_Ret.filter(ele => ele.employeeID == P_EmployeeBO[i].id);
              retention.sort(function(a,b) {
                const nameA = a.id; 
                const nameB = b.id; 
                if (nameA < nameB) {
                  return 1;
                }
                if (nameA > nameB) {
                  return -1;
                }
                
              })


              //console.log(P_Emp[i].name+' '+JSON.stringify(retention));
              var color=false;
              if (retention.length>0) {
                color=retention[0].withdrawlDate==null?true:false;
              }  
              temp1['color'] = color;

               var pip=[];
               var pip2=[];
              pip=P_Pip.filter(ele => ele.empID== P_EmployeeBO[i].id);
              pip2=P_Pip.find(ele => ele.empID== P_EmployeeBO[i].id);
              if(pip2!=undefined)
              {  
              temp1['MH']= pip2.category;
             
              }
              else{
              temp1['MH']=false;
                
              }

              temp1['BgColor']=pip.length>0?true:false;

            if(temp1.billable == 'Billable'){
              var avail_date2 = availableDate1;
              var today2 = new Date();
              var curr_date2 = today2;
              var difference1= (avail_date2-curr_date2);

              var days = Math.round(difference1/(1000 * 3600 * 24));

                if(days <= 30 && days >=0){
                temp1['available'] = changeFormat(availableDate1);
                retPayload['internalb'].push(temp1);
             }
            }
            else{
              temp1['available'] = changeFormat(availableDate1);
              retPayload['internalnb'].push(temp1);
            }
          }
        }
      }
    }

    for(var j=0; j<P_SupplyBO.length; j++){
      var link1 = P_DemandLinkBO.find(function(link){return link.supplyID != null && link.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID});
      // var link1 = P_DemandLinkBO.find(ln => ln.supplyIDObject.items[0].profileID == P_SupplyBO[j].profileID);
      if(link1 != undefined){
        if(link1.allocationType != 'LOCKED'){
          var st = P_SupplyBO[j].status;
          if(!(st.includes('Rejected') || st.includes('Declined') || st.includes('Drop'))){
            var temp2 = {};
            temp2['pID'] = P_SupplyBO[j].profileID;
            temp2['pName'] = P_SupplyBO[j].name;
            temp2['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
            temp2['pStatus'] = P_SupplyBO[j].status;
                  if(P_SupplyBO[j].doj != null && P_SupplyBO[j].doj != undefined && P_SupplyBO[j].doj !="" && P_SupplyBO[j].doj !=" "&& P_SupplyBO[j].doj!=''&& P_SupplyBO[j].doj!=' '){
                     var date1 = P_SupplyBO[j].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyBO[j].doj = date1 ;
      }
            temp2['doj'] = P_SupplyBO[j].doj;
            temp2['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
            temp2['pSkill'] = P_Skill;
            temp2['pLoc'] = P_SupplyBO[j].location;

            retPayload['external'].push(temp2);
          }
        }
      }
      else{
        var st1 = P_SupplyBO[j].status;
        if(!(st1.includes('Rejected') || st1.includes('Declined') || st1.includes('Drop'))){
          var temp3 = {};
          temp3['pID'] = P_SupplyBO[j].profileID;
          temp3['pName'] = P_SupplyBO[j].name;
          temp3['pGrade'] = P_SupplyBO[j].recommendedGrade ? P_SupplyBO.recommendedGrade : '';
          temp3['pStatus'] = P_SupplyBO[j].status;
                if(P_SupplyBO[j].doj != null && P_SupplyBO[j].doj != undefined && P_SupplyBO[j].doj !="" && P_SupplyBO[j].doj !=" "&& P_SupplyBO[j].doj!=''&& P_SupplyBO[j].doj!=' '){
                     var date1 = P_SupplyBO[j].doj;
                  var [year,month,day] = date1.split('-');


      [year, month, day] = date1.split('-');

      year = year.toString();
      
      var mon = "";
      switch (month) {
        case "01":
          mon = 'Jan';
          date1 = [day, mon, year].join('-');
          break;
        case "02":
          mon = 'Feb';
          date1 = [day, mon, year].join('-');
          break;
        case "03":
          mon = 'Mar';
          date1 = [day, mon, year].join('-');
          break;
        case "04":
          mon = 'Apr';
          date1 = [day, mon, year].join('-');
          break;
        case "05":
          mon = 'May';
          date1 = [day, mon, year].join('-');
          break;
        case "06":
          mon = 'Jun';
          date1 = [day, mon, year].join('-');
          break;
        case "07":
          mon = 'Jul';
          date1 = [day, mon, year].join('-');
          break;
        case "08":
          mon = 'Aug';
          date1 = [day, mon, year].join('-');
          break;
        case "09":
          mon = 'Sep';
          date1 = [day, mon, year].join('-');
          break;
        case "10":
          mon = 'Oct';
          date1 = [day, mon, year].join('-');
          break;
        case "11":
          mon = 'Nov';
          date1 = [day, mon, year].join('-');
          break;
        case "12":
          mon = 'Dec';
          date1 = [day, mon, year].join('-');
          break;

      }
       date1 = [day,mon,year].join('-');
      if (year.length == 2 && month.length == 2 && day.length == 4) {
       
     
       date1 = [year, mon, day].join('-');
      }
      
              
                 P_SupplyBO[j].doj = date1 ;
      }
          temp3['doj'] = P_SupplyBO[j].doj;
          temp3['pCapab'] = P_SupplyBO[j].capabilityObject.items[0].name;
          temp3['pSkill'] = P_Skill;
          temp3['pLoc'] = P_SupplyBO[j].location;

          retPayload['external'].push(temp3);
        }
      }
    }

    console.log(retPayload);

  
    

    return retPayload;
  };

   PageModule.prototype.assigncommunityandSG=function(P_Emp){
    var retpayload = {};

    if(P_Emp.globalPractice != null){
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.DownloadDemandNomination=function(demandNomination,metaDataArray){
  console.log(demandNomination);
  console.log(JSON.stringify(metaDataArray));
  var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<metaDataArray.length;i++)
  {
      header.push(metaDataArray[i].headerName);
  }
  multidata.push(header);

  for(let i = 0;i<demandNomination.length;i++)
  {
    
    var instanceArray = []; 
    for(var j = 0;j<metaDataArray.length;j++)
    {
      var data=demandNomination[i][metaDataArray[j]['metadata']]==null?'NA':demandNomination[i][metaDataArray[j]['metadata']];
      instanceArray.push(data);
    }



    
    multidata.push(instanceArray);
    console.log("-------------------");
    console.log(instanceArray);
    console.log("-------------------");
  }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Demand Nomination Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Demand Nomination Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
 console.log(fileBytes);
 var blob = new Blob([fileBytes],{type:'octet/stream'});
 var filename = "Demand Nomination Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
 if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
 } else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
}

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.DownloadDemandAnalytics=function(demandAnalytics,metaDataArray){
  console.log(demandAnalytics);
  console.log(JSON.stringify(metaDataArray));
  var multidata = new Array();
  var header = new Array();
  for(let i = 0;i<metaDataArray.length;i++)
  {
      header.push(metaDataArray[i].headerName);
  }
  multidata.push(header);
  console.log('@1483'+JSON.stringify(multidata));

  for(let i = 0;i<demandAnalytics.length;i++)
  {
    
    var instanceArray = []; 
    for(var j = 0;j<metaDataArray.length;j++)
    {
      var data=demandAnalytics[i][metaDataArray[j]['metadata']]==null?'NA':demandAnalytics[i][metaDataArray[j]['metadata']];
      if(metaDataArray[j]['metadata'] == 'roleStartDate' || metaDataArray[j]['metadata'] == 'roleEndDate' || metaDataArray[j]['metadata'] == 'demandCreationDate' || metaDataArray[j]['metadata'] == 'doj' || metaDataArray[j]['metadata']=='cloud' || metaDataArray[j]['metadata']=='clientInterview'){
        data=isNaN(Date.parse(demandAnalytics[i][metaDataArray[j]['metadata']])) ?'NA':dateFormat(demandAnalytics[i][metaDataArray[j]['metadata']]);
      }
      instanceArray.push(data);
    }



    
    multidata.push(instanceArray);
    console.log("-------------------");
    console.log(instanceArray);
    console.log("-------------------");
  }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Demand Analytics Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Demand Analytics Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
 console.log(fileBytes);
 var blob = new Blob([fileBytes],{type:'octet/stream'});
 var filename = "Demand Analytics Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
 if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
 } else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
}

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.FilterDownloadData = function (P_DemandBO, P_ClientBO, P_CapabBO, P_BUBO, P_skillGroupBO) {
    console.log('DemandBO'+JSON.stringify(P_DemandBO));
    console.log('Client'+JSON.stringify(P_ClientBO));
    console.log('Capability'+JSON.stringify(P_CapabBO));
    console.log('BusinessUnit'+JSON.stringify(P_BUBO));
    console.log('Skill'+JSON.stringify(P_skillGroupBO));
    var retPayload=P_DemandBO;

    if(P_ClientBO.length == 1)
    {
      retPayload=retPayload.filter(ele=>ele.client==P_ClientBO.id);
    }
    console.log("Payload"+JSON.stringify(retPayload));
    return retPayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uniqueClientName = function (data) {
    const uniqueClientNames = new Set();
  const result = [];

  data.forEach(item => {
    if (item.clientName !== null && !uniqueClientNames.has(item.clientName)) {
      uniqueClientNames.add(item.clientName);
      result.push({ clientName: item.clientName });
    }
  });

  return result;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.buildQuery = function (activeFlag, format, clientName, sectorName, status, globalPractice, skillGroupName,teamRequestNumber,demandType) {

   
    let query = "activeFlag='" + activeFlag + "'";

    if (clientName !== undefined && clientName !== null && clientName !== '') {
        query += " and clientObject.clientName = '" + clientName + "'";
    }

    if (sectorName !== undefined && sectorName !== null && sectorName !== '') {
        query += " and sector = '" + sectorName + "'";
    }

    if (status !== undefined && status !== null && status !== '') {
        query += " and status LIKE '%" + status + "%'";
    }

    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPracticeObject.name LIKE '%" + globalPractice + "%'";
    }

    if (skillGroupName !== undefined && skillGroupName !== null && skillGroupName !== '') {
        query += " and skillGroupObject.skillGroupName LIKE '%" + skillGroupName + "%'";
    }

    if (teamRequestNumber !== undefined && teamRequestNumber !== null && teamRequestNumber !== '') {
        query += " and teamRequestNumber = '" + teamRequestNumber + "'";
    }

    if (demandType !== undefined && demandType !== null && demandType !== '') {
     query += " and demandType = '" + demandType + "'";
    }


    return query;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.dialogTitle = function (data) {

    let name;
    let client=(data[0].clientObject.items[0].clientName).substring(0, 25);
    let demand ;

    if ((data[0].demandType).endsWith("Project")) {
    
    demand= (data[0].demandType).slice(0, -"Project".length).trim();
  } else {
   demand=(data[0].demandType);
  }

    name=data[0].teamRequestNumber+' : '+data[0].globalPracticeObject.items[0].name+'-'+data[0].skillGroupObject.items[0].skillGroupName+' ('+data[0].localGrade+') '+'['+data[0].sectorObject.items[0].name+'-'+client+'..., '+demand+']';
    return  name;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.benchSearchADP = function (P_Emp, P_Alloc,P_Skill,proposalBO,currentDemandBOID) {
     var retPayload = [];

 retPayload['internalb'] = [];
    retPayload['internalnb'] = [];


       for(var i=0; i<P_Emp.length; i++){
         let proposal=proposalBO.find(ele=>ele.employeeID==P_Emp[i].id);
      let alloc=P_Alloc.filter(ele=> ele.employee==P_Emp[i].id);
      let latestRecord = alloc.sort((a, b) => new Date(b.allocationEndDate) - new Date(a.allocationEndDate))[0];
      if(proposal!=undefined){
      if(proposal.status=='Allocated' || proposal.status=='Blocked/Client interview'){
        continue;
      }
       else if(currentDemandBOID==proposal.teamRquestNumber){
        continue;
      }
      }
      
      if(latestRecord != undefined){
        var availableDate = new Date(latestRecord.allocationEndDate);
        availableDate.setDate(availableDate.getDate() + 1); 

        var temp = {};
        temp['id'] = P_Emp[i].employeeID;
        temp['name'] = P_Emp[i].name;
        temp['grade'] = P_Emp[i].localGrade;
         temp['billable'] = (proposal?.status === 'Proposed') ? (P_Emp[i].billable + " (Proposed)") : P_Emp[i].billable;
       
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[i].globalPracticeObject.items[0].name;
        temp['skill'] = P_Emp[i].skillGroup1==null?'':P_Emp[i].skillGroup1Object.items[0].skillGroupName;
        // temp['type'] = P_Type;
        // temp['status'] = P_Emp[0].status;
         temp['BoID']=P_Emp[i].id;
          temp['status']=P_Emp[i].status;
      
      
        // temp['loc'] = P_Emp[0].locationObject.items[0].location;
        // temp['demandSupplyBOId']=P_demandSupplyId;
        // temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      
        
      
    var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

                if(days <= 30 && days >=0){
                temp['available'] = changeFormat(availableDate);
                retPayload['internalb'].push(temp);
             }
            
            else if(temp['status']==="Bench - Deployable"){
              temp['available'] = changeFormat(availableDate);
              retPayload['internalnb'].push(temp);
            }
      }
       }

retPayload.internalbCount = retPayload['internalb'].length;
retPayload.internalnbCount = retPayload['internalnb'].length;
       
    return retPayload;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.buildqueryforSearchBench = function (activeFlag, globalPractice, employeeID, name, localGrade, skillGroup) {
     let query = "activeFlag='Y'";

    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPractice='" + globalPractice + "'";
    }

    if (employeeID !== undefined && employeeID !== null && employeeID !== '') {
        query += " and employeeID='" + employeeID + "'";
    }

    if (name !== undefined && name !== null && name !== '') {
        query += " and id='" + name + "'";
    }

    if (localGrade !== undefined && localGrade !== null && localGrade !== '') {
        query += " and localGrade='" + localGrade + "'";
    }

    if (skillGroup !== undefined && skillGroup !== null && skillGroup !== '' && skillGroup !== 'All Skills') {
        query += " and skillGroup1='" + skillGroup + "'";
    }

    return query;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.skillGroupQuery = function (arg1) {
    let query;
    // query=
  };

   PageModule.prototype.checkBox = function (arg1,data) {
    // let data=[];
    if(data.includes(arg1)){
      data = data.filter(item => item !== arg1);
    }
    else{
      data.push(arg1);
    }
    return data;
  };
PageModule.prototype.areDifferent = function(oldValue, newValue) {
    if(JSON.stringify(newValue) === JSON.stringify(oldValue))
    return false
    else 
    return true;
  };

  PageModule.prototype.isFormValid = function(detail, event) {
    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      return true;
    }
    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
    let table = event.target;
    let editables = table.querySelectorAll('.editable');
    for (let i = 0; i < editables.length; i++) {
      let editable = editables.item(i);
      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        return false;
      }
    }
    return true;
  };



PageModule.prototype.proposedADP = function (emp, array, capb, skillg, proposalBO) {
    let data = [];
    let data1 = [];
    
    // Preprocessing for faster lookup
    const empMap = new Map(emp.map(e => [e.id, e]));
    const skillgMap = new Map(skillg.map(s => [s.id, s.skillGroupName]));
    const capbMap = new Map(capb.map(c => [c.id, c.name]));

    for (let i = 0; i < proposalBO.length; i++) {
        const proposal = proposalBO[i];
        const a = empMap.get(proposal.employeeID);
        if (!a) continue; // Skip if employee not found

        const skillgrp1 = skillgMap.get(a.skillGroup1) || '';
        const skillgrp2 = skillgMap.get(a.skillGroup2) || '';
        const skillgrp3 = skillgMap.get(a.skillGroup3) || '';
        const capaba = capbMap.get(a.globalPractice) || '';

        const retpayload = {
            employeeID: a.employeeID,
             BoID: a.id,
            name: a.name,
            capability: capaba,
            skillGroup1: skillgrp1,
            skillGroup2: skillgrp2,
            skillGroup3: skillgrp3,
            allocationEndDate: proposal.allocationEndDate,
            allocationStartDate: proposal.allocationStartDate,
            lockEndDate: proposal.lockEndDate,
            loctType: proposal.loctType,
            nBDCode: proposal.nBDCode,
            proposalDate: proposal.proposalDate,
            rejectionNote: proposal.rejectionNote,
            rejectionReason: proposal.rejectionReason,
            status: proposal.status,
            teamRquestNumber: proposal.teamRquestNumber,
            id: proposal.id,
            grade: a.localGrade,
            projectCode: proposal.projectCode,
            remarks: proposal.remarks
        };

        if (proposal.status === "Proposed" || proposal.status === "Blocked/Client interview" || proposal.status === "NBD Block Expired") {
            data.push(retpayload);
        } else {
            data1.push(retpayload);
        }
    }
    
    console.log('data', data);
    return { data, data1 };
};




// PageModule.prototype.proposedADP = function (emp,array,capb,skillg,proposalBO) {
//     let data=[];
//     let data1=[];
//     for(let i=0; i<proposalBO.length; i++){
//       let a=emp.find(ele=> ele.id==proposalBO[i].employeeID);
//       let skillgrp1 = skillg.find (ele=> ele.id==a.skillGroup1);
//        let skillgrp2 = skillg.find (ele=> ele.id==a.skillGroup2);
//         let skillgrp3 = skillg.find (ele=> ele.id==a.skillGroup3);
//          let capaba = capb.find (ele=> ele.id==a.globalPractice);
//          if(proposalBO[i].status=="Proposed" || proposalBO[i].status=="Blocked/Client interview" || proposalBO[i].status=="NBD Block Expired"){
//             let retpayload={};
//       retpayload['employeeID']=a.employeeID;
//       retpayload['name']=a.name;
//       // retpayload['sector']=a.sectorObject.items[0].name;
//       retpayload['capability']=capaba.name;
//       retpayload['skillGroup1']=skillgrp1==undefined ? '':skillgrp1.skillGroupName;
//       retpayload['skillGroup2']=skillgrp2==undefined? '':skillgrp2.skillGroupName ;
//       retpayload['skillGroup3']=skillgrp3==undefined?'':skillgrp3.skillGroupName;
//         // retpayload['allocationenddate']=a.empProjectAllocationBOC.items[0].allocationEndDate;  
//         retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
//          retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
//           retpayload['lockEndDate']=proposalBO[i].lockEndDate;
//            retpayload['loctType']=proposalBO[i].loctType;
//             retpayload['nBDCode']=proposalBO[i].nBDCode;
//              retpayload['proposalDate']=proposalBO[i].proposalDate;
//               retpayload['rejectionNote']=proposalBO[i].rejectionNote;
//                retpayload['rejectionReason']=proposalBO[i].rejectionReason;
//                retpayload['status']=proposalBO[i].status;
//                retpayload['teamRquestNumber']=proposalBO[i].teamRquestNumber;
//                retpayload['proposalDate']=proposalBO[i].proposalDate;
//                retpayload['id']=proposalBO[i].id;
//                retpayload['grade']=a.localGrade;
//                 retpayload['projectCode']=proposalBO[i].projectCode;
//                  retpayload['remarks']=proposalBO[i].remarks;
//       data.push(retpayload);
//          }
//          else{
//             let retpayload={};
//       retpayload['employeeID']=a.employeeID;
//       retpayload['name']=a.name;
//       // retpayload['sector']=a.sectorObject.items[0].name;
//       retpayload['capability']=capaba.name;
//       retpayload['skillGroup1']=skillgrp1==undefined ? '':skillgrp1.skillGroupName;
//       retpayload['skillGroup2']=skillgrp2==undefined? '':skillgrp2.skillGroupName ;
//       retpayload['skillGroup3']=skillgrp3==undefined?'':skillgrp3.skillGroupName;
//         // retpayload['allocationenddate']=a.empProjectAllocationBOC.items[0].allocationEndDate;  
//         retpayload['allocationEndDate']=proposalBO[i].allocationEndDate;
//          retpayload['allocationStartDate']=proposalBO[i].allocationStartDate;
//           retpayload['lockEndDate']=proposalBO[i].lockEndDate;
//            retpayload['loctType']=proposalBO[i].loctType;
//             retpayload['nBDCode']=proposalBO[i].nBDCode;
//              retpayload['proposalDate']=proposalBO[i].proposalDate;
//               retpayload['rejectionNote']=proposalBO[i].rejectionNote;
//                retpayload['rejectionReason']=proposalBO[i].rejectionReason;
//                retpayload['status']=proposalBO[i].status;
//                retpayload['teamRquestNumber']=proposalBO[i].teamRquestNumber;
//                retpayload['proposalDate']=proposalBO[i].proposalDate;
//                retpayload['id']=proposalBO[i].id;
//                retpayload['grade']=a.localGrade;
//                  retpayload['projectCode']=proposalBO[i].projectCode;
//                  retpayload['remarks']=proposalBO[i].remarks;
              
//       data1.push(retpayload);
//          }
     
//     }
//     console.log('data',data);
//     return {data,data1};
//   };
PageModule.prototype.statusOptions = function (lockType) {
  let data1=[];
    let data={};

    if(lockType=="FIRM"){
      data['option']="Allocated";
      data1.push(data);
    }
    else if(lockType=="NBD"){
      let array=["Blocked/Client interview","NBD Block Expired","Rejected"];
      for(let i=0; i<array.length; i++){
         data['option']=array[i];
         data1.push(data);
      }
    }
    else if(lockType=="MP"){
      let array=["Proposed","Rejected","Allocated to alternate demand"];
      for(let i=0; i<array.length; i++){
         data['option']=array[i];
         data1.push(data);
      }
    }
    return data1;
}

function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
        }

  function dateFormat (bo_date){
    const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var date = new Date(bo_date);
    var reqd_date = (date.getDate()<10?'0'+date.getDate():''+date.getDate())+'-'+months[date.getMonth()]+'-'+date.getFullYear();
    return reqd_date;
  }


PageModule.prototype.dialogTitleforRadioset= function (data) {

    let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.id+' : '+data.name+' ('+data.grade+') '+'['+data.capab+']';
    return  name;
  };

PageModule.prototype.Dateset= function() {
      var rollOfDate = new Date();
      var currentDate = new Date();
      //setting the rollof date to 30 days from current date
      rollOfDate.setDate(currentDate.getDate()+30);
      return rollOfDate;
    };  

  PageModule.prototype.getCurrentYear = function () {
    let date = new Date().toISOString().split('T')[0];
    let currentYr = new Date(date).getFullYear();
    console.log('@@currYr',currentYr);
    return currentYr;
 
  };

 PageModule.prototype.createEmployeeSkillArray1=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     let empSkillArray=new Array(); 

    for(let index=0;index<empSkillBO.length;index++){

     let skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
     if(skillObject){
      let skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      if(skillGroupObject){
      let capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      let empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}'
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
     }

     }



    }
    
return empSkillArray;

  };


 PageModule.prototype.q = function (current) {
     let query="status='ADMIN APPROVED' AND (coAuthor ='"+current+"' OR author ='"+current+"' OR coAuthor2 ='"+current+"'OR coAuthor3 ='"+current+"')";
    return query;
  };


PageModule.prototype.assignCommunitywithSkillGroup = function (P_Emp) {
     var retpayload = {};

    if(P_Emp.globalPractice != null){
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  };


 PageModule.prototype.getDefaultedMonth=function(tcBO){

  let data = [];
  let currentYear = (new Date()).getFullYear();
  let def = tcBO.filter(ele => ele.defaultedYear == currentYear);
  let retpayload = {};
  retpayload['month'] = "Year : " + currentYear;
  let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  for (let i = 0; i < months.length; i++) {
    let month = months[i].toLowerCase().substring(0, 3);
    if (i < (new Date()).getMonth()+1) {
      retpayload[month] = def.find(ele => ele.defaultedMonth == months[i]) == undefined ? 'N' : def.find(ele => ele.initialFlag == 'Issue') ? 'N' : 'Y';
    } else {
      retpayload[month] = '-';
    }
  }
  data.push(retpayload);
  return data;
};
  
 PageModule.prototype.totalCrediHrsFunction = function (T_main) {
    let totalcredithrs = 0;
    let totalcreditHrs;
    let credithrs;
    if(T_main.length == 0){
      totalcreditHrs = '0 hrs';
    }
    else{
      for (let i = 0;i<T_main.length;i++){
        credithrs=T_main[i].creditHrs;
       totalcredithrs += Number(credithrs);

      }
      totalcreditHrs = totalcredithrs.toFixed(2) + ' hrs';
    }
        
   return totalcreditHrs;
  };



   PageModule.prototype.postAllData = function (E_cyl,E_mas,E_main) {

 let data = [];
     for(let i=0; i<E_main.length;i++){

       let retpayload = {};

       let ele=E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO);

       retpayload ['awardName']= E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO).awardName;

        retpayload ['yearMonth']= E_main[i].yearMonth;

        retpayload['rRType']=E_mas.find(recele =>recele.id == ele.recognisationMasterBO).rRType;

        data.push(retpayload);

     }

     console.log(">>",data);

    return data;

  };

   PageModule.prototype.getEmpProjAllocationData = function (P_EmpProjAllocBO,P_ClientBO,P_ProjectBO) {
    console.log('##1717',P_EmpProjAllocBO);
    let data = [];
       
    for(let i=0; i<P_EmpProjAllocBO.length; i++){
      let retpayload = {};
      let cliele = P_ClientBO.find(cliele => cliele.id == P_EmpProjAllocBO[i].client);
      let projele = P_ProjectBO.find(projele => projele.id == P_EmpProjAllocBO[i].project);
      
    if(P_EmpProjAllocBO[i].allocationEndDate == "2000-01-01" ){
      console.log('##12true');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = '';
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    else{
      console.log('##11false');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = P_EmpProjAllocBO[i].allocationEndDate;
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    console.log('##24',retpayload);    
    }
    return(data);
  };


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.batchProposal = function (dataBO,BOName,operation) {
      var batchProcessingVariableArray = new Array();
      for (var i = 0; i < dataBO.length; i++) {
      
      var data = '{"id": "part' + i + '","path": "/' + BOName + '/'+dataBO[i].id +'","operation": "' + operation + '","payload":{"status":"'+dataBO[i].status+'","loctType":"'+dataBO[i].loctType+'","proposalDate":"'+dataBO[i].proposalDate+'","lockEndDate":"'+dataBO[i].lockEndDate+'","allocationStartDate":"'+dataBO[i].allocationStartDate+'","allocationEndDate":"'+dataBO[i].allocationEndDate+'","nBDCode":"'+dataBO[i].nBDCode+'","rejectionReason":"'+dataBO[i].rejectionReason+'","rejectionNote":"'+dataBO[i].rejectionNote+'"}}';
        
      batchProcessingVariableArray.push(data);


    }
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.todayyy = function () {
    // Create a new Date object
var currentDate = new Date();
 
// Get the current date components
var year = currentDate.getFullYear();
var month = currentDate.getMonth() + 1; // Months are zero-based, so add 1
var day = currentDate.getDate();
 
// Format the date as a string (you can customize the format as needed)
var formattedDate = year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
 
console.log("Current Date: " + formattedDate);
return formattedDate;
  };


  PageModule.prototype.VisaExpiryDateConvert=function(VisaDate) {
    if(VisaDate != null && VisaDate!= undefined && VisaDate != ''){
    let orgDate = VisaDate;
    let [day,mon,year]=orgDate.split('-');
    let updatedDate;
    if(mon == undefined){
      return day;
    }
    else{
    day = day<10?'0'+day:''+day;
    year='20'+year;
    updatedDate = day+'-'+mon+'-'+year;
    return updatedDate;
    }
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.dialogTitleForProposedAdp = function (data) {

     let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.employeeID+' : '+data.name+' ('+data.grade+') '+'['+data.capability+']';
    return  name;
  };
  return PageModule;
});