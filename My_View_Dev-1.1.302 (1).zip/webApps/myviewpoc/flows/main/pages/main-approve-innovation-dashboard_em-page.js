define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    emTableAdp(empBO, innoBO, buBO) {
      var data=[];
       
        // var empNames=[];   
    
       for (var i=0;i<innoBO.length;i++)
           {
              
              var retpayload={}; 
            
              var  empNames = empBO.find(ele=>ele.id ==innoBO[i].eMEmailID);
              var emProposed = innoBO.filter(ele => ele.eMEmailID == innoBO[i].eMEmailID && ele.status == 'PROPOSED');
                var emImple = innoBO.filter(ele => ele.eMEmailID == innoBO[i].eMEmailID && ele.status == 'EM APPROVAL REQUESTED');
                var sect = empNames!= undefined ? (buBO.find(ele => ele.id == empNames.bu)) : undefined;
            // var  emProposed  =(innoBO.filter(ele=>ele.eMEmailID==completedata[i].eMEmailID && ele.status==(completedata[i].status)== 'PROPOSED'));

              // const arrayUniqueByKey = [...new Map(data.map(item =>  [item['emName'], item])).values()];
              if (empNames==undefined && sect==undefined ){
                continue;
              }
               retpayload['sector'] = sect!= undefined? sect.name: '';
              retpayload['emName']=empNames!= undefined? empNames.name:'';
              retpayload['approvalPendingProposedIdea']=emProposed.length;
               retpayload['approvalPendingImplementedIdea']=emImple.length;
              
              data.push(retpayload);
               
           }
        
          console.log("164",data); 
          console.log("Length for first data",data.length);     


   // sorting of tabledata
     data.sort((a, b) => {let fa = a.sector,fb = b.sector; 
      if (fa < fb) 
      {
        return -1;
        } 
      else if (fa > fb) 
      {
        return 1;
        } 
      return 0; 
      }); 

      return data;
  }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    dataHide2(previousData) {

     console.log("135", previousData.length, JSON.stringify(previousData));
      var payload2=[];
      var temp=[];
      for (var i=0;i<previousData.length;i++)
      {    
           if (temp!=undefined ? temp.filter(Element=>Element.sector==previousData[i].sector).length==0 : true)
           {
           var tempD={};
           tempD['sector']=previousData[i].sector;
        
           
           var data=[];
           data=previousData.filter(Element=>Element.sector==tempD.sector);


           console.log("test1", JSON.stringify(data[0]));
           payload2.push(data[0]);
           
           temp.push(tempD);

for (var j = 0; j < data.length; j++) {
  // Check if emName already exists in payload2
  var existingEmNames = payload2.map(item => item.emName);
  if (existingEmNames.includes(data[j].emName)) {
    continue; // Skip iteration if emName already exists
  }

  var retpayload = {};
  retpayload['sector'] = '';
  retpayload['emName'] = data[j].emName;
  retpayload['approvalPendingProposedIdea'] = data[j].approvalPendingProposedIdea;
  retpayload['approvalPendingImplementedIdea'] = data[j].approvalPendingImplementedIdea;

  payload2.push(retpayload);
}
        }
      }
          console.log("164", JSON.stringify(payload2));          
          return payload2;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    muTableAdp(innoBO, empBO , buBO) {

        var data=[];
    
       for (var i=0;i<innoBO.length;i++)
           {
              var retpayload={}; 
              var  muName = empBO.find((ele)=>ele.id ==innoBO[i].muSpoc);
               var  muproposed = innoBO.filter(ele => ele.muSpoc == innoBO[i].muSpoc && ele.status == 'PROPOSED');
                var  muImple = innoBO.filter(ele => ele.muSpoc == innoBO[i].muSpoc && ele.status == 'MU SPOC APPROVAL REQUESTED');  
                var sectorr = muName!= undefined ? (buBO.find(ele => ele.id == muName.bu)) : '';

                 if (typeof innoBO[i].muSpoc !== 'undefined' && muName && typeof muName.name !== 'undefined') {
                 retpayload['muSpoc'] = muName!=undefined? muName.name:'';
                   retpayload['sector'] = sectorr!= undefined? sectorr.name: '';
                //  retpayload['approvalPendingProposedIdea']=muproposed.length;
               retpayload['approvalPendingImplementedIdea']=muImple.length;
            
              data.push(retpayload);
                 }
           }
        
          console.log("164444",data); 
          console.log("Length for mu data",data.length);  

           // sorting of tabledata
     data.sort((a, b) => {let fa = a.sector,fb = b.sector; 
      if (fa < fb) 
      {
        return -1;
        } 
      else if (fa > fb) 
      {
        return 1;
        } 
      return 0; 
      }); 

          return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    dataHideMU(previousData) {

  //          var payload2 = [];
  // var temp = [];
  
  // for (var i = 0; i < previousData.length; i++) {
  //   if (!temp.some(element => element.muSpoc === previousData[i].muSpoc)) {
  //     var tempD = {};
  //     tempD['muSpoc'] = previousData[i].muSpoc;
  //     payload2.push(previousData[i]);
  //     temp.push(tempD);
  //   }
  // }
  //  console.log("16444",payload2);
  //  console.log("Length:", payload2.length);

  // return payload2;

   console.log("135", previousData.length, JSON.stringify(previousData));
      var payload2=[];
      var temp=[];
      for (var i=0;i<previousData.length;i++)
      {    
           if (temp!=undefined ? temp.filter(Element=>Element.sector==previousData[i].sector).length==0 : true)
           {
           var tempD={};
           tempD['sector']=previousData[i].sector;
        
           
           var data=[];
           data=previousData.filter(Element=>Element.sector==tempD.sector);


           console.log("test1", JSON.stringify(data[0]));
           payload2.push(data[0]);
           
           temp.push(tempD);

for (var j = 0; j < data.length; j++) {
  // Check if muName already exists in payload2
  var existingmuNames = payload2.map(item => item.muSpoc);
  if (existingmuNames.includes(data[j].muSpoc)) {
    continue; // Skip iteration if muName already exists
  }

  var retpayload = {};
  retpayload['sector'] = '';
  retpayload['muSpoc'] = data[j].muSpoc;
  retpayload['approvalPendingProposedIdea'] = data[j].approvalPendingProposedIdea;
  retpayload['approvalPendingImplementedIdea'] = data[j].approvalPendingImplementedIdea;

  payload2.push(retpayload);
}

        }

      }
          console.log("164", JSON.stringify(payload2));          
          return payload2;
    }
    
    

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getDetailsforEM(innoBO1, empBO, ideaNameBO) {
       
       var data =[];
       for (var i=0;i<innoBO1.length;i++)
           {
              var retpayload={}; 
                   var  empNames = empBO.find(ele=>ele.id ==innoBO1[i].eMEmailID);
                        var   empName = ideaNameBO.find((ele)=>ele.id ==innoBO1[i].ideaGeneratorEmpID);  

                 retpayload['name'] =empNames.name;
                 retpayload['ideaName'] =innoBO1[i].ideaName;
                 retpayload['ideaGeneratorEmpID'] =empName.name;
                 retpayload['ideaGenerationDate'] =innoBO1[i].ideaGenerationDate;
                       
              data.push(retpayload);                
           }
        
          console.log("164444",data); 
          console.log("Length for mu data",data.length);          
          return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    consoleValues(emname, statuss) {
      console.log('enNamevalue',emname);
      console.log('statusvalue',statuss);

    }


     getDetailsforMu(innoBO1, empBO, ideaNameBO11) {
       var data =[];
       for (var i = 0; i < innoBO1.length; i++) {
        var retpayload = {};
        var muName = empBO.find((ele) => ele.id == innoBO1[i].muSpoc);
        var muproposed = innoBO1.filter(ele => ele.muSpoc == innoBO1[i].muSpoc && ele.status == 'PROPOSED');
        var empNameidea = ideaNameBO11.find((ele) => ele.id == innoBO1[i].ideaGeneratorEmpID);

        retpayload['name'] = muName.name;
        retpayload['ideaName'] = innoBO1[i].ideaName;
        retpayload['ideaGeneratorEmpID'] = empNameidea.name;
        retpayload['ideaGenerationDate'] = innoBO1[i].ideaGenerationDate;

        data.push(retpayload);
    }

    console.log("164444", data);
    console.log("164444mu", muproposed);
    console.log("Length for mu data", data.length);
    return data;
     }

  }
  return PageModule;
});
