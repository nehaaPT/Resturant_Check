define([], () => {
  'use strict';
let PageModule = function PageModule() {};

 PageModule.prototype.table = function (assignCertBO) {
          var data =[];
    
    for(var i = 0; i<assignCertBO.length; i++) {

      var retpayload = {};
      var emp = assignCertBO[i].employeeID;
      var empid = emp.id;    
      retpayload['id']=assignCertBO[i].id;
      retpayload['certificationCode'] = assignCertBO[i].certificationCode!=null?assignCertBO[i].certificationCode:'';
      retpayload['certificationName'] = assignCertBO[i].certificationName!=null?assignCertBO[i].certificationName:'';
      retpayload['status'] = assignCertBO[i].empstatus!=null?assignCertBO[i].empstatus:'';
      retpayload['examDate'] = assignCertBO[i].examdate!=null?assignCertBO[i].examDate:'';
  data.push(retpayload);
    }
    return data;
 };

 PageModule.prototype.constructEmailNotification=function(employeeId, empData, certDetails) {
  console.log("##",employeeId);
       let employee = empData.find(element => element.id == employeeId);
       let employeeEmail = employee ? employee.email : "";
    let employeeName = employee ? employee.name : "";
    
     let certName = certDetails[0].certificationName != null ? certDetails[0].certificationName : "-";
     let exam = certDetails[0].examDate != null ? certDetails[0].examDate : "-";
    

    var subject = "Ready to attempt the Certification & Request for Exam Voucher";

    // var emailBody = "";
    // emailBody += "Dear " + employeeName + ",\n\n";
    // emailBody += "I trust this message finds you well. As part of our ongoing commitment to fostering continuous learning and professional development, we are excited to offer you an opportunity to enhance your skills and knowledge through an upskilling training program.\n\n";
    // emailBody += "Training Program Details:\n";
    // emailBody += "Course Title: " + trainName + "\n";
    // emailBody += "Training Portal Link: " + trainingDetails[0].portalLink + "\n";
    // emailBody += "Duration: " + trainingDetails[0].startDate + " to " + trainingDetails[0].endDate + "\n";
    // emailBody += "Remarks: " + remarks + "\n\n";
    // emailBody += "Make sure to complete the trainings by the end date mentioned.\n\n";
    // emailBody += "Next Steps: Once the Training is complete, go to MyView & change the status to complete. Do Note once confirmed a confirmation email will be sent to the competency & capability confirming on the final status.\n\n";
    // emailBody += "Thank you for your dedication and commitment to excellence. We look forward to supporting you on this exciting journey of growth and learning.\n\n";
    // emailBody += "Best regards,\nCompetency Team.\n\n";
    // emailBody += "[For Queries reach out to Ambika Bhosle / Bindu Yedla]";

    return {
        Subject: subject,
        // MailBody: emailBody,
        name: employeeName,
        email: employeeEmail,
        cName:certName,
        edate:exam
    };
    };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  function changeFormat(currentDate) {
    try {

     let now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);

    }
    catch (err) {
      // console.log('#131'+currentDate);
      return currentDate;
    }
  }

PageModule.prototype.batchProcessing = function (BOName, operation, dataBO, certBO) {
  let batchProcessingVariableArray = [];

  for (let index = 0; index < dataBO.length; index++) {
    let cert = certBO.find(ele => ele.certificationName === dataBO[index].certificationName);

    let today = new Date();
    let data = {
       "id": "part" + index,
                "path": "/" + BOName + "/",
                "operation": operation,
     "payload": {
       "status": "CL_Approved",
        "certification": cert ? cert.id : null,
        "employeeId": dataBO[index].employeeID || null, 
        "examPlannedDate": dataBO[index].examDate || null, 
        "cLActionDate": changeFormat(today),
        "certificationRequestDate": changeFormat(today),
        "capability":dataBO[index].capability,
        "remark":"CL already approved"
      }
    };

    batchProcessingVariableArray.push(data);
  } 

    return { parts: batchProcessingVariableArray };

};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.calculateDate = function () {
   var currentDate = new Date();
    var futureDate = new Date();
    // Increase the number of days -- 10 days in this example
    futureDate.setDate( currentDate.getDate() + 90 );
    return futureDate;
  };


  
  return PageModule;
});
