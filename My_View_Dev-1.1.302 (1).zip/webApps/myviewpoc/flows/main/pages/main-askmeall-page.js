define([], () => {
  'use strict';

   class PageModule {
  }
   PageModule.prototype.getAgeing=function(created){
    
    var day;
    var created1=new Date(created);
    var curr = new Date();
    var difference= Math.abs(created1 - curr);
    var days = difference/(1000 * 3600 * 24);
    day = Math.floor(days);

    return day;
   }
  
  return PageModule;
});
