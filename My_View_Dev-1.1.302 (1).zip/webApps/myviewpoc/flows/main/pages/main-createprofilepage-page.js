define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  function changeFormat(currentDate) {
    try{
   
      var now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
   
    }
    catch(err){
      // console.log('#131'+currentDate);
      return currentDate;
    }
  };

  PageModule.prototype.generateProfileID = function(P_ProfileID,profileDataPayload){
    var temp;
    if(P_ProfileID < 20000){
      temp = 20000;
    }
    else{
      temp = P_ProfileID+1;
    }
    profileDataPayload.profileID = temp;
    return profileDataPayload;
  };


  PageModule.prototype.validateData = function(P_ProfileDataObject){
    var retPayload = {};
    retPayload['profileData'] = {};
    if((P_ProfileDataObject.capability == null) || (P_ProfileDataObject.skillGroup1 == null) || (P_ProfileDataObject.source == null)){
      retPayload.status = 0;
    }
    else if((P_ProfileDataObject.email == null) && (P_ProfileDataObject.phoneNumber == null)){
      retPayload.status = 1;
    }
    else{
      var today = changeFormat(new Date());
      P_ProfileDataObject.profileReceived = today;
      P_ProfileDataObject.profileSentToCapability = today;
      if(P_ProfileDataObject.status == '2. Awaiting Selection Decision (CAPABILITY)'){
        P_ProfileDataObject.stageOfRejection = null;
      }
      else if(P_ProfileDataObject.status == '7.1 Rejected - Screening'){
        P_ProfileDataObject.stageOfRejection = 'Rejected Screening';
      }
      P_ProfileDataObject.skillGroup2 = P_ProfileDataObject.skillGroup2 ? P_ProfileDataObject.skillGroup2 : null;
      // P_ProfileDataObject.activeFlag = 'Y';

      retPayload['profileData'] = P_ProfileDataObject;
      retPayload['status'] = 2;
    }

    console.log(retPayload);
    return retPayload;
  };


  PageModule.prototype.getData=function(payload){
    console.log('#64'+JSON.stringify(payload));
  };

  PageModule.prototype.extractFileData=function(fileObj){
    var retPayload = [];
    console.log('123'+fileObj[0]);
    var form = new FormData();
    form.append('file',fileObj[0],fileObj[0].name);
    //form.append('json','{"filename":"_Resume", "profile_id" : "'+profileId+'"}');
    console.log('@3'+JSON.stringify(form));
    retPayload['file'] = form;
    retPayload['fileName'] = fileObj[0].name;
    
    return retPayload;
  };
  PageModule.prototype.createPayLoad=function(P_FileObj,P_ProfileId){
    P_FileObj.append('json','{"filename": "'+P_ProfileId+'_Resume.xlsx"}');
    return P_FileObj;
  };
  
  PageModule.prototype.demo=function(P_Arg){
    console.log(P_Arg);
  };
  
  return PageModule;
});
