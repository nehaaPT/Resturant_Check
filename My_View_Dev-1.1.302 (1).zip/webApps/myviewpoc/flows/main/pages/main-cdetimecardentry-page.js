define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.getCurrentYear = function () {
    var date2 = new Date();
     const date = date2.getFullYear();
     console.log("!!!",date);
     return date;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.validateInput = function (month,year) {
    let x=new Date();
    let test = new Date();
    test.setDate(0);test.setDate(0);test.setDate(0);
    let test2=new Date(test.getFullYear(), test.getMonth(), 1);
    let validDate= `${test2.getFullYear()}-${ test2.getMonth()<9?'0'+(test2.getMonth()+1):''+(test2.getMonth()+1)}-${test2.getDate()<10?'0'+test2.getDate():test2.getDate()}`;
    let lastDay = new Date(x.getFullYear(), x.getMonth() + 4, 0);
    let currentDate = `${lastDay.getFullYear()}-${ lastDay.getMonth()<9?'0'+(lastDay.getMonth()+1):''+(lastDay.getMonth()+1)}-${lastDay.getDate()<10?'0'+lastDay.getDate():lastDay.getDate()}`;
    let firstDay = new Date(Number(year), Number(month), 1);
    let speacifiedDate = `${firstDay.getFullYear()}-${ firstDay.getMonth()<9?'0'+(firstDay.getMonth()+1):''+(firstDay.getMonth()+1)}-${firstDay.getDate()<10?'0'+firstDay.getDate():firstDay.getDate()}`;
    if(speacifiedDate<=currentDate && speacifiedDate >= validDate){
      return true;
    }
    else{
      return false;
    }
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.validateEdit = function (weekEnding) {
    let x=new Date();
   
    let firstDay=new Date(x.getFullYear(), x.getMonth(), 1);
    let firstDate= `${firstDay.getFullYear()}-${ firstDay.getMonth()<9?'0'+(firstDay.getMonth()+1):''+(firstDay.getMonth()+1)}-${firstDay.getDate()<10?'0'+firstDay.getDate():firstDay.getDate()}`;
    let lastDay = new Date(x.getFullYear(), x.getMonth() + 1, 0);
    let lastDate = `${lastDay.getFullYear()}-${ lastDay.getMonth()<9?'0'+(lastDay.getMonth()+1):''+(lastDay.getMonth()+1)}-${lastDay.getDate()<10?'0'+lastDay.getDate():lastDay.getDate()}`;
    let specifiedDay = new Date(weekEnding);
    let speacifiedDate = `${specifiedDay.getFullYear()}-${ specifiedDay.getMonth()<9?'0'+(specifiedDay.getMonth()+1):''+(specifiedDay.getMonth()+1)}-${specifiedDay.getDate()<10?'0'+specifiedDay.getDate():specifiedDay.getDate()}`;
    if(speacifiedDate<=lastDate && speacifiedDate >= firstDate){
      return true;
    }
    else{
      return false;
    }
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.getCurrentMonth = function () {
    let mainarray=[];
    var date2 = new Date();
    var innerArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
     const month = date2.getMonth();
     let initial=(Number(month)-3)<0?0:Number(month)-3,current=Number(month);
     let monthAdp=[];

     for(let a=0;a<=current;a++){
       let retpayload = {};
         retpayload['month']=innerArray[a];
         retpayload['id']=a;
           monthAdp.push(retpayload);
     }
     const NegArray=innerArray.slice((Number(month)-3));
     for(let i=0;i<NegArray.length;i++){
       let retpayload = {};
         retpayload['month']=NegArray[i];
         retpayload['id']=innerArray.indexOf(NegArray[i]);
           monthAdp.push(retpayload);
     }
     mainarray.push(monthAdp);
     mainarray.push(month);

     const year = date2.getFullYear();
     let YearAdp=[];
    if(month<3){
      let retpayload2 = {};
         retpayload2['month']=year;
         retpayload2['id']=year;
           YearAdp.push(retpayload2);
      let retpayload3 = {};
         retpayload3['month']=Number(year)-1;
         retpayload3['id']=Number(year)-1;
           YearAdp.push(retpayload3);
    }
    else{
      let retpayload2 = {};
         retpayload2['month']=year;
         retpayload2['id']=year;
           YearAdp.push(retpayload2);
    }
     mainarray.push(year);
     mainarray.push(YearAdp);
     
     return mainarray;
  };
  PageModule.prototype.getYears = function () {
    var returnArray = [];
    for(var i = (new Date().getFullYear())-1; i < (new Date().getFullYear())+1; i++) {
      var innerObj = {};
      innerObj['year'] = i;
        returnArray.push(innerObj);
    }
    console.log("!!!",returnArray);
    return returnArray;
  };

  PageModule.prototype.getMonths = function () {
    var returnArray = [];
    var innerArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    for(var i = (new Date().getDate())-2; i < (new Date().getDate())+2; i++) {
      var innerObj = {};
      switch (i){
        case -1: i=11; break;
        case -2: i=10; break;
        case +12: i=0; break;
        case +13: i=1; break;
      }
        innerObj['month'] = innerArray[i];
        returnArray.push(innerObj);
    }
    console.log("!!!",returnArray);
    return returnArray;
  };

//  function endFirstWeek(firstDate, firstDay) {
//     if (! firstDay) {
//         return 7 - firstDate.getDay();
//     }
//     if (firstDate.getDay() < firstDay) {
//         return firstDay - firstDate.getDay();
//     } else {
//         return 7 - firstDate.getDay() + firstDay;
//     }
// }

// PageModule.prototype.getWeeksStartAndEndInMonth = function(month, year, start) {
//     let weeks = [],
//         firstDate = new Date(year, month, 1),
//         lastDate = new Date(year, month + 1, 0),
//         numDays = lastDate.getDate();

//     let start = 1;
//     let end = endFirstWeek(firstDate, 2);
//     while (start <= numDays) {
//         weeks.push({start: start, end: end});
//         start = end + 1;
//         end = end + 7;
//         end = start === 1 && end === 8 ? 1 : end;
//         if (end > numDays) {
//             end = numDays;
//         }
//     }
//     return weeks;"field": "errorDetails"
// };

  PageModule.prototype.returnValue = function (arg1) {
    console.log("!!!",arg1);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  PageModule.prototype.Dialog = function (date) {
    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    let count=1;
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
        //  innerObj['day'+count] = date5;
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }

      }
    }}
    // innerArray.push(innerObj);
    return innerArray.length;
  };

  PageModule.prototype.createTableColumns = function (date) {
    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
       
      }
    }}
    
    innerArray=innerArray.reverse();
    
    // let array=[];
    // for(let i = innerArray.length; i > 0; i--){
    // let obj={};
    // obj["Category"]=''
    // }
    

    let innerString = '';
    innerString = innerString + '[{' + '"headerText":' + '"Category",' + '"field":' + '"category",'+'"template":'+'"Category",'+'"width":'+'"200"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Project Code/NBD Code",' + '"field":' + '"projectDetails",'+'"template":'+'"Project",'+'"width":'+'"120"' + '},';
   
                              
    for(let i = 1; i <= innerArray.length; i++) {
      if(i === innerArray.length) {
        innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: center;",' + '"field":' + '"day'+i+'",'+'"template":'+'"day'+i+'",'+'"width":'+'"130"' + '},';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: center;",' + '"field":' + '"day'+i+'",'+'"template":'+'"day'+i+'",'+'"width":'+'"130"' + '},';
    }
    innerString = innerString + '{' + '"headerText":' + '"Comments",' + '"field":' + '"comment1",'+'"template":'+'"Comments",'+'"width":'+'"80"' + '}]';
    //  innerString = innerString + '{' + '"headerText":' + '"",' + '"field":' + '"",'+'"template":'+'"AddProject",'+'"width":'+'"60"' + '}]';
    // innerString = innerString + ']';
    console.log("!!!",JSON.parse(innerString));
    let returnarray=[];
    returnarray.push(JSON.parse(innerString));
    returnarray.push(innerArray);
    return returnarray;
  };

  

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  PageModule.prototype.timeTrackColumns = function (Bodata,month,year) {
    var returnArray = [];
    var innerObj = {};
    var date = new Date(), y = Number(year), m = Number(month);
    var firstDay = new Date(y, m, 1);
    var lastDay = new Date(y, m + 1, 0);

    let day = firstDay.getDay();
    let count=7-Number(day);
    let baseDate;
    
    const date1 = new Date(firstDay);
    date1.setDate(firstDay.getDate()+(Number(count)-1));
    baseDate=date1;
    const options = { day: '2-digit', month: 'short', year: 'numeric' };
    const formattedDate = date1.toLocaleDateString('en-US', options);
    
    
    innerObj['timecard'] = "NEW";
    innerObj['weekEnding'] = formattedDate;
    innerObj['hrs']= '';
    innerObj['status']='Pending';
    returnArray.push(innerObj);

      let week=7;
      baseDate.setDate(baseDate.getDate()+7);

    for(let i=baseDate;i.getMonth()===m;i.setDate(baseDate.getDate()+Number(week))){
      let innerObj1 = {};
      const date2 = new Date(i);
    const formattedDate1 = date2.toLocaleDateString('en-US', options);

    innerObj1['timecard'] = "NEW";
    innerObj1['weekEnding'] = formattedDate1;
    innerObj1['hrs']= '';
    innerObj1['status']='Pending';
    returnArray.push(innerObj1);
    
    }

    let innerObj2={};
    const date3 = new Date(lastDay);
    const formattedDate3 = date3.toLocaleDateString('en-US', options);
    

    innerObj2['timecard'] = "NEW";
    innerObj2['weekEnding'] = formattedDate3;
    innerObj2['hrs']= '';
    innerObj2['status']='Pending';
    returnArray.push(innerObj2);

    for(let a=0;a<returnArray.length;a++){
      let DataCheck=Bodata.filter(ele=>new Date(ele.weekEnding).getDate()===new Date(returnArray[a].weekEnding).getDate() && new Date(ele.weekEnding).getMonth()===new Date(returnArray[a].weekEnding).getMonth() && new Date(ele.weekEnding).getFullYear()===new Date(returnArray[a].weekEnding).getFullYear());
      if(DataCheck.length>0){
        let hrscount=0;
        for(let b=0; b< DataCheck.length; b++){
          hrscount+=Number(DataCheck[b].day1)+Number(DataCheck[b].day2)+Number(DataCheck[b].day3)+Number(DataCheck[b].day4)+Number(DataCheck[b].day5)+Number(DataCheck[b].day6)+Number(DataCheck[b].day7);
        }
        returnArray[a].weekEnding= new Date(DataCheck[0].weekEnding).toLocaleDateString('en-US', options);
        returnArray[a].timecard= 'Edit';
        returnArray[a].hrs=hrscount;
        returnArray[a].status='Submitted';
        
      }
    }

    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getDates = function (date) {
    // var innerArray =  ["01-Apr-2023","02-Apr-2023","03-Apr-2023","04-Apr-2023","05-Apr-2023","06-Apr-2023","07-Apr-2023"];
    var returndate = `${new Date(date).getFullYear()}-${(new Date(date).getMonth())<9?'0'+(new Date(date).getMonth()+1):''+(new Date(date).getMonth()+1)}-${(new Date(date).getDate())<10?'0'+(new Date(date).getDate()):''+(new Date(date).getDate())}`;
    // var innerObj = {};
    // innerObj['day1'] = innerArray[0];
    // innerObj['day2'] = innerArray[1];
    // innerObj['day3'] = innerArray[2];
    // innerObj['day4'] = innerArray[3];
    // innerObj['day5'] = innerArray[4];
    // innerObj['day6'] = innerArray[5];
    // innerObj['day7'] = innerArray[6];
    // returnArray.push(innerObj);

    
    return returndate;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createData = function (currentData,tableData) {
    tableData.push(currentData);

    return tableData;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.validateCategory = function (boData,allData,weekending,employee,categoryData) {
    let returnArray=[];
    let nextIdValue;
    if (nextIdValue === undefined) {
      nextIdValue = allData.length>0?allData[0].id:1;
      allData.forEach(e => {
        if (e.id > nextIdValue)
         nextIdValue = e.id;
      });
    }
    ++nextIdValue;

    for(let i=0;i<categoryData.length;i++){
     
     let validate=boData.length>0?boData.filter(ele=>ele.category===categoryData[i].id):'';
     let innerObj = {};
     if(validate.length>0){
       for(let x=0;x<validate.length;x++){
         returnArray.push(validate[x]);
         if(x===0){
           returnArray[returnArray.length-1].categoryVisibility=true;
         }else{
           returnArray[returnArray.length-1].categoryVisibility=false;
         }
     }
     }
     else{
      //  let columnarray=[];
      //  for(let a=0;a<columns.length;a++){
      //       columnarray.push('day'+a);
      //     }
      //  let payload={
      //    category:array[i],

      //  };

      returnArray.push(
        {
          category:categoryData[i].id,
          categoryName:categoryData[i].listOfCategory,
          projectDetails:'',
          comment1:'',
          day1:'',
          day2:'',
          day3:'',
          day4:'',
          day5:'',
          day6:'',
          day7:'',
          categoryVisibility:true,
          employee:employee,
          id:nextIdValue,
          weekEnding:weekending,
         
        });
        ++nextIdValue;
     }
      
    }
    let mainArray=[];
    mainArray.push(returnArray);
    mainArray.push(nextIdValue);
    return mainArray;
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   * 
   * 
   * */
   PageModule.prototype.AddLine = function (rowData,adpData,nextIdValue) {
     let returnArray=[];
     for(let i=0;i<adpData.length;i++){
       returnArray.push(adpData[i]);
       if(adpData[i].id===rowData.id){
         returnArray.push(
        {
          category:rowData.category,
          categoryName:rowData.listOfCategory,
          projectDetails:'',
          comment1:'',
          day1:'',
          day2:'',
          day3:'',
          day4:'',
          day5:'',
          day6:'',
          day7:'',
          categoryVisibility:false,
          employee:rowData.employee,
          id:nextIdValue,
          weekEnding:rowData.weekEnding,
         
        });
       }
     }
     let mainArray=[];
     let updateID=Number(nextIdValue)+1;
     mainArray.push(returnArray);
     mainArray.push(nextIdValue);
    return mainArray;
   };




  PageModule.prototype.Report = function (BoData) {
    let array=[];
    let CapabilityHrs=0,DesignAuthorityHrs=0,PursuitResponseHrs=0;
    let date=new Date();
    for(let a=0;a<BoData.length;a++){
      if(new Date(BoData[a].weekEnding).getMonth()===new Date(date).getMonth() && new Date(BoData[a].weekEnding).getFullYear()===new Date(date).getFullYear());
      
      switch(BoData[a].category)
      {
        case 'Capability': CapabilityHrs+=Number(BoData[a].day1)+Number(BoData[a].day2)+Number(BoData[a].day3)+Number(BoData[a].day4)+Number(BoData[a].day5)+Number(BoData[a].day6)+Number(BoData[a].day7);break;
        case 'Design Authority': DesignAuthorityHrs+=Number(BoData[a].day1)+Number(BoData[a].day2)+Number(BoData[a].day3)+Number(BoData[a].day4)+Number(BoData[a].day5)+Number(BoData[a].day6)+Number(BoData[a].day7);break;
        case 'Pursuit Response and Offers': PursuitResponseHrs =Number(BoData[a].day1)+Number(BoData[a].day2)+Number(BoData[a].day3)+Number(BoData[a].day4)+Number(BoData[a].day5)+Number(BoData[a].day6)+Number(BoData[a].day7);break;

      } 
      }
      let TotalHrs=Number(CapabilityHrs)+Number(DesignAuthorityHrs)+Number(PursuitResponseHrs);
        let object={};
        object['category']= 'Capability';
        object['janHrs']= CapabilityHrs;
        object['total']=CapabilityHrs;
        object['percentage']=((Number(CapabilityHrs)*100)/Number(TotalHrs)).toFixed(2)+'%';
        array.push(object);

        let object1={};
        object1['category']= 'Design Authority';
        object1['janHrs']= DesignAuthorityHrs;
        object1['total']=DesignAuthorityHrs;
        object1['percentage']=((Number(DesignAuthorityHrs)*100)/Number(TotalHrs)).toFixed(2)+'%';
        array.push(object1);

        let object2={};
        object2['category']= 'Pursuit Response and Offers';
        object2['janHrs']= PursuitResponseHrs;
        object2['total']=PursuitResponseHrs;
        object2['percentage']=((Number(PursuitResponseHrs)*100)/Number(TotalHrs)).toFixed(2)+'%';
        array.push(object2);

        let object3={};
        object3['category']= 'Grand Total';
        object3['janHrs']= TotalHrs;
        object3['total']=TotalHrs;
        object3['percentage']=100+'%';
        array.push(object3);
      return array;
    };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.fetchDate = function (date) {

    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
      }
    }}
    let returnData=innerArray.reverse();
    return returnData;
  };

  PageModule.prototype.areDifferent = function(oldValue, newValue) {
    if(JSON.stringify(newValue) === JSON.stringify(oldValue))
    return false;
    else 
    return true;
  };

  PageModule.prototype.isFormValid = function(detail, event) {
    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      return true;
    }
    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
    let table = event.target;
    let editables = table.querySelectorAll('.editable');
    for (let i = 0; i < editables.length; i++) {
      let editable = editables.item(i);
      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        return false;
      }
    }
    return true;
  };

  PageModule.prototype.validateBeforeSubmit = function(AdpData,projectDetails) {
    let validAllEmpty=0,valid2Empty=0,validateHours=0;
    for(let i=0;i<AdpData.length;i++){
          let details=projectDetails.filter(e=>e.category===AdpData[i].category && e.employee===AdpData[i].employee && e.weekEnding===AdpData[i].weekEnding);
          AdpData[i].projectDetails=details.length>0?'ENTERED':"NO";
      if(((AdpData[i].comment1==='' || AdpData[i].comment1===undefined || AdpData[i].comment1===null) || (AdpData[i].projectDetails==='NO'||AdpData[i].projectDetails==='')) && ((AdpData[i].day1!=='' && AdpData[i].day1!==undefined && AdpData[i].day1!==null) || (AdpData[i].day2!=='' && AdpData[i].day2!==undefined && AdpData[i].day2!==null) || (AdpData[i].day3!=='' && AdpData[i].day3!==undefined && AdpData[i].day3!==null) || (AdpData[i].day4!=='' && AdpData[i].day4!==undefined && AdpData[i].day4!==null) || (AdpData[i].day5!=='' && AdpData[i].day5!==undefined && AdpData[i].day5!==null) || (AdpData[i].day6!=='' && AdpData[i].day6!==undefined && AdpData[i].day6!==null ) || (AdpData[i].day7!=='' && AdpData[i].day7!==undefined && AdpData[i].day7!==null))){
        valid2Empty++;
      }
      else{
        let projectHours=0;
        let enteredHours=Number(AdpData[i].day1) + Number(AdpData[i].day2) + Number(AdpData[i].day3) + Number(AdpData[i].day4) + Number(AdpData[i].day5) + Number(AdpData[i].day6) + Number(AdpData[i].day7);
        for(let x=0;x<details.length;x++){
          projectHours+=Number(details[x].hours);
        }
        if(Number(projectHours)!==Number(enteredHours)){
        validateHours++;}
      }
      
      if((AdpData[i].comment1==='' || AdpData[i].comment1===undefined || AdpData[i].comment1===null) && (AdpData[i].projectDetails==='NO' || AdpData[i].projectDetails==='') && (AdpData[i].day1===''||AdpData[i].day1===undefined||AdpData[i].day1===null) && (AdpData[i].day2===''||AdpData[i].day2===undefined||AdpData[i].day2===null) && (AdpData[i].day3===''||AdpData[i].day3===undefined||AdpData[i].day3===null) && (AdpData[i].day4===''||AdpData[i].day4===undefined||AdpData[i].day4===null) && (AdpData[i].day5===''||AdpData[i].day5===undefined||AdpData[i].day5===null) && (AdpData[i].day6===''||AdpData[i].day6===undefined||AdpData[i].day6===null ) && (AdpData[i].day7===''||AdpData[i].day7===undefined||AdpData[i].day7===null) ){
        validAllEmpty++;
      }
      
    }
    if(valid2Empty==0 && validAllEmpty<4 && validateHours==0){
      return true;
    }
    else{
      return false;
    }
  };


  PageModule.prototype.BatchProcess = function(Bodata, UpdatedData) {
    let array=[];
    for(let i=0;i<UpdatedData.length;i++){
      let fetch=Bodata.find(e=>e.id===UpdatedData[i].id);
      let payload;
      let finalData=UpdatedData[i];
      delete finalData.categoryName;
      delete finalData.categoryVisibility;
      delete finalData.categoryObject;

      if(fetch){
         payload='{"id": "part'+i+'","path": "/CDETimeEntry/'+finalData.id+'","operation": "update","payload": '+JSON.stringify(finalData)+'}';
    array.push(JSON.parse(payload));
      }
      else{
        
         payload='{"id": "part'+i+'","path": "/CDETimeEntry/","operation": "create","payload": '+JSON.stringify(finalData)+'}';
      
    array.push(JSON.parse(payload));
      }
    }
    return { parts: array };
  };

  return PageModule;
});