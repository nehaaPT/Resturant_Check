define([], () => {
  'use strict';

  class PageModule {


     gethyper(demand, client, skill,cap,key) {
      let data = [];
      let dat = new Date();
      let curr_monthvar = dat.getMonth() + 1;
      for (var i = 0; i < demand.length; i++) {
        var rett = {};
        let roledate = new Date(demand[i].roleStartDate);
        let monthvar = roledate.getMonth() + 1;
        let cl = client.find(ele => ele.id == demand[i].client);
        let capa = cap.find(ele => ele.id == demand[i].globalPractice);
        let ski = skill.find(ele => ele.id == demand[i].skillGroup);
        if(demand[i].demandType=="Sold Project"){
        if (monthvar < curr_monthvar && key=='2') {
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar ===curr_monthvar) && key=='3'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar === curr_monthvar +1) && key=='4'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar > curr_monthvar +1)&& key=='5'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if(key=='6'){
           rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        }
        else if (demand[i].demandType=="Pursuit Project"){
          if (monthvar < curr_monthvar && key=='7') {
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar ===curr_monthvar) && key=='8'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar === curr_monthvar +1) && key=='9'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if((monthvar > curr_monthvar +1)&& key=='10'){
          rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        else if(key=='11'){
           rett['tid'] = demand[i].teamRequestNumber;
          rett['account'] = cl != undefined ? cl.clientName : '';
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['sd'] = demand[i].roleStartDate;
          rett['dc'] = demand[i].demandCreationDate;
          data.push(rett);
        }
        }

      }
      return data;
    }
  
        nonqualified(dembo,capbo,clibo,skillgrpbo,bubo) {
      let data=[];
      for (let i=0;i<dembo.length;i++){
        let retpayload={};
        let cap = capbo.find(ele => ele.id == dembo[i].globalPractice);
        let cli = clibo.find(ele => ele.id == dembo[i].client);
        let skgrp = skillgrpbo.find(ele => ele.id == dembo[i].skillGroup);
        let bu = bubo.find(ele => ele.id == dembo[i].sector);
        retpayload['DemandID'] = dembo[i].teamRequestNumber;
        retpayload['DemandType'] = dembo[i].demandType;
        retpayload['DemandCreationDate'] = dembo[i].demandCreationDate;
        retpayload['Client'] = cli != undefined ? cli.clientName:'';
        retpayload['Capability'] = cap != undefined?cap.name:'';
        retpayload['SkillGroup'] = skgrp != undefined?skgrp.skillGroupName:'';
        retpayload['Sector'] = bu != undefined?bu.name:'';
        data.push(retpayload);

      }
      return data;
    };
    accountQuery(clientName, sectorName) {
 
   
let query='';
 
    if (clientName !== undefined && clientName !== null && clientName !== '') {
        query += "client = '" + clientName + "'";
    }
 
    if (sectorName !== undefined && sectorName !== null && sectorName !== '') {
        query += " and sector = '" + sectorName + "'";
    }

  
 
    return query;
 
  };
     pastduedates(demandBO, capabilityBO, buBO, skillBO, clientBO) {
    let data = [];

    for (let i = 0; i < demandBO.length; i++) {
      let retpayload = {};

      let demand = demandBO.find(ele => ele.id === demandBO[i].teamRequestNumber);
      let capability = capabilityBO.find(ele => ele.id === demandBO[i].globalPractice);
      let sector = buBO.find(ele => ele.id === demandBO[i].sector);
      let skill = skillBO.find(ele => ele.id === demandBO[i].skillGroup);
      let client = clientBO.find(ele => ele.id === demandBO[i].client);

      var currentDate = new Date();
      var formattedCurrentDate = currentDate.getFullYear() + '-' +
        ('0' + (currentDate.getMonth() + 1)).slice(-2) + '-' +
        ('0' + currentDate.getDate()).slice(-2);
      var parsedCurrentDate = new Date(formattedCurrentDate + "T00:00:00");

      let end = new Date(demandBO[i].roleStartDate);
      var formattedReleaseDate = end.getFullYear() + '-' +
        ('0' + (end.getMonth() + 1)).slice(-2) + '-' +
        ('0' + end.getDate()).slice(-2);
      var parsedReleaseDate = new Date(formattedReleaseDate + "T00:00:00");

      var timediff = parsedReleaseDate - parsedCurrentDate;
      let final = timediff / (1000 * 3600 * 24);




      if (final < 0) {
        retpayload['teamRequestNumber'] = demandBO[i].teamRequestNumber;
        retpayload['projectName'] = demandBO[i].projectName;
        retpayload['positionName'] = demandBO[i].positionName;
        retpayload['roleStartDate'] = demandBO[i].roleStartDate;
        retpayload['globalPractice'] = capability ? capability.name : '';
        retpayload['sector'] = sector ? sector.name : '';
        retpayload['skillGroup'] = skill ? skill.skillGroupName : '';
        retpayload['client'] = client ? client.clientName : '';

        data.push(retpayload);
      }
    }






    return data;
  };

 getdata1(demand, skill, cap, client,sect) {
  var data = [];
  let itemcount = 0;
  for (var i = 0; i < demand.length; i++) {
    var ret = {};
    let currentDate = new Date();
    let formattedCurrentDate = currentDate.getFullYear() + '-' +
      ('0' + (currentDate.getMonth() + 1)).slice(-2) + '-' +
      ('0' + currentDate.getDate()).slice(-2);
    let parsedCurrentDate = new Date(formattedCurrentDate + "T00:00:00");

    let date = new Date(demand[i].demandCreationDate);

    let formattedProposalDate = date.getFullYear() + '-' +
      ('0' + (date.getMonth() + 1)).slice(-2) + '-' +
      ('0' + date.getDate()).slice(-2);
    let parsedProposalDate = new Date(formattedProposalDate + "T00:00:00");

    if (!isNaN(date)) {
      let timeDiff = parsedCurrentDate - parsedProposalDate;
      var days = timeDiff / (1000 * 3600 * 24);
    }
    let cl = client.find(ele => ele.id == demand[i].client);
    let capa = cap.find(ele => ele.id == demand[i].globalPractice);
    let ski = skill.find(ele => ele.id == demand[i].skillGroup);
    let sectt = sect.find(ele => ele.id == demand[i].sector);
    if (days > 0 && days < 60) {
      ret['tid'] = demand[i].teamRequestNumber;
      ret['account'] = cl != undefined ? cl.clientName : '';
      ret['capability'] = capa != undefined ? capa.name : '';
      ret['sect'] = sectt != undefined ? sectt.name : '';
      ret['sg'] = ski != undefined ? ski.skillGroupName : '';
      ret['sd'] = demand[i].roleStartDate;
      ret['dc'] = demand[i].demandCreationDate;
      ret['pjname'] = demand[i].projectName;
      ret['poname'] = demand[i].positionName;
      data.push(ret);
      itemcount++;
    }
  }
  
  // Sort data by demand creation date
  data.sort((a, b) => new Date(a.dc) - new Date(b.dc));

  return { data: data, count: itemcount };
}

  

    getdata(emp, empro, cap, skill, type, rolloff) {
    let data = [];
    let itemcount=0;
    for (var i = 0; i < emp.length; i++) {
      let ret = {};
      let cap1 = cap.find(ele => ele.id == emp[i].globalPractice);
      let sugcap = cap.find(ele => ele.id == emp[i].suggestedCapabillity);
      let c1 = skill.find(ele => ele.id == emp[i].skillGroup1);
      let c2 = skill.find(ele => ele.id == emp[i].skillGroup2);
      let c3 = skill.find(ele => ele.id == emp[i].skillGroup3);
      let csk=skill.find(ele=>ele.id==emp[i].CapabilitySkillGroup);
      if (!(empro.find(ele => ele.employeeID == emp[i].id)) && type == "undefined") {
        var currentDate = new Date();
        var newCurrentDate = currentDate.getFullYear() + '-' +
          ('0' + (currentDate.getMonth() + 1)).slice(-2) + '-' +
          ('0' + currentDate.getDate()).slice(-2);
        var finalCurrentDate = new Date(newCurrentDate + "T00:00:00");
        var availDate = new Date(emp[i].employeeSubgroup);
        var newavailDate = availDate.getFullYear() + '-' +
          ('0' + (availDate.getMonth() + 1)).slice(-2) + '-' +
          ('0' + availDate.getDate()).slice(-2);
        var finalavailDate = new Date(newavailDate + "T00:00:00");
        if (!isNaN(availDate)) {
          var timeDiff = finalavailDate - finalCurrentDate;
          var days = timeDiff / (1000 * 3600 * 24);
        }
        else{
          days=0;
        }
        ret['empid'] = emp[i].employeeID;
        ret['name'] = emp[i].name;
        ret['grade'] = emp[i].localGrade;
        ret['csg']=csk!=undefined?csk.skillGroupName:'',
        ret['cap'] = cap1 != undefined ? cap1.name : '';
        ret['cg'] = sugcap != undefined ? sugcap.name : '';
        ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
        ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
        ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
        ret['ba'] = days;
        data.push(ret);
        itemcount++;

      }
      if (!(empro.find(ele => ele.employeeID == emp[i].id)) && type == "") {
        var currentDate1 = new Date();
        var newCurrentDate1 = currentDate1.getFullYear() + '-' +
          ('0' + (currentDate1.getMonth() + 1)).slice(-2) + '-' +
          ('0' + currentDate1.getDate()).slice(-2);
        var finalCurrentDate1 = new Date(newCurrentDate1 + "T00:00:00");
        var availDate1 = new Date(emp[i].employeeSubgroup);
        var newavailDate1 = availDate1.getFullYear() + '-' +
          ('0' + (availDate1.getMonth() + 1)).slice(-2) + '-' +
          ('0' + availDate1.getDate()).slice(-2);
        var finalavailDate1 = new Date(newavailDate1 + "T00:00:00");
        if (!isNaN(availDate1)) {
          var timeDiff1 = finalavailDate1 - finalCurrentDate1;
          var days1 = timeDiff1 / (1000 * 3600 * 24);
        }
        ret['empid'] = emp[i].employeeID;
        ret['name'] = emp[i].name;
        ret['grade'] = emp[i].localGrade;
        ret['cap'] = cap1 != undefined ? cap1.name : '';
        ret['csg']=csk!=undefined?csk.skillGroupName:'',
        ret['cg'] = sugcap != undefined ? sugcap.name : '';
        ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
        ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
        ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
        ret['ba'] = days1;
        data.push(ret);
        itemcount++;

      }
      // if (!(empro.find(ele => ele.employeeID == emp[i].id)) ) {
      //   ret['empid'] = emp[i].employeeID;
      //   ret['name'] = emp[i].name;
      //   ret['grade'] = emp[i].localGrade;
      //   ret['cap'] = cap1 != undefined ? cap1.name : '';
      //   ret['cg'] = sugcap != undefined ? sugcap.name : '';
      //   ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
      //   ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
      //   ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
      //   data.push(ret);

      // }
      if (type == "Bench - Deployable") {
        if (!(empro.find(ele => ele.employeeID == emp[i].id)) && (emp[i].status == type)) {
          var currentDate3 = new Date();
          var newCurrentDate3 = currentDate3.getFullYear() + '-' +
            ('0' + (currentDate3.getMonth() + 1)).slice(-2) + '-' +
            ('0' + currentDate3.getDate()).slice(-2);
          var finalCurrentDate3 = new Date(newCurrentDate3 + "T00:00:00");
          var availDate3 = new Date(emp[i].employeeSubgroup);
          var newavailDate3 = availDate3.getFullYear() + '-' +
            ('0' + (availDate3.getMonth() + 1)).slice(-2) + '-' +
            ('0' + availDate3.getDate()).slice(-2);
          var finalavailDate3 = new Date(newavailDate3 + "T00:00:00");
          if (!isNaN(availDate3)) {
            var timeDiff3 = finalavailDate3 - finalCurrentDate3;
            var days3 = timeDiff3 / (1000 * 3600 * 24);
          }
          ret['empid'] = emp[i].employeeID;
          ret['name'] = emp[i].name;
          ret['grade'] = emp[i].localGrade;
          ret['cap'] = cap1 != undefined ? cap1.name : '';
          ret['csg']=csk!=undefined?csk.skillGroupName:'',
          ret['cg'] = sugcap != undefined ? sugcap.name : '';
          ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
          ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
          ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
          ret['ba'] = days3;
          data.push(ret);
          itemcount++;

        }
      }
      if (!(empro.find(ele => ele.employeeID == emp[i].id)) && type == "rolloff") {
        if (rolloff.find(ele => ele.employeeID == emp[i].id)) {
          let roll = rolloff.find(ele => ele.employeeID == emp[i].id);
          let rodate = roll.releaseDate
          if (rodate) {
            var currentDate6 = new Date();
            let formattedCurrentDate = currentDate6.getFullYear() + '-' +
              ('0' + (currentDate6.getMonth() + 1)).slice(-2) + '-' +
              ('0' + currentDate6.getDate()).slice(-2);
            let parsedCurrentDate = new Date(formattedCurrentDate + "T00:00:00");

            let date = new Date(rodate);

            let formattedProposalDate = date.getFullYear() + '-' +
              ('0' + (date.getMonth() + 1)).slice(-2) + '-' +
              ('0' + date.getDate()).slice(-2);
            let parsedProposalDate = new Date(formattedProposalDate + "T00:00:00");

            if (!isNaN(date)) {
              let timeDiff = parsedProposalDate - parsedCurrentDate;
              var dayDiff = timeDiff / (1000 * 3600 * 24);
            }
          }

          if (dayDiff > 0 && dayDiff < 30) {
            var currentDate4 = new Date();
            var newCurrentDate4 = currentDate4.getFullYear() + '-' +
              ('0' + (currentDate4.getMonth() + 1)).slice(-2) + '-' +
              ('0' + currentDate4.getDate()).slice(-2);
            var finalCurrentDate4 = new Date(newCurrentDate4 + "T00:00:00");
            var availDate4 = new Date(emp[i].employeeSubgroup);
            var newavailDate4 = availDate4.getFullYear() + '-' +
              ('0' + (availDate4.getMonth() + 1)).slice(-2) + '-' +
              ('0' + availDate4.getDate()).slice(-2);
            var finalavailDate4 = new Date(newavailDate4 + "T00:00:00");
            if (!isNaN(availDate4)) {
              var timeDiff4 = finalavailDate4 - finalCurrentDate4;
              var days4 = timeDiff4 / (1000 * 3600 * 24);
            }
            ret['empid'] = emp[i].employeeID;
            ret['name'] = emp[i].name;
            ret['grade'] = emp[i].localGrade;
            ret['cap'] = cap1 != undefined ? cap1.name : '';
            ret['csg']=csk!=undefined?csk.skillGroupName:'',
            ret['cg'] = sugcap != undefined ? sugcap.name : '';
            ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
            ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
            ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
            ret['ba'] = days4;
            data.push(ret);
            itemcount++;
          }
        }

      }
      if (!(empro.find(ele => ele.employeeID == emp[i].id)) && type == "benroll") {
        if (rolloff.find(ele => ele.employeeID == emp[i].id)) {
          let roll = rolloff.find(ele => ele.employeeID == emp[i].id);
          let rodate = roll.releaseDate
          if (rodate && emp[i].status == 'Bench - Deployable') {
            var currentDate5 = new Date();
            var formattedCurrentDate = currentDate5.getFullYear() + '-' +
              ('0' + (currentDate5.getMonth() + 1)).slice(-2) + '-' +
              ('0' + currentDate5.getDate()).slice(-2);
            var parsedCurrentDate = new Date(formattedCurrentDate + "T00:00:00");

            let date = new Date(rodate);

            var formattedProposalDate = date.getFullYear() + '-' +
              ('0' + (date.getMonth() + 1)).slice(-2) + '-' +
              ('0' + date.getDate()).slice(-2);
            var parsedProposalDate = new Date(formattedProposalDate + "T00:00:00");

            if (!isNaN(date)) {
              var timeDiff5 = parsedProposalDate - parsedCurrentDate;
              var dayDiff1 = timeDiff5 / (1000 * 3600 * 24);
            }
          }

          if (dayDiff1 > 0 && dayDiff1 < 30) {
            var currentDate9 = new Date();
            var newCurrentDate6 = currentDate9.getFullYear() + '-' +
              ('0' + (currentDate9.getMonth() + 1)).slice(-2) + '-' +
              ('0' + currentDate9.getDate()).slice(-2);
            var finalCurrentDate6 = new Date(newCurrentDate6 + "T00:00:00");
            var availDate6 = new Date(emp[i].employeeSubgroup);
            var newavailDate6 = availDate6.getFullYear() + '-' +
              ('0' + (availDate6.getMonth() + 1)).slice(-2) + '-' +
              ('0' + availDate6.getDate()).slice(-2);
            var finalavailDate6 = new Date(newavailDate6 + "T00:00:00");
            if (!isNaN(availDate6)) {
              var timeDiff6 = finalavailDate6 - finalCurrentDate6;
              var days6 = timeDiff6 / (1000 * 3600 * 24);
            }
            ret['empid'] = emp[i].employeeID;
            ret['name'] = emp[i].name;
            ret['grade'] = emp[i].localGrade;
            ret['csg']=csk!=undefined?csk.skillGroupName:'',
            ret['cap'] = cap1 != undefined ? cap1.name : '';
            ret['cg'] = sugcap != undefined ? sugcap.name : '';
            ret['sg1'] = c1 != undefined ? c1.skillGroupName : '';
            ret['sg2'] = c2 != undefined ? c2.skillGroupName : '';
            ret['sg3'] = c3 != undefined ? c3.skillGroupName : '';
            ret['ba']=days6;
            data.push(ret);
            itemcount++;
          }
        }
      }
    }
    return { data: data, count: itemcount };
  };

    demandAnalyticsDataCreate(P_demandBO, emp, rollOffBO, sector, roldate) {
      let initData = [];
      let finalData = [];
      let rollemp = [];
      let empbench = [];
      let final = [];
      let final3 = [];
      let row1=0, row2=0, row3=0, row4=0, row5=0, row6=0, row7=0, row8=0, row9=0, row10=0,row11=0;

      let curdate = formatDate(new Date);

      function formatDate(date) {
        const yyyy = date.getFullYear();
        const mm = String(date.getMonth() + 1).padStart(2, '0');
        const dd = String(date.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
      }

      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb"];
      let d = new Date();
      let curr_month = d.getMonth() + 1;

      // Object to hold month names
      let monthData = {
        currentMonth: monthNames[curr_month - 1],
        nextMonth: monthNames[curr_month],
        future: monthNames[curr_month + 1] + '+'
      };

      console.log("Step 1: Initializing data structures");
      console.log("monthData:", monthData);

      // Populate initData array
      for (let i = 0; i < P_demandBO.length; i++) {
        let row = {
          sector: P_demandBO[i].sectorObject.items[0].name,
          account: P_demandBO[i].client != undefined ? P_demandBO[i].clientObject.items[0].clientName : '',
          roleStartDate: P_demandBO[i].roleStartDate,
          demandType: P_demandBO[i].demandType.trim()
        };
        initData.push(row);
      }

      console.log("Step 2: initData populated");
      console.log("initData:", initData);

      // Process initData to populate finalData
      initData.forEach(data => {
        let roleStartDate = new Date(data.roleStartDate);
        let month = roleStartDate.getMonth() + 1;
        let element = finalData.find(item => item.sector === data.sector && item.account === data.account);

        if (!element) {
          let temp = {
            sector: data.sector,
            account: data.account,
            sold_curr_month: 0,
            sold_next_month: 0,
            sold_future_month: 0,
            pastdue_sold: 0,
            pursuit_curr_month: 0,
            pursuit_next_month: 0,
            pursuit_future_month: 0,
            pastdue_pursuit: 0,
            soldDemands: 0,
            pursuitdemand: 0,
            currentBench: 0, // Default to 0
            rolloffs: 0,
            offers_curr_month: 0,
            offers_next_month: 0,
            offers_future_month: 0,
            pastdue_offers: 0
          };

          if (data.demandType === 'Sold Project') {
            if (month === curr_month) {
              temp.sold_curr_month = 1;
            } else if (month === curr_month + 1) {
              temp.sold_next_month = 1;
            } else if (month > curr_month + 1) {
              temp.sold_future_month = 1;
            } else if (month < curr_month) {
              temp.pastdue_sold = 1;
            }
            temp.soldDemands = 1;
          } else if (data.demandType === 'Pursuit Project') {
            if (month === curr_month) {
              temp.pursuit_curr_month = 1;
            } else if (month === curr_month + 1) {
              temp.pursuit_next_month = 1;
            } else if (month > curr_month + 1) {
              temp.pursuit_future_month = 1;
            } else if (month < curr_month) {
              temp.pastdue_pursuit = 1;
            }
            temp.pursuitdemand =1;
          }

          finalData.push(temp);
        } else {
          // Update existing element in finalData
          let index = finalData.findIndex(item => item.sector === element.sector && item.account === element.account);
          if (data.demandType === 'Sold Project') {
            if (month === curr_month) {
              finalData[index].sold_curr_month += 1;
            } else if (month === curr_month + 1) {
              finalData[index].sold_next_month += 1;
            } else if (month > curr_month + 1) {
              finalData[index].sold_future_month += 1;
            } else if (month < curr_month) {
              finalData[index].pastdue_sold += 1;
            }
            finalData[index].soldDemands += 1;
          } else if (data.demandType === 'Pursuit Project') {
            if (month === curr_month) {
              finalData[index].pursuit_curr_month += 1;
            } else if (month === curr_month + 1) {
              finalData[index].pursuit_next_month += 1;
            } else if (month > curr_month + 1) {
              finalData[index].pursuit_future_month += 1;
            } else if (month < curr_month) {
              finalData[index].pastdue_pursuit += 1;
            }
            finalData[index].pursuitdemand +=1;
          }
        }
      });

      console.log("Step 3: finalData populated");
      console.log("finalData:", finalData);

      // Populate empbench array
      emp.forEach(employee => {
        let sec = sector.find(sec => sec.id === employee.bu);
        empbench.push({
          sectors: sec !== undefined ? sec.name : '',
          status: employee.status,
        });
      });

      console.log("Step 4: empbench populated");
      console.log("empbench:", empbench);

      // Process empbench to populate final
      // empbench.forEach(item => {
      //   let elem = final.find(data => data.sector === item.sectors);
      //   if (!elem) {
      //     let temp = {
      //       sector: item.sectors,
      //       currentBench: item.status === 'Bench - Deployable' ? 1 : 0,
      //       status: item.status,
      //     };
      //     final.push(temp);
      //   } else {
      //     let index = final.findIndex(data => data.sector === elem.sector);
      //     if (item.status === 'Bench - Deployable') {
      //       final[index].currentBench += 1;
      //     }
      //   }
      // });
          for(var i=0;i<empbench.length;i++){
      let ret1={};
      var elem=final.find(function(data){return data.sector == empbench[i].sectors})
      if(elem==undefined){
        let tem={};
         tem['sector']=empbench[i].sectors;
         tem['currentBench']=0;
         tem['status']=empbench[i].status;
         if(empbench[i].status==='Bench - Deployable'){
          tem['currentBench']=1;
         }
         final.push(tem);
      }
      else{
        var ind=final.findIndex(function(data){return data.sector ===elem.sector;})
        if(empbench[i].status==='Bench - Deployable'){
          final[ind]['currentBench'] += 1;
        }
      }
    };

      // Process rollOffBO to populate final3
      for (var i = 0; i < rollOffBO.length; i++) {
        var ret = {};
        let sect = sector.find(ele => ele.id == rollOffBO[i].bu);
        if (sect != undefined && sect.name != "") {
          ret['sector'] = sect.name;
          ret['rolloffs'] = 0;
          ret['roldate'] = rollOffBO[i].releaseDate;
          if (rollOffBO[i].releaseDate > curdate && rollOffBO[i].releaseDate < roldate) {
            ret['rolloffs'] = 1;
          }
          final3.push(ret);
        }
      }

      console.log("Step 5: final3 populated");
      console.log("final3:", final3);

      // Merge final3 with mergedData
      let mergedData = finalData.map(item => {
        let match = final.find(subItem => subItem.sector === item.sector);
        let match3 = final3.find(subItem => subItem.sector === item.sector);
        if (match) {
          return {
            ...match,
            sector: item.sector,
            account: item.account,
            sold_curr_month: item.sold_curr_month,
            sold_next_month: item.sold_next_month,
            sold_future_month: item.sold_future_month,
            pastdue_sold: item.pastdue_sold,
            soldDemands: item.soldDemands,
            pursuit_curr_month: item.pursuit_curr_month,
            pursuit_next_month: item.pursuit_next_month,
            pursuit_future_month: item.pursuit_future_month,
            pastdue_pursuit: item.pastdue_pursuit,
            rolloffs: match3 ? match3.rolloffs : 0,
            offers_curr_month: 0,
            offers_next_month: 0,
            offers_future_month: 0,
            pastdue_offers: 0,
            pursuitdemand :item.pursuitdemand
          };
        } else {
          // Include unmatched data from finalData
          return {
            sector: item.sector,
            account: item.account,
            sold_curr_month: item.sold_curr_month,
            sold_next_month: item.sold_next_month,
            sold_future_month: item.sold_future_month,
            pastdue_sold: item.pastdue_sold,
            soldDemands: item.soldDemands,
            pursuitdemand :item.pursuitdemand,
            pursuit_curr_month: item.pursuit_curr_month,
            pursuit_next_month: item.pursuit_next_month,
            pursuit_future_month: item.pursuit_future_month,
            pastdue_pursuit: item.pastdue_pursuit,
            currentBench: 0,
            rolloffs: match3 ? match3.rolloffs : 0,
            offers_curr_month: 0,
            offers_next_month: 0,
            offers_future_month: 0,
            pastdue_offers: 0
          };
        }
      });




      console.log("Step 6: mergedData populated");
      console.log("mergedData:", mergedData);

      finalData['currentMonth'] = monthNames[curr_month - 1];
      finalData['nextMonth'] = monthNames[curr_month];
      finalData['future'] = monthNames[curr_month + 1] + '+';

      for (let i=0;i<finalData.length;i++){
      row1+=finalData[i].pastdue_sold;
      row2+= finalData[i].sold_curr_month;
      row3+=finalData[i].sold_next_month;
      row4+=finalData[i].sold_future_month;
      row5+=finalData[i].soldDemands;
      row6+=finalData[i].pastdue_pursuit;
      row7+=finalData[i].pursuit_curr_month;
      row8+=finalData[i].pursuit_next_month;
      row9+=finalData[i].pursuit_future_month;
      row10+=finalData[i].pursuitdemand;
      
      
    };
    let temp1={};
    temp1['sector']='Total';
    temp1['pastdue_sold']=row1;
    temp1['sold_curr_month']=row2;
    temp1['sold_next_month']=row3;
    temp1['sold_future_month']=row4;
    temp1['soldDemands']=row5;
    temp1['pastdue_pursuit']=row6;
    temp1['pursuit_curr_month']=row7;
    temp1['pursuit_next_month']=row8;
    temp1['pursuit_future_month']=row9;
    temp1['pursuitdemand']=row10;
  
    finalData.push(temp1);

      return finalData; // Return the month names along with the merged data
    };
    
//   demandData(P_demandBO, emp, rollOffBO, cap, supply, roldate, skill) {
//   let initData = [];
//   let finalData = [];
//   let empbench = [];
//   let final = [];
//   let final3 = [];
//   let supp = [];
//   let fs = [];

//   let curdate = formatDate(new Date());

//   function formatDate(date) {
//     const yyyy = date.getFullYear();
//     const mm = String(date.getMonth() + 1).padStart(2, '0');
//     const dd = String(date.getDate()).padStart(2, '0');
//     return `${yyyy}-${mm}-${dd}`;
//   }

//   function parseDate(dateStr) {
//     const parts = dateStr.split('-');
//     return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
//   }
//   function parseDateGetMonth(dateStr) {
//     const parts = dateStr.split('-');
//     return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
//   }

//   const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb"];
//   let d = new Date();
//   let curr_month = d.getMonth() + 1;

//   // Object to hold month names
//   let monthData = {
//     currentMonth: monthNames[curr_month - 1],
//     nextMonth: monthNames[curr_month],
//     future: monthNames[curr_month + 1] + '+'
//   };

//   // console.log("Step 1: Initializing data structures");
//   // console.log("monthData:", monthData);

//   // Populate initData array
//   for (let i = 0; i < P_demandBO.length; i++) {
//     let capabilityName = P_demandBO[i].globalPracticeObject.items[0] !== undefined ? P_demandBO[i].globalPracticeObject.items[0].name : '';

//     let skillGroupName = P_demandBO[i].skillGroup && P_demandBO[i].skillGroupObject && P_demandBO[i].skillGroupObject.items && P_demandBO[i].skillGroupObject.items.length > 0
//       ? P_demandBO[i].skillGroupObject.items[0].skillGroupName
//       : '';

//     let row = {
//       capability: capabilityName,
//       skillGroup: skillGroupName,
//       roleStartDate: P_demandBO[i].roleStartDate,
//       demandType: P_demandBO[i].demandType ? P_demandBO[i].demandType.trim() : ''
//     };
//     initData.push(row);
//   }

//   // console.log("Step 2: initData populated");
//   // console.log("initData:", initData);

//   // Process initData to populate finalData
//  initData.forEach(data => {
//     let roleStartDate = new Date(data.roleStartDate);
//     let month = roleStartDate.getMonth() + 1;
//     let element = finalData.find(item => item.capability === data.capability && item.skillGroup === data.skillGroup);

//     if (!element) {
//       let temp = {
//         capability: data.capability,
//         skillGroup: data.skillGroup,
//         sold_curr_month: 0,
//         sold_next_month: 0,
//         sold_future_month: 0,
//         pastdue_sold: 0,
//         soldPursuit:0,
//         pursuit_curr_month: 0,
//         pursuit_next: 0,
//         pursuit_future: 0,
//         pastdue_pursuit: 0,
//         soldDemands: 0,
//         currentBench: 0, // Default to 0
//         rolloffs: 0,
//         offers_curr: 0,
//         offers_next: 0,
//         offers_future: 0,
//         pastdue_offers: 0
//       };

//       if (data.demandType === 'Sold Project') {
//         if (month === curr_month) {
//           temp.sold_curr_month = 1;
//         } else if (month === curr_month + 1) {
//           temp.sold_next_month = 1;
//         } else if (month > curr_month + 1) {
//           temp.sold_future_month = 1;
//         } else if (month < curr_month) {
//           temp.pastdue_sold = 1;
//         }
//         temp.soldDemands = 1;
//       } else if (data.demandType === 'Pursuit Project') {
//         if (month === curr_month) {
//           temp.pursuit_curr_month = 1;
//         } else if (month === curr_month + 1) {
//           temp.pursuit_next = 1;
//         } else if (month > curr_month + 1) {
//           temp.pursuit_future = 1;
//         } else if (month < curr_month) {
//           temp.pastdue_pursuit = 1;
//         }
//         temp.soldPursuit = 1;
//       }

//       finalData.push(temp);
//     } else {
//       // Update existing element in finalData
//       let index = finalData.findIndex(item => item.capability === element.capability && item.skillGroup === element.skillGroup);
//       if (data.demandType === 'Sold Project') {
//         if (month === curr_month) {
//           finalData[index].sold_curr_month += 1;
//         } else if (month === curr_month + 1) {
//           finalData[index].sold_next_month += 1;
//         } else if (month > curr_month + 1) {
//           finalData[index].sold_future_month += 1;
//         } else if (month < curr_month) {
//           finalData[index].pastdue_sold += 1;
//         }
//         finalData[index].soldDemands += 1;
//       } else if (data.demandType === 'Pursuit Project') {
//         if (month === curr_month) {
//           finalData[index].pursuit_curr_month += 1;
//         } else if (month === curr_month + 1) {
//           finalData[index].pursuit_next += 1;
//         } else if (month > curr_month + 1) {
//           finalData[index].pursuit_future += 1;
//         } else if (month < curr_month) {
//           finalData[index].pastdue_pursuit += 1;
//         }
//         finalData[index].soldPursuit +=1;
//       }
//     }
//   });

//   // console.log("Step 3: finalData populated");
//   // console.log("finalData:", finalData);

//   // Populate empbench array
//   emp.forEach(employee => {
//     let capability = cap.find(capability => capability.id === employee.globalPractice);
//     let sg1 = skill.find(ele => ele.id === employee.CapabilitySkillGroup);
//     // let sg2 = skill.find(ele => ele.id === employee.skillGroup2);
//     // let sg3 = skill.find(ele => ele.id === employee.skillGroup3);
//     empbench.push({
//       capabilities: capability !== undefined ? capability.name : '',
//       skillGroup: [sg1 !== undefined ? sg1.skillGroupName : ''],
//       status: employee.status
//     });
//   });

//   // console.log("Step 4: empbench populated");
//   // console.log("empbench:", empbench);

//   // Process empbench to populate final
//   empbench.forEach(item => {
//     item.skillGroup.forEach(sg => {
//       if (sg) {
//         let elem = final.find(data => data.capability === item.capabilities && data.skillGroup === sg);
//         if (!elem) {
//           let temp = {
//             capability: item.capabilities,
//             skillGroup: sg,
//             currentBench: item.status === 'Bench - Deployable' ? 1 : 0,
//             status: item.status
//           };
//           final.push(temp);
//         } else {
//           let index = final.findIndex(data => data.capability === elem.capability && data.skillGroup === elem.skillGroup);
//           if (item.status === 'Bench - Deployable') {
//             final[index].currentBench += 1;
//           }
//         }
//       }
//     });
//   });


//    for(var e=0;e<rollOffBO.length;e++) {
//   let emp2 = emp.find(ele => ele.id === rollOffBO[e].employeeID);
//   if(emp2!=undefined && emp2.globalPractice!=undefined && emp2.CapabilitySkillGroup!=undefined){
//     let capability = cap.find(capability => capability.id === emp2.globalPractice);
//     let eskill = skill.find(ele => ele.id === emp2.CapabilitySkillGroup);

//     fs.push({
//       capabilities: capability !== undefined ? capability.name : '',
//       skillGroup: [eskill !== undefined ? eskill.skillGroupName : ''],
//       rollOfDate: rollOffBO[e].releaseDate,
//       id:rollOffBO[e].employeeID
//     });
//   }
//   }
   
//   fs.forEach(item => {
//     item.skillGroup.forEach(sg => {
//       if (sg) {
//         let elem = final3.find(data => data.capability === item.capabilities && data.skillGroup === sg);
//         if (!elem) {
//           let temp = {
//             capability: item.capabilities,
//             id :item.id,
//             skillGroup: sg,
//             rolloffs: (item.rollOfDate > curdate && item.rollOfDate < roldate) ? 1 : 0,
//           };
//           final3.push(temp);
//         } else {
//           let index = final3.findIndex(data => data.capability === elem.capability && data.skillGroup === elem.skillGroup);
//           if (item.rollOfDate > curdate && item.rollOfDate < roldate) {
          
//             final3[index].rolloffs += 1;
//           }
//             console.log("*",final3);
//         }
//       }
//     });
//   });
 
// const uniqueArray=[];
//   // Process supply array
//   for (let a = 0; a < supply.length; a++) {
//     let scap = cap.find(ele => ele.id == supply[a].capability); //Capability Name
//     // let dojblanks= supply.filter(supply[a].doj!=null);
//     let ss1 = skill.find(ele => ele.id == supply[a].skillGroup1); //Skil set 1
//     let ss2 = skill.find(ele =>ele.id== supply[a].skillGroup2); //Skil set 2
//     let ss3 = skill.find(ele =>ele.id== supply[a].skillGroup3); //Skil set 3

// function getMonthFromDate(dateStr) {
//     // Split the string into parts [DD, MM, YYYY]
//     const parts = dateStr.split('-');
 
//     // Construct a new date string in the format "MM/DD/YYYY"
//     const dateString = `${parts[1]}/${parts[0]}/${parts[2]}`;
//     // Create a new Date object using the dateString
//     const date = new Date(dateString);
//     // Get the month from the date object
//     // Note: getMonth returns a 0-indexed month (0 for January, 1 for February, etc.)
//     const month = date.getMonth() + 1;  // Add 1 to make it 1-indexed
 
//     return month;
// }



//     let trimmedDate = supply[a].doj;
//     if(supply[a].doj!= null){
//       let trimmedDate = supply[a].doj.trim();
//     }
//     else{
//       let trimmedDate = supply[a].doj;
//     }
//     if (scap && trimmedDate!= null && trimmedDate!== "") { // Ensure doj exists before proceeding

//       let dojMonth = getMonthFromDate(trimmedDate);
//       //let returnDate = parseDateStringToDate(supply[a].doj);
//       // if(returnDate== 'Invalid date format'){
//       //   console.log("Issue with Data Formate",typeof(supply[a].doj),supply[a].id+"-"+scap.id+"-"+ss1.id );
//       // }
//       //let dojMonth = dojDate.getMonth() + 1; // getMonth() returns month from 0-11, so add 1
      
//       //console.log('capab',scap.name,'skill1',ss1.skillGroupName,'skill2',ss2?ss2.skillGroupName:'','skill3',ss3?ss3.skillGroupName:'');
      
      
      
//       initData.forEach(data => {
//         if (data.capability === scap.name && (data.skillGroup === ss1.skillGroupName || data.skillGroup === ss1.skillGroupName || data.skillGroup === ss1.skillGroupName)) {

//           // console.log(`Processing supply entry: ${JSON.stringify(supply[a])}`);
//           // console.log(`Matched with initData: ${JSON.stringify(data)}`);
          
//         // console.log("Test.........",data.capability,data.skillGroup);
        
//         if(!uniqueArray.includes(supply[a].id+"-"+scap.id+"-"+ss1.id ))
//         {
//           console.log("Months.....",supply[a].doj,dojMonth,supply[a].id+"-"+scap.id+"-"+ss1.id);
//           uniqueArray.push(supply[a].id+"-"+scap.id+"-"+ss1.id);
//           // Check and add count based on dojMonth
//           let element = supp.find(item => item.capability === scap.name && item.skillGroup === data.skillGroup);
//           if (!element) {
//             // If no element found, create a new one
//             let temp1 = {
//               capability: scap.name,
//               skillGroup: data.skillGroup,
//               sold_curr_month: 0,
//               sold_next_month: 0,
//               sold_future_month: 0,
//               pastdue_sold: 0,
//               pursuit_curr_month: 0,
//               pursuit_next: 0,
//               pursuit_future: 0,
//               pastdue_pursuit: 0,
//               soldDemands: 0,
//               currentBench: 0, // Default to 0
//               rolloffs: 0,
//               offers_curr: 0, //Present Month
//               offers_next: 0, //Next Month
//               offers_future: 0, //Future Month
//               pastdue_offers: 0 //Before Current Month 
//             };
//             if (dojMonth === curr_month) {
//               temp1.offers_curr = 1;
//             } else if (dojMonth === curr_month + 1) {
//               temp1.offers_next = 1;
//             } else if (dojMonth > curr_month + 1) {
//               temp1.offers_future = 1;
//             } else if (dojMonth < curr_month) {
//               temp1.pastdue_offers = 1;
//             }
//             supp.push(temp1);
//           } else {
//             let index = supp.findIndex(item => item.capability === scap.name && item.skillGroup === data.skillGroup);
//             if (index !== -1) {
//               if (dojMonth === curr_month) {
//                 supp[index].offers_curr += 1;
//               } else if (dojMonth === curr_month + 1) {
//                 supp[index].offers_next += 1;
//               } else if (dojMonth > curr_month + 1) {
//                 supp[index].offers_future += 1;
//               } else if (dojMonth < curr_month) {
//                 supp[index].pastdue_offers += 1;
//               }
//             }
//           }

//         }

          
//         //If End
//         }
//       });
//     }
//   //for loop end
 
//   }
//   const uniqueArr = [...new Set(uniqueArray)];
//   console.log("Uni..........",uniqueArr);

  
//   // console.log("Step 5: final populated");
//   // console.log("supp:", supp);

//   // Merge finalData with final to create mergedData
//   let mergedData = finalData.map(item => {
//     let match = final.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
//     let match3 = final3.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
//     let match2 = supp.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
//     if (match) {
//       return {
//         ...match,
//         capability: item.capability,
//         skillGroup: item.skillGroup,
//         sold_curr_month: item.sold_curr_month,
//         sold_next_month: item.sold_next_month,
//         sold_future_month: item.sold_future_month,
//         pastdue_sold: item.pastdue_sold,
//         soldDemands: item.soldDemands,
//         soldPursuit:item.soldPursuit,
//         pursuit_curr_month: item.pursuit_curr_month,
//         pursuit_next: item.pursuit_next,
//         pursuit_future: item.pursuit_future,
//         pastdue_pursuit: item.pastdue_pursuit,
//         // currentBench:match ? match.currentBench:0,
//         rolloffs: match3 ? match3.rolloffs : 0,
//         pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
//         offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
//         offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
//         offers_future: match2 ? (match2.offers_future || 0) : 0 // Include offers_future_month from item
//       };
//     } else {
//       // Include unmatched data from finalData
//       return {
//         capability: item.capability,
//         skillGroup: item.skillGroup,
//         sold_curr_month: item.sold_curr_month,
//         sold_next_month: item.sold_next_month,
//         sold_future_month: item.sold_future_month,
//         pastdue_sold: item.pastdue_sold,
//         soldDemands: item.soldDemands,
//         soldPursuit:item.soldPursuit,
//         pursuit_curr_month: item.pursuit_curr_month,
//         pursuit_next: item.pursuit_next,
//         pursuit_future: item.pursuit_future,
//         pastdue_pursuit: item.pastdue_pursuit,
//         rolloffs: match3 ? match3.rolloffs : 0,
//         currentBench: 0,
//         pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
//         offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
//         offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
//         offers_future: match2 ? (match2.offers_future || 0) : 0 // Include offers_future_month from item
//       };
//     }
//   });
//   // console.log("Step 6: mergedData populated");
//   // console.log("mergedData:", mergedData);

//   mergedData['currentMonth'] = monthNames[curr_month - 1];
//   mergedData['nextMonth'] = monthNames[curr_month];
//   mergedData['future'] = monthNames[curr_month + 1] + '+';

//   return mergedData; // Return the month names along with the merged data
// }




demandData(P_demandBO, emp, rollOffBO, cap, supply, roldate, skill) {
  let initData = [];
  let finalData = [];
  let empbench = [];
  let final = [];
  let final3 = [];
  let supp = [];
  let fs = [];

  let rows1=0, rows2=0, rows3=0, rows4=0, rows5=0, rows6=0, rows7=0, rows8=0, rows9=0, rows10=0,rows11=0,rows12=0,rows13=0,rows14=0,rows15=0,rows16=0,rows17=0,rows18=0;

  let curdate = formatDate(new Date());

  function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  function parseDate(dateStr) {
    const parts = dateStr.split('-');
    return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
  }
  function parseDateGetMonth(dateStr) {
    const parts = dateStr.split('-');
    return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
  }

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb"];
  let d = new Date();
  let curr_month = d.getMonth() + 1;

  // Object to hold month names
  let monthData = {
    currentMonth: monthNames[curr_month - 1],
    nextMonth: monthNames[curr_month],
    future: monthNames[curr_month + 1] + '+'
  };

  // console.log("Step 1: Initializing data structures");
  // console.log("monthData:", monthData);

  // Populate initData array
  for (let i = 0; i < P_demandBO.length; i++) {
    let capabilityName = P_demandBO[i].globalPracticeObject.items[0] !== undefined ? P_demandBO[i].globalPracticeObject.items[0].name : '';

    let skillGroupName = P_demandBO[i].skillGroup && P_demandBO[i].skillGroupObject && P_demandBO[i].skillGroupObject.items && P_demandBO[i].skillGroupObject.items.length > 0
      ? P_demandBO[i].skillGroupObject.items[0].skillGroupName
      : '';

    let row = {
      capability: capabilityName,
      skillGroup: skillGroupName,
      roleStartDate: P_demandBO[i].roleStartDate,
      demandType: P_demandBO[i].demandType ? P_demandBO[i].demandType.trim() : ''
    };
    initData.push(row);
  }

  // console.log("Step 2: initData populated");
  // console.log("initData:", initData);

  // Process initData to populate finalData
  initData.forEach(data => {
    let roleStartDate = new Date(data.roleStartDate);
    let month = roleStartDate.getMonth() + 1;
    let element = finalData.find(item => item.capability === data.capability && item.skillGroup === data.skillGroup);

    if (!element) {
      let temp = {
        capability: data.capability,
        skillGroup: data.skillGroup,
        sold_curr_month: 0,
        sold_next_month: 0,
        sold_future_month: 0,
        pastdue_sold: 0,
        soldPursuit:0,
        pursuit_curr_month: 0,
        pursuit_next: 0,
        pursuit_future: 0,
        shadow:0,
        pastdue_pursuit: 0,
        soldDemands: 0,
        currentBench: 0, // Default to 0
        rolloffs: 0,
        offers_curr: 0,
        offers_next: 0,
        offers_future: 0,
        pastdue_offers: 0,
        totalOffers:0
      };

      if (data.demandType === 'Sold Project') {
        if (month === curr_month) {
          temp.sold_curr_month = 1;
        } else if (month === curr_month + 1) {
          temp.sold_next_month = 1;
        } else if (month > curr_month + 1) {
          temp.sold_future_month = 1;
        } else if (month < curr_month) {
          temp.pastdue_sold = 1;
        }
        temp.soldDemands = 1;
      } else if (data.demandType === 'Pursuit Project') {
        if (month === curr_month) {
          temp.pursuit_curr_month = 1;
        } else if (month === curr_month + 1) {
          temp.pursuit_next = 1;
        } else if (month > curr_month + 1) {
          temp.pursuit_future = 1;
        } else if (month < curr_month) {
          temp.pastdue_pursuit = 1;
        }
        temp.soldPursuit = 1;
      }

      finalData.push(temp);
    } else {
      // Update existing element in finalData
      let index = finalData.findIndex(item => item.capability === element.capability && item.skillGroup === element.skillGroup);
      if (data.demandType === 'Sold Project') {
        if (month === curr_month) {
          finalData[index].sold_curr_month += 1;
        } else if (month === curr_month + 1) {
          finalData[index].sold_next_month += 1;
        } else if (month > curr_month + 1) {
          finalData[index].sold_future_month += 1;
        } else if (month < curr_month) {
          finalData[index].pastdue_sold += 1;
        }
        finalData[index].soldDemands += 1;
      } else if (data.demandType === 'Pursuit Project') {
        if (month === curr_month) {
          finalData[index].pursuit_curr_month += 1;
        } else if (month === curr_month + 1) {
          finalData[index].pursuit_next += 1;
        } else if (month > curr_month + 1) {
          finalData[index].pursuit_future += 1;
        } else if (month < curr_month) {
          finalData[index].pastdue_pursuit += 1;
        }
        finalData[index].soldPursuit +=1;
      }
    }
  });

  // console.log("Step 3: finalData populated");
  // console.log("finalData:", finalData);

  // Populate empbench array
  emp.forEach(employee => {
    let capability = cap.find(capability => capability.id === employee.globalPractice);
    let sg1 = skill.find(ele => ele.id === employee.CapabilitySkillGroup);
    // let sg2 = skill.find(ele => ele.id === employee.skillGroup2);
    // let sg3 = skill.find(ele => ele.id === employee.skillGroup3);
    empbench.push({
      capabilities: capability !== undefined ? capability.name : '',
      skillGroup: [sg1 !== undefined ? sg1.skillGroupName : ''],
      grade : employee.grade,
      status: employee.status
    });
  });

  // console.log("Step 4: empbench populated");
  // console.log("empbench:", empbench);

  // Process empbench to populate final
  empbench.forEach(item => {
    item.skillGroup.forEach(sg => {
      if (sg) {
        let elem = final.find(data => data.capability === item.capabilities && data.skillGroup === sg);
        if (!elem) {
          let temp = {
            capability: item.capabilities,
            skillGroup: sg,
           currentBench: (item.status === 'Bench - Deployable' && item.grade != 'A') ? 1 : 0,
            shadow : item.status === 'Shadow ' ? 1: 0,
            status: item.status
          };
          final.push(temp);
        } else {
          let index = final.findIndex(data => data.capability === elem.capability && data.skillGroup === elem.skillGroup);
          if (item.status === 'Bench - Deployable' && item.grade!='A') {
            final[index].currentBench += 1;
          }else if(item.status === 'Shadow '){
            final[index].shadow +=1;
          }
        }
      }
    });
  });


   for(var e=0;e<rollOffBO.length;e++) {
  let emp2 = emp.find(ele => ele.id === rollOffBO[e].employeeID);
  if(emp2!=undefined && emp2.globalPractice!=undefined && emp2.CapabilitySkillGroup!=undefined){
    let capability = cap.find(capability => capability.id === emp2.globalPractice);
    let eskill = skill.find(ele => ele.id === emp2.CapabilitySkillGroup);

    fs.push({
      capabilities: capability !== undefined ? capability.name : '',
      skillGroup: [eskill !== undefined ? eskill.skillGroupName : ''],
      rollOfDate: rollOffBO[e].releaseDate,
      id:rollOffBO[e].employeeID
    });
  }
  }
   
  fs.forEach(item => {
    item.skillGroup.forEach(sg => {
      if (sg) {
        let elem = final3.find(data => data.capability === item.capabilities && data.skillGroup === sg);
        if (!elem) {
          let temp = {
            capability: item.capabilities,
            id :item.id,
            skillGroup: sg,
            rolloffs: (item.rollOfDate > curdate && item.rollOfDate < roldate) ? 1 : 0,
          };
          final3.push(temp);
        } else {
          let index = final3.findIndex(data => data.capability === elem.capability && data.skillGroup === elem.skillGroup);
          if (item.rollOfDate > curdate && item.rollOfDate < roldate) {
          
            final3[index].rolloffs += 1;
          }
            console.log("*",final3);
        }
      }
    });
  });
 
const uniqueArray=[];
  // Process supply array
  for (let a = 0; a < supply.length; a++) {
    let scap = cap.find(ele => ele.id == supply[a].capability); //Capability Name
    // let dojblanks= supply.filter(supply[a].doj!=null);
    let ss1 = skill.find(ele => ele.id == supply[a].skillGroup1); //Skil set 1
    let ss2 = skill.find(ele =>ele.id== supply[a].skillGroup2); //Skil set 2
    let ss3 = skill.find(ele =>ele.id== supply[a].skillGroup3); //Skil set 3

function getMonthFromDate(dateStr) {
    // Split the string into parts [YYYY, MM, DD]
    const parts = dateStr.split('-');
    // Extract the month part (parts[1]) and convert it to a number
    const month = parseInt(parts[1], 10); // Use parseInt with radix 10 to ensure correct parsing
 
    return month;
}


    let trimmedDate = supply[a].doj;
    if(supply[a].doj!= null){
      let trimmedDate = supply[a].doj.trim();
    }
    else{
      let trimmedDate = supply[a].doj;
    }
    if (scap && trimmedDate!= null && trimmedDate!== "" && supply[a].status==='8. Joined') { // Ensure doj exists before proceeding

      let dojMonth = getMonthFromDate(trimmedDate);
      //let returnDate = parseDateStringToDate(supply[a].doj);
      // if(returnDate== 'Invalid date format'){
      //   console.log("Issue with Data Formate",typeof(supply[a].doj),supply[a].id+"-"+scap.id+"-"+ss1.id );
      // }
      //let dojMonth = dojDate.getMonth() + 1; // getMonth() returns month from 0-11, so add 1
      
      //console.log('capab',scap.name,'skill1',ss1.skillGroupName,'skill2',ss2?ss2.skillGroupName:'','skill3',ss3?ss3.skillGroupName:'');
      
      
      
      initData.forEach(data => {
        if (data.capability === scap.name && (data.skillGroup === ss1.skillGroupName || data.skillGroup === ss1.skillGroupName || data.skillGroup === ss1.skillGroupName)) {

          // console.log(`Processing supply entry: ${JSON.stringify(supply[a])}`);
          // console.log(`Matched with initData: ${JSON.stringify(data)}`);
          
        // console.log("Test.........",data.capability,data.skillGroup);
        
        if(!uniqueArray.includes(supply[a].id+"-"+scap.id+"-"+ss1.id ))
        {
          console.log("Months.....",supply[a].doj,dojMonth,supply[a].id+"-"+scap.id+"-"+ss1.id);
          uniqueArray.push(supply[a].id+"-"+scap.id+"-"+ss1.id);
          // Check and add count based on dojMonth
          let element = supp.find(item => item.capability === scap.name && item.skillGroup === data.skillGroup);
          if (!element) {
            // If no element found, create a new one
            let temp1 = {
              capability: scap.name,
              skillGroup: data.skillGroup,
              sold_curr_month: 0,
              sold_next_month: 0,
              sold_future_month: 0,
              pastdue_sold: 0,
              pursuit_curr_month: 0,
              shadow:0,
              pursuit_next: 0,
              pursuit_future: 0,
              pastdue_pursuit: 0,
              soldDemands: 0,
              soldPursuit:0,
              currentBench: 0, // Default to 0
              rolloffs: 0,
              offers_curr: 0, //Present Month
              offers_next: 0, //Next Month
              offers_future: 0, //Future Month
              pastdue_offers: 0, //Before Current Month 
              totalOffers:0

            };
            if (dojMonth === curr_month) {
              temp1.offers_curr = 1;
            } else if (dojMonth === curr_month + 1) {
              temp1.offers_next = 1;
            } else if (dojMonth > curr_month + 1) {
              temp1.offers_future = 1;
            } else if (dojMonth < curr_month) {
              temp1.pastdue_offers = 1;
            }
            temp1.totalOffers = 1;
            supp.push(temp1);
          } else {
            let index = supp.findIndex(item => item.capability === scap.name && item.skillGroup === data.skillGroup);
            if (index !== -1) {
              if (dojMonth === curr_month) {
                supp[index].offers_curr += 1;
              } else if (dojMonth === curr_month + 1) {
                supp[index].offers_next += 1;
              } else if (dojMonth > curr_month + 1) {
                supp[index].offers_future += 1;
              } else if (dojMonth < curr_month) {
                supp[index].pastdue_offers += 1;
              }
              supp[index].totalOffers+=1;
            }
          }

        }

          
        //If End
        }
      });
    }
  //for loop end
 
  }
  const uniqueArr = [...new Set(uniqueArray)];
  console.log("Uni..........",uniqueArr);

  
  // console.log("Step 5: final populated");
  // console.log("supp:", supp);

  // Merge finalData with final to create mergedData
  let mergedData = finalData.map(item => {
    let match = final.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
    let match3 = final3.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
    let match2 = supp.find(subItem => subItem.capability === item.capability && subItem.skillGroup === item.skillGroup);
    if (match) {
      return {
        ...match,
        capability: item.capability,
        skillGroup: item.skillGroup,
        sold_curr_month: item.sold_curr_month,
        sold_next_month: item.sold_next_month,
        sold_future_month: item.sold_future_month,
        pastdue_sold: item.pastdue_sold,
        soldDemands: item.soldDemands,
        soldPursuit:item.soldPursuit,
        pursuit_curr_month: item.pursuit_curr_month,
        pursuit_next: item.pursuit_next,
        pursuit_future: item.pursuit_future,
        pastdue_pursuit: item.pastdue_pursuit,
        // currentBench:match ? match.currentBench:0,
        rolloffs: match3 ? match3.rolloffs : 0,
        pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
        offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
        offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
        offers_future: match2 ? (match2.offers_future || 0) : 0, // Include offers_future_month from item
        totalOffers: match2 ? (match2.totalOffers || 0) : 0
      };
    } else {
      // Include unmatched data from finalData
      return {
        capability: item.capability,
        skillGroup: item.skillGroup,
        sold_curr_month: item.sold_curr_month,
        sold_next_month: item.sold_next_month,
        sold_future_month: item.sold_future_month,
        pastdue_sold: item.pastdue_sold,
        soldDemands: item.soldDemands,
        soldPursuit:item.soldPursuit,
        pursuit_curr_month: item.pursuit_curr_month,
        pursuit_next: item.pursuit_next,
        pursuit_future: item.pursuit_future,
        pastdue_pursuit: item.pastdue_pursuit,
        rolloffs: match3 ? match3.rolloffs : 0,
        currentBench: 0,
        shadow:0,
        pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
        offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
        offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
        offers_future: match2 ? (match2.offers_future || 0) : 0, // Include offers_future_month from item
        totalOffers: match2 ? (match2.totalOffers || 0) : 0
      };
    }
  });

  // console.log("Step 6: mergedData populated");
  // console.log("mergedData:", mergedData);

  mergedData['currentMonth'] = monthNames[curr_month - 1];
  mergedData['nextMonth'] = monthNames[curr_month];
  mergedData['future'] = monthNames[curr_month + 1] + '+';
  mergedData.sort((a, b) => b.soldDemands - a.soldDemands);

      for (let i=0;i<mergedData.length;i++){
      rows1+=mergedData[i].pastdue_sold;
      rows2+= mergedData[i].sold_curr_month;
      rows3+=mergedData[i].sold_next_month;
      rows4+=mergedData[i].sold_future_month;
      rows5+=mergedData[i].soldDemands;
      rows6+=mergedData[i].pastdue_pursuit;
      rows7+=mergedData[i].pursuit_curr_month;
      rows8+=mergedData[i].pursuit_next;
      rows9+=mergedData[i].pursuit_future;
      rows10+=mergedData[i].soldPursuit;
      rows11+=mergedData[i].currentBench;
      rows12+=mergedData[i].shadow;
      rows13+=mergedData[i].rolloffs;
      rows14+=mergedData[i].pastdue_offers;
      rows15+=mergedData[i].offers_curr;
      rows16+=mergedData[i].offers_next;
      rows17+=mergedData[i].offers_future;
      rows18+=mergedData[i].totalOffers;
      
      
    };
    let temp1={};
    temp1['capability']='Total';
    temp1['pastdue_sold']=rows1;
    temp1['sold_curr_month']=rows2;
    temp1['sold_next_month']=rows3;
    temp1['sold_future_month']=rows4;
    temp1['soldDemands']=rows5;
    temp1['pastdue_pursuit']=rows6;
    temp1['pursuit_curr_month']=rows7;
    temp1['pursuit_next']=rows8;
    temp1['pursuit_future']=rows9;
    temp1['soldPursuit']=rows10;
    temp1['currentBench']=rows11;
    temp1['shadow']=rows12;
    temp1['rolloffs']=rows13;
    temp1['pastdue_offers']=rows14;
    temp1['offers_curr']=rows15;
    temp1['offers_next']=rows16;
    temp1['offers_future']=rows17;
    temp1['totalOffers']=rows18;
    let countOfRecords = mergedData.length;
    mergedData.push(temp1);
  
  return { mergedData, countOfRecords }; // Return the month names along with the merged data
}



 demandHyper(demand, cap, skill,key,row,sectorr,clientt,emprop) {
      let data = [];
      let dat = new Date();
      let curr_monthvar = dat.getMonth() + 1;
      for (var i = 0; i < demand.length; i++) {
        var rett = {};
        let rolestartdate = new Date(demand[i].roleStartDate);
        let monthd = rolestartdate.getMonth() + 1;
        let capa = cap.find(ele => ele.id == demand[i].globalPractice);
        let ski = skill.find(ele => ele.id == demand[i].skillGroup);
        let sect = sectorr.find(ele => ele.id == demand[i].sector);
        let cli = clientt.find(ele => ele.id == demand[i].client);

        if((capa!=undefined && ski!=undefined) && row.capability===capa.name && row.skillGroup===ski.skillGroupName){
        if(demand[i].demandType=="Sold Project"){
        if (monthd < curr_monthvar && key=='2') {
          rett['trno'] = demand[i].teamRequestNumber;
          rett['dt'] = demand[i].demandType;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
             rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          data.push(rett);
        }
        else if(monthd ===curr_monthvar && key=='3'){
              rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['dt'] = demand[i].demandType;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
               rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          data.push(rett);
        }
        else if(monthd === curr_monthvar +1 && key=='4'){
            rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['dt'] = demand[i].demandType;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
               rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          data.push(rett);
        }
        else if(monthd > curr_monthvar +1 && key=='5'){
             rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['dt'] = demand[i].demandType;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
               rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          data.push(rett);
        }
        else if(key=='6'){
             rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['dt'] = demand[i].demandType;
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
              rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
            rett['client1'] = cli != undefined ? cli.clientName : '';
          data.push(rett);
        }
        }
        if(demand[i].demandType=="Pursuit Project"){
         if (monthd < curr_monthvar && key=='7') {
          rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['dt'] = demand[i].demandType;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
              rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
            rett['client1'] = cli != undefined ? cli.clientName : '';
          data.push(rett);
        }
        else if(monthd ===curr_monthvar && key=='8'){
              rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['dt'] = demand[i].demandType;
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
              rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
            rett['client1'] = cli != undefined ? cli.clientName : '';
          data.push(rett);
        }
        else if(monthd === curr_monthvar +1 && key=='9'){
            rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
          rett['dt'] = demand[i].demandType;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
               rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          data.push(rett);
        }
        else if(monthd > curr_monthvar +1 && key=='10'){
             rett['trno'] = demand[i].teamRequestNumber;
             rett['dt'] = demand[i].demandType;
          rett['capability'] = capa != undefined ? capa.name : '';
             rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
          data.push(rett);
        }
        else if(key=='11'){
             rett['trno'] = demand[i].teamRequestNumber;
          rett['capability'] = capa != undefined ? capa.name : '';
             rett['empropCount'] = emprop.filter(emp => emp.teamRquestNumber == demand[i].id).length;
          rett['sg'] = ski != undefined ? ski.skillGroupName : '';
          rett['dt'] = demand[i].demandType;
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
           rett['sector1'] = sect != undefined ? sect.name : '';
            rett['client1'] = cli != undefined ? cli.clientName : '';
          data.push(rett);
        }
        }
        }

      }
      return data;
    };

    benchHyper(empBO,capBO,skillBO,row,emprop){
      var x=[];
      let count=0;
      for(var j=0;j<empBO.length;j++){
        var y={};
        let capn = capBO.find(ele=>ele.id==empBO[j].globalPractice);
        let skilln = skillBO.find(ele=>ele.id==empBO[j].CapabilitySkillGroup);
        if((capn!=undefined && skilln!=undefined) && capn.name === row.capability && row.skillGroup === skilln.skillGroupName){
          if(empBO[j].status === 'Bench - Deployable' && empBO[j].grade!='A'){
            y['empID']=empBO[j].employeeID;
            y['name']=empBO[j].name;
              y['BoID']=empBO[j].id;
            y['lg']=empBO[j].grade;
            y['capability']=capn.name;
            y['sg'] = skilln.skillGroupName;
             y['empropCount'] =emprop.filter(emp => emp.employeeID == empBO[j].id).length;
            x.push(y);
          }

        }
      }
        x.sort((a, b) => {
    const gradeOrder = ['F', 'E', 'D', 'C', 'B', 'A'];
    return gradeOrder.indexOf(a.lg) - gradeOrder.indexOf(b.lg);
  });
      return x;
    };
  
  shadowHyper(emp,cap,skill,row){
    var z=[];
    for(var i=0;i<emp.length;i++){
      var t={};
       let capm = cap.find(ele=>ele.id==emp[i].globalPractice);
       let skillm = skill.find(ele=>ele.id==emp[i].CapabilitySkillGroup);
      if((capm!=undefined && skillm!=undefined) && capm.name === row.capability && row.skillGroup === skillm.skillGroupName){
        if(emp[i].status==='Shadow '){
          t['eid']=emp[i].employeeID;
          t['grade']=emp[i].localGrade;
          t['name']=emp[i].name;
          t['BoID']=emp[i].id;
          z.push(t);

        }
      }
    }
     z.sort((a, b) => {
    const gradeOrder = ['A5', 'A4'];
    return gradeOrder.indexOf(a.grade) - gradeOrder.indexOf(b.grade);
  });
    return z;
   

  }

    rolloffHyper(c,s,e,rol,row,roldate,emprop){
      var d=[];
      let curdate = formatDate(new Date());

  function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }
      for(var q=0;q<rol.length;q++){
        var edt = e.find(ele=>ele.id==rol[q].employeeID);
        if(edt!=undefined && edt.CapabilitySkillGroup!=undefined){
        var cdt = c.find(ele=>ele.id==edt.globalPractice);
        var sdt = s.find(ele=>ele.id==edt.CapabilitySkillGroup);
        }
        var t={};
        if(cdt!=undefined && row.capability === cdt.name && row.skillGroup === sdt.skillGroupName){
          if(rol[q].releaseDate > curdate && rol[q].releaseDate < roldate){
            t['empID']=edt!=undefined ? edt.employeeID:'';
             t['BoID']=edt!=undefined ? edt.id:'';
            t['name']=edt!=undefined ? edt.name:'';
            t['capability']=cdt!=undefined?cdt.name:'';
            t['lg']=edt.grade;
            t['sg']=sdt!=undefined?sdt.skillGroupName:'';
            t['releaseDate']=rol[q].releaseDate;
             t['empropCount'] = emprop.filter(emp => emp.employeeID == edt.id).length;
            d.push(t);
           }
      }
    }
          d.sort((a, b) => {
    const gradeOrder = ['F', 'E', 'D', 'C', 'B', 'A'];
    return gradeOrder.indexOf(a.lg) - gradeOrder.indexOf(b.lg);
  });
    return d;
    };

    supplyHyper(cap,skill,supply,row,key){
      var data=[];
      let dat = new Date();
         let curr_monthvar = dat.getMonth() + 1;
      function getMonthFromDate(dateStr) {
    // Split the string into parts [YYYY, MM, DD]
    const parts = dateStr.split('-');
    // Extract the month part (parts[1]) and convert it to a number
    const month = parseInt(parts[1], 10); // Use parseInt with radix 10 to ensure correct parsing
 
    return month;
}

      for(var g=0;g<supply.length;g++){
        let cn = cap.find(ele=>ele.id==supply[g].capability);
        let s1 = skill.find(ele=>ele.id==supply[g].skillGroup1);
        let s2 = skill.find(ele=>ele.id==supply[g].skillGroup2);
         let s3 = skill.find(ele=>ele.id==supply[g].skillGroup3);
         let trimmedDate = supply[g].doj;
         var rett={};
    if(supply[g].doj!= null){
      let trimmedDate = supply[g].doj.trim();
    }
    else{
      let trimmedDate = supply[g].doj;
    }
    if (cn && trimmedDate!= null && trimmedDate!== ""&& s1!=undefined ) { // Ensure doj exists before proceeding
      let dojMonth = getMonthFromDate(trimmedDate);
      if(row.capability===cn.name && row.skillGroup === s1.skillGroupName && supply[g].status==='8. Joined'){
         if (dojMonth < curr_monthvar && key=='15') {
          rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['profileID']=supply[g].profileID;
          rett['capability'] = cn != undefined ? cn.name : '';
          rett['sg'] = row.skillGroup;
          data.push(rett);
        }
        else if(dojMonth === curr_monthvar && key=='16'){
                rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['capability'] = cn != undefined ? cn.name : '';
          rett['sg'] = row.skillGroup;
          rett['profileID']=supply[g].profileID;
          data.push(rett);
        }
        else if(dojMonth === curr_monthvar +1 && key=='17'){
              rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['capability'] = cn != undefined ? cn.name : '';
          rett['sg'] = row.skillGroup;
          rett['profileID']=supply[g].profileID;
          data.push(rett);
        }
        else if(dojMonth > curr_monthvar +1 && key=='18'){
              rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['profileID']=supply[g].profileID;
          rett['capability'] = cn != undefined ? cn.name : '';
          rett['sg'] = row.skillGroup;
          data.push(rett);
        }
        else if( key=='19'){
              rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['profileID']=supply[g].profileID;
          rett['capability'] = cn != undefined ? cn.name : '';
          rett['sg'] = row.skillGroup;
          data.push(rett);
        } 
      }
      }
   
      }
         return data;
    };


    caphyp(emp,row){
      var u=[];
      for(var t=0;t<emp.length;t++){
        var w={};
        let cap = emp[t].globalPracticeObject.items!=undefined? emp[t].globalPracticeObject.items[0].name:'';
        let sk = emp[t].capabilitySkillGroupObject.items!=undefined?emp[t].capabilitySkillGroupObject.items[0].skillGroupName:'';
        let retd = emp[t].retentionBOCollection.items!=undefined?emp[t].retentionBOCollection.items[0].resignationDate:'';
        let lwd =emp[t].retentionBOCollection.items!=undefined?emp[t].retentionBOCollection.items[0].lastWorkingDate:'';
        if((cap!=undefined && sk!=undefined) && row.capability === cap && row.skillGroup === sk){
        w['empID']=emp[t].employeeID;
        w['BoID']=emp[t].id;
        w['name']=emp[t].name;
        w['resignationDate']=retd;
        w['lwd']=lwd;
        w['grade']=emp[t].grade;
        u.push(w);
      }
      }
        u.sort((a, b) => {
    const gradeOrder = ['F', 'E', 'D', 'C', 'B', 'A'];
    return gradeOrder.indexOf(a.grade) - gradeOrder.indexOf(b.grade);
  });
      return u;
    };

    proposalHyp(emprop){
      var w=[];
      for(var q=0;q<emprop.length;q++){
        var s={};
        let demands = emprop[q].teamRquestNumberObject!=undefined?emprop[q].teamRquestNumberObject.items[0].teamRequestNumber:'';
        s['trno']=demands;
        s['tol'] =emprop[q].loctType;
        s['pdate']=emprop[q].proposalDate;
        s['eid'] = emprop[q].employeeIDObject.items[0].employeeID;
        s['name'] = emprop[q].employeeIDObject.items[0].name;
        s['grade'] = emprop[q].employeeIDObject.items[0].grade;
        w.push(s);
      }
      return w;
    };

    skillhypdemand(demand){
      var dataS=[];
      var dataP=[];
      for(var i=0;i<demand.length;i++){
        var rett={};
         rett['trno'] = demand[i].teamRequestNumber;
          rett['dt'] = demand[i].demandType;
          rett['rolestartdate'] = demand[i].roleStartDate;
          rett['trn'] = demand[i].teamRequestName;
          if (demand[i].demandType == "Sold Project") {
        dataS.push(rett);
      } else if(demand[i].demandType=="Pursuit Project"){
        dataP.push(rett);
      }
      }
       return { sold: dataS, pursuit: dataP };
    };
  
  skillhypbench(emp){
    var a=[];
    if(Array.isArray(emp) && emp.length !== 0){
    for(var b=0;b<emp.length;b++){
      var y={};
       if(emp[b].status === 'Bench - Deployable'){
            y['empID']=emp[b].employeeID;
            y['BoID']=emp[b].id;
            y['name']=emp[b].name;
            y['lg']=emp[b].grade;
            a.push(y);
          }
    }
          a.sort((a, b) => {
    const gradeOrder = ['F', 'E', 'D', 'C', 'B', 'A'];
    return gradeOrder.indexOf(a.lg) - gradeOrder.indexOf(b.lg);
  });
    }
  return a;
  };


  skillhyproff(rol,roldate,e,row,c,s){
    var d=[];
      let curdate = formatDate(new Date());

  function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }
        for(var q=0;q<rol.length;q++){
        var edt = e.find(ele=>ele.id==rol[q].employeeID);
        if(edt!=undefined && edt.CapabilitySkillGroup!=undefined){
        var cdt = c.find(ele=>ele.id==edt.globalPractice);
        var sdt = s.find(ele=>ele.id==edt.CapabilitySkillGroup);
        }
        if(cdt!=undefined && sdt!=undefined){
        if(row.capability === cdt.name && row.skillGroup === sdt.skillGroupName){
          if(rol[q].releaseDate > curdate && rol[q].releaseDate < roldate){
             var t={};
            t['empID']=edt!=undefined ? edt.employeeID:'';
            t['name']=edt!=undefined ? edt.name:'';
            t['lg']=edt!=undefined?edt.grade:'';
            t['rd']=rol[q].releaseDate;
            t['BoID']=rol[q].id;
            if(t.empID!='' && t.name!=''&&t.lg!=''){
            d.push(t);
            }
           }
      }
      }
    }
    return d;
  };

  skillhypoffers(supply,emp){
     var data=[];
   
      for(var g=0;g<supply.length;g++){
       let el1 = emp.find(ele=>ele.id==supply[g].panelL1);
       let el2 = emp.find(ele=>ele.id==supply[g].panelL2);
         var rett={};
      
          rett['doj'] = supply[g].doj;
          rett['status']=supply[g].status;
          rett['name']=supply[g].name;
          rett['email']=supply[g].email;
          rett['location']=supply[g].location;
          rett['pl1']=el1!=undefined?el1.email:'';
          rett['pl2']=el2!=undefined?el2.email:'';
          rett['sentcap']=supply[g].profileSentToCapability;
          rett['profr']=supply[g].profileReceived;
          rett['phn']=supply[g].phoneNumber;
          rett['profileID']=supply[g].profileID;
          rett['reccap']=supply[g].decisionReceivedFromCap;
          rett['rod']=supply[g].offerRolledOutDate;
          data.push(rett);
    
      }
         return data;
    };
  
  skillStatusesOffers(supply, row, skill) {
    var y = [];
    var statuses = [
        '2. Awaiting Selection Decision (CAPABILITY)',
        '2.1. Awaiting Client Interview (PDL / DM)',
        '3. Forward for Offer Roll Out (PSC)',
        '4. Awaiting Offer Roll Out (RECRUITMENT)',
        '5. Awaiting Joining (PDL / DM)',
        '8. Joined'
    ];

    // Initialize counts for each status
    var statusCounts = statuses.map(status => ({ status: status, count: 0 }));

    for (var i = 0; i < supply.length; i++) {
        let sn = skill.find(sele => sele.id == supply[i].skillGroup1);
        if (sn && row.skillGroup === sn.skillGroupName) {
            // Find the index of the current supply item's status in the statuses array
            let statusIndex = statuses.indexOf(supply[i].status);
            if (statusIndex !== -1) {
                // Increment the count for the corresponding status
                statusCounts[statusIndex].count += 1;
            }
        }
    }

    return statusCounts;
}

  
  skillhyproposals(emprop,emp,row,cap,skill){
    var e=[];
    for(var h=0;h<emprop.length;h++){
      var d={};
      let edetail = emp.find(ele=>ele.id==emprop[h].employeeID);
      if(edetail!=undefined){
      let cn = cap.find(cele=>cele.id==edetail.globalPractice);
      let sn = skill.find(sele=>sele.id==edetail.CapabilitySkillGroup);
      if(cn!=undefined && sn!=undefined){
        if(cn.name === row.capability && row.skillGroup === sn.skillGroupName){
          d['empID']=edetail.employeeID;
          d['name']=edetail.name;
          
          d['did']=emprop[h].teamRequestNumber;
          d['status']=emprop[h].status;
          e.push(d);
        }
      }
      }
    }
    return e;
  };

  



    dateset() {
      var rollOfDate = new Date();
      var currentDate = new Date();

      //setting the rollof date to 30 days from current date
      rollOfDate.setDate(currentDate.getDate() + 30);
      var dd = String(rollOfDate.getDate()).padStart(2, '0');
      var mm = String(rollOfDate.getMonth() + 1).padStart(2, '0');
      var yyyy = rollOfDate.getFullYear();

      rollOfDate = yyyy + '-' + mm + '-' + dd;
      return rollOfDate;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    downloadLateral(down) {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('EmployeeID');
        retpayload.push('Employee Name');
        retpayload.push('Grade');
        retpayload.push('Capability');
        retpayload.push('Capability Skill Group');
        retpayload.push('Competency');
        retpayload.push('Competency Skill Group 1');
        retpayload.push('Competency Skill Group 2');
        retpayload.push('Competency Skill Group 3');
        retpayload.push('Bench Ageing');

      }
      else{
        retpayload.push(down[i-1].empid);
        retpayload.push(down[i-1].name);
        retpayload.push(down[i-1].grade);
        retpayload.push(down[i-1].cap);
        retpayload.push(down[i-1].csg);
        retpayload.push(down[i-1].cg);
        retpayload.push(down[i-1].sg1);
        retpayload.push(down[i-1].sg2);
        retpayload.push(down[i-1].sg3);
        retpayload.push(down[i-1].ba);

      }
      data.push(retpayload);
    }
     return data;
  };
   xlLateral(innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" Lateral Supply  Data");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" Lateral Supply  Data"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
      function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Lateral Supply  Data_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };


    downloadstale(down) {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('Demand ID');
        retpayload.push('Account');
        retpayload.push('Capability');
        retpayload.push('Skill Group');
        retpayload.push('Role Start Date');
        retpayload.push('Demand Creation Date');


      }
      else{
        retpayload.push(down[i-1].tid);
        retpayload.push(down[i-1].account);
        retpayload.push(down[i-1].capability);
        retpayload.push(down[i-1].sg);
        retpayload.push(down[i-1].sd);
        retpayload.push(down[i-1].dc);


      }
      data.push(retpayload);
    }
     return data;
  };
   xlstale(innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" Stale Demands Data");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" Stale Demands Data"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
      function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Stale Demands Data_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };

    
      downloadPastDue(down) {
    var data=new Array();
    for(var i=0;i<=down.length;i++){
      var retpayload=new Array();
      if(i==0){
        retpayload.push('Demand ID');
        retpayload.push('Role Start Date');
        retpayload.push('Capability');
        retpayload.push('Skill Group');
        retpayload.push('Sector');
        retpayload.push('Client');
        retpayload.push('Project Name');
        retpayload.push('Position Name');


      }
      else{
        retpayload.push(down[i-1].teamRequestNumber);
        retpayload.push(down[i-1].roleStartDate);
        retpayload.push(down[i-1].globalPractice);
        retpayload.push(down[i-1].skillGroup);
        retpayload.push(down[i-1].sector);
        retpayload.push(down[i-1].client);
        retpayload.push(down[i-1].projectName);
        retpayload.push(down[i-1].positionName);


      }
      data.push(retpayload);
    }
     return data;
  };
   xlPastDue(innerArray)  {
   var wb = XLSX.utils.book_new();
    wb.SheetNames.push(" Past Due  Data");
    var ws = XLSX.utils.aoa_to_sheet(innerArray);
    wb.Sheets[" Past Due  Data"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});
      function FileToBytes(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++)
            view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    }
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Past Due  Data_" + new Date().toISOString().split('T')[0] + ".xlsx";
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };

 convertDateFormat(inputDate) {

    // Parse the input date string
    const date = new Date(inputDate);

    // Months array for mapping month index to month name abbreviation
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Extract day, month, and year components
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear().toString().substr(-2); // Get last 2 digits of the year

    // Extract hour, minute, and second components
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');
    const second = date.getSeconds().toString().padStart(2, '0');

    // Construct the formatted date string
    const formattedDate = `${day}-${month}-${year} ${hour}:${minute}:${second}`;

    return formattedDate;

};
    
  }
  
   PageModule.prototype.exportToPDF = function () {

    // var images = document.querySelectorAll("#downloadImage")
    // for (var i = 0, len = images.length; i < len; i++) {
    //   images[i].removeAttribute(":src");
    // }
    domtoimage.toPng(document.getElementById('table-id-to-export'))
      .then(function (blob) {
        var pdf = new jsPDF('l', 'pt', [$('#table-id-to-export').width(), $('#table-id-to-export').height()]);
        pdf.addImage(blob, 'PNG', 0, 0, $('#table-id-to-export').width(), $('#table-id-to-export').height());
        pdf.save("Capability.pdf");


      });
  
  };

  PageModule.prototype.getAvailableDemandsData = function (P_Data) {
    var retPayload = [];
    for (var i = 0; i < P_Data.length; i++) {
      var temp = {};

      temp['trn'] = P_Data[i].teamRequestNumber;
      temp['demandType'] = P_Data[i].demandType;
      temp['localGrade'] = P_Data[i].localGrade;
      temp['creationDate'] = P_Data[i].creationDate;
      temp['roleStartDate'] = P_Data[i].roleStartDate;
      temp['sector'] = P_Data[i].sectorObject.items[0].name;
      temp['client'] = P_Data[i].clientObject.items[0].clientName;
      temp['project'] = P_Data[i].projectName;
      temp['position'] = P_Data[i].positionName;
      temp['capability'] = P_Data[i].globalPracticeObject.items[0].name;
      temp['skillGroup'] = P_Data[i].skillGroupObject.items[0].skillGroupName;
      temp['status'] = P_Data[i].status;

      retPayload.push(temp);
    }

    console.log(retPayload);
    return retPayload;
  };
  

  PageModule.prototype.createEmployeeSkillArray=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     var empSkillArray=new Array(); 

    for(var index=0;index<empSkillBO.length;index++){

     var skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
      var skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      var capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      var empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}';
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
    }
    
return empSkillArray;

  };

PageModule.prototype.assignCommunitywithSkillGroup = function (P_Emp) {
     var retpayload = {};

    if(P_Emp.globalPractice != null){
        //  if (P_Emp.globalPractice && P_Emp.globalPracticeObject && P_Emp.globalPracticeObject.items && P_Emp.globalPracticeObject.items.length > 0) {
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  };

PageModule.prototype.getDefaultedMonth=function(tcBO){

  let data = [];
  let currentYear = (new Date()).getFullYear();
  let def = tcBO.filter(ele => ele.defaultedYear == currentYear);
  let retpayload = {};
  retpayload['month'] = "Year : " + currentYear;
  let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  for (let i = 0; i < months.length; i++) {
    let month = months[i].toLowerCase().substring(0, 3);
    if (i < (new Date()).getMonth()+1) {
      retpayload[month] = def.find(ele => ele.defaultedMonth == months[i]) == undefined ? 'N' : def.find(ele => ele.initialFlag == 'Issue') ? 'N' : 'Y';
    } else {
      retpayload[month] = '-';
    }
  }
  data.push(retpayload);
  return data;
};

  PageModule.prototype.postAllData = function (E_cyl,E_mas,E_main) {

 let data = [];
     for(let i=0; i<E_main.length;i++){

       let retpayload = {};

       let ele=E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO);

       retpayload ['awardName']= E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO).awardName;

        retpayload ['yearMonth']= E_main[i].yearMonth;

        retpayload['rRType']=E_mas.find(recele =>recele.id == ele.recognisationMasterBO).rRType;

        data.push(retpayload);

     }

     console.log(">>",data);

    return data;

  };

   PageModule.prototype.getEmpProjAllocationData = function (P_EmpProjAllocBO,P_ClientBO,P_ProjectBO) {
    console.log('##1717',P_EmpProjAllocBO);
    let data = [];
       
    for(let i=0; i<P_EmpProjAllocBO.length; i++){
      let retpayload = {};
      let cliele = P_ClientBO.find(cliele => cliele.id == P_EmpProjAllocBO[i].client);
      let projele = P_ProjectBO.find(projele => projele.id == P_EmpProjAllocBO[i].project);
      
    if(P_EmpProjAllocBO[i].allocationEndDate == "2000-01-01" ){
      console.log('##12true');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = '';
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    else{
      console.log('##11false');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = P_EmpProjAllocBO[i].allocationEndDate;
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    console.log('##24',retpayload);    
    }
    return(data);
  };


PageModule.prototype.totalCrediHrsFunction = function (T_main) {
    let totalcredithrs = 0;
    let totalcreditHrs;
    let credithrs;
    if(T_main.length == 0){
      totalcreditHrs = '0 hrs';
    }
    else{
      for (let i = 0;i<T_main.length;i++){
        credithrs=T_main[i].creditHrs;
       totalcredithrs += Number(credithrs);

      }
      totalcreditHrs = totalcredithrs.toFixed(2) + ' hrs';
    }
        
   return totalcreditHrs;
  };

   PageModule.prototype.q = function (current) {
     let query="status='ADMIN APPROVED' AND (coAuthor ='"+current+"' OR author ='"+current+"' OR coAuthor2 ='"+current+"'OR coAuthor3 ='"+current+"')";
    return query;
  };


    PageModule.prototype.getCurrentYear = function () {
    let date = new Date().toISOString().split('T')[0];
    let currentYr = new Date(date).getFullYear();
    console.log('@@currYr',currentYr);
    return currentYr;
 
  };

   PageModule.prototype.getLinkedDemandsData = function (P_LinkBO, P_Capab, P_Sector, P_Client, P_Skill) {
    var retPayload = [];
    for (var i = 0; i < P_LinkBO.length; i++) {
      var temp = {};

      var capab = P_Capab.find(ele => ele.id == P_LinkBO[i].demandIDObject.items[0].globalPractice);
      var skill = P_Skill.find(ele => ele.id == P_LinkBO[i].demandIDObject.items[0].skillGroup);
      var sector = P_Sector.find(ele => ele.id == P_LinkBO[i].demandIDObject.items[0].sector);
      var client = P_Client.find(ele => ele.id == P_LinkBO[i].demandIDObject.items[0].client);

      temp['trn'] = P_LinkBO[i].demandIDObject.items[0].teamRequestNumber;
      temp['demandType'] = P_LinkBO[i].demandIDObject.items[0].demandType;
      temp['localGrade'] = P_LinkBO[i].demandIDObject.items[0].localGrade;
      temp['creationDate'] = P_LinkBO[i].demandIDObject.items[0].creationDate;
      temp['roleStartDate'] = P_LinkBO[i].demandIDObject.items[0].roleStartDate;
      temp['sector'] = sector != undefined ? sector.name : '';
      temp['client'] = client != undefined ? client.clientName : '';
      temp['project'] = P_LinkBO[i].demandIDObject.items[0].projectName;
      temp['position'] = P_LinkBO[i].demandIDObject.items[0].positionName;
      temp['capability'] = capab != undefined ? capab.name : '';
      temp['skillGroup'] = skill != undefined ? skill.skillGroupName : '';
      temp['status'] = P_LinkBO[i].demandIDObject.items[0].status;
      temp['map'] = P_LinkBO[i].allocationType;

      retPayload.push(temp);
    }

    console.log(retPayload);
    return retPayload;
  };

   PageModule.prototype.checkUserRole = function (P_ProfileObject, P_UserBODetails, P_CapabilityBO) {
    var retPayload = {};
    retPayload['prevPanelL1'] = P_ProfileObject.panelL1;
    retPayload['prevPanelL2'] = P_ProfileObject.panelL2;
    retPayload['prevPanelL3'] = P_ProfileObject.panelL3;
    retPayload['prevPanelL4'] = P_ProfileObject.clientInterview;
    var l1date = "";
    var l2date = "";
    var l3date = "";
    var cdate = "";
    var now = new Date().toLocaleDateString('en-GB');
    var [day, month, year] = now.split('/');
    month = month - 1;
    var curDate = [year, month, day].join('-');
    if (P_ProfileObject.l1InterviewDate != null) {
      var [year, month, day] = P_ProfileObject.l1InterviewDate.split('-');
      month = month - 1;
      l1date = [year, month, day].join('-');
    }
    if (P_ProfileObject.l2InterviewDate != null) {
      var [year1, month1, day1] = P_ProfileObject.l2InterviewDate.split('-');
      month1 = month1 - 1;
      l2date = [year1, month1, day1].join('-');
    }
    if (P_ProfileObject.l3InterviewDate != null) {
      var [year, month, day] = P_ProfileObject.l3InterviewDate.split('-');
      month = month - 1;
      l3date = [year, month, day].join('-');
    }
    if (P_ProfileObject.clientInterviewDate != null) {
      var [year, month, day] = P_ProfileObject.clientInterviewDate.split('-');
      month = month - 1;
      cdate = [year, month, day].join('-');
    }


 var userRoleDetails = P_UserBODetails.find(function (data) { return (data.roleIdObject.items[0].roleName == "Profile Coordinator" || data.roleIdObject.items[0].roleName == "Capability Lead" || data.roleIdObject.items[0].roleName == "PSC" || data.roleIdObject.items[0].roleName == "Panel" || data.roleIdObject.items[0].roleName == "Recruitment" || data.roleIdObject.items[0].roleName == "Recruitment CL" || data.roleIdObject.items[0].roleName == "Extended Leadership"); });
    //console.log("@AA :" + userRoleDetails);
    // console.log("@AAQ" + userRoleDetails.roleIdObject.items[0].roleName);
    if (userRoleDetails != undefined) {
      if (P_ProfileObject.panelL1 == userRoleDetails.employeeId ) {
        if (P_ProfileObject.interviewStatus == 'Awaiting L1') {
          retPayload['l1FeedbackUploaded'] = false;
          retPayload['L1action'] = false;
        }
        retPayload['role'] = "PanelL1";
        retPayload['recommendedGrade'] = false;
        retPayload['doj'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['location'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
      }
      else if (P_ProfileObject.panelL2 == userRoleDetails.employeeId) {
        if (P_ProfileObject.interviewStatus == 'Awaiting L2') {
          retPayload['l2FeedbackUploaded'] = false;
          retPayload['L2action'] = false;
        }
        retPayload['role'] = "PanelL2";
        retPayload['recommendedGrade'] = false;
        retPayload['doj'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['location'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
      }
      else if (P_ProfileObject.panelL3 == userRoleDetails.employeeId) {
        if (P_ProfileObject.interviewStatus == 'Awaiting L3') {
          retPayload['l3FeedbackUploaded'] = false;
          retPayload['L3action'] = false;
        }
        retPayload['role'] = "PanelL3";
        retPayload['recommendedGrade'] = false;
        retPayload['doj'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['location'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
      }
      else if (P_ProfileObject.clientInterview == userRoleDetails.employeeId) {
        if (P_ProfileObject.interviewStatus == 'Awaiting Client Interview') {
          retPayload['l4FeedbackUploaded'] = false;
          retPayload['L4action'] = false;
        }
        retPayload['role'] = "PanelL4";
        retPayload['recommendedGrade'] = false;
        retPayload['doj'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['location'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
      }
      else if (userRoleDetails.roleIdObject.items[0].roleName == 'Recruitment') {
        console.log("In11");
        retPayload['role'] = "Recruitment";
        if (P_ProfileObject.status == "4. Awaiting Offer Roll Out (RECRUITMENT)" || P_ProfileObject.status == "5. Awaiting Joining (PDL / DM)") {
          console.log("In12");
          retPayload['status'] = false;
        }
        retPayload['recommendedGrade'] = false;
        retPayload['phoneNumber'] = false;
        retPayload['secondaryPhoneNumber'] = false;
        retPayload['email'] = false;
        retPayload['location'] = false;
        retPayload['doj'] = false;
        retPayload['comments'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
        retPayload['employeeID'] = false;
        retPayload['accountJoiningFor'] = false;
        retPayload['additionalSourceInformation'] = false;
        retPayload['panelL1'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL2'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL3'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL4'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l1InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l2InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l3InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['clientInterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l1InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l2InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l3InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['clientInterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;

        console.log("In13");

      }
      else if (userRoleDetails.roleIdObject.items[0].roleName == 'Profile Coordinator') {
        retPayload['role'] = "Profile Coordinator";
        retPayload['activeFlag'] = false;
        retPayload['capability'] = false;
        retPayload['comments'] = false;
        retPayload['doj'] = false;
        retPayload['email'] = false;
        retPayload['format'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
        retPayload['location'] = false;
        retPayload['name'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['phoneNumber'] = false;
        retPayload['secondaryPhoneNumber'] = false;
        retPayload['recommendedGrade'] = false;
        retPayload['rejectionReasonComments'] = false;
        retPayload['sfID'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['source'] = false;
        retPayload['status'] = false;

        retPayload['panelL1'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL2'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL3'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['panelL4'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l1InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l2InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l3InterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['clientInterviewDate'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l1InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l2InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['l3InterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['clientInterviewTime'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;

        retPayload['employeeID'] = false;
        retPayload['stepCategory'] = (P_ProfileObject.status == "0. Sent Back for Profile Completeness (RECRUITMENT)") ? false : true;
    retPayload['L1action'] = false;
    retPayload['L2action'] = false;
    retPayload['L3action'] = false;
    retPayload['L4action'] = false;
    retPayload['l1FeedbackUploaded'] = false;
    retPayload['l2FeedbackUploaded'] = false;
    retPayload['l3FeedbackUploaded'] = false;
    retPayload['l4FeedbackUploaded'] = false;
    retPayload['l1FeedbackFile'] = P_ProfileObject.l1FeedbackUploaded != null ? true : false;
    retPayload['l2FeedbackFile'] = P_ProfileObject.l2FeedbackUploaded != null ? true : false;
    retPayload['l3FeedbackFile'] = P_ProfileObject.l3FeedbackUploaded != null ? true : false;
    retPayload['l4FeedbackFile'] = P_ProfileObject.clientInterviewFeedback != null ? true : false;
      }
      else if (userRoleDetails.roleIdObject.items[0].roleName == 'PSC') {
        retPayload['role'] = "PSC";
        if (P_ProfileObject.status == "3. Forward for Offer Roll Out (PSC)") {
          retPayload['status'] = false;
        }
        retPayload['sfID'] = false;
        retPayload['comments'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
      }
      else if (userRoleDetails.roleIdObject.items[0].roleName == 'Extended Leadership'|| userRoleDetails.roleIdObject.items[0].roleName == 'Panel') {
        retPayload['role'] = "Extended Leadership";
        
        retPayload['downloadProfile'] = false;
      }
      else {
        retPayload['role'] = "Others";
      }

      console.log("@ee" + P_CapabilityBO.recruitmentCL1);
      console.log("@ee id" + userRoleDetails.employeeId);
        var emp =  P_UserBODetails.find(ele => ele.roleId == '33');
       
      if (P_CapabilityBO.lead1 == userRoleDetails.employeeId || P_CapabilityBO.lead2 == userRoleDetails.employeeId || (emp!=undefined ? emp.roleIdObject.items[0].roleName == 'Recruitment CL' && userRoleDetails.employeeIdObject.items[0].globalPractice == P_ProfileObject.capability : P_CapabilityBO.recruitmentCL1 == userRoleDetails.employeeId || P_CapabilityBO.recruitmentCL2 == userRoleDetails.employeeId)) {
        retPayload['role'] = "Capability Lead";
        retPayload['recommendedGrade'] = false;
        retPayload['doj'] = false;
        retPayload['skillGroup1'] = false;
        retPayload['skillGroup2'] = false;
        retPayload['skillGroup3'] = false;
        retPayload['location'] = false;
        retPayload['noticePeriod'] = false;
        retPayload['downloadProfile'] = false;
        retPayload['updateDetails'] = false;
        retPayload['status'] = (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") ? false : true;
        retPayload['rejectionReasonComments'] = false;
        retPayload['comments'] = false;
        retPayload['panelL1'] = false;
        retPayload['panelL2'] = false;
        retPayload['panelL3'] = false;
        retPayload['panelL4'] = false;
        retPayload['L1action'] = false;
        retPayload['L2action'] = false;
        retPayload['L3action'] = false;
        retPayload['L4action'] = false;
        retPayload['l1FeedbackUploaded'] = false;
        retPayload['l2FeedbackUploaded'] = false;
        retPayload['l3FeedbackUploaded'] = false;
        retPayload['l4FeedbackUploaded'] = false;
        retPayload['l1FeedbackFile'] = P_ProfileObject.l1FeedbackUploaded != null ? true : false;
        retPayload['l2FeedbackFile'] = P_ProfileObject.l2FeedbackUploaded != null ? true : false;
        retPayload['l3FeedbackFile'] = P_ProfileObject.l3FeedbackUploaded != null ? true : false;
        retPayload['l4FeedbackFile'] = P_ProfileObject.clientInterviewFeedback != null ? true : false;
        retPayload['l1InterviewDate'] = false;
        retPayload['l2InterviewDate'] = false;
        retPayload['l3InterviewDate'] = false;
        retPayload['clientInterviewDate'] = false;
        retPayload['l1InterviewTime'] = false;
        retPayload['l2InterviewTime'] = false;
        retPayload['l3InterviewTime'] = false;
        retPayload['clientInterviewTime'] = false;

        retPayload['stepCategory'] = (P_ProfileObject.status == "0. Sent Back for Profile Completeness (RECRUITMENT)") ? false : true;
      }
      
    }

    console.log("@ax" + JSON.stringify(retPayload));
    // retPayload['P_ProfileObject'] = P_ProfileObject;
    return retPayload;
  };


  PageModule.prototype.getdateTime = function (stringDateTime) {
    console.log("@@ Time" + stringDateTime);
    console.log(new Date(stringDateTime));
    var date = new Date(stringDateTime).toLocaleString("sv-SE").replace(" ", "T");
    console.log("@@ Time" + date);
    return date;
  };

    PageModule.prototype.downloadNew = function (base64File, filename) {
    console.log('@@File Name' + filename);
    var fileBytes = atob(base64File);

    fileBytes = FileToBytes(fileBytes);
    console.log(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    }
    else {
      var link = document.createElement("a");
      if (link.download !== undefined) {
        // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        document.body.removeChild(link);
      }
    }
  };

  PageModule.prototype.createUploadPayload = function (P_File, P_Path, P_Filename) {

    var form = new FormData();
    P_Path = P_Path + P_Filename;
    var bucketName = "Profile_Bucket";
    form.append('file', P_File[0], P_Filename);
    form.append('json', '{"filename":"' + P_Path + '", "bucket_name" : "' + bucketName + '"}');
    return form;
  };

  PageModule.prototype.validateData = function (P_ProfileObject, P_PanelInfo,noShowCL) {
    /* Returning Temp Values:

      0 - Feedback File missing.
      1 - Panel Comments missing.
      2 - Validation Success.
      3 - Profile Comments missing.
      4 - Step 0 Category missing.
      5 - Rejection Reason Comments missing.
      6 - Panel not assigned but action taken.
      7 - Feedback and Comments uploaded without taking action.
      8- Interview Date missing.
    */
    var retPayload = {};
    retPayload['profileData'] = {};
    switch (P_PanelInfo.role) {
      case "PanelL1":
        if (P_ProfileObject.l1Action == "accept") {
          if (P_PanelInfo.l1FeedbackFile) {
            retPayload['temp'] = 2; //2- Validation Success
            if (P_ProfileObject.interviewStatus == 'Awaiting L1') {
              if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            P_ProfileObject.comments = "Panel L1 Action taken.Action - Accept";
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.l1Action == "reject") {
          if (P_PanelInfo.l1FeedbackFile) {
            if (P_ProfileObject.l1Comments == null || P_ProfileObject.l1Comments == "" || P_ProfileObject.l1Comments == undefined) {
              retPayload['temp'] = 1;
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              P_ProfileObject.comments = "Panel L1 Action taken.Action - Reject";
              retPayload['temp'] = 2;
            }
          }
          else {
            retPayload['temp'] = 0; // 0- Feedback FIle missing is missing 
          }
        }
        else if (P_ProfileObject.l1Action == "noShow") {
          if (P_ProfileObject.l1Comments == null || P_ProfileObject.l1Comments == "" || P_ProfileObject.l1Comments == undefined) {
            retPayload['temp'] = 1; // 1- Comments missing
          }
          else {
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L1 Action taken.Action - No Show";
            retPayload['temp'] = 2;
          }
        }
          else if (P_ProfileObject.l1Action == "cancel") {
         
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L1 Action taken.Action - Cancel";
            retPayload['temp'] = 2;
          
        }
        else {
          if (P_PanelInfo.l1FeedbackFile) {
            if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 7;
            }
          }
          else if (P_ProfileObject.l1Comments != null || P_ProfileObject.l1Comments != undefined) {
            if (P_ProfileObject.l1Comments != "") {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
          }
        }
        break;

      case "PanelL2":
        if (P_ProfileObject.l2Action == "accept") {
          if (P_PanelInfo.l2FeedbackFile) {
            retPayload['temp'] = 2;
            if (P_ProfileObject.interviewStatus == 'Awaiting L2') {
              if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            P_ProfileObject.comments = "Panel L2 Action taken.Action - Accept";
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.l2Action == "reject") {
          if (P_PanelInfo.l2FeedbackFile) {
            if (P_ProfileObject.l2Comments == null || P_ProfileObject.l2Comments == "" || P_ProfileObject.l2Comments == undefined) {
              retPayload['temp'] = 1;
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              P_ProfileObject.comments = "Panel L2 Action taken.Action - Reject";
              retPayload['temp'] = 2;
            }
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.l2Action == "noShow") {
          if (P_ProfileObject.l2Comments == null || P_ProfileObject.l2Comments == "" || P_ProfileObject.l2Comments == undefined) {
            retPayload['temp'] = 1;
          }
          else {
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L2 Action taken.Action - No Show";
            retPayload['temp'] = 2;
          }
        }
         else if (P_ProfileObject.l2Action == "cancel") {
         
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L2 Action taken.Action - Cancel";
            retPayload['temp'] = 2;
          
        }
        else {
          if (P_PanelInfo.l2FeedbackFile) {
            if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 7;
            }
          }
          else if (P_ProfileObject.l2Comments != null || P_ProfileObject.l2Comments != undefined) {
            if (P_ProfileObject.l2Comments != "") {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
          }
        }
        break;

      case "PanelL3":
        if (P_ProfileObject.l3Action == "accept") {
          if (P_PanelInfo.l3FeedbackFile) {
            retPayload['temp'] = 2;
            if (P_ProfileObject.interviewStatus == 'Awaiting L3') {
              if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            P_ProfileObject.comments = "Panel L3 Action taken.Action - Accept";
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.l3Action == "reject") {
          if (P_PanelInfo.l3FeedbackFile) {
            if (P_ProfileObject.l3Comments == null || P_ProfileObject.l3Comments == "" || P_ProfileObject.l3Comments == undefined) {
              retPayload['temp'] = 1;
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              P_ProfileObject.comments = "Panel L3 Action taken.Action - Reject";
              retPayload['temp'] = 2;
            }
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.l3Action == "noShow") {
          if (P_ProfileObject.l3Comments == null || P_ProfileObject.l3Comments == "" || P_ProfileObject.l3Comments == undefined) {
            retPayload['temp'] = 1;
          }
          else {
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L3 Action taken.Action - No Show";
            retPayload['temp'] = 2;
          }
        }
          else if (P_ProfileObject.l3Action == "cancel") {
         
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L3 Action taken.Action - Cancel";
            retPayload['temp'] = 2;
          
        }
        else {
          if (P_PanelInfo.l3FeedbackFile) {
            if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 7;
            }
          }
          else if (P_ProfileObject.l3Comments != null || P_ProfileObject.l3Comments != undefined) {
            if (P_ProfileObject.l3Comments != "") {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
          }
        }
        break;

      case "PanelL4":
        if (P_ProfileObject.clientInterviewAction == "accept") {
          if (P_PanelInfo.l4FeedbackFile) {
            retPayload['temp'] = 2;
            if (P_ProfileObject.interviewStatus == 'Awaiting Client Interview') {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
            P_ProfileObject.comments = "Client Interview Action taken.Action - Accept";
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.clientInterviewAction == "reject") {
          if (P_PanelInfo.l4FeedbackFile) {
            if (P_ProfileObject.clientInterviewComments == null || P_ProfileObject.clientInterviewComments == "" || P_ProfileObject.clientInterviewComments == undefined) {
              retPayload['temp'] = 1;
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              retPayload['temp'] = 2;
              P_ProfileObject.comments = "Client Interview Action taken.Action - Reject";
            }
          }
          else {
            retPayload['temp'] = 0;
          }
        }
        else if (P_ProfileObject.clientInterviewAction == "noShow") {
          if (P_ProfileObject.clientInterviewComments == null || P_ProfileObject.clientInterviewComments == "" || P_ProfileObject.clientInterviewComments == undefined) {
            retPayload['temp'] = 1;
          }
          else {
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            retPayload['temp'] = 2;
            P_ProfileObject.comments = "Client Interview Action taken.Action - No Show";
          }
        }
         else if (P_ProfileObject.clientInterviewAction == "cancel") {
         
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Client Interview Action taken.Action - Cancel";
            retPayload['temp'] = 2;
          
        }
        else {
          if (P_PanelInfo.l4FeedbackFile) {
            if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 7;
            }
          }
          else if (P_ProfileObject.clientInterviewComments != null || P_ProfileObject.clientInterviewComments != undefined) {
            if (P_ProfileObject.clientInterviewComments != "") {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
          }
        }
        break;

      case "Recruitment":
        if (P_ProfileObject.comments == null) {
          retPayload['temp'] = 3;
        }
        else {
          retPayload['temp'] = 2;
        }
       if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if ( P_ProfileObject.interviewStatus == "Awaiting Panel"  && P_ProfileObject.panelL1 != null && P_ProfileObject.l1Action == null && P_ProfileObject.l1InterviewDate == null) {

                retPayload['temp'] = 8;
              }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL2 != null && P_ProfileObject.l2Action == null && P_ProfileObject.l2InterviewDate == null && P_ProfileObject.l2FeedbackUploaded == null && P_ProfileObject.l1Action != null && P_ProfileObject.l1FeedbackUploaded != null ) {

                 retPayload['temp'] = 8;
              }
              else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision"  && P_ProfileObject.panelL3 != null && P_ProfileObject.l3Action == null && P_ProfileObject.l3InterviewDate == null && P_ProfileObject.l3FeedbackUploaded == null && P_ProfileObject.l2Action != null && P_ProfileObject.l2FeedbackUploaded != null ) {

                 retPayload['temp'] = 8;
              }
             else if  (P_ProfileObject.interviewStatus == "Awaiting CL Decision"  && P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterviewAction == null && P_ProfileObject.clientInterviewDate == null  && P_ProfileObject.clientInterviewFeedbackUploaded == null && P_ProfileObject.l3Action != null && P_ProfileObject.l3FeedbackUploaded != null) {

                retPayload['temp'] = 8;
              }
          }
        if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if ((P_ProfileObject.interviewStatus == "Awaiting Panel" || P_ProfileObject.interviewStatus == "Awaiting CL Decision") && P_ProfileObject.panelL1 != null && P_ProfileObject.l1Action == null && P_ProfileObject.l1FeedbackUploaded == null) {

            P_ProfileObject.interviewStatus = "Awaiting L1";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL2 != null && P_ProfileObject.l2Action == null && P_ProfileObject.l2FeedbackUploaded == null && P_ProfileObject.l1Action != null && P_ProfileObject.l1FeedbackUploaded != null) {

            P_ProfileObject.interviewStatus = "Awaiting L2";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL3 != null && P_ProfileObject.l3Action == null && P_ProfileObject.l3FeedbackUploaded == null && P_ProfileObject.l2Action != null && P_ProfileObject.l2FeedbackUploaded != null) {

            P_ProfileObject.interviewStatus = "Awaiting L3";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterviewAction == null && P_ProfileObject.clientInterviewFeedbackUploaded == null && P_ProfileObject.l3Action != null && P_ProfileObject.l3FeedbackUploaded != null) {

            P_ProfileObject.interviewStatus = "Awaiting Client Interview";
          }

          if (P_ProfileObject.l1Action == "accept") {
            if (P_PanelInfo.l1FeedbackFile) {
              if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }

          }
          else if (P_ProfileObject.l1Action == "reject") {
            if (P_PanelInfo.l1FeedbackFile) {


              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else {
            if (P_ProfileObject.l1Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }

          if (P_ProfileObject.l2Action == "accept") {
            if (P_PanelInfo.l2FeedbackFile) {
              if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
          }

          else if (P_ProfileObject.l2Action == "reject") {
            if (P_PanelInfo.l2FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else {
            if (P_ProfileObject.l2Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }


          if (P_ProfileObject.l3Action == "accept") {
            if (P_PanelInfo.l3FeedbackFile) {
              if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }

          }
          else if (P_ProfileObject.l3Action == "reject") {
            if (P_PanelInfo.l3FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else {
            if (P_ProfileObject.l3Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }


          if (P_ProfileObject.clientInterviewAction == "accept") {
            if (P_PanelInfo.l4FeedbackFile) {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }

          }
          else if (P_ProfileObject.clientInterviewAction == "reject") {
            if (P_PanelInfo.l4FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else {
            if (P_ProfileObject.clientInterviewAction == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }


          if (retPayload['temp'] == undefined) {
            if ((P_PanelInfo.prevPanelL1 == null || P_PanelInfo.prevPanelL1 == 1524) && (P_ProfileObject.panelL1 != null && P_ProfileObject.panelL1 != 1524)) {
              if (P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
            }
            if ((P_PanelInfo.prevPanelL2 == null || P_PanelInfo.prevPanelL2 == 1524) && (P_ProfileObject.panelL2 != null && P_ProfileObject.panelL2 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if (P_ProfileObject.l1Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }

            }
            if ((P_PanelInfo.prevPanelL3 == null || P_PanelInfo.prevPanelL3 == 1524) && (P_ProfileObject.panelL3 != null && P_ProfileObject.panelL3 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if (P_ProfileObject.l2Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
            }
            if ((P_PanelInfo.prevPanelL4 == null || P_PanelInfo.prevPanelL4 == 1524) && (P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterview != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if ((P_ProfileObject.panelL3 != null || P_ProfileObject.panelL3 != 1524) && P_ProfileObject.l3Action == null) {
                if (P_ProfileObject.l2Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L3";
                }
              }
              else if (P_ProfileObject.l3Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
            }
          }
        }


        break;

      case "Profile Coordinator":
        if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if (P_ProfileObject.interviewStatus == 'NA') {
            P_ProfileObject.interviewStatus = "Awaiting Panel";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting Panel" && P_ProfileObject.panelL1 != null && P_ProfileObject.l1Action == null && P_ProfileObject.l1FeedbackUploaded == null && P_ProfileObject.l1InterviewDate != null) {

            P_ProfileObject.interviewStatus = "Awaiting L1";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL2 != null && P_ProfileObject.l2Action == null && P_ProfileObject.l2FeedbackUploaded == null && P_ProfileObject.l1Action != null && P_ProfileObject.l1FeedbackUploaded != null && P_ProfileObject.l2InterviewDate != null) {

            P_ProfileObject.interviewStatus = "Awaiting L2";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL3 != null && P_ProfileObject.l3Action == null && P_ProfileObject.l3FeedbackUploaded == null && P_ProfileObject.l2Action != null && P_ProfileObject.l2FeedbackUploaded != null && P_ProfileObject.l3InterviewDate != null) {

            P_ProfileObject.interviewStatus = "Awaiting L3";
          }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterviewAction == null && P_ProfileObject.clientInterviewFeedbackUploaded == null && P_ProfileObject.l3Action != null && P_ProfileObject.l3FeedbackUploaded != null && P_ProfileObject.clientInterviewDate != null) {

            P_ProfileObject.interviewStatus = "Awaiting Client Interview";
          }


        }
            if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if ( P_ProfileObject.interviewStatus == "Awaiting Panel"  && P_ProfileObject.panelL1 != null && P_ProfileObject.l1Action == null && P_ProfileObject.l1InterviewDate == null) {

                retPayload['temp'] = 8;
              }
          else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision" && P_ProfileObject.panelL2 != null && P_ProfileObject.l2Action == null && P_ProfileObject.l2InterviewDate == null && P_ProfileObject.l2FeedbackUploaded == null && P_ProfileObject.l1Action != null && P_ProfileObject.l1FeedbackUploaded != null ) {

                 retPayload['temp'] = 8;
              }
              else if (P_ProfileObject.interviewStatus == "Awaiting CL Decision"  && P_ProfileObject.panelL3 != null && P_ProfileObject.l3Action == null && P_ProfileObject.l3InterviewDate == null && P_ProfileObject.l3FeedbackUploaded == null && P_ProfileObject.l2Action != null && P_ProfileObject.l2FeedbackUploaded != null ) {

                 retPayload['temp'] = 8;
              }
             else if  (P_ProfileObject.interviewStatus == "Awaiting CL Decision"  && P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterviewAction == null && P_ProfileObject.clientInterviewDate == null  && P_ProfileObject.clientInterviewFeedbackUploaded == null && P_ProfileObject.l3Action != null && P_ProfileObject.l3FeedbackUploaded != null) {

                retPayload['temp'] = 8;
              }
          }
        if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if (P_ProfileObject.l1Action == "accept") {
            if (P_PanelInfo.l1FeedbackFile) {
              if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }

          }
          else if (P_ProfileObject.l1Action == "reject") {
            if (P_PanelInfo.l1FeedbackFile) {


              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else if (P_ProfileObject.l1Action == "cancel") {
                if (P_ProfileObject.panelL1 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
                 P_ProfileObject.l1Action = null;
              }
                else  if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }

              

            

          }

          else {
            if (P_ProfileObject.l1Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }

          if (P_ProfileObject.l2Action == "accept") {
            if (P_PanelInfo.l2FeedbackFile) {
              if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }

          }
          else if (P_ProfileObject.l2Action == "reject") {
            if (P_PanelInfo.l2FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else if (P_ProfileObject.l2Action == "cancel") {
               
                  if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
                P_ProfileObject.l2Action = null;
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
           }

          else {
            if (P_ProfileObject.l2Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }


          if (P_ProfileObject.l3Action == "accept") {
            if (P_PanelInfo.l3FeedbackFile) {
              if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }

          }
          else if (P_ProfileObject.l3Action == "reject") {
            if (P_PanelInfo.l3FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
           else if (P_ProfileObject.l3Action == "cancel") {
               
                 if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
                 P_ProfileObject.l3Action = null;
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
           }

          else {
            if (P_ProfileObject.l3Action == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }
          }


          if (P_ProfileObject.clientInterviewAction == "accept") {
            if (P_PanelInfo.l4FeedbackFile) {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }

          }
          else if (P_ProfileObject.clientInterviewAction == "reject") {
            if (P_PanelInfo.l4FeedbackFile) {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";

            }

          }
          else if (P_ProfileObject.clientInterviewAction == "cancel") {
               
                 if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
                 P_ProfileObject.clientInterviewAction = null;
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
           }
          else {
            if (P_ProfileObject.clientInterviewAction == "noShow") {

              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }


          if (retPayload['temp'] == undefined) {
            if ((P_PanelInfo.prevPanelL1 == null || P_PanelInfo.prevPanelL1 == 1524) && (P_ProfileObject.panelL1 != null && P_ProfileObject.panelL1 != 1524)) {
              if (P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
            }
            if ((P_PanelInfo.prevPanelL2 == null || P_PanelInfo.prevPanelL2 == 1524) && (P_ProfileObject.panelL2 != null && P_ProfileObject.panelL2 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if (P_ProfileObject.l1Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }

            }
            if ((P_PanelInfo.prevPanelL3 == null || P_PanelInfo.prevPanelL3 == 1524) && (P_ProfileObject.panelL3 != null && P_ProfileObject.panelL3 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if (P_ProfileObject.l2Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
            }
            if ((P_PanelInfo.prevPanelL4 == null || P_PanelInfo.prevPanelL4 == 1524) && (P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterview != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if ((P_ProfileObject.panelL3 != null || P_ProfileObject.panelL3 != 1524) && P_ProfileObject.l3Action == null) {
                if (P_ProfileObject.l2Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L3";
                }
              }
              else if (P_ProfileObject.l3Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
            }
          }
        }
        else {
          if (P_ProfileObject.status == "0. Sent Back for Profile Completeness (RECRUITMENT)") {
            if (P_ProfileObject.stepCategory == null) {
              retPayload['temp'] = 4; // Step 0 category not available
            }
            else {
              P_ProfileObject.interviewStatus = 'NA';
              retPayload['temp'] = 2;
            }
          }
          else if (P_ProfileObject.status == "7.1 Rejected - Screening" || P_ProfileObject.status == "7.2 Rejected - L1" || P_ProfileObject.status == "7.3 Rejected - L2" || P_ProfileObject.status == "7.4 Rejected - L3" || P_ProfileObject.status == "7.5 Rejected - Client" || P_ProfileObject.status == "7.6 Rejected - Approvals" || P_ProfileObject.status == "7.7 Rejected - Fake/Blacklisted") {
            if (P_ProfileObject.rejectionReasonComments == null || P_ProfileObject.rejectionReasonComments == "" || P_ProfileObject.rejectionReasonComments == undefined) {
              retPayload['temp'] = 5;
            }
            else {
              if (P_ProfileObject.stepCategory != null) {
                P_ProfileObject.stepCategory = null;
              }
              P_ProfileObject.interviewStatus = 'NA';
              retPayload['temp'] = 2;
            }
          }
          else if (P_ProfileObject.status == "3. Forward for Offer Roll Out (PSC)") {
            P_ProfileObject.interviewStatus = 'NA';
          }
        }

        if (P_ProfileObject.comments == null || P_ProfileObject.comments == "" || P_ProfileObject.comments == undefined) {
          if (retPayload['temp'] == undefined || retPayload['temp'] == 2) {
            retPayload['temp'] = 3;
          }
        }
        else if (retPayload['temp'] == undefined) {
          retPayload['temp'] = 2;
        }

        break;

      case "Capability Lead":
        if (P_ProfileObject.status == "2. Awaiting Selection Decision (CAPABILITY)") {
          if (P_ProfileObject.interviewStatus == "Awaiting Panel") {
            if (P_ProfileObject.panelL1 == null && P_ProfileObject.panelL2 == null && P_ProfileObject.panelL3 == null && P_ProfileObject.clientInterview == null) {
              if (P_ProfileObject.l1Action != undefined || P_ProfileObject.l2Action != undefined || P_ProfileObject.l3Action != undefined || P_ProfileObject.clientInterviewAction != undefined) {
                retPayload['temp'] = 6;
              }
            }
          }
          

          if ((P_ProfileObject.panelL1 == null || P_ProfileObject.panelL1 == 1524) && P_ProfileObject.l1Action != null) {
            retPayload['temp'] = 6;
          }
          if ((P_ProfileObject.panelL2 == null || P_ProfileObject.panelL2 == 1524) && P_ProfileObject.l2Action != null) {
            retPayload['temp'] = 6;
          }
          if ((P_ProfileObject.panelL3 == null || P_ProfileObject.panelL3 == 1524) && P_ProfileObject.l3Action != null) {
            retPayload['temp'] = 6;
          }
          if ((P_ProfileObject.clientInterview == null || P_ProfileObject.clientInterview == 1524) && P_ProfileObject.clientInterviewAction != null) {
            retPayload['temp'] = 6;
          }

          if (P_ProfileObject.l1Action == "accept") {
            if (P_PanelInfo.l1FeedbackFile) {
              if (P_ProfileObject.panelL2 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }
              else if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.l1Action == "reject") {
            if (P_PanelInfo.l1FeedbackFile) {
              if (P_ProfileObject.l1Comments == null || P_ProfileObject.l1Comments == "" || P_ProfileObject.l1Comments == undefined) {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 1;
                }
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0; // 0- Feedback File missing is missing 
            }
          }
          else if (P_ProfileObject.l1Action == "noShow") {
            if (P_ProfileObject.l1Comments == null || P_ProfileObject.l1Comments == "" || P_ProfileObject.l1Comments == undefined) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 1; // 1- Comments missing
              }
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }
            else if (P_ProfileObject.l1Action == "cancel") {
         
            P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            P_ProfileObject.comments = "Panel L1 Action taken";
            retPayload['temp'] = 2;
          
        }
          else {
            if (P_PanelInfo.l1FeedbackFile) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
            else if (P_ProfileObject.l1Comments != null || P_ProfileObject.l1Comments != undefined) {
              if (P_ProfileObject.l1Comments != "") {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 7;
                }
              }
            }
          }
            if(noShowCL == 1)
        {
           retPayload['temp'] = 2;
        }
          if (P_ProfileObject.l2Action == "accept") {
            if (P_PanelInfo.l2FeedbackFile) {
              if (P_ProfileObject.panelL3 != null) {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
              else if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.l2Action == "reject") {
            if (P_PanelInfo.l2FeedbackFile) {
              if (P_ProfileObject.l2Comments == null || P_ProfileObject.l2Comments == "" || P_ProfileObject.l2Comments == undefined) {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 1;
                }
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.l2Action == "noShow") {
            if (P_ProfileObject.l2Comments == null || P_ProfileObject.l2Comments == "" || P_ProfileObject.l2Comments == undefined) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 1;
              }
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }
          else if (P_ProfileObject.l2Action == "cancel") {
                if (P_ProfileObject.panelL2 != null) {
                 P_ProfileObject.interviewStatus = "Awaiting CL Decision";
           
            retPayload['temp'] = 2;
              }

          }
          else {
            if (P_PanelInfo.l2FeedbackFile) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
            else if (P_ProfileObject.l2Comments != null || P_ProfileObject.l2Comments != undefined) {
              if (P_ProfileObject.l2Comments != "") {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 7;
                }
              }
            }
          }

          if (P_ProfileObject.l3Action == "accept") {
            if (P_PanelInfo.l3FeedbackFile) {
              if (P_ProfileObject.clientInterview != null) {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.l3Action == "reject") {
            if (P_PanelInfo.l3FeedbackFile) {
              if (P_ProfileObject.l3Comments == null || P_ProfileObject.l3Comments == "" || P_ProfileObject.l3Comments == undefined) {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 1;
                }
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.l3Action == "noShow") {
            if (P_ProfileObject.l3Comments == null || P_ProfileObject.l3Comments == "" || P_ProfileObject.l3Comments == undefined) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 1;
              }
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }
              else if (P_ProfileObject.l3Action == "cancel") {
                if (P_ProfileObject.panelL3 != null) {
                 P_ProfileObject.interviewStatus = "Awaiting CL Decision";
           
            retPayload['temp'] = 2;
              }

          }
          else {
            if (P_PanelInfo.l3FeedbackFile) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
            else if (P_ProfileObject.l3Comments != null || P_ProfileObject.l3Comments != undefined) {
              if (P_ProfileObject.l3Comments != "") {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 7;
                }
              }
            }
          }

          if (P_ProfileObject.clientInterviewAction == "accept") {
            if (P_PanelInfo.l4FeedbackFile) {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.clientInterviewAction == "reject") {
            if (P_PanelInfo.l4FeedbackFile) {
              if (P_ProfileObject.clientInterviewComments == null || P_ProfileObject.clientInterviewComments == "" || P_ProfileObject.clientInterviewComments == undefined) {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 1;
                }
              }
              else {
                P_ProfileObject.interviewStatus = "Awaiting CL Decision";
              }
            }
            else if (retPayload['temp'] == undefined) {
              retPayload['temp'] = 0;
            }
          }
          else if (P_ProfileObject.clientInterviewAction == "noShow") {
            if (P_ProfileObject.clientInterviewComments == null || P_ProfileObject.clientInterviewComments == "" || P_ProfileObject.clientInterviewComments == undefined) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 1;
              }
            }
            else {
              P_ProfileObject.interviewStatus = "Awaiting CL Decision";
            }
          }
               else if (P_ProfileObject.clientInterviewAction == "cancel") {
                if (P_ProfileObject.clientInterview != null) {
                 P_ProfileObject.interviewStatus = "Awaiting CL Decision";
           
            retPayload['temp'] = 2;
              }
             

              

            

          }
          else {
            if (P_PanelInfo.l4FeedbackFile) {
              if (retPayload['temp'] == undefined) {
                retPayload['temp'] = 7;
              }
            }
            else if (P_ProfileObject.clientInterviewComments != null || P_ProfileObject.clientInterviewComments != undefined) {
              if (P_ProfileObject.clientInterviewComments != "") {
                if (retPayload['temp'] == undefined) {
                  retPayload['temp'] = 7;
                }
              }
            }
          }

          if (retPayload['temp'] == undefined) {
            if ((P_PanelInfo.prevPanelL1 == null || P_PanelInfo.prevPanelL1 == 1524) && (P_ProfileObject.panelL1 != null && P_ProfileObject.panelL1 != 1524)) {
              if (P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
            }
            if ((P_PanelInfo.prevPanelL2 == null || P_PanelInfo.prevPanelL2 == 1524) && (P_ProfileObject.panelL2 != null && P_ProfileObject.panelL2 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if (P_ProfileObject.l1Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L2";
              }

            }
            if ((P_PanelInfo.prevPanelL3 == null || P_PanelInfo.prevPanelL3 == 1524) && (P_ProfileObject.panelL3 != null && P_ProfileObject.panelL3 != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if (P_ProfileObject.l2Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting L3";
              }
            }
            if ((P_PanelInfo.prevPanelL4 == null || P_PanelInfo.prevPanelL4 == 1524) && (P_ProfileObject.clientInterview != null && P_ProfileObject.clientInterview != 1524)) {
              if ((P_ProfileObject.panelL1 != null || P_ProfileObject.panelL1 != 1524) && P_ProfileObject.l1Action == null) {
                P_ProfileObject.interviewStatus = "Awaiting L1";
              }
              else if ((P_ProfileObject.panelL2 != null || P_ProfileObject.panelL2 != 1524) && P_ProfileObject.l2Action == null) {
                if (P_ProfileObject.l1Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L2";
                }
              }
              else if ((P_ProfileObject.panelL3 != null || P_ProfileObject.panelL3 != 1524) && P_ProfileObject.l3Action == null) {
                if (P_ProfileObject.l2Action == "accept") {
                  P_ProfileObject.interviewStatus = "Awaiting L3";
                }
              }
              else if (P_ProfileObject.l3Action == "accept") {
                P_ProfileObject.interviewStatus = "Awaiting Client Interview";
              }
            }
          }
        }
        else {
          if (P_ProfileObject.status == "0. Sent Back for Profile Completeness (RECRUITMENT)") {
            if (P_ProfileObject.stepCategory == null) {
              retPayload['temp'] = 4;
            }
            else {
              P_ProfileObject.interviewStatus = 'NA';
              retPayload['temp'] = 2;
            }
          }
          else if (P_ProfileObject.status == "7.1 Rejected - Screening" || P_ProfileObject.status == "7.2 Rejected - L1" || P_ProfileObject.status == "7.3 Rejected - L2" || P_ProfileObject.status == "7.4 Rejected - L3" || P_ProfileObject.status == "7.5 Rejected - Client" || P_ProfileObject.status == "7.7 Rejected - Fake/Blacklisted") {
            if (P_ProfileObject.rejectionReasonComments == null || P_ProfileObject.rejectionReasonComments == "" || P_ProfileObject.rejectionReasonComments == undefined) {
              retPayload['temp'] = 5;
            }
            else {
              P_ProfileObject.interviewStatus = 'NA';
              retPayload['temp'] = 2;
            }
          }
          else if (P_ProfileObject.status == "3. Forward for Offer Roll Out (PSC)") {
            P_ProfileObject.interviewStatus = 'NA';
            retPayload['temp'] = 2;
          }
        }

        if (P_ProfileObject.comments == null || P_ProfileObject.comments == "" || P_ProfileObject.comments == undefined) {
          if (retPayload['temp'] == undefined || retPayload['temp'] == 2) {
            retPayload['temp'] = 3;
          }
        }
        else if (retPayload['temp'] == undefined) {
          retPayload['temp'] = 2;
        }
        break;

      case "PSC":
        if (P_ProfileObject.comments == null) {
          retPayload['temp'] = 3;
        }
        else {
          retPayload['temp'] = 2;
        }
        break;
    }

    retPayload['profileData'] = P_ProfileObject;
    return retPayload;
  };
  
  PageModule.prototype.getToday = function () {
    var now = new Date();
    // console.log("@Time12 :"+now.toString);
    return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
  };

  PageModule.prototype.benchSearchADP = function (P_Emp, P_Alloc,P_Skill,proposalBO,currentDemandBOID,pipBO,rollofRadarBO) {
     var retPayload = [];
//      let empCheck = {
//     employeeID: null,
//     teamRequestNumber: null,
//     status:null
// };
 retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
     retPayload['internalshadow'] = [];


       for(var i=0; i<P_Emp.length; i++){
   let pip=pipBO.find(ele=>ele.empID==P_Emp[i].id);
    let rolloff=rollofRadarBO.find(ele=>ele.employeeID==P_Emp[i].id);
         let proposal=proposalBO.find(ele=>ele.employeeID==P_Emp[i].id && ele.teamRquestNumber==currentDemandBOID);
           let proposal1=proposalBO.filter(ele=>ele.employeeID==P_Emp[i].id);
           let containsStatus = proposal1.some(record => record.status === 'Allocated' || record.status === 'Blocked/Client interview');
           let containsStatus12 = proposal1.some(record => record.status === 'Proposed' );
      let alloc=P_Alloc.filter(ele=> ele.employee==P_Emp[i].id);
      let latestRecord = alloc.sort((a, b) => new Date(b.allocationEndDate) - new Date(a.allocationEndDate))[0];
       let latestRecord1 = alloc.sort((a, b) => new Date(b.allocationStartDate) - new Date(a.allocationStartDate))[0];
      if(proposal1.length!==0){
      if (containsStatus) {
    continue;
       } else if (proposal !== undefined && currentDemandBOID === proposal.teamRquestNumber && proposal.status!=='Rejected' && proposal.status!=='Cancelled') {
           continue;
       }
      }
      if(latestRecord != undefined){
        var availableDate = new Date(latestRecord.allocationEndDate);
          var startDate = new Date(latestRecord1.allocationStartDate);
        availableDate.setDate(availableDate.getDate() + 1); 
        

        var temp = {};
        temp['id'] = P_Emp[i].employeeID;
        temp['name'] = P_Emp[i].name;
        temp['grade'] = P_Emp[i].localGrade;
         temp['billable'] = (containsStatus12 === true) ? (P_Emp[i].billable + " (Proposed)") : P_Emp[i].billable;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = P_Emp[i].globalPracticeObject.items[0].name;
          temp['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp['skill'] = P_Emp[i].skillGroup1==null?'':P_Emp[i].skillGroup1Object.items[0].skillGroupName;
         temp['skill2'] = P_Emp[i].skillGroup2==null?'':P_Emp[i].skillGroup2Object.items[0].skillGroupName;
          temp['skill3'] = P_Emp[i].skillGroup3==null?'':P_Emp[i].skillGroup3Object.items[0].skillGroupName;
        temp['location'] = P_Emp[i].location==null?'':P_Emp[i].locationObject.items[0].location;
        // temp['status'] = P_Emp[0].status;
         temp['BoID']=P_Emp[i].id;
          temp['status']=P_Emp[i].status;
           temp['pip']=pip!=undefined?true:false;
      
      
        // temp['loc'] = P_Emp[0].locationObject.items[0].location;
        // temp['demandSupplyBOId']=P_demandSupplyId;
        // temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      
        
      
    var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

if(rolloff!=undefined){
   var availableDateRolloff = new Date(rolloff.releaseDate);
              var avail_date11 = availableDateRolloff;
              var today11 = new Date();
              var curr_date11 = today11;
              var difference1= (avail_date11-curr_date11);

              var days1 = Math.round(difference1/(1000 * 3600 * 24));
}
            //     if(days <= 30 && days >=0){
            //     temp['available'] = changeFormat(availableDate);
            //     retPayload['internalb'].push(temp);
            //  }
            

             if(rolloff!=undefined && days1 <= 30 && days1 >=0){
                 temp['available'] = changeFormat(rolloff.releaseDate);
                  temp['category']='Non-Bench';
                 retPayload['internalb'].push(temp);
              }


            else if(temp['status']==="Bench - Deployable" ||  temp['status']==="Bench - Resigned" ||  temp['status']==="Bench - Blocked" ){
              temp['available'] = changeFormat(availableDate);
               temp['category']='Bench';
              retPayload['internalnb'].push(temp);             
            }

            else if(temp['status']==="Shadow "){
              temp['available1'] = changeFormat(startDate);
               temp['category']='Shadow';
              temp['ageing'] = calculateAgeInPastDayss12233(temp['available1']);
             if (temp['ageing'] >= 60) {
        retPayload['internalshadow'].push(temp);
    }
              
            }
      }
       }

retPayload.internalbCount = retPayload['internalb'].length;
retPayload.internalnbCount = retPayload['internalnb'].length;
retPayload.internalshadowCount = retPayload['internalshadow'].length;

retPayload['internalnb'].sort((a, b) => {
    // First, sort by grade
    const gradeComparison = b.grade.localeCompare(a.grade);
    
    // If grades are equal, sort by id
    if (gradeComparison === 0) {
        return a.id - b.id;
    } else {
        return gradeComparison;
    }
});

retPayload['internalb'].sort((a, b) => new Date(a.available) - new Date(b.available));

 function calculateAgeInPastDayss12233(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
       
    return retPayload;
    
  };

  
  
  PageModule.prototype.dateFormat1 = function (dateStr) {
  // const dateStr = '2024-03-24';
const date = new Date(dateStr);
const day = date.getDate();
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
const monthIndex = date.getMonth();
const year = date.getFullYear();
const formattedDate = day + '-' + monthNames[monthIndex] + '-' + year;
console.log(formattedDate);

return formattedDate;
  }

    PageModule.prototype.isDateBeforeToday = function (inputDate) {

     var today = new Date();
    var inputDateObj = new Date(inputDate);
    inputDateObj.setDate(inputDateObj.getDate() + 1);
     if (inputDateObj < today) {
        return true;
    } else {
        return false;
    }
  };

   PageModule.prototype.dialogTitle = function (data) {

    let name;
    let client=(data[0].clientObject.items[0].clientName).substring(0, 25);
    let demand ;

    if ((data[0].demandType).endsWith("Project")) {
    
    demand= (data[0].demandType).slice(0, -"Project".length).trim();
  } else {
   demand=(data[0].demandType);
  }

    name=data[0].teamRequestNumber+' : '+data[0].globalPracticeObject.items[0].name+'-'+data[0].skillGroupObject.items[0].skillGroupName+' ('+data[0].localGrade+') '+'['+data[0].sectorObject.items[0].name+'-'+client+'..., '+demand+']';
    return  name;
  };

    PageModule.prototype.checkAgeing = function (ageinggg) {
    
     if (ageinggg > 30) {
        return true;
    } else {
        return false;
    }
  };
  
   PageModule.prototype.calculateAgeing = function (birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(Math.abs(timeDiff) / (1000 * 3600 * 24)); // Absolute value and floor
    return daysDiff;
  };

  
  PageModule.prototype.demandUpdateValidation = function(cBO,sBO,cTabcopy,sTabcopy,load) {
 var record = [];

 var sRecord = sBO.filter(ele=>ele.skillGroupName == sTabcopy);

 for(var i=0;i<sRecord.length;i++){

    var matchingRecord = sRecord[i].capability;  

    var cRecord = cBO.filter(ele=>ele.id == matchingRecord);

    for(var j=0;j<cRecord.length;j++){
    
    var matchingCRecord = cRecord[j].name;

    if (matchingCRecord == cTabcopy) {
            load.record.push(matchingCRecord);
          
        }
    }

 }
   
return load;
 };

 PageModule.prototype.demandValidation = function(cBO,sBO,cTabcopy,sTabcopy,load) {
 var record = [];

 var sRecord = sBO.filter(ele=>ele.skillGroupName == sTabcopy);

 for(var i=0;i<sRecord.length;i++){

    var matchingRecord = sRecord[i].capability;  

    var cRecord = cBO.filter(ele=>ele.id == matchingRecord);

    for(var j=0;j<cRecord.length;j++){
    
    var matchingCRecord = cRecord[j].name;

    if (matchingCRecord == cTabcopy) {
            load.record.push(matchingCRecord);
          
        }
    }

 }
   
return load;
 };

   PageModule.prototype.updateDemandDetails = function (BOName,operation,sgBO,cBO,demandBO,panelData,capTab,skillTab,clientInterview,cloud) {
 var batchProcessingVariableArray = [];

 
 var boid=panelData.id;

 var sTab = skillTab;
 var cTab = capTab;

var sgRowFoundduplicate;
  var cRowFoundduplicate;

    if(sTab!=undefined){
    for (var i = 0; i < sgBO.length; i++) {
    if (sgBO[i].skillGroupName === sTab) {
      sgRowFoundduplicate = sgBO[i]; 
      break; 
    }
  }
     }

if(cTab!=undefined){
  for (var j = 0; j < cBO.length; j++) {
    if (cBO[j].name === cTab) {
      cRowFoundduplicate = cBO[j]; 
      break; 
    }
  }
}


var skillId = sgRowFoundduplicate!=undefined?sgRowFoundduplicate.id:'';
var cId = cRowFoundduplicate!=undefined?cRowFoundduplicate.id:'';
var boID = boid;



if(cTab!='' && sTab!=''){
   let data = {
      id: "part" + boid,
      path: "/" + BOName + "/" + boid,
      operation: operation,
      payload: {
                globalPractice: cId,
                skillGroup: skillId,
                clientInterview: clientInterview,
                cloud: cloud
                }
              };

    batchProcessingVariableArray.push(data);
}

  // if((sTab == '' || sTab != undefined) && cTab != undefined && !cFind){
  //   let data = {
  //     id: "part" + boid,
  //     path: "/" + BOName + "/" + boid,
  //     operation: operation,
  //     payload: {
  //               globalPractice: cId,
  //               capabilityStatus: 'Y'
  //               }
  //             };

  //   batchProcessingVariableArray.push(data);
  // }
  return JSON.stringify({ parts: batchProcessingVariableArray });

  };

    PageModule.prototype.VisaExpiryDateConvert=function(VisaDate) {
    if(VisaDate != null && VisaDate!= undefined && VisaDate != ''){
    let orgDate = VisaDate;
    let [day,mon,year]=orgDate.split('-');
    let updatedDate;
    if(mon == undefined){
      return day;
    }
    else{
    day = day<10?'0'+day:''+day;
    year='20'+year;
    updatedDate = day+'-'+mon+'-'+year;
    return updatedDate;
    }
    }
  };

 PageModule.prototype.dialogTitleUpdate = function (data) {

    let name;
    let client=(data.clientObject.items[0].clientName).substring(0, 25);
    let demand ;

    if ((data.demandType).endsWith("Project")) {
    
    demand= (data.demandType).slice(0, -"Project".length).trim();
  } else {
   demand=(data.demandType);
  }

    name=data.teamRequestNumber+' : '+data.globalPracticeObject.items[0].name+'-'+data.skillGroupObject.items[0].skillGroupName+' ('+data.localGrade+') '+'['+data.sectorObject.items[0].name+'-'+client+'..., '+demand+']';
    return  name;
  };

  PageModule.prototype.createEmployeeSkillArray1=function(skillGroupBO,communityBO,empSkillBO,lookupBO,skillBO){

     let empSkillArray=new Array(); 

    for(let index=0;index<empSkillBO.length;index++){

     let skillObject=skillBO.find(each=>each.id==empSkillBO[index].skill);   
     if(skillObject){
      let skillGroupObject=skillGroupBO.find(each=>each.id==skillObject.skillGroup);
      if(skillGroupObject){
      let capabillityName=communityBO.find(each=>each.id==skillGroupObject.capability).name;
      let empSkillString='{"sNo":"'+(index+1)+'","capabillityName":"'+capabillityName+'","skillGroup":"'+skillGroupObject.skillGroupName+'","skillName":"'+skillObject.skillName+'","skillRating":"'+lookupBO.find(each=>each.lookupValue==empSkillBO[index].skillRating).description+'"}'
      console.log('#612'+empSkillString);
      empSkillArray.push(JSON.parse(empSkillString));
      
     }

     }



    }
    
return empSkillArray;

  };

   PageModule.prototype.q = function (current) {
     let query="status='ADMIN APPROVED' AND (coAuthor ='"+current+"' OR author ='"+current+"' OR coAuthor2 ='"+current+"'OR coAuthor3 ='"+current+"')";
    return query;
  };
  
PageModule.prototype.assignCommunitywithSkillGroup = function (P_Emp) {
     var retpayload = {};

    if(P_Emp.globalPractice != null){
      retpayload['community'] = P_Emp.globalPracticeObject.items[0].name;
    }
    else{
      retpayload['community'] = '';
    }

    if(P_Emp.suggestedCapabillity != null){
      retpayload['sugcommunity'] = P_Emp.suggestedCapabillityObj.items[0].name;
    }
    else{
      retpayload['sugcommunity'] = '';
    }

    if(P_Emp.skillGroup1 != null){
      retpayload['sugprimarySG'] = P_Emp.skillGroup1Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugprimarySG'] = '';
    }

    if(P_Emp.skillGroup2 != null){
      retpayload['sugsecondarySG'] = P_Emp.skillGroup2Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugsecondarySG'] = '';
    }

    if(P_Emp.skillGroup3 != null){
      retpayload['sugtertiarySG'] = P_Emp.skillGroup3Object.items[0].skillGroupName;
    }
    else{
      retpayload['sugtertiarySG'] = '';
    }

    return retpayload;
  };

  
//  PageModule.prototype.getDefaultedMonth=function(tcBO){

//   let data = [];
//   let currentYear = (new Date()).getFullYear();
//   let def = tcBO.filter(ele => ele.defaultedYear == currentYear);
//   let retpayload = {};
//   retpayload['month'] = "Year : " + currentYear;
//   let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
//   for (let i = 0; i < months.length; i++) {
//     let month = months[i].toLowerCase().substring(0, 3);
//     if (i < (new Date()).getMonth()+1) {
//       retpayload[month] = def.find(ele => ele.defaultedMonth == months[i]) == undefined ? 'N' : def.find(ele => ele.initialFlag == 'Issue') ? 'N' : 'Y';
//     } else {
//       retpayload[month] = '-';
//     }
//   }
//   data.push(retpayload);
//   return data;
// };

PageModule.prototype.getDefaultedMonth = function (tcBO) {
    let data = [];
    let currentYear = (new Date()).getFullYear();
    let def = tcBO.filter(ele => ele.defaultedYear === currentYear);
    let retpayload = {};
    retpayload['month'] = "Year : " + currentYear;
    let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    for (let i = 0; i < months.length; i++) {
        let month = months[i].toLowerCase().substring(0, 3);
        retpayload[month] = i < (new Date()).getMonth() + 1
            ? def.find(ele => ele.defaultedMonth === months[i]) === undefined
                ? 'N'
                : (def.find(ele => ele.initialFlag === 'Issue') === undefined ? 'N' : 'Y')
            : '-';
    }

    data.push(retpayload);
    return data;
};

 PageModule.prototype.totalCrediHrsFunction = function (T_main) {
    let totalcredithrs = 0;
    let totalcreditHrs;
    let credithrs;
    if(T_main.length == 0){
      totalcreditHrs = '0 hrs';
    }
    else{
      for (let i = 0;i<T_main.length;i++){
        credithrs=T_main[i].creditHrs;
       totalcredithrs += Number(credithrs);

      }
      totalcreditHrs = totalcredithrs.toFixed(2) + ' hrs';
    }
        
   return totalcreditHrs;
  };



//    PageModule.prototype.postAllData = function (E_cyl,E_mas,E_main) {

//  let data = [];
//      for(let i=0; i<E_main.length;i++){

//        let retpayload = {};

//        let ele=E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO);

//        retpayload ['awardName']= E_cyl.find(ele => ele.id == E_main[i].recognisationCycleBO).awardName;

//         retpayload ['yearMonth']= E_main[i].yearMonth;

//         retpayload['rRType']=E_mas.find(recele =>recele.id == ele.recognisationMasterBO).rRType;

//         data.push(retpayload);

//      }

//      console.log(">>",data);

//     return data;

//   };
PageModule.prototype.postAllData = function (E_cyl, E_mas, E_main) {
    let data = [];
    
    for (let i = 0; i < E_main.length; i++) {
        let retpayload = {};
        
        // Find the relevant element from E_cyl
        let ele = E_cyl.find(ele => ele.id === E_main[i].recognisationCycleBO);
        
        // Use ternary operator to handle cases where ele might be undefined
        retpayload['awardName'] = ele ? ele.awardName : 'Unknown Award';

        retpayload['yearMonth'] = E_main[i].yearMonth;

        // Use ternary operator to handle cases where E_mas might be undefined
        retpayload['rRType'] = ele && E_mas.find(recele => recele.id === ele.recognisationMasterBO)
            ? E_mas.find(recele => recele.id === ele.recognisationMasterBO).rRType
            : 'Unknown Type';

        data.push(retpayload);
    }

    console.log(">>", data);

    return data;
};

  PageModule.prototype.getEmpProjAllocationData = function (P_EmpProjAllocBO,P_ClientBO,P_ProjectBO) {
    console.log('##1717',P_EmpProjAllocBO);
    let data = [];
       
    for(let i=0; i<P_EmpProjAllocBO.length; i++){
      let retpayload = {};
      let cliele = P_ClientBO.find(cliele => cliele.id == P_EmpProjAllocBO[i].client);
      let projele = P_ProjectBO.find(projele => projele.id == P_EmpProjAllocBO[i].project);
      
    if(P_EmpProjAllocBO[i].allocationEndDate == "2000-01-01" ){
      console.log('##12true');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = '';
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    else{
      console.log('##11false');
      retpayload['client'] = cliele.clientName;
      retpayload['allocationEndDate'] = P_EmpProjAllocBO[i].allocationEndDate;
      retpayload['allocationStartDate'] = P_EmpProjAllocBO[i].allocationStartDate;
      retpayload['id'] = P_EmpProjAllocBO[i].id;
      retpayload['projectCode'] = projele.projectCode;
      retpayload['projectName'] = projele.projectName;
      data.push(retpayload);
    }
    console.log('##24',retpayload);    
    }
    return(data);
  };
  PageModule.prototype.buildqueryforSearchBench = function (activeFlag, globalPractice, employeeID, name, localGrade, skillGroup) {
     let query = "activeFlag='Y'";

    if (globalPractice !== undefined && globalPractice !== null && globalPractice !== '') {
        query += " and globalPractice='" + globalPractice + "'";
    }

    if (employeeID !== undefined && employeeID !== null && employeeID !== '') {
        query += " and employeeID='" + employeeID + "'";
    }

    if (name !== undefined && name !== null && name !== '') {
        query += " and id='" + name + "'";
    }

    if (localGrade !== undefined && localGrade !== null && localGrade !== '') {
        query += " and localGrade='" + localGrade + "'";
    }

    if (skillGroup !== undefined && skillGroup !== null && skillGroup !== '' && skillGroup !== 'All Skills') {
        // query += " and (skillGroup1='" + skillGroup + "' OR skillGroup2='" + skillGroup + "' OR skillGroup3='" + skillGroup + "')";
         query += " and (CapabilitySkillGroup='" + skillGroup + "')";
    }

    return query;
  };
  
  PageModule.prototype.benchSearchADPforButton = function (P_Emp, P_Alloc,P_Skill,proposalBO,currentDemandBOID,pipBO,rollofRadarBO,skillBO,capbBO) {
     var retPayload = [];
//      let empCheck = {
//     employeeID: null,
//     teamRequestNumber: null,
//     status:null
// };
 retPayload['internalb'] = [];
    retPayload['internalnb'] = [];
    retPayload['internalshadow'] = [];
    


       for(var i=0; i<P_Emp.length; i++){
         let capability=capbBO.find(ele=> ele.id==P_Emp[i].globalPractice);
    let skill1=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup1);
     let skill2=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup2);
      let skill3=skillBO.find(ele=> ele.id==P_Emp[i].skillGroup3);
      

   let pip=pipBO.find(ele=>ele.empID==P_Emp[i].id);
    let rolloff=rollofRadarBO.find(ele=>ele.employeeID==P_Emp[i].id);
         let proposal=proposalBO.find(ele=>ele.employeeID==P_Emp[i].id && ele.teamRquestNumber==currentDemandBOID);
           let proposal1=proposalBO.filter(ele=>ele.employeeID==P_Emp[i].id);
           let containsStatus = proposal1.some(record => record.status === 'Allocated' || record.status === 'Blocked/Client interview');
           let containsStatus12 = proposal1.some(record => record.status === 'Proposed' );
      let alloc=P_Alloc.filter(ele=> ele.employee==P_Emp[i].id);
      let latestRecord = alloc.sort((a, b) => new Date(b.allocationEndDate) - new Date(a.allocationEndDate))[0];
       let latestRecord1 = alloc.sort((a, b) => new Date(b.allocationStartDate) - new Date(a.allocationStartDate))[0];
      if(proposal1.length!==0){
      if (containsStatus) {
    continue;
       } else if (proposal !== undefined && currentDemandBOID === proposal.teamRquestNumber && proposal.status!=='Rejected' && proposal.status!=='Cancelled') {
           continue;
       }
      }
      if(latestRecord != undefined){
        var availableDate = new Date(latestRecord.allocationEndDate);
         var startDate = new Date(latestRecord1.allocationStartDate);
        availableDate.setDate(availableDate.getDate() + 1); 
        

        var temp = {};
        temp['id'] = P_Emp[i].employeeID;
        temp['name'] = P_Emp[i].name;
        temp['grade'] = P_Emp[i].localGrade;
         temp['billable'] = (containsStatus12 === true) ? (P_Emp[i].billable + " (Proposed)") : P_Emp[i].billable;
        temp['available'] = changeFormat(availableDate);
        temp['capab'] = capability==null?'':capability.name;
         temp['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp['skill'] = skill1==null?'':skill1.skillGroupName;
         temp['skill2'] = skill2==null?'':skill2.skillGroupName;
          temp['skill3'] = skill3==null?'':skill3.skillGroupName;
           temp['location'] = P_Emp[i].location==null?'':P_Emp[i].locationObject.items[0].location;
        // temp['type'] = P_Type;
        // temp['status'] = P_Emp[0].status;
         temp['BoID']=P_Emp[i].id;
          temp['status']=P_Emp[i].status;
           temp['pip']=pip!=undefined?true:false;
      
      
        // temp['loc'] = P_Emp[0].locationObject.items[0].location;
        // temp['demandSupplyBOId']=P_demandSupplyId;
        // temp['demandSupplyReason']=P_Comments;
        retPayload.push(temp);
        console.log('@1291'+JSON.stringify(temp));
      
        
      
    var avail_date1 = availableDate;
              var today1 = new Date();
              var curr_date1 = today1;
              var difference= (avail_date1-curr_date1);

              var days = Math.round(difference/(1000 * 3600 * 24));

if(rolloff!=undefined){
   var availableDateRolloff = new Date(rolloff.releaseDate);
              var avail_date11 = availableDateRolloff;
              var today11 = new Date();
              var curr_date11 = today11;
              var difference1= (avail_date11-curr_date11);

              var days1 = Math.round(difference1/(1000 * 3600 * 24));
}
            //     if(days <= 30 && days >=0){
            //     temp['available'] = changeFormat(availableDate);
            //     retPayload['internalb'].push(temp);
            //  }
            

             if(rolloff!=undefined && days1 <= 30 && days1 >=0){
                 temp['available'] = changeFormat(rolloff.releaseDate);
                  temp['category']='Non-Bench';
                 retPayload['internalb'].push(temp);
              }


            else if(temp['status']==="Bench - Deployable" ||  temp['status']==="Bench - Resigned"  ||  temp['status']==="Bench - Blocked"){
              temp['available'] = changeFormat(availableDate);
               temp['category']='Bench';
              retPayload['internalnb'].push(temp);             
            }

             else if(temp['status']==="Shadow "){
              temp['available1'] = changeFormat(startDate);
               temp['category']='Shadow';
              temp['ageing'] = calculateAgeInPastDayss122(temp['available1']);
             if (temp['ageing'] >= 60) {
        retPayload['internalshadow'].push(temp);
    }
              
            }
      }
        
      
       }

retPayload.internalbCount = retPayload['internalb'].length;
retPayload.internalnbCount = retPayload['internalnb'].length;
retPayload.internalshadowCount = retPayload['internalshadow'].length;

retPayload['internalnb'].sort((a, b) => {
    // First, sort by grade
    const gradeComparison = b.grade.localeCompare(a.grade);
    
    // If grades are equal, sort by id
    if (gradeComparison === 0) {
        return a.id - b.id;
    } else {
        return gradeComparison;
    }
});

retPayload['internalb'].sort((a, b) => new Date(a.available) - new Date(b.available));

  function calculateAgeInPastDayss122(birthdate) {
    var today = new Date();
    var birthDate = new Date(birthdate);
    var timeDiff = today.getTime() - birthDate.getTime();
    var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
    return daysDiff;
   }
       
    return retPayload;

   
  };

   PageModule.prototype.allresourcesADP = function (P_Emp, pipBO) {
    var retPayload = {
        allResources: []
    };

    for (var i = 0; i < P_Emp.length; i++) {
        let pip = pipBO.find(ele => ele.empID == P_Emp[i].id);
        var temp1 = {};

        temp1['id'] = P_Emp[i].employeeID;
        temp1['name'] = P_Emp[i].name;
        temp1['grade'] = P_Emp[i].localGrade == null ? '' : P_Emp[i].localGrade ;
        temp1['billable'] = P_Emp[i].billable == null ? '': P_Emp[i].billable ;
        temp1['capab'] = P_Emp[i].globalPracticeObject.items[0] ? P_Emp[i].globalPracticeObject.items[0].name : '';
        temp1['capabSkill'] = P_Emp[i].capabilitySkillGroupObject.items[0] ? P_Emp[i].capabilitySkillGroupObject.items[0].skillGroupName : '';
        temp1['skill'] = P_Emp[i].skillGroup1 == null ? '' : P_Emp[i].skillGroup1Object.items[0].skillGroupName;
        temp1['skill2'] = P_Emp[i].skillGroup2 == null ? '' : P_Emp[i].skillGroup2Object.items[0].skillGroupName;
        temp1['skill3'] = P_Emp[i].skillGroup3 == null ? '' : P_Emp[i].skillGroup3Object.items[0].skillGroupName;
        temp1['location'] = P_Emp[i].location == null ? '' : P_Emp[i].locationObject.items[0].location;
        temp1['BoID'] = P_Emp[i].id;
        temp1['status'] = P_Emp[i].status == null ? '' : P_Emp[i].status;
        temp1['pip'] = pip !== undefined ? true : false;

        retPayload.allResources.push(temp1);
    }

    retPayload.allResourcesCount = retPayload.allResources.length;

    // retPayload.allResources.sort((a, b) => {
    //     // First, sort by grade
    //     const gradeComparison1 = b.grade.localeCompare(a.grade);

    //     // If grades are equal, sort by id
    //     if (gradeComparison1 === 0) {
    //         return a.id - b.id;
    //     } else {
    //         return gradeComparison1;
    //     }
    // });

    return retPayload; // Return the corrected retPayload object
};

  PageModule.prototype.todayyy = function () {
    // Create a new Date object
var currentDate = new Date();
 
// Get the current date components
var year = currentDate.getFullYear();
var month = currentDate.getMonth() + 1; // Months are zero-based, so add 1
var day = currentDate.getDate();
 
// Format the date as a string (you can customize the format as needed)
var formattedDate = year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
 
console.log("Current Date: " + formattedDate);
return formattedDate;
  };

  
PageModule.prototype.dialogTitleforRadioset= function (data) {

    let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.id+' : '+data.name+' ('+data.grade+') '+'['+data.capab+']';
    return  name;
  };

   PageModule.prototype.allocationDate = function (availableDateStr) {
    var availableDate = new Date(availableDateStr);

// Add one day to the available date
availableDate.setDate(availableDate.getDate() + 1);

// Convert the new date back to a string if needed
var oneDayAfterAvailableDateStr = availableDate.toISOString().substring(0, 10);

// Now you have the one day after the available date in the variable oneDayAfterAvailableDateStr
console.log("One day after available date:", oneDayAfterAvailableDateStr);
return oneDayAfterAvailableDateStr;
  };
     PageModule.prototype.fileName = function (objectName,employeeID) {
    var fileName ;
    // fileName = objectName;
    fileName = 'OracleEmpResume/'+employeeID;
    var ext=objectName.split(".");
    fileName=fileName+'.'+ext[ext.length-1];
    return fileName;
  };
  PageModule.prototype.date = function () {
   let today = new Date().toISOString().slice(0, 10);
    return today;
  };

  PageModule.prototype.filePayload = function(fileObj, bucketName, fileName) {
        
        var form = new FormData();
        form.append('file', fileObj, fileName);
        form.append('json', '{"filename":"' + fileName + '", "bucket_name" : "' + bucketName + '"}');
    
        return form;
    };

//  function formatDate(date) {
//     const month = (date.getMonth() + 1).toString().padStart(2, '0');
//     const day = date.getDate().toString().padStart(2, '0');
//     return `${month}/${day}`;
// }
   PageModule.prototype.getAgeing=function(plannedDate){
    const date1 = new Date(plannedDate);
const date2 = new Date();
const diffTime = Math.abs(date2 - date1);
const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
console.log('@12'+plannedDate);
  if(plannedDate == null || date1>date2)
  {
    return 0;
  }
  else
  {
    return diffDays-1;
  }


  };

    
function changeFormat(currentDate) {
    try{
   
      var now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);
   
    }
    catch(err){
       console.log('#131'+currentDate);
      return currentDate;
    }
  }
PageModule.prototype.proposedADP = function (emp, capb, skillg, proposalBO,pipBO,loca) {
    let data = [];
    let data1 = [];
    
    // Preprocessing for faster lookup
    const empMap = new Map(emp.map(e => [e.id, e]));
    const skillgMap = new Map(skillg.map(s => [s.id, s.skillGroupName]));
    const capbMap = new Map(capb.map(c => [c.id, c.name]));
    

    for (let i = 0; i < proposalBO.length; i++) {
      let pip=pipBO.find(ele=>ele.empID==proposalBO[i].employeeID);
     
      
        const proposal = proposalBO[i];
        const a = empMap.get(proposal.employeeID);
   let loc=loca.find(ele=> ele.id==a.location);
        if (!a) continue; // Skip if employee not found

        const skillgrp1 = skillgMap.get(a.skillGroup1) || '';
        const skillgrp2 = skillgMap.get(a.skillGroup2) || '';
        const skillgrp3 = skillgMap.get(a.skillGroup3) || '';
        const capaba = capbMap.get(a.globalPractice) || '';

       const ageing11=calculateAgeInPastDays(proposal.proposalDate);
       const ageing1122=calculateAgeInPastDays8989(proposal.proposalDate,proposal.proposalEndDate);
        const retpayload = {
            employeeID: a.employeeID,
             location: loc.location,
             BoID: a.id,
            name: a.name,
            resignedstatus: a.status,
            capability: capaba,
            skillGroup1: skillgrp1,
            skillGroup2: skillgrp2,
            skillGroup3: skillgrp3,
            allocationEndDate: proposal.allocationEndDate,
            allocationStartDate: proposal.allocationStartDate,
            tEApproverEmail: proposal.tEApproverEmail,
            percentageAllocation: proposal.percentageAllocation,
            lockEndDate: proposal.lockEndDate,
            loctType: proposal.loctType,
            nBDCode: proposal.nBDCode,
            proposalDate: proposal.proposalDate,
             proposalEndDate: proposal.proposalEndDate,
            rejectionNote: proposal.rejectionNote,
            rejectionReason: proposal.rejectionReason,
            status: proposal.status,
            teamRquestNumber: proposal.teamRquestNumber,
            id: proposal.id,
            grade: a.localGrade,
            projectCode: proposal.projectCode,
            remarks: proposal.remarks,
             availability: proposal.availability,
             selfNominated: proposal.selfNominated,
             ageing:ageing11,
             ageingPast:ageing1122,
             color:ageing11 > 7,
             pip:pip!=undefined

        };
        if (proposal.status === "Proposed" || proposal.status === "Blocked/Client interview" || proposal.status === "Allocated" || proposal.status === "Self Nominated") {
            data.push(retpayload);
        } else {
            data1.push(retpayload);
        }
    }
    function calculateAgeInPastDays(birthdate) {
        var today = new Date();
        var birthDate = new Date(birthdate);
        var timeDiff = today.getTime() - birthDate.getTime();
        var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
        return daysDiff;
        }


  PageModule.prototype.getCurrentYear = function () {
    let date = new Date().toISOString().split('T')[0];
    let currentYr = new Date(date).getFullYear();
    console.log('@@currYr',currentYr);
    return currentYr;
 
  };
        function calculateAgeInPastDays8989(birthdate,date) {
          if(date!=undefined){
        var today = new Date(date);
        var birthDate = new Date(birthdate);
        var timeDiff = today.getTime() - birthDate.getTime();
        var daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
          
        return daysDiff;
          }
          else {
            return "" ;
          }
        }
    
    console.log('data', {data,data1});
    return { data, data1 };
};


  PageModule.prototype.dialogTitleForProposedAdp = function (data) {

     let name;
    // let client=(data[0].clientObject.items[0].clientName).substring(0, 20);
    name=data.employeeID+' : '+data.name+' ('+data.grade+') '+'['+data.capability+']';
    return  name;
  };
  
function formatDate(dateString) {
    let date = new Date(dateString);
    let year = date.getFullYear();
    let month = (date.getMonth() + 1).toString().padStart(2, '0'); // January is 0!
    let day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

 PageModule.prototype.gradewiseDemands = function(P_demandBO, emp, rollOffBO, cap, supply, roldate, skill,row) {
  let initData = [];
  let finalData = [];
  let empbench = [];
  let final = [];
  let final3 = [];
  let supp = [];
  let fs = [];

  let rows1=0, rows2=0, rows3=0, rows4=0, rows5=0, rows6=0, rows7=0, rows8=0, rows9=0, rows10=0,rows11=0,rows12=0,rows13=0,rows14=0,rows15=0,rows16=0,rows17=0,rows18=0;

  let curdate = formatDate(new Date());

  function formatDate(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  function parseDate(dateStr) {
    const parts = dateStr.split('-');
    return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
  }
  function parseDateGetMonth(dateStr) {
    const parts = dateStr.split('-');
    return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
  }

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb"];
  let d = new Date();
  let curr_month = d.getMonth() + 1;

  // Object to hold month names
  let monthData = {
    currentMonth: monthNames[curr_month - 1],
    nextMonth: monthNames[curr_month],
    future: monthNames[curr_month + 1] + '+'
  };

  // console.log("Step 1: Initializing data structures");
  // console.log("monthData:", monthData);

  // Populate initData array
  for (let i = 0; i < P_demandBO.length; i++) {
    let localGrade = P_demandBO[i].localGrade;
     let skillGroupName = P_demandBO[i].skillGroup && P_demandBO[i].skillGroupObject && P_demandBO[i].skillGroupObject.items && P_demandBO[i].skillGroupObject.items.length > 0
      ? P_demandBO[i].skillGroupObject.items[0].skillGroupName
      : '';
    let row = {
      localGrade: localGrade,
      skillGroup: skillGroupName,
      roleStartDate: P_demandBO[i].roleStartDate,
      demandType: P_demandBO[i].demandType ? P_demandBO[i].demandType.trim() : ''
    };
    initData.push(row);
  }

  // console.log("Step 2: initData populated");
  // console.log("initData:", initData);

  // Process initData to populate finalData
  initData.forEach(data => {
    let roleStartDate = new Date(data.roleStartDate);
    let month = roleStartDate.getMonth() + 1;
    let element = finalData.find(item => item.localGrade === data.localGrade);

    if (!element) {
      let temp = {
        localGrade: data.localGrade,
        sold_curr_month: 0,
        sold_next_month: 0,
        sold_future_month: 0,
        pastdue_sold: 0,
        soldPursuit:0,
        pursuit_curr_month: 0,
        pursuit_next: 0,
        pursuit_future: 0,
        shadow:0,
        pastdue_pursuit: 0,
        soldDemands: 0,
        currentBench: 0, // Default to 0
        rolloffs: 0,
        offers_curr: 0,
        offers_next: 0,
        offers_future: 0,
        pastdue_offers: 0,
        totalOffers:0
      };

      if (data.demandType === 'Sold Project') {
        if (month === curr_month) {
          temp.sold_curr_month = 1;
        } else if (month === curr_month + 1) {
          temp.sold_next_month = 1;
        } else if (month > curr_month + 1) {
          temp.sold_future_month = 1;
        } else if (month < curr_month) {
          temp.pastdue_sold = 1;
        }
        temp.soldDemands = 1;
      } else if (data.demandType === 'Pursuit Project') {
        if (month === curr_month) {
          temp.pursuit_curr_month = 1;
        } else if (month === curr_month + 1) {
          temp.pursuit_next = 1;
        } else if (month > curr_month + 1) {
          temp.pursuit_future = 1;
        } else if (month < curr_month) {
          temp.pastdue_pursuit = 1;
        }
        temp.soldPursuit = 1;
      }

      finalData.push(temp);
    } else {
      // Update existing element in finalData
      let index = finalData.findIndex(item => item.localGrade === element.localGrade);
      if (data.demandType === 'Sold Project') {
        if (month === curr_month) {
          finalData[index].sold_curr_month += 1;
        } else if (month === curr_month + 1) {
          finalData[index].sold_next_month += 1;
        } else if (month > curr_month + 1) {
          finalData[index].sold_future_month += 1;
        } else if (month < curr_month) {
          finalData[index].pastdue_sold += 1;
        }
        finalData[index].soldDemands += 1;
      } else if (data.demandType === 'Pursuit Project') {
        if (month === curr_month) {
          finalData[index].pursuit_curr_month += 1;
        } else if (month === curr_month + 1) {
          finalData[index].pursuit_next += 1;
        } else if (month > curr_month + 1) {
          finalData[index].pursuit_future += 1;
        } else if (month < curr_month) {
          finalData[index].pastdue_pursuit += 1;
        }
        finalData[index].soldPursuit +=1;
      }
    }
  });

  // console.log("Step 3: finalData populated");
  // console.log("finalData:", finalData);

  // Populate empbench array
 emp.forEach(employee => {
  let capability = cap.find(capability => capability.id === employee.globalPractice);
  let sg1 = skill.find(ele => ele.id === employee.CapabilitySkillGroup);
  let localGrade = employee.localGrade;
  empbench.push({
    capabilities: capability !== undefined ? capability.name : '',
    localGrade: employee.localGrade,
    grade: employee.grade,
    status: employee.status
  });
});

console.log("Step 4: empbench populated");
console.log("empbench:", empbench);

// Process empbench to populate final
empbench.forEach(item => {
  let elem = final.find(data => data.localGrade === item.localGrade);
  if (!elem) {
    let temp = {
      localGrade: item.localGrade,
      currentBench: (item.status === 'Bench - Deployable' && item.grade != 'A') ? 1 : 0,
      shadow: item.status === 'Shadow ' ? 1 : 0,
      status: item.status
    };
    final.push(temp);
  } else {
    let index = final.findIndex(data => data.localGrade === elem.localGrade);
    if (item.status === 'Bench - Deployable' && item.grade != 'A') {
      final[index].currentBench += 1;
    } else if (item.status === 'Shadow ') {
      final[index].shadow += 1;
    }
  }
});




// Process rollOffBO array
for (var e = 0; e < rollOffBO.length; e++) {
  let emp2 = emp.find(ele => ele.id === rollOffBO[e].employeeID);
  if (emp2 != undefined && emp2.globalPractice != undefined && emp2.CapabilitySkillGroup != undefined) {
    let capability = cap.find(capability => capability.id === emp2.globalPractice);
    let eskill = skill.find(ele => ele.id === emp2.CapabilitySkillGroup);
    let lg = emp2.localGrade;
    if(eskill.skillGroupName === row.skillGroup){
    fs.push({
      localGrade: lg,
      rollOfDate: rollOffBO[e].releaseDate,
      id: rollOffBO[e].employeeID
    });
  }
  }
}

// Process fs array
fs.forEach(item => {
  let elem = final3.find(data => data.localGrade === item.localGrade);
  if (!elem) {
    let temp = {
      localGrade: item.localGrade,
      id: item.id,
      rolloffs: (item.rollOfDate > curdate && item.rollOfDate < roldate) ? 1 : 0,
    };
    final3.push(temp);
  } else {
    let index = final3.findIndex(data => data.localGrade === elem.localGrade);
    if (item.rollOfDate > curdate && item.rollOfDate < roldate) {
      final3[index].rolloffs += 1;
    }
  }
});



 
 const uniqueArray = [];

// // Process supply array
for (let a = 0; a < supply.length; a++) {
  // let scap = cap.find(ele => ele.id == supply[a].capability); // Capability Name
  let eg = emp.find(ele => ele.id == supply[a].panelL1);
  let ss1 = skill.find(ele => ele.id == supply[a].skillGroup1); // Skill set 1
  let ss2 = skill.find(ele => ele.id == supply[a].skillGroup2); // Skill set 2
  let ss3 = skill.find(ele => ele.id == supply[a].skillGroup3); // Skill set 3

  function getMonthFromDate(dateStr) {
    // Split the string into parts [YYYY, MM, DD]
    const parts = dateStr.split('-');
    // Extract the month part (parts[1]) and convert it to a number
    const month = parseInt(parts[1], 10); // Use parseInt with radix 10 to ensure correct parsing
    return month;
  }

  let trimmedDate = supply[a].doj;
  if (supply[a].doj != null) {
    trimmedDate = supply[a].doj.trim();
  } else {
    trimmedDate = supply[a].doj;
  }

  if (trimmedDate != null && trimmedDate !== "" && supply[a].status === '8. Joined') { // Ensure doj exists before proceeding
    let dojMonth = getMonthFromDate(trimmedDate);

    initData.forEach(data => {
      if 
         (data.skillGroup === ss1.skillGroupName || data.skillGroup === ss2?.skillGroupName || data.skillGroup === ss3?.skillGroupName){
        if (!uniqueArray.includes(supply[a].id)) {
          console.log("Months.....", supply[a].doj);
          uniqueArray.push(supply[a].id);

          // Check and add count based on dojMonth
          let element = supp.find(item =>  item.skillGroup === data.skillGroup);
          if (!element) {
            // If no element found, create a new one
            let temp1 = {
              skillGroup: data.skillGroup,
              sold_curr_month: 0,
              sold_next_month: 0,
              sold_future_month: 0,
              pastdue_sold: 0,
              pursuit_curr_month: 0,
              shadow: 0,
              pursuit_next: 0,
              pursuit_future: 0,
              pastdue_pursuit: 0,
              soldDemands: 0,
              soldPursuit: 0,
              currentBench: 0, // Default to 0
              rolloffs: 0,
              offers_curr: 0, // Present Month
              offers_next: 0, // Next Month
              offers_future: 0, // Future Month
              pastdue_offers: 0, // Before Current Month
              totalOffers: 0
            };
            if (dojMonth === curr_month) {
              temp1.offers_curr = 1;
            } else if (dojMonth === curr_month + 1) {
              temp1.offers_next = 1;
            } else if (dojMonth > curr_month + 1) {
              temp1.offers_future = 1;
            } else if (dojMonth < curr_month) {
              temp1.pastdue_offers = 1;
            }
            temp1.totalOffers = 1;
            supp.push(temp1);
          } else {
            let index = supp.findIndex(item => item.skillGroup === data.skillGroup);
            if (index !== -1) {
              if (dojMonth === curr_month) {
                supp[index].offers_curr += 1;
              } else if (dojMonth === curr_month + 1) {
                supp[index].offers_next += 1;
              } else if (dojMonth > curr_month + 1) {
                supp[index].offers_future += 1;
              } else if (dojMonth < curr_month) {
                supp[index].pastdue_offers += 1;
              }
              supp[index].totalOffers += 1;
            }
          }
          }
        }
      });
    }
  }
    
  


  // const uniqueArr = [...new Set(uniqueArray)];
  // console.log("Uni..........",uniqueArr);

  
  // // console.log("Step 5: final populated");
  // // console.log("supp:", supp);

  // // Merge finalData with final to create mergedData
  let mergedData = finalData.map(item => {
    let match = final.find(subItem => subItem.localGrade === item.localGrade);
    let match3 = final3.find(subItem => subItem.localGrade === item.localGrade);
    let match2 = supp.find(subItem => subItem.skillGroup === item.skillGroup);
    if (match) {
      return {
        ...match,
        localGrade: item.localGrade,
  
        sold_curr_month: item.sold_curr_month,
        sold_next_month: item.sold_next_month,
        sold_future_month: item.sold_future_month,
        pastdue_sold: item.pastdue_sold,
        soldDemands: item.soldDemands,
        soldPursuit:item.soldPursuit,
        pursuit_curr_month: item.pursuit_curr_month,
        pursuit_next: item.pursuit_next,
        pursuit_future: item.pursuit_future,
        pastdue_pursuit: item.pastdue_pursuit,
        // currentBench:match ? match.currentBench:0,
        rolloffs: match3 ? match3.rolloffs : 0,
        pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
        offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
        offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
        offers_future: match2 ? (match2.offers_future || 0) : 0, // Include offers_future_month from item
        totalOffers: match2 ? (match2.totalOffers || 0) : 0
      };
    } else {
      // Include unmatched data from finalData
      return {
        localGrade: item.localGrade,
        sold_curr_month: item.sold_curr_month,
        sold_next_month: item.sold_next_month,
        sold_future_month: item.sold_future_month,
        pastdue_sold: item.pastdue_sold,
        soldDemands: item.soldDemands,
        soldPursuit:item.soldPursuit,
        pursuit_curr_month: item.pursuit_curr_month,
        pursuit_next: item.pursuit_next,
        pursuit_future: item.pursuit_future,
        pastdue_pursuit: item.pastdue_pursuit,
        rolloffs: match3 ? match3.rolloffs : 0,
        currentBench: 0,
        shadow:0,
        pastdue_offers: match2 ? (match2.pastdue_offers || 0) : 0, // Include pastdue_offers from item
        offers_curr: match2 ? (match2.offers_curr || 0) : 0, // Include offers_curr_month from item
        offers_next: match2 ? (match2.offers_next || 0) : 0, // Include offers_next_month from item
        offers_future: match2 ? (match2.offers_future || 0) : 0, // Include offers_future_month from item
        totalOffers: match2 ? (match2.totalOffers || 0) : 0
      };
    }
  });

  // console.log("Step 6: mergedData populated");
  // console.log("mergedData:", mergedData);

  mergedData['currentMonth'] = monthNames[curr_month - 1];
  mergedData['nextMonth'] = monthNames[curr_month];
  mergedData['future'] = monthNames[curr_month + 1] + '+';
  mergedData.sort((a, b) => b.soldDemands - a.soldDemands);
  

  
  return  mergedData;
};

  return PageModule;
});
