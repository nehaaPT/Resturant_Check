define([], () => {
  'use strict';

    var PageModule = function PageModule() {};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnValue = function (arg1)  {
      console.log("!!!",arg1);
    };
     PageModule.prototype.getcourse=function(t_cour,t_cir,circ) {
      var retArray = [];
      for(var i = 0; i<t_cir.length;i++) {
        if(circ[0].curriculum == t_cir[i].curriculum) {
          for(var j=0;j<t_cour.length;j++){
            var innerArray = {};
            if(t_cour[j].curriculum == t_cir[i].id) {
              innerArray['course'] = t_cour[j]['course'];
              retArray.push(innerArray);
            }
          }
        }
      }
      //console.log("!!!",t_cour);
      //console.log("!!!",t_cir);
      //console.log("!!!",circ);
      //console.log("!!!",retArray);

      return retArray;
    };
    PageModule.prototype.postcurriculumtypedata = function (arg1,capability)  {
      console.log("LLL",capability);
      var data=[];
      
      for(var i=0;i<arg1.length;i++){
         var retpayload = {};
        retpayload ['curriculumType']=arg1[i].curriculumType;
        retpayload ['description']=arg1[i].description;
        retpayload ['id']=arg1[i].id;
        
 retpayload ['capability']= capability.find(ele => ele.id == arg1[i].capability).name;
 data.push(retpayload);
 //console.log("LLL",data);
      }
      return data;

    };

  PageModule.prototype.getFileData = function (excelData,uploadMasterObject,t_curTy,t_curr,t_cour,t_top) {
    var readExcelPromise = new Promise(function (resolve) {
      var excelFile = excelData[0];
      var returnArray = [];
      //console.log("@@@",excelFile);
      var size;

      var reader = new FileReader();

      reader.onload = function (e) {
        //console.log("rrr",excelFile);
        var data = e.target.result;
        var excelPayloadArray = new Array();
        //var errorArray = [];
        var workBook = XLSX.read(data, { type: 'binary'});
        var allSheets = workBook.SheetNames;
        // var allSheets = [];
        //console.log("!!!",allSheets);
        size = allSheets.size;
        //console.log("!!!",workBook);
        var sheetRows = [];
        var sheetRows2 = [];
        var sheetRows3 = [];
        var sheetRows4 = [];

        // Curriculum Type
        for (var i = 0; i < 1; i++) {
          sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);
          //console.log("!!!",allSheets[i]);
          //console.log("!!!",sheetRows);
          //returnArray.push(sheetRows);
        }
        console.log("!!!",sheetRows);
        for(var j = 0; j < sheetRows.length; j++) {
            var count = 0;
            for(var index1 = 0; index1 < t_curTy.length; index1++) {
              if(sheetRows[j]['Curriculum Type'] == t_curTy[index1].curriculumType) {
                var innerObj = {};
                innerObj['capability'] = sheetRows[j]['Capability'];
                innerObj['curriculumType'] = sheetRows[j]['Curriculum Type'];
                innerObj['description'] = sheetRows[j]['Description'];
                innerObj['id'] = t_curTy[index1].id;
                uploadMasterObject.curriculumTypeArray.updateArray.push(innerObj);
                count += 1;
                break;
              }
              }
              if(count == 0) {
                var innerObj1 = {};
                innerObj1['capability'] = sheetRows[j]['Capability'];
                innerObj1['curriculumType'] = sheetRows[j]['Curriculum Type'];
                innerObj1['description'] = sheetRows[j]['Description'];
                uploadMasterObject.curriculumTypeArray.createArray.push(innerObj1);
            }
          //console.log("!!!",innerObj);
        }
      
       // Curriculum
       if(uploadMasterObject.curriculumTypeArray.updateArray.length != sheetRows.length) {
       for (var k = 1; k < 2; k++) {
          sheetRows2 = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[k]]);
          //console.log("!!!",allSheets[i]);
         // console.log("!!!",sheetRows2);
          //returnArray.push(sheetRows2);
        }
        for(var l = 0; l < sheetRows2.length; l++) {
             var innerObj2 = {};
          innerObj2['curriculumType'] = sheetRows2[l]['Curriculum Type'];
          innerObj2['curriculum'] = sheetRows2[l]['Curriculum'];
          innerObj2['description'] = sheetRows2[l]['Description'];
               uploadMasterObject.curriculumArray.createArray.push(innerObj2);
           // }
          //console.log("!!!",innerObj2);
        }

        for (var m = 2; m < 3; m++) {
          sheetRows3 = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[m]]);
          //console.log("!!!",allSheets[i]);
          //console.log("!!!",sheetRows3);
          //returnArray.push(sheetRows2);
        }
        for(var n = 0; n < sheetRows3.length; n++) {
         var innerObj3 = {};
          innerObj3['curriculumType'] = sheetRows3[n]['Curriculum Type'];
          innerObj3['curriculum'] = sheetRows3[n]['Curriculum'];
          innerObj3['course'] = sheetRows3[n]['Course'];
          innerObj3['description'] = sheetRows3[n]['Description'];
            uploadMasterObject.courseArray.createArray.push(innerObj3);
          //}
          //console.log("!!!",innerObj2);
        }

       for (var p = 3; p < 4; p++) {
          sheetRows4 = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[p]]);
          //console.log("!!!",allSheets[i]);
          //console.log("!!!",sheetRows4);
          //returnArray.push(sheetRows2);
        }
        for(var q = 0; q < sheetRows4.length; q++) {
         var innerObj4 = {};
          innerObj4['curriculumType'] = sheetRows4[q]['Curriculum Type'];
          innerObj4['curriculum'] = sheetRows4[q]['Curriculum'];
          innerObj4['course'] = sheetRows4[q]['Course'];
          innerObj4['topic'] = sheetRows4[q]['Topic'];
          innerObj4['description'] = sheetRows4[q]['Description'];
          innerObj4['trainingHours'] = sheetRows4[q]['Training Duration (Hours)'];
          innerObj4['seq'] = sheetRows4[q]['Sequence'];
          innerObj4['topicLink'] = sheetRows4[q]['Topic Link'];
          // innerObj4['seq'] = q;
          //innerObj4['trainingHours'] = sheetRows4[q]['__EMPTY_5'];
            uploadMasterObject.topicArray.createArray.push(innerObj4);
         // } 
          //console.log("!!!",innerObj2);
        }
        resolve(uploadMasterObject);   
      };
      };
     reader.readAsBinaryString(excelFile);
      console.log("!!!",uploadMasterObject);       
    });
   return uploadMasterObject;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  // PageModule.prototype.curriculumFunction = function (curriculumArray) {
  //   var returnArray = [];
  //   for(var i = 0; i < curriculumArray.length; i++) {
  //     var innerObj = {};
  //   }
  //   console.log("!!!",curriculumArray);
  // };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getCurriculumData = function (curriculumTypeUploadedData,uploadMasterObject) {
    var returnArray = [];
    for(var i = 0; i < uploadMasterObject.curriculumArray.createArray.length; i++) {
      for(var j = 0; j < curriculumTypeUploadedData.length; j++) {
        if(uploadMasterObject.curriculumArray.createArray[i].curriculumType == curriculumTypeUploadedData[j].curriculumType) {
          var innerObj = {};
          innerObj['curriculumType'] = curriculumTypeUploadedData[j].id;
          innerObj['curriculum'] = uploadMasterObject.curriculumArray.createArray[i].curriculum;
          innerObj['description'] = uploadMasterObject.curriculumArray.createArray[i].description;
          returnArray.push(innerObj);
        }
      }
    }
    //console.log("!!!",curriculumTypeUploadedData);
    //console.log("!!!",uploadMasterObject);
    //console.log("!!!",returnArray);
     return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getCourseData = function (curriculumUploadedData,uploadMasterObject) {
    var returnArray = [];
    for(var i = 0; i < uploadMasterObject.courseArray.createArray.length; i++) {
      for(var j = 0; j < curriculumUploadedData.length; j++) {
        if(uploadMasterObject.courseArray.createArray[i].curriculumType == curriculumUploadedData[j].curriculumTypeName && uploadMasterObject.courseArray.createArray[i].curriculum == curriculumUploadedData[j].curriculum) {
          var innerObj = {};
          innerObj['curriculumType'] = curriculumUploadedData[j].curriculumType;
          innerObj['curriculum'] = curriculumUploadedData[j].id;
          innerObj['course'] = uploadMasterObject.courseArray.createArray[i].course;
          innerObj['description'] = uploadMasterObject.courseArray.createArray[i].description;
          returnArray.push(innerObj);
        }
      }
    }
     console.log("!!!",curriculumUploadedData);
     //console.log("!!!",uploadMasterObject);
     //console.log("!!!",returnArray);

     return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTopicData = function (courseUploadedData,uploadMasterObject) {
    var returnArray = [];
    var count = 0;
    for(var i = 0; i < uploadMasterObject.topicArray.createArray.length; i++) {
      for(var j = 0; j < courseUploadedData.length; j++) {
        if(uploadMasterObject.topicArray.createArray[i].course == courseUploadedData[j].course) {
          var innerObj = {};
          count += 1;
          innerObj['curriculumType'] = courseUploadedData[j].curriculumType;
          innerObj['curriculum'] = courseUploadedData[j].curriculum;
          innerObj['course'] = courseUploadedData[j].id;
          innerObj['topic'] = uploadMasterObject.topicArray.createArray[i].topic;
          innerObj['description'] = uploadMasterObject.topicArray.createArray[i].description;
          innerObj['trainingHours'] = uploadMasterObject.topicArray.createArray[i].trainingHours;
          innerObj['seq'] = uploadMasterObject.topicArray.createArray[i].seq;
          if(uploadMasterObject.topicArray.createArray[i].topicLink != undefined) {
            innerObj['topicLink'] = uploadMasterObject.topicArray.createArray[i].topicLink;
            innerObj['activeLink'] = "Y";
          }
          else {
            innerObj['activeLink'] = "N";
          }
          //innerObj['activeLink'] = "N";
          innerObj['seq'] = uploadMasterObject.topicArray.createArray[i].seq;

          returnArray.push(innerObj);
        }
      }
    }

     //console.log("!!!",courseUploadedData);
     //console.log("!!!",uploadMasterObject);
     console.log("!!!",returnArray);

     return returnArray;
  };

PageModule.prototype.reloadPage = function () {
    location.reload();
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.validateCurriculumType = function (t_curTy,curTy) {
    var returnArray = [];
    for(var i = 0; i < curTy.length; i++) {
      var count = 0;
      for(var j = 0; j < t_curTy.length; j++) {
        if(curTy[i].curriculumType == t_curTy[j].curriculumType) {
          count += 1;
          continue;
        }
      }
      if(count == 0) {
        var innerObj = {};
        innerObj['curriculumType'] = curTy[i].curriculumType;
        innerObj['activeFlag'] = "Y";
      }
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.downloadFunction = function (t_curTy,t_curr,t_cour,t_top) {
    var multArray = new Array();
    //console.log("!!!",t_curTy);
    //console.log("!!!",t_curr);
    //console.log("!!!",t_cour);
   // console.log("!!!",t_top);
    // for(var i = 0; i < t_curTy.length; i++){
    //   for(var j  = 0; j < t_curr.length; j++) {
    //     if(t_curTy[i].id == t_curr[j].curriculumType) {
    //     for(var k = 0; k < t_cour.length; k++)      {
    //       if(t_curr[j].id == t_cour[k].curriculum) {
          for(var i = 0; i <= t_top.length; i++) {
            // if(t_cour[k].id == t_top[l].course) {
             var payloadArray = new Array();
            if(i == 0) {
            payloadArray.push('Capability');
            payloadArray.push('Curriculum Type');
            payloadArray.push('Curriculum');
            payloadArray.push('Course');
            payloadArray.push('Topic');
            payloadArray.push('Description');
            payloadArray.push('Topic Link');
            payloadArray.push('Training Duration');
          }
        else{
           payloadArray.push(t_curTy.find(ele => ele.id == t_top[i-1].curriculumType).capability);
           payloadArray.push(t_curTy.find(ele => ele.id == t_top[i-1].curriculumType).curriculumType);
           payloadArray.push(t_curr.find(ele => ele.id == t_top[i-1].curriculum).curriculum);
           payloadArray.push(t_cour.find(ele => ele.id == t_top[i-1].course).course);
           payloadArray.push(t_top[i-1].topic);
           payloadArray.push(t_top[i-1].description);
           payloadArray.push(t_top[i-1].topicLink);
           payloadArray.push(t_top[i-1].trainingHours);
          //payloadArray.push(t_top[l-1].topic);
          //  payloadArray.push(Number(train_adp[i-1].creditHrs));
          //  var date = new Date(train_adp[i-1].month);
          //  const formattedDate = date.toLocaleDateString('en-GB', {
          //  month: 'short', year: 'numeric'
          //  }).replace(/ /g, '-');
          //  payloadArray.push(formattedDate);
           //console.log("**",typeof(payloadArray[10]));
         }
           multArray.push(payloadArray); 
          }
    //      }
    //     }
    //    }
    //   }
    //  }
    // }
    //console.log("!!!",multArray);
    return multArray;
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.writeToExcelFunction = function (data) {
    var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Training");
  var ws = XLSX.utils.aoa_to_sheet(data);
  wb.Sheets["Training"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'csv',  type: 'binary'});
    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Training_Master_" + new Date().toISOString().split('T')[0] + ".csv";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) {// feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  };

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  PageModule.prototype.updatedLinkData = function (t_link,t_top,updatedRowData,activeLinkType) {
    var returnArray = [];
    for(var i = 0; i < t_top.length; i++) {
      //console.log("!!!",t_top[i].id);
      if(t_top[i].id == updatedRowData['id'] && t_top[i].topicLink != updatedRowData['topicLink']) {
        var innerObj = {};
        var innerObj2 = {};
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        //console.log("!!!",t_top[i].id);
        var count = 0;
       if (t_link.length != 0) {
        for(var j = 0; j < t_link.length; j++) {
          if(t_link[j].topic == t_top[i].id && t_link[j].activeLink == 'Y' && count == 0) {
          innerObj['activeLink'] = 'N';
          innerObj['id'] = t_link[j].id;
          innerObj['linkExpireDate'] = today;
          activeLinkType.updateArray.push(innerObj);
          innerObj2['activeLink'] = 'Y';
          innerObj2['activityCode'] = updatedRowData['id'];
          innerObj2['topic'] = updatedRowData['id'];
          innerObj2['topicLink'] = updatedRowData['topicLink'];
          //innerObj2['trainingHours'] = t_top[i].trainingHours;
          innerObj2['curriculumType'] = t_top[i].curriculumType;
          innerObj2['curriculum'] = t_top[i].curriculum;
          innerObj2['course'] = t_top[i].course;
          activeLinkType.addArray.push(innerObj2);
          count += 1;
          }
        }
          if(count == 0) {
          innerObj['activeLink'] = 'N';
          innerObj['activityCode'] = updatedRowData['id'];
          innerObj['topic'] = updatedRowData['id'];
          innerObj['topicLink'] = t_top[i].topicLink;
          //innerObj['trainingHours'] =  t_top[i].trainingHours;
          innerObj['curriculumType'] = t_top[i].curriculumType;
          innerObj['curriculum'] = t_top[i].curriculum;
          innerObj['course'] = t_top[i].course;
          innerObj['linkExpireDate'] = today;
          activeLinkType.addArray.push(innerObj);
          innerObj2['activeLink'] = 'Y';
          innerObj2['activityCode'] = updatedRowData['id'];
          innerObj2['topic'] = updatedRowData['id'];
          innerObj2['topicLink'] = updatedRowData['topicLink'];
          //innerObj2['trainingHours'] =  t_top[i].trainingHours;
          innerObj2['curriculumType'] = t_top[i].curriculumType;
          innerObj2['curriculum'] = t_top[i].curriculum;
          innerObj2['course'] = t_top[i].course;
          activeLinkType.addArray.push(innerObj2);
          }
       }
       else {
          innerObj['activeLink'] = 'N';
          innerObj['activityCode'] = updatedRowData['id'];
          innerObj['topic'] = updatedRowData['id'];
          innerObj['topicLink'] = t_top[i].topicLink;
          //innerObj['trainingHours'] =  t_top[i].trainingHours;
          innerObj['curriculumType'] = t_top[i].curriculumType;
          innerObj['curriculum'] = t_top[i].curriculum;
          innerObj['course'] = t_top[i].course;
          innerObj['linkExpireDate'] = today;
          activeLinkType.addArray.push(innerObj);
          innerObj2['activeLink'] = 'Y';
          innerObj2['activityCode'] = updatedRowData['id'];
          innerObj2['topic'] = updatedRowData['id'];
          innerObj2['topicLink'] = updatedRowData['topicLink'];
          //innerObj2['trainingHours'] =  t_top[i].trainingHours;
          innerObj2['curriculumType'] = t_top[i].curriculumType;
          innerObj2['curriculum'] = t_top[i].curriculum;
          innerObj2['course'] = t_top[i].course;
          activeLinkType.addArray.push(innerObj2);
       }
    }
  }
    //console.log("!!!",t_top);
    //console.log("!!!",updatedRowData);
    //console.log("!!!",activeLinkType);

    return activeLinkType;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.topicAssignedEmployee = function (rowData,t_track,t_emp) {
    var returnArray = [];
    for(var i = 0; i < t_track.length; i++) {
      if(t_track[i].topic == rowData.id && t_track[i].Status != "Completed") {
        var innerObj = {};
        var ele = t_emp.find(ele => ele.id == t_track[i].employeeID);
        var empID = t_emp.find(ele => ele.id == t_track[i].employeeID).employeeID;
        var empName = t_emp.find(ele => ele.id == t_track[i].employeeID).name;
        var empMail = t_emp.find(ele => ele.id == t_track[i].employeeID).email;
        //innerObj['id'] = t_track[i].id;
        innerObj['employeeID'] = empID;
        innerObj['name'] = empName;
        innerObj['mail'] = empMail;
        innerObj['topic'] = rowData.topic;
        innerObj['topicLink'] = rowData.topicLink;
        innerObj['trainingHours'] = rowData.trainingHours;
        innerObj['targetDate'] = t_track[i].targetDate;
        returnArray.push(innerObj);
      }
    }
    //console.log("!!!",returnArray);
    //console.log("!!!",rowData);
    //console.log("!!!",t_track);
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.emailBody = function (data) {
    var body = "";
    var myViewlink="https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/";
    var raiseTicketLink = "https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/?page=shell&shell=main&main=main-suggestionformat";
    var columnStyle = "text-align: center; vertical-align: middle;";
    body += "<head> <style>.sty{text-align: center; vertical-align: middle;} table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; } td, th { border: 1px solid; text-align:left; padding: 10px; } th { background-color: #ADD8E6; text-align:center; } </style> </head> <br>";
    body += "Dear, ";
    body += data.name;
    body += "<br><br>The following topic link has been update, Please use the below link in the table going forward: <br><br>";
    body += "<table><tr> <th>Topic Name</th> <th>Link</th> <th>Training Duration</th> <th>Due Date</th> </tr>";
    // // for(var j = 0; j < name.length; j++) {
    // for(var i = 0; i < sessions.length; i++) {
    //   if(sessions[i].employeeID == empID) {
        var date = new Date(data.targetDate);
       const formattedDate = date.toLocaleDateString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).replace(/[/]/g, '-');
    //   //    if(i == sessions.length-1) {
    body += "<tr><td>"+data.topic+"</td><td class = sty><a href="+data.topicLink+">Click Here</a></td><td class = sty>"+data.trainingHours+" Hours</td><td class = sty>"+formattedDate+"</td></tr>";
    //   // }
    //     body += "<tr><td>"+sessions[i].topic+"</td><td class = sty><a href="+sessions[i].topicLink+">Click Here</a></td><td class = sty>"+sessions[i].trainingHours+" Hours</td><td class = sty>"+formattedDate+"</td></tr>";
    //   }
    // }
    body += "</table><br><br>";
    body += "To access the above Training, <a href="+myViewlink+">click here</a> Or you can follow the path: My View-->> My Training -->> My Assigned Training<br><br>";
    body += "Note:<br><br>";
    body += "       •	In case of any issues while accessing below links then please raise a ticket on <a href="+raiseTicketLink+">My View</a>(Login on My View >> My view -> My Ticket -> Create Ticket)";
    body += "<br><br>From,<br>NA Oracle Competency</body>";

    return body;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.curriculumTypeValidateFunction = function (current,t_curTy) {
    var validateStatus;
    for(var i = 0; i < t_curTy.length; i++) {
      if(current == t_curTy[i].curriculumType) {
        validateStatus = "Already exist";
        break;
      }
    }
    return validateStatus;
  };


  return PageModule;
});
