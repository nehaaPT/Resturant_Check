define([], () => {
  'use strict';

  var PageModule = function PageModule() {};

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.buildQFormat = function (format) {
    var qparameter=''
    if (format=="Both")
    qparameter="(employeeBOObject.format='US' or employeeBOObject.format='India')";

    else if(format=="US") {
      qparameter="employeeBOObject.format='US'";
    }
    else{
      qparameter="employeeBOObject.format='India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };
  
    PageModule.prototype.getskill= function(emp,app) {
      var data=[];
      for(var i=0;i<app.length;i++){
        var eap= emp.find(ele=>ele.id==app[i].employeeBO);
      
        // bhargav1 = id.relation 
        var temp={};
            temp['name']=eap!=null ? eap.name:'Team';
            temp['appreciationMsg']=app[i].appreciationMsg;
            temp['customerName']=app[i].customerName;
           temp['teamAppreciation']=app[i].teamAppreciation;
           temp['yearMonth']=app[i].yearMonth;
        data.push(temp);
         }
      return data;
    }
  return PageModule;
});
