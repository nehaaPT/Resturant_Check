define(['ojs/ojarraytreedataprovider', 'vb/BusinessObjectsTransforms'], function (ArrayTreeDataProvider, BOTransforms)  {
  'use strict';
 var PageModule = function PageModule() {};
    
  
   PageModule.prototype.getName = function (context) {
     console.log("@",context.data.name);
    return context.data.name;
  };
  PageModule.prototype.processFilter = function (configuration, options, transformsContext) {
     var textValue = options && options.text;
    
     if (transformsContext && transformsContext['vb-textFilterAttributes']) {
       console.log(transformsContext['vb-textFilterAttributes'][3]);
       var options_new = {
         op: '$or',
        criteria: [
        ]
     };

     for (var i = 0; i < transformsContext['vb-textFilterAttributes'].length; i++) {
         var itemCriterion = {};
         itemCriterion.attribute = transformsContext['vb-textFilterAttributes'][i];
    itemCriterion.op = '$co';
       itemCriterion.value = textValue;
         options_new.criteria.push(itemCriterion);
      console.log(itemCriterion);
        
       }
       var options_new1 = {
    op: '$and',
       criteria: [
      ]
       };
        
     options_new1.criteria.push(options_new);   
        
     
     var itemCriterion1 = {};
         itemCriterion1.attribute = 'activeFlag';
         itemCriterion1.op = '$eq';
         itemCriterion1.value = 'Y';
         options_new1.criteria.push(itemCriterion1);
 
        
        
 
//       // - NOTE -
//       / below assignment override any existing FilterCriterion set on SDP.
// proper solution is to merge options_new into existing conditions
       options = options_new1;
    }

    return BOTransforms.request.filter(configuration, options);
  
  };
   PageModule.prototype.roleEmployeeADP = function (cap,emp,role) {
    
  var retpay=[];
    for(var i=0;i<role.length;i++)
    {
      if(role[i].roleIdObject.items[0].roleName == 'Recruitment CL' || role[i].roleIdObject.items[0].roleName == 'Panel' ){
      var data={};
      data['id']=role[i].id;
      var ele = emp.find(ele=>ele.id == role[i].employeeId);
      data['employeeDetails'] = ele.name;
      data['capability'] = (cap.find(ele1 => ele1.id == ele.globalPractice)).name;
      data['roleName'] = role[i].roleIdObject.items[0].roleName;

    
    retpay.push(data);
    }
    }
    return retpay;
  };

  return PageModule;
});
