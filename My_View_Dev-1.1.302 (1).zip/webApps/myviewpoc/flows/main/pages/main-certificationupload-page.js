define([], () => {
  'use strict';
let PageModule = function PageModule() {};

 PageModule.prototype.constructEmailNotification=function(employeeId, empData, certDetails,remarks) {
       let employee = empData.find(element => element.id == employeeId);
    let employeeName = employee ? employee.name : "";
    let employeeEmail = employee ? employee.email : "";

    

     let certName = certDetails[0].certificationName != null ? certDetails[0].certificationName : "-";
     let certCode = certDetails[0].certificationCode != null ? certDetails[0].certificationCode : "-";
     let capy = certDetails[0].capability != null ? certDetails[0].capability : "-";
     let exam = certDetails[0].examDate != null ? certDetails[0].examDate : "-";
    

    var subject = "Required Certification for Employee: " +employeeName+ "";

    // var emailBody = "";
    // emailBody += "Dear " + employeeName + ",\n\n";
    // emailBody += "I trust this message finds you well. As part of our ongoing commitment to fostering continuous learning and professional development, we are excited to offer you an opportunity to enhance your skills and knowledge through an upskilling training program.\n\n";
    // emailBody += "Training Program Details:\n";
    // emailBody += "Course Title: " + trainName + "\n";
    // emailBody += "Training Portal Link: " + trainingDetails[0].portalLink + "\n";
    // emailBody += "Duration: " + trainingDetails[0].startDate + " to " + trainingDetails[0].endDate + "\n";
    // emailBody += "Remarks: " + remarks + "\n\n";
    // emailBody += "Make sure to complete the trainings by the end date mentioned.\n\n";
    // emailBody += "Next Steps: Once the Training is complete, go to MyView & change the status to complete. Do Note once confirmed a confirmation email will be sent to the competency & capability confirming on the final status.\n\n";
    // emailBody += "Thank you for your dedication and commitment to excellence. We look forward to supporting you on this exciting journey of growth and learning.\n\n";
    // emailBody += "Best regards,\nCompetency Team.\n\n";
    // emailBody += "[For Queries reach out to Ambika Bhosle / Bindu Yedla]";

    return {
        Subject: subject,
        // MailBody: emailBody,
        name: employeeName,
        email: employeeEmail,
        cName:certName,
        cCode:certCode,
        cap:capy,
        edate:exam,
        rmark:remarks
    };
    };

    


PageModule.prototype.changeFormat = function (currentDate) {
    try {

     let now = new Date(currentDate);
      return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10);

    }
    catch (err) {
      // console.log('#131'+currentDate);
      return currentDate;
    }
  };

 PageModule.prototype.buildQFormat = function (format) {
    var qparameter=''
    if (format=="Both")
    qparameter="(employeeIDObject.format='US' or employeeIDObject.format='India')";

    else if(format=="US") {
      qparameter="employeeIDObject.format='US'";
    }
    else{
      qparameter="employeeIDObject.format='India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };

  PageModule.prototype.searchCert = function (assignCertBO,empBO,certCatBO,capBO) {
         var data =[];
    
    for(var i = 0; i<assignCertBO.length; i++) {

      var retpayload = {};
      var emp = empBO.find(ele => ele.id == assignCertBO[i].employeeID);
      var cm = certCatBO.find(ele => ele.id == assignCertBO[i].category);
      var capy = capBO.find(ele=>ele.id==assignCertBO[i].capability);

      retpayload['certificationCode'] = assignCertBO[i].certificationCode!=null?assignCertBO[i].certificationCode:'';
      retpayload['certificationName'] = assignCertBO[i].certificationName!=null?assignCertBO[i].certificationName:'';
      retpayload['status'] = assignCertBO[i].status!=null?assignCertBO[i].status:'';
      retpayload['employeeID'] = emp.employeeID!=null?emp.employeeID:'';
      retpayload['employeeName'] = emp.name!=null?emp.name:'';
      retpayload['region'] = emp.region!=null?emp.region:'';
      retpayload['format'] = emp.format!=null?emp.format:'';
      retpayload['categoryObject'] = cm.category!=null?cm.category:'';
      retpayload['capabilityObject'] = capy.name!=null?capy.name:'';
      retpayload['examDate'] = assignCertBO[i].examDate!=null?assignCertBO[i].examDate:'';
      retpayload['remarks'] = assignCertBO[i].remarks!=null?assignCertBO[i].remarks:'';
      retpayload['id'] = assignCertBO[i].id!=null?assignCertBO[i].id:'';
     
      console.log('@25'+JSON.stringify(retpayload));
     
      data.push(retpayload);
    }
    return data;
  };

PageModule.prototype.uploadTes = function (excelData, excelplayloadarray, certCategoryBO, certMasterBO, assignCertBO, empBO, capBO) {
    var readExcelPromise = new Promise(resolve => {
        var excelFile = excelData[0];
        var reader = new FileReader();

        var createTesArray = []; // Initialize an empty array to store the data

        reader.onload = function (e) {
            var data = e.target.result;
            var workBook = XLSX.read(data, { type: 'binary' });
            var allSheets = workBook.SheetNames;

            for (var i = 0; i < allSheets.length; i++) {
                var sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);

                for (var index = 0; index < sheetRows.length; index++) {
                    var parsedSheetRows = sheetRows[index];
                    var retpayload = {};

                    var empid = empBO.find(ele => ele.employeeID == parsedSheetRows['employeeID']);
                    var cgy = certCategoryBO.find(ele => ele.category == parsedSheetRows['category']);
                    var certcode = parsedSheetRows['certificationCode'];
                    var ccodeid = assignCertBO.find(ele => ele.certificationCode == parsedSheetRows['certificationCode']);
                    var certname = parsedSheetRows['certificationName'];
                    var cnameid = assignCertBO.find(ele => ele.certificationName == parsedSheetRows['certificationName']);
                    var capy = parsedSheetRows['capability'];
                    var cap = capBO.find(ele => ele.name == parsedSheetRows['capability']);
                    var rem = parsedSheetRows['remarks'];

                    retpayload['employeeID'] = empid.id;
                    retpayload['name'] = empid.id;
                    retpayload['category'] = cgy.id;
                    retpayload['certificationCode'] = certcode;
                    retpayload['certificationName'] = certname;
                    retpayload['remarks'] = rem;
                    retpayload['capability'] = cap.id;

                    createTesArray.push(retpayload); // Push the object directly into the array
                }
            }
            resolve(createTesArray); // Resolve with the single array
        };

        reader.readAsBinaryString(excelFile);
    });

    return readExcelPromise;
};


 PageModule.prototype.isFormValid = function(detail, event) {
    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      return true;
    }
    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
    let table = event.target;
    let editables = table.querySelectorAll('.editable');
    for (let i = 0; i < editables.length; i++) {
      let editable = editables.item(i);
      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        return false;
      }
    }
    return true;
  };

  PageModule.prototype.areDifferent = function(oldValue, newValue) {
    if(JSON.stringify(newValue) === JSON.stringify(oldValue))
    return false
    else 
    return true;
  };



  PageModule.prototype.updateTes = function (tesDataArray, operation, BOName, batchSize) {
    let batchProcessingVariableArray = [];
    
    for (let batchStart = 0; batchStart < tesDataArray.length; batchStart += batchSize) {
        let batchEnd = Math.min(batchStart + batchSize, tesDataArray.length);
        let batchData = tesDataArray.slice(batchStart, batchEnd);
        for (let index = 0; index < batchData.length; index++) {
            let data;
              
                data = {
                    "id": "part" + index,
                    "path": "/" + BOName + "/" +batchData[index].id,
                    "operation": operation,
                    "payload": {
                        "employeeID": batchData[index].employeeID,
                        "employeeName": batchData[index].name,
                        //"examdate": batchData[index].examdate,
                        "category": batchData[index].category,  
                        "certificationCode": batchData[index].certificationCode,
                        "certificationName": batchData[index].certificationName,
                        "capability": batchData[index].capability,
                        "remarks": batchData[index].remarks,             
                    }
               
            }

            batchProcessingVariableArray.push(data);
        }
    }

    return { parts: batchProcessingVariableArray };
};
  
  PageModule.prototype.createTesBatch = function (dataBO,operation,BOName,certCategoryBO,certMasterBO,empBO,capBO) {
 
var batchProcessingVariableArray = new Array();
 
    for (var index = 0; index < dataBO.length; index++) {

    
       var eid = empBO.find(ele=>ele.id==dataBO[index].employeeID);
       var cmcat = certCategoryBO.find(ele=>ele.id==dataBO[index].category);
       var cap = capBO.find(ele=>ele.id==dataBO[index].capability);

       var data = '{"id": "part' + index + '","path": "/' + BOName + '/","operation": "' + operation + '",    "payload": {"employeeID":"'+eid.id+'","employeeName":"'+eid.id+'","category":"'+cmcat.id+'","certificationCode":"'+dataBO[index].certificationCode+'","certificationName":"'+dataBO[index].certificationName+'","capability":"'+cap.id+'","remarks":"'+dataBO[index].remarks+'","format":"'+eid.id+'","region":"'+eid.id+'"}}';
 
           // var data = '{"id": "part' + index + '","path": "/' + BOName + '/","operation": "' + operation + '",   "payload":'+JSON.stringify(dataBO[index])+'}';
 
      batchProcessingVariableArray.push(data);
 
    }
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
   
  };

  PageModule.prototype.tabledata = function(BO,empBO,certCategoryBO,capBO){
    var data = [];
    for(var i =0;i<BO.length;i++){
       var eid = empBO.find(ele=>ele.id==BO[i].employeeID);
       var cmcat = certCategoryBO.find(ele=>ele.id==BO[i].category);
       var capy = capBO.find(ele=>ele.id==BO[i].capability);
       var temp = {};
      temp['id']=BO[i].id!=null?BO[i].id:'';
      temp['categoryObject']=cmcat.category!=null?cmcat.category:'';
      temp['certificationCode']=BO[i].certificationCode!=null?BO[i].certificationCode:'';
      temp['certificationName']=BO[i].certificationName!=null?BO[i].certificationName:'';
      temp['employeeName']=eid.name!=null?eid.name:'';
      temp['employeeID']=eid.employeeID!=null?eid.employeeID:'';
      temp['status']=BO[i].status!=null?BO[i].status:'';
      temp['examDate']=BO[i].examDate!=null?BO[i].examDate:'';
      temp['capabilityObject']=capy.name!=null?capy.name:'';
      temp['remarks']=BO[i].remarks!=null?BO[i].remarks:'';
       temp['empstatus']=BO[i].remarks!=null?BO[i].empstatus:'';
      data.push(temp);
    }
    return data;
  };
  
  PageModule.prototype.employeeData=function(assignCertBO,empBO) {
       var array =[] ; 
       for(var i=0; i<assignCertBO.length; i++ ){
        var retpayload= {};
        var employee = empBO.find(ele => ele.id == assignCertBO[i].employeeID);
        array.push(employee.employeeID);
        console.log('1234',array);
       }
       return array;
    };

  PageModule.prototype.downloadDetails=function(employeeData,metaDataArray){
  
  var multidata = new Array();

  for(let i = 0;i<=employeeData.length;i++)
  {
    var instanceArray = []; 
    if(i == 0) {
      instanceArray.push('employeeID');
      instanceArray.push('employeeName');
      instanceArray.push('category');
      instanceArray.push('certificationCode');
      instanceArray.push('certificationName');     
      instanceArray.push('capability');
      instanceArray.push('remarks');
    //  instanceArray.push('YearMonth');
      instanceArray.push('examDate');
      instanceArray.push('status');
      
      multidata.push(instanceArray);
    }
    else {

     //  var date=new Date(employeeData[i-1].yearMonth);
        if(isNaN(Number(employeeData[i-1].employeeID,Number))) {
          instanceArray.push(employeeData[i-1].employeeID);
        }
        else{
         instanceArray.push(Number(employeeData[i-1].employeeID));
         //console.log("%%",Number(employeeData[i-1].employeeID));
       }
       instanceArray.push(employeeData[i-1].employeeName);
       instanceArray.push(employeeData[i-1].category);
       instanceArray.push(employeeData[i-1].certificationCode);
       instanceArray.push(employeeData[i-1].certificationName);     
       instanceArray.push(employeeData[i-1].capability);
       instanceArray.push(employeeData[i-1].remarks);
       instanceArray.push(employeeData[i-1].examDate);
       instanceArray.push(employeeData[i-1].status);
      //  instanceArray.push(employeeData[i-1].yearMonth=((date.getDate()<=9?'0'+date.getDate():''+(date.getDate()))+'-'+(date.toLocaleString('default', { month: 'short' }))+'-'+date.getFullYear()));
       multidata.push(instanceArray);
   }
   
   }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Certification Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Certification Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
console.log(fileBytes);
var blob = new Blob([fileBytes],{type:'octet/stream'});
var filename = "Certification Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
} else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
 };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.chekValue = function (arg1) {
    console.log("###",arg1);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.batchProcessing = function (BOName,operation,dataBO) {
 var batchProcessingVariableArray = [];

  for (var i = 0; i < dataBO.length; i++) {
    let data = {
      id: "part" + i,
      path: "/" + BOName + "/" + dataBO[i].id,
      operation: operation,
      payload: {
        status: dataBO[i].status,
        remarks:dataBO[i].remarks
      }
    };

    batchProcessingVariableArray.push(data);
  }

  return JSON.stringify({ parts: batchProcessingVariableArray });

  };
  function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
  }
  return PageModule;
});
