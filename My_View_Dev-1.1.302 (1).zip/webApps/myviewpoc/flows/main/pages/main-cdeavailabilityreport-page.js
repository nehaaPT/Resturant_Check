define([], () => {
  'use strict';
let PageModule = function PageModule() {};

PageModule.prototype.capSearch = function (cap, date) {
   var query = "";
   var qparameter='';
   if(cap!="")
   {
     
  query = "(employeeObject.globalPractice = "+cap+")";
   } 
   return query;
   };
PageModule.prototype.capSearch1 = function (cap, date) {
   var query = "";
   var qparameter='';
   if(cap!="")
   {
     
  query = "(employeeObject.globalPractice = "+cap+" ) ";
   } 
   return query;
   };

PageModule.prototype.capSearch2 = function ( date,name) {
   var query = "";
   var qparameter='';
   
   
     
  query = "( employee="+name+") ";
   
   return query;
   };
PageModule.prototype.currentdate = function () {
let date = new Date().getFullYear();
return date;
};

PageModule.prototype.getDates = function (date) {
   
    var returndate = `${new Date(date).getFullYear()}-${(new Date(date).getMonth())<9?'0'+(new Date(date).getMonth()+1):''+(new Date(date).getMonth()+1)}-${(new Date(date).getDate())<10?'0'+(new Date(date).getDate()):''+(new Date(date).getDate())}`;
    

    
    return returndate;
  };

   PageModule.prototype.createTableColumns = function (date) {
    var endDate =new Date(date);
    var innerArray =  [];
    var date6=new Date(endDate).toLocaleDateString('en-GB');
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       var date5=new Date(endDate.setDate(endDate.getDate()-1)).toLocaleDateString('en-GB');
       if(new Date(endDate).getMonth()=== new Date(date).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
      }
    }}
    
    innerArray=innerArray.reverse();
    
    // let array=[];
    // for(let i = innerArray.length; i > 0; i--){
    // let obj={};
    // obj["Category"]=''
    // }
    

    let innerString = '';
    
    innerString = innerString + '[{' + '"headerText":' + '"Category",' +'"headerStyle":'+'"text-align: center;",'+'"template":'+'"category",' + '"field":' + '"categoryObject",'+'"width":'+'"170"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Week Ending",' + '"field":' + '"weekEnding",'+'"width":'+'"140"' + '},';
    innerString = innerString + '{' + '"headerText":' + '"Project Details",' + '"field":' + '"projectDetails",'+'"width":'+'"150"' + '},';
    
     
                              
    for(let i = 1; i <= innerArray.length; i++) {
      if(i === innerArray.length) {
        innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+ innerArray[i-1] + '",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;",' + '"field":' + '"day'+i+'",'+'"width":'+'"126"' + '},';
    }
    innerString = innerString + '{' + '"headerText":' + '"Comments",' + '"field":' + '"comment1",'+'"template":'+'"comments",'+'"width":'+'"130"' + '}';
    innerString = innerString + ']';
    console.log("!!!",JSON.parse(innerString));
    let returnarray=[];
    returnarray.push(JSON.parse(innerString));
    returnarray.push(innerArray);
    return returnarray;
  };

PageModule.prototype.date = function (month,year) {
    let maxValue, minValue;
    let queryString = "";
    let queryString1 = "";
    let dateRanges = [];
    let array=[];
    let y= year;
    if(month.includes("ALL")===false){
      for(let i=0;i<month.length;i++){
        let m = month[i];
        let firstDay = new Date(y, Number(m), 1);
        let lastDay = new Date(y, Number(m) + 1, 0);

        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
        dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    }
      else{
        maxValue=11,minValue=0;
        let firstDay = new Date(y, Number(minValue), 1);
        let lastDay = new Date(y, Number(maxValue) + 1, 0);
       
        let startDate=(`${new Date(firstDay).getFullYear()}-${(new Date(firstDay).getMonth())<9?'0'+(new Date(firstDay).getMonth()+1):''+(new Date(firstDay).getMonth()+1)}-${(new Date(firstDay).getDate())<10?'0'+(new Date(firstDay).getDate()):''+(new Date(firstDay).getDate())}`);
        let endDate= (`${new Date(lastDay).getFullYear()}-${(new Date(lastDay).getMonth())<9?'0'+(new Date(lastDay).getMonth()+1):''+(new Date(lastDay).getMonth()+1)}-${(new Date(lastDay).getDate())<10?'0'+(new Date(lastDay).getDate()):''+(new Date(lastDay).getDate())}`);
       
       dateRanges.push("(" + "weekEnding BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
      }
    
      
      if (dateRanges.length === 1) {
      queryString =   "AND "+dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString = "AND(" + dateRanges.join(" OR ") + ")";
      }

      if (dateRanges.length === 1) {
      queryString1 =   dateRanges  ;
      }
      else if (dateRanges.length > 1) {
      queryString1 = "(" + dateRanges.join(" OR ") + ")";
      }
      array.push(queryString);
      array.push(queryString1);

       return array;        
   };

PageModule.prototype.tableHeading = function (month) {
    let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b});
    }

    let innerString = '';
     innerString = innerString + '[{' + '"headerText":' + '"Employee",' + '"field":' + '"name",'+'"template":'+'"Others",'+'"width":'+'"254",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;"' + '},';
   innerString = innerString + '{' + '"headerText":' + '"Capability",' + '"field":' + '"capability",'+'"template":'+'"Others",'+'"width":'+'"140",' +'"headerStyle":'+'"text-align: left;",'+'"style":'+'"text-align: left;"' + '},';
                              
    for(let i = 0; i < month.length; i++) {
      let x=HeadArray[month[i]];
      if(i === month.length-1) {
        
        innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"style":'+'"text-align: center;",'+'"width":'+'"84",' + '"field":' + '"'+x + 'Hrs",'+'"template":'+'"'+x + '"' + '}';
        break;
      }
      innerString = innerString + '{' + '"headerText":' + '"'+x + '",' +'"headerStyle":'+'"text-align: center;",'+'"style":'+'"text-align: center;",'+'"width":'+'"84",' + '"field":' + '"'+x + 'Hrs",'+'"template":'+'"'+x + '"' + '},';
    }

    // innerString = innerString + '{' + '"headerText":' + '"Total",' + '"field":' + '"total",'+'"template":'+'"Others",'+'"width":'+'"87",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '},';
    // innerString = innerString + '{' + '"headerText":' + '"%",' + '"field":' + '"percentage",'+'"template":'+'"Others",'+'"width":'+'"75",'+'"style":'+'"text-align: center;",'+'"headerStyle":'+'"text-align: center;"' + '}';
    innerString = innerString + ']';

    let columns=JSON.parse(innerString);
    return columns;
    };

    PageModule.prototype.employeeLOV = function (data) {

      let object={},array=[];
      for(let i=0;i<data.length;i++){
        object['id']=data[i].id;
        object['name']=data[i].name+'-'+data[i].employeeID;
        object['capability']=data[i].globalPractice;
        array.push(object);
      }
      return array;

    };

//     function isLeapYear(year) {
//     return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
// }


//    let years = year.map(range => {
//     let matches = range.match(/\d{4}-\d{2}/g); // Extracts all year-month pairs from the string
//     let year = parseInt(matches[0].substr(0, 4)); // Extract year from the first match
//     let months = matches.map(match => parseInt(match.substr(5, 2))); // Extract months from all matches
//     return { year, months };
// });

// let yearspecific = isLeapYear.year

// function totalWorkingHours(month, yearspecific) {
//     let totalWorkingHours = 0;

//     years.forEach(yearData => {
//         yearData.months.forEach(yearMonth => {
//             if (yearMonth === month) {
//                 let daysInMonth;
//                 if (month === 1 && isLeapYear(yearData.year)) {
//                     // February in a leap year has 29 days
//                     daysInMonth = 29;
//                 } else {
//                     daysInMonth = new Date(yearData.year, month + 1, 0).getDate();
//                 }

//                 let weekdays = 0;

//                 for (let d = 1; d <= daysInMonth; d++) {
//                     let currentDate = new Date(yearData.year, month, d);
//                     if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
//                         weekdays++;
//                     }
//                 }

//                 totalWorkingHours += weekdays * 9; // Assuming 9 working hours per day
//             }
//         });
//     });

//     return totalWorkingHours;
// }


     PageModule.prototype.capReport = function (AllBoData,empData,year,capBO) {
       let array=[];
       let TotalHrs=0;
       let TotJanHrs=0,TotFebHrs=0,TotMarHrs=0,TotAprHrs=0,TotMayHrs=0,TotJunHrs=0,TotJulHrs=0,TotAugHrs=0,TotSepHrs=0,TotOctHrs=0,TotNovHrs=0,TotDecHrs=0;



       for(var i=0;i<capBO.length;i++){
   
         let BoData = empData.filter(ele => ele.employeeIdObject.items[0].globalPractice === capBO[i].id);
         
      //  var capabilityId = empData[i].globalPractice;
      //  var capabilityName = capBO[i].name;

        
         let JanHrs=0,FebHrs=0,MarHrs=0,AprHrs=0,MayHrs=0,JunHrs=0,JulHrs=0,AugHrs=0,SepHrs=0,OctHrs=0,NovHrs=0,DecHrs=0;
         let JanArray=[],FebArray=[],MarArray=[],AprArray=[],MayArray=[],JunArray=[],JulArray=[],AugArray=[],SepArray=[],OctArray=[],NovArray=[],DecArray=[];
         let date=new Date(year);
         let JanTotal=0,FebTotal=0,MarTotal=0,AprTotal=0,MayTotal=0,JunTotal=0,JulTotal=0,AugTotal=0,SepTotal=0,OctTotal=0,NovTotal=0,DecTotal=0;
         
        //  let arrayobj=Object.values(BoData); 
        //  const arrayUniqueByKey = [...new Map(BoData.map(item =>  [item['employee'], item])).values()];   
        //  let uni=arrayUniqueByKey;

         let validateLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0?true:false;
         let totalDaysOfMonth;
         if(validateLeapYear===true){
           totalDaysOfMonth=[31,29,31,30,31,30,31,31,30,31,30,31];
         }else{
           totalDaysOfMonth=[31,28,31,30,31,30,31,31,30,31,30,31]
         }

         

      for(let a=0;a<BoData.length;a++){
        let employeeWiseData=AllBoData.filter(ele=>ele.employee===BoData[a].employeeIdObject.items[0].id);

        let arrayobj2=Object.values(employeeWiseData); 
         const arrayUniqueByKey2 = [...new Map(employeeWiseData.map(item =>  [item['weekEnding'], item])).values()];   
         let uni2=arrayUniqueByKey2;

      let name=BoData[a].employeeIdObject.items[0];
      let totalEmpHours = 0;
      let janemployeeHrs=0,febemployeeHrs=0,maremployeeHrs=0,apremployeeHrs=0,mayemployeeHrs=0,junemployeeHrs=0,julemployeeHrs=0,augemployeeHrs=0,sepemployeeHrs=0,octemployeeHrs=0,novemployeeHrs=0,decemployeeHrs=0;
      let totalJanHours =0,totalFebHours=0,totalMarHours=0,totalAprHours=0,totalMayHours=0,totalJunHours=0,totalJulHours=0,totalAugHours=0,totalSepHours=0,totalOctHours=0,totalNovHours=0,totalDecHours=0;
      let janemployeeArray=[],febemployeeArray=[],maremployeeArray=[],apremployeeArray=[],mayemployeeArray=[],junemployeeArray=[],julemployeeArray=[],augemployeeArray=[],sepemployeeArray=[],octemployeeArray=[],novemployeeArray=[],decemployeeArray=[];
      let janAvailabilityPercentage=0,febAvailabilityPercentage=0,marAvailabilityPercentage=0,aprAvailabilityPercentage=0,mayAvailabilityPercentage=0,junAvailabilityPercentage=0,julAvailabilityPercentage=0,augAvailabilityPercentage=0,sepAvailabilityPercentage=0,octAvailabilityPercentage=0,novAvailabilityPercentage=0,decAvailabilityPercentage=0;
      let janMaximumHours=0,febMaximumHours=0,marMaximumHours=0,aprMaximumHours=0,mayMaximumHours=0,junMaximumHours=0,julMaximumHours=0,augMaximumHours=0,sepMaximumHours=0,octMaximumHours=0,novMaximumHours=0,decMaximumHours=0;
      let month=0;
      let montharray=[];
    for(let z=0;z<uni2.length;z++){
      let weekEndHrs=0
      let CatArray=[];
      let weekwiseData=employeeWiseData.filter(ele=>ele.weekEnding===uni2[z].weekEnding);
    for(let c=0;c<weekwiseData.length;c++){

      if(new Date(weekwiseData[c].weekEnding).getFullYear()===new Date(date).getFullYear());{       

        month=new Date(weekwiseData[c].weekEnding).getMonth()+1;
        if(montharray.includes(month)){
          let dummy=1
        }
        else{
          montharray.push(month)
        }

        weekEndHrs+=Number(weekwiseData[c].day1)+Number(weekwiseData[c].day2)+Number(weekwiseData[c].day3)+Number(weekwiseData[c].day4)+Number(weekwiseData[c].day5)+Number(weekwiseData[c].day6)+Number(weekwiseData[c].day7);
        CatArray.push(weekwiseData[c]);
      }}
          let endDate =new Date(uni2[z].weekEnding);
    let innerArray =  [];
    let date6=new Date(endDate);
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       let date5=new Date(endDate.setDate(endDate.getDate()-1));
       if(new Date(endDate).getMonth()=== new Date(uni2[z].weekEnding).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
      }
    }}
         let weekdays;
         let workday;
         let weekMax;
         let currentDate
         if(weekEndHrs!=0){
        switch(month){
        case 1:
          janemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          janemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JanHrs+=Number(weekEndHrs);
          JanTotal+= Number(weekEndHrs);
          TotJanHrs+=Number(weekEndHrs);

           totalJanHours = janemployeeHrs;
          janMaximumHours = (Number(weekdays)*9);
           janAvailabilityPercentage = (janemployeeHrs / janMaximumHours) * 100;
          break;
        case 2:
          febemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          febemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          FebHrs+=Number(weekEndHrs);
          FebTotal+=Number(weekEndHrs) ;
          TotFebHrs+=Number(weekEndHrs);

          totalFebHours = febemployeeHrs;
         febMaximumHours = (Number(weekdays)*9);
          febAvailabilityPercentage = (febemployeeHrs / febMaximumHours) * 100;
          break;
        case 3:
          maremployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          maremployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          MarHrs+=Number(weekEndHrs);
          MarTotal+=Number(weekEndHrs) ;
          TotMarHrs+=Number(weekEndHrs);

          totalMarHours = maremployeeHrs;
           marMaximumHours = (Number(weekdays)*9);
          marAvailabilityPercentage = (maremployeeHrs / marMaximumHours) * 100;
          break;
        case 4:
          apremployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          apremployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          AprHrs+=Number(weekEndHrs);
          AprTotal+=Number(weekEndHrs) ;
          TotAprHrs+=Number(weekEndHrs);

          totalAprHours = apremployeeHrs;
          aprMaximumHours = (Number(weekdays)*9);
          aprAvailabilityPercentage = (apremployeeHrs / aprMaximumHours) * 100;
          break;
        case 5:
          mayemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          mayemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          MayHrs+=Number(weekEndHrs);
          MayTotal+=Number(weekEndHrs) ;
          TotMayHrs+=Number(weekEndHrs);

          totalMayHours = mayemployeeHrs;
          mayMaximumHours = (Number(weekdays)*9);
          mayAvailabilityPercentage = (mayemployeeHrs / mayMaximumHours) * 100;
          break;
        case 6:
          junemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          junemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JunHrs+=Number(weekEndHrs);
          JunTotal+=Number(weekEndHrs) ;
          TotJunHrs+=Number(weekEndHrs);

          totalJunHours = junemployeeHrs;
          junMaximumHours = (Number(weekdays)*9);
          junAvailabilityPercentage = (junemployeeHrs / junMaximumHours) * 100;
          break;
        case 7:
          julemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          julemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JulHrs+=Number(weekEndHrs);
          JulTotal+=Number(weekEndHrs) ;
          TotJulHrs+=Number(weekEndHrs);

          totalJulHours = julemployeeHrs;
           julMaximumHours = (Number(weekdays)*9);
          julAvailabilityPercentage = (julemployeeHrs / julMaximumHours) * 100;
          break;
        case 8:
          augemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          augemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          AugHrs+=Number(weekEndHrs);
          AugTotal+=Number(weekEndHrs);
          TotAugHrs+=Number(weekEndHrs);

          totalAugHours = augemployeeHrs;
           augMaximumHours = (Number(weekdays)*9);
          augAvailabilityPercentage = (augemployeeHrs / augMaximumHours) * 100;
          break;
        case 9:
          sepemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          sepemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          SepHrs+=Number(weekEndHrs);
          SepTotal+=Number(weekEndHrs) ;
          TotSepHrs+=Number(weekEndHrs);

          totalSepHours = sepemployeeHrs;
           sepMaximumHours  = (Number(weekdays)*9);
          sepAvailabilityPercentage = (sepemployeeHrs / sepMaximumHours) * 100;
          break;
        case 10:
          octemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          octemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          OctHrs+=Number(weekEndHrs);
          OctTotal+=Number(weekEndHrs) ;
          TotOctHrs+=Number(weekEndHrs);

          totalOctHours = octemployeeHrs;
           octMaximumHours = (Number(weekdays)*9);
          octAvailabilityPercentage = (octemployeeHrs / octMaximumHours) * 100;
          break;
        case 11:
          novemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          novemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          NovHrs+=Number(weekEndHrs);
          NovTotal+=Number(weekEndHrs) ;
          TotNovHrs+=Number(weekEndHrs);

          totalNovHours = novemployeeHrs;
           novMaximumHours = (Number(weekdays)*9);
          novAvailabilityPercentage = (novemployeeHrs / novMaximumHours) * 100;
          break;
        case 12:
          decemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          decemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          DecHrs+=Number(weekEndHrs);
          DecTotal+=Number(weekEndHrs) ;
          TotDecHrs+=Number(weekEndHrs);

          totalDecHours = decemployeeHrs;
           decMaximumHours  = (Number(weekdays)*9);
          decAvailabilityPercentage = (decemployeeHrs / decMaximumHours) * 100;
          break;

      }}
      }
      // employeeArray.push({weekEnding:'Total',  hrs:employeeHrs});
     for(let e=0;e<montharray.length;e++){
     switch(montharray[e]){
        case 1:
          janemployeeArray.push({weekEnding:'Total',  hrs:janemployeeHrs, avail:janAvailabilityPercentage.toFixed(2)});
          JanArray.push({name: name.name?name.name:'',  hrs:janemployeeHrs, data:janemployeeArray, availability: janAvailabilityPercentage.toFixed(2) + '%'});

          // let janAvailabilityPercentage = ((janemployeeHrs / (9 * 7 * janemployeeArray.length)) * 100).toFixed(2) + '%';
          //   JanArray[JanArray.length - 1].availabilityPercentage = janAvailabilityPercentage;
          
          break;
        case 2:
          febemployeeArray.push({weekEnding:'Total',  hrs:febemployeeHrs, avail:febAvailabilityPercentage.toFixed(2)});
          FebArray.push({name: name.name?name.name:'',  hrs:febemployeeHrs, data:febemployeeArray, availability: febAvailabilityPercentage.toFixed(2) + '%'});

          // let febAvailabilityPercentage = ((febemployeeHrs / (9 * 7 * febemployeeArray.length)) * 100).toFixed(2) + '%';
          //   FebArray[FebArray.length - 1].availabilityPercentage = febAvailabilityPercentage;
            
          break;
        case 3:
          maremployeeArray.push({weekEnding:'Total',  hrs:maremployeeHrs, avail:marAvailabilityPercentage.toFixed(2)});
          MarArray.push({name: name.name?name.name:'',  hrs:maremployeeHrs, data:maremployeeArray, availability: marAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 4:
          apremployeeArray.push({weekEnding:'Total',  hrs:apremployeeHrs, avail:aprAvailabilityPercentage.toFixed(2)});
          AprArray.push({name: name.name?name.name:'',  hrs:apremployeeHrs, data:apremployeeArray, availability: aprAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 5:
          mayemployeeArray.push({weekEnding:'Total',  hrs:mayemployeeHrs, avail:mayAvailabilityPercentage.toFixed(2)});
          MayArray.push({name: name.name?name.name:'',  hrs:mayemployeeHrs, data:mayemployeeArray, availability: mayAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 6:
          junemployeeArray.push({weekEnding:'Total',  hrs:junemployeeHrs, avail:junAvailabilityPercentage.toFixed(2)});
          JunArray.push({name: name.name?name.name:'',  hrs:junemployeeHrs, data:junemployeeArray, availability: junAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 7:
          julemployeeArray.push({weekEnding:'Total',  hrs:julemployeeHrs, avail:julAvailabilityPercentage.toFixed(2)});
          JulArray.push({name: name.name?name.name:'',  hrs:julemployeeHrs, data:julemployeeArray, availability: julAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 8:
          augemployeeArray.push({weekEnding:'Total',  hrs:augemployeeHrs, avail:augAvailabilityPercentage.toFixed(2)});
          AugArray.push({name: name.name?name.name:'',  hrs:augemployeeHrs, data:augemployeeArray, availability: augAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 9:
          sepemployeeArray.push({weekEnding:'Total',  hrs:sepemployeeHrs, avail:sepAvailabilityPercentage.toFixed(2)});
          SepArray.push({name: name.name?name.name:'',  hrs:sepemployeeHrs, data:sepemployeeArray, availability: sepAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 10:
          octemployeeArray.push({weekEnding:'Total',  hrs:octemployeeHrs, avail:octAvailabilityPercentage.toFixed(2)});
          OctArray.push({name: name.name?name.name:'',  hrs:octemployeeHrs, data:octemployeeArray, availability: octAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 11:
          novemployeeArray.push({weekEnding:'Total',  hrs:novemployeeHrs, avail:novAvailabilityPercentage.toFixed(2)});
          NovArray.push({name: name.name?name.name:'',  hrs:novemployeeHrs, data:novemployeeArray, availability: novAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 12:
          decemployeeArray.push({weekEnding:'Total',  hrs:decemployeeHrs, avail:decAvailabilityPercentage.toFixed(2)});
          DecArray.push({name: name.name?name.name:'',  hrs:decemployeeHrs, data:decemployeeArray, availability: decAvailabilityPercentage.toFixed(2) + '%'});
          break;

      }}
      // CategoryArray.push({name: name.name?name.name:'',  hrs:employeeHrs, data:employeeArray});
      // employeeTotalHours = {};
let object={};
let validateCurrentMonth=new Date().getMonth();
       object['name'] = name.name?name.name:'';
       object['capability']=capBO[i].name?capBO[i].name:'NA';
        object['JanHrs']= (0>Number(validateCurrentMonth))?janAvailabilityPercentage.toFixed(2):(100-janAvailabilityPercentage).toFixed(2);
        object['janData']= janemployeeArray;
        object['FebHrs']= (1>Number(validateCurrentMonth))?febAvailabilityPercentage.toFixed(2):(100-febAvailabilityPercentage).toFixed(2);
        object['febData']= febemployeeArray;
        object['MarHrs']= (2>Number(validateCurrentMonth))?marAvailabilityPercentage.toFixed(2):(100-marAvailabilityPercentage).toFixed(2);
        object['marData']= maremployeeArray;
        object['AprHrs']= (3>Number(validateCurrentMonth))?aprAvailabilityPercentage.toFixed(2):(100-aprAvailabilityPercentage).toFixed(2);
        object['aprData']= apremployeeArray;
        object['MayHrs']= (4>Number(validateCurrentMonth))?mayAvailabilityPercentage.toFixed(2):(100-mayAvailabilityPercentage).toFixed(2);
        object['mayData']= mayemployeeArray;
        object['JunHrs']= (5>Number(validateCurrentMonth))?junAvailabilityPercentage.toFixed(2):(100-junAvailabilityPercentage).toFixed(2);
        object['junData']= junemployeeArray;
        object['JulHrs']= (6>Number(validateCurrentMonth))?julAvailabilityPercentage.toFixed(2):(100-julAvailabilityPercentage).toFixed(2);
        object['julData']= julemployeeArray;
        object['AugHrs']= (7>Number(validateCurrentMonth))?augAvailabilityPercentage.toFixed(2):(100-augAvailabilityPercentage).toFixed(2);
        object['augData']= augemployeeArray;
        object['SepHrs']= (8>Number(validateCurrentMonth))?sepAvailabilityPercentage.toFixed(2):(100-sepAvailabilityPercentage).toFixed(2);
        object['sepData']= sepemployeeArray;
        object['OctHrs']= (9>Number(validateCurrentMonth))?octAvailabilityPercentage.toFixed(2):(100-octAvailabilityPercentage).toFixed(2);
        object['octData']= octemployeeArray;
        object['NovHrs']= (10>Number(validateCurrentMonth))?novAvailabilityPercentage.toFixed(2):(100-novAvailabilityPercentage).toFixed(2);
        object['novData']= novemployeeArray;
        object['DecHrs']= (11>Number(validateCurrentMonth))?decAvailabilityPercentage.toFixed(2):(100-decAvailabilityPercentage).toFixed(2);
        object['decData']= decemployeeArray;
        // object['total']=Number(janemployeeHrs)+ Number(febemployeeHrs)+ Number(maremployeeHrs)+ Number(apremployeeHrs)+ Number(mayemployeeHrs)+ Number(junemployeeHrs)+ Number(julemployeeHrs)+ Number(augemployeeHrs)+ Number(sepemployeeHrs)+ Number(octemployeeHrs)+ Number(novemployeeHrs)+ Number(decemployeeHrs);
        // object['percentage']='';
        array.push(object);
        TotalHrs +=Number(janemployeeHrs)+ Number(febemployeeHrs)+ Number(maremployeeHrs)+ Number(apremployeeHrs)+ Number(mayemployeeHrs)+ Number(junemployeeHrs)+ Number(julemployeeHrs)+ Number(augemployeeHrs)+ Number(sepemployeeHrs)+ Number(octemployeeHrs)+ Number(novemployeeHrs)+ Number(decemployeeHrs);
 
    }
      //  JanArray.push({name: 'Total',  hrs:JanTotal});
      //  FebArray.push({name: 'Total',  hrs:FebTotal});
      //  MarArray.push({name: 'Total',  hrs:MarTotal});
      //  AprArray.push({name: 'Total',  hrs:AprTotal});
      //  MayArray.push({name: 'Total',  hrs:MayTotal});
      //  JunArray.push({name: 'Total',  hrs:JunTotal});
      //  JulArray.push({name: 'Total',  hrs:JulTotal});
      //  AugArray.push({name: 'Total',  hrs:AugTotal});
      //  SepArray.push({name: 'Total',  hrs:SepTotal});
      //  OctArray.push({name: 'Total',  hrs:OctTotal});
      //  NovArray.push({name: 'Total',  hrs:NovTotal});
      //  DecArray.push({name: 'Total',  hrs:DecTotal});

      //  TotalHrs = Number(TotalHrs)+ Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);
        // let object={};
        
        //object['name']= empData[i].name;
        // object['name'] = capBO[i].name;;
        // object['JanHrs']= JanHrs;
        // object['janData']= JanArray;
        // object['FebHrs']= FebHrs;
        // object['febData']= FebArray;
        // object['MarHrs']= MarHrs;
        // object['marData']= MarArray;
        // object['AprHrs']= AprHrs;
        // object['aprData']= AprArray;
        // object['MayHrs']= MayHrs;
        // object['mayData']= MayArray;
        // object['JunHrs']= JunHrs;
        // object['junData']= JunArray;
        // object['JulHrs']= JulHrs;
        // object['julData']= JulArray;
        // object['AugHrs']= AugHrs;
        // object['augData']= AugArray;
        // object['SepHrs']= SepHrs;
        // object['sepData']= SepArray;
        // object['OctHrs']= OctHrs;
        // object['octData']= OctArray;
        // object['NovHrs']= NovHrs;
        // object['novData']= NovArray;
        // object['DecHrs']= DecHrs;
        // object['decData']= DecArray;
        // object['total']=Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);;
        // object['percentage']='';
        // array.push(object);

      
    }
    // for(let x=0;x<array.length;x++){

    //   array[x].percentage=((Number(array[x].total)*100)/(Number(TotalHrs)===0?1:Number(TotalHrs))).toFixed(2)+'%';
    // }
   
        // let object3={};
        // object3['name']= 'Grand Total';
        // object3['JanHrs']= TotJanHrs;
        // object3['FebHrs']= TotFebHrs;
        // object3['MarHrs']= TotMarHrs;
        // object3['AprHrs']= TotAprHrs;
        // object3['MayHrs']= TotMayHrs;
        // object3['JunHrs']= TotJunHrs;
        // object3['JulHrs']= TotJulHrs;
        // object3['AugHrs']= TotAugHrs;
        // object3['SepHrs']= TotSepHrs;
        // object3['OctHrs']= TotOctHrs;
        // object3['NovHrs']= TotNovHrs;
        // object3['DecHrs']= TotDecHrs;
        // object3['total']=TotalHrs;
        // object3['percentage']=TotalHrs===0?0:100+'%';
        // array.push(object3);
      return array;
      
    };

    PageModule.prototype.exportToPDF = function () {

    // var images = document.querySelectorAll("#downloadImage")
    // for (var i = 0, len = images.length; i < len; i++) {
    //   images[i].removeAttribute(":src");
    // }
    domtoimage.toPng(document.getElementById('table-id-to-export'))
      .then(function (blob) {
        var pdf = new jsPDF('l', 'pt', [$('#table-id-to-export').width(), $('#table-id-to-export').height()]);
        pdf.addImage(blob, 'PNG', 0, 0, $('#table-id-to-export').width(), $('#table-id-to-export').height());
        pdf.save("Employees.pdf");


      });
  };
     PageModule.prototype.capReportTab2 = function (AllBoData,empData,year,capBO,employeeFilter) {
       let array=[];
       let TotalHrs=0;
       let TotJanHrs=0,TotFebHrs=0,TotMarHrs=0,TotAprHrs=0,TotMayHrs=0,TotJunHrs=0,TotJulHrs=0,TotAugHrs=0,TotSepHrs=0,TotOctHrs=0,TotNovHrs=0,TotDecHrs=0;



       for(var i=0;i<capBO.length;i++){
   
         let BoData = empData.filter(ele => ele.employeeIdObject.items[0].globalPractice === capBO[i].id);
         
      //  var capabilityId = empData[i].globalPractice;
      //  var capabilityName = capBO[i].name;

        
         let JanHrs=0,FebHrs=0,MarHrs=0,AprHrs=0,MayHrs=0,JunHrs=0,JulHrs=0,AugHrs=0,SepHrs=0,OctHrs=0,NovHrs=0,DecHrs=0;
         let JanArray=[],FebArray=[],MarArray=[],AprArray=[],MayArray=[],JunArray=[],JulArray=[],AugArray=[],SepArray=[],OctArray=[],NovArray=[],DecArray=[];
         let date=new Date(year);
         let JanTotal=0,FebTotal=0,MarTotal=0,AprTotal=0,MayTotal=0,JunTotal=0,JulTotal=0,AugTotal=0,SepTotal=0,OctTotal=0,NovTotal=0,DecTotal=0;
         
        //  let arrayobj=Object.values(BoData); 
        //  const arrayUniqueByKey = [...new Map(BoData.map(item =>  [item['employee'], item])).values()];   
        //  let uni=arrayUniqueByKey;

         let validateLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0?true:false;
         let totalDaysOfMonth;
         if(validateLeapYear===true){
           totalDaysOfMonth=[31,29,31,30,31,30,31,31,30,31,30,31];
         }else{
           totalDaysOfMonth=[31,28,31,30,31,30,31,31,30,31,30,31]
         }

         

      for(let a=0;a<BoData.length;a++){
        if((employeeFilter==null || employeeFilter==undefined || employeeFilter=='' ) || employeeFilter==BoData[a].employeeIdObject.items[0].id){
        let employeeWiseData=AllBoData.filter(ele=>ele.employee===BoData[a].employeeIdObject.items[0].id);

        let arrayobj2=Object.values(employeeWiseData); 
         const arrayUniqueByKey2 = [...new Map(employeeWiseData.map(item =>  [item['weekEnding'], item])).values()];   
         let uni2=arrayUniqueByKey2;

      let name=BoData[a].employeeIdObject.items[0];
      let totalEmpHours = 0;
      let janemployeeHrs=0,febemployeeHrs=0,maremployeeHrs=0,apremployeeHrs=0,mayemployeeHrs=0,junemployeeHrs=0,julemployeeHrs=0,augemployeeHrs=0,sepemployeeHrs=0,octemployeeHrs=0,novemployeeHrs=0,decemployeeHrs=0;
      let totalJanHours =0,totalFebHours=0,totalMarHours=0,totalAprHours=0,totalMayHours=0,totalJunHours=0,totalJulHours=0,totalAugHours=0,totalSepHours=0,totalOctHours=0,totalNovHours=0,totalDecHours=0;
      let janemployeeArray=[],febemployeeArray=[],maremployeeArray=[],apremployeeArray=[],mayemployeeArray=[],junemployeeArray=[],julemployeeArray=[],augemployeeArray=[],sepemployeeArray=[],octemployeeArray=[],novemployeeArray=[],decemployeeArray=[];
      let janAvailabilityPercentage=0,febAvailabilityPercentage=0,marAvailabilityPercentage=0,aprAvailabilityPercentage=0,mayAvailabilityPercentage=0,junAvailabilityPercentage=0,julAvailabilityPercentage=0,augAvailabilityPercentage=0,sepAvailabilityPercentage=0,octAvailabilityPercentage=0,novAvailabilityPercentage=0,decAvailabilityPercentage=0;
      let janMaximumHours=0,febMaximumHours=0,marMaximumHours=0,aprMaximumHours=0,mayMaximumHours=0,junMaximumHours=0,julMaximumHours=0,augMaximumHours=0,sepMaximumHours=0,octMaximumHours=0,novMaximumHours=0,decMaximumHours=0;
      let month=0;
      let montharray=[];
    for(let z=0;z<uni2.length;z++){
      let weekEndHrs=0
      let CatArray=[];
      let weekwiseData=employeeWiseData.filter(ele=>ele.weekEnding===uni2[z].weekEnding);
    for(let c=0;c<weekwiseData.length;c++){

      if(new Date(weekwiseData[c].weekEnding).getFullYear()===new Date(date).getFullYear());{       

        month=new Date(weekwiseData[c].weekEnding).getMonth()+1;
        if(montharray.includes(month)){
          let dummy=1
        }
        else{
          montharray.push(month)
        }

        weekEndHrs+=Number(weekwiseData[c].day1)+Number(weekwiseData[c].day2)+Number(weekwiseData[c].day3)+Number(weekwiseData[c].day4)+Number(weekwiseData[c].day5)+Number(weekwiseData[c].day6)+Number(weekwiseData[c].day7);
        CatArray.push(weekwiseData[c]);
      }}
          let endDate =new Date(uni2[z].weekEnding);
    let innerArray =  [];
    let date6=new Date(endDate);
    innerArray.push(date6);
    if(new Date(endDate).getDay() !== 0){
    for (let i=0; i<6;i++){
      
       let date5=new Date(endDate.setDate(endDate.getDate()-1));
       if(new Date(endDate).getMonth()=== new Date(uni2[z].weekEnding).getMonth()){
       innerArray.push(date5);
       if(new Date(endDate).getDay() === 0){
                 break;
               }
      }
    }}
         let weekdays;
         let workday;
         let weekMax;
         let currentDate
         if(weekEndHrs!=0){
        switch(month){
        case 1:
          janemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          janemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JanHrs+=Number(weekEndHrs);
          JanTotal+= Number(weekEndHrs);
          TotJanHrs+=Number(weekEndHrs);

           totalJanHours = janemployeeHrs;
          janMaximumHours = (Number(weekdays)*9);
           janAvailabilityPercentage = (janemployeeHrs / janMaximumHours) * 100;
          break;
        case 2:
          febemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          febemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          FebHrs+=Number(weekEndHrs);
          FebTotal+=Number(weekEndHrs) ;
          TotFebHrs+=Number(weekEndHrs);

          totalFebHours = febemployeeHrs;
         febMaximumHours = (Number(weekdays)*9);
          febAvailabilityPercentage = (febemployeeHrs / febMaximumHours) * 100;
          break;
        case 3:
          maremployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          maremployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          MarHrs+=Number(weekEndHrs);
          MarTotal+=Number(weekEndHrs) ;
          TotMarHrs+=Number(weekEndHrs);

          totalMarHours = maremployeeHrs;
           marMaximumHours = (Number(weekdays)*9);
          marAvailabilityPercentage = (maremployeeHrs / marMaximumHours) * 100;
          break;
        case 4:
          apremployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          apremployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          AprHrs+=Number(weekEndHrs);
          AprTotal+=Number(weekEndHrs) ;
          TotAprHrs+=Number(weekEndHrs);

          totalAprHours = apremployeeHrs;
          aprMaximumHours = (Number(weekdays)*9);
          aprAvailabilityPercentage = (apremployeeHrs / aprMaximumHours) * 100;
          break;
        case 5:
          mayemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          mayemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          MayHrs+=Number(weekEndHrs);
          MayTotal+=Number(weekEndHrs) ;
          TotMayHrs+=Number(weekEndHrs);

          totalMayHours = mayemployeeHrs;
          mayMaximumHours = (Number(weekdays)*9);
          mayAvailabilityPercentage = (mayemployeeHrs / mayMaximumHours) * 100;
          break;
        case 6:
          junemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          junemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JunHrs+=Number(weekEndHrs);
          JunTotal+=Number(weekEndHrs) ;
          TotJunHrs+=Number(weekEndHrs);

          totalJunHours = junemployeeHrs;
          junMaximumHours = (Number(weekdays)*9);
          junAvailabilityPercentage = (junemployeeHrs / junMaximumHours) * 100;
          break;
        case 7:
          julemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          julemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          JulHrs+=Number(weekEndHrs);
          JulTotal+=Number(weekEndHrs) ;
          TotJulHrs+=Number(weekEndHrs);

          totalJulHours = julemployeeHrs;
           julMaximumHours = (Number(weekdays)*9);
          julAvailabilityPercentage = (julemployeeHrs / julMaximumHours) * 100;
          break;
        case 8:
          augemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          augemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          AugHrs+=Number(weekEndHrs);
          AugTotal+=Number(weekEndHrs);
          TotAugHrs+=Number(weekEndHrs);

          totalAugHours = augemployeeHrs;
           augMaximumHours = (Number(weekdays)*9);
          augAvailabilityPercentage = (augemployeeHrs / augMaximumHours) * 100;
          break;
        case 9:
          sepemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          sepemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          SepHrs+=Number(weekEndHrs);
          SepTotal+=Number(weekEndHrs) ;
          TotSepHrs+=Number(weekEndHrs);

          totalSepHours = sepemployeeHrs;
           sepMaximumHours  = (Number(weekdays)*9);
          sepAvailabilityPercentage = (sepemployeeHrs / sepMaximumHours) * 100;
          break;
        case 10:
          octemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          octemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          OctHrs+=Number(weekEndHrs);
          OctTotal+=Number(weekEndHrs) ;
          TotOctHrs+=Number(weekEndHrs);

          totalOctHours = octemployeeHrs;
           octMaximumHours = (Number(weekdays)*9);
          octAvailabilityPercentage = (octemployeeHrs / octMaximumHours) * 100;
          break;
        case 11:
          novemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          novemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          NovHrs+=Number(weekEndHrs);
          NovTotal+=Number(weekEndHrs) ;
          TotNovHrs+=Number(weekEndHrs);

          totalNovHours = novemployeeHrs;
           novMaximumHours = (Number(weekdays)*9);
          novAvailabilityPercentage = (novemployeeHrs / novMaximumHours) * 100;
          break;
        case 12:
          decemployeeHrs+=Number(weekEndHrs);
          weekdays=0;
          workday=0;
          for (let d = 1; d <= totalDaysOfMonth[Number(month)-1]; d++) {
                    currentDate = new Date(year, Number(month)-1, d);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        weekdays++;
                    }
                }
                for(let week=0;week<innerArray.length;week++){
                  currentDate = new Date(innerArray[week]);
                    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) { // Exclude Sunday (0) and Saturday (6)
                        workday++;
                }}
             weekMax=((Number(weekEndHrs) / (Number(workday)*9)) * 100)!='Infinity'?((Number(weekEndHrs) / (Number(workday)*9)) * 100):'-';
          decemployeeArray.push({weekEnding:uni2[z].weekEnding ?uni2[z].weekEnding:'',  hrs:weekEndHrs, data:CatArray, avail:weekMax!='-'?weekMax.toFixed(2):weekMax});
          DecHrs+=Number(weekEndHrs);
          DecTotal+=Number(weekEndHrs) ;
          TotDecHrs+=Number(weekEndHrs);

          totalDecHours = decemployeeHrs;
           decMaximumHours  = (Number(weekdays)*9);
          decAvailabilityPercentage = (decemployeeHrs / decMaximumHours) * 100;
          break;

      }}
      }
      // employeeArray.push({weekEnding:'Total',  hrs:employeeHrs});
     for(let e=0;e<montharray.length;e++){
     switch(montharray[e]){
        case 1:
          janemployeeArray.push({weekEnding:'Total',  hrs:janemployeeHrs, avail:janAvailabilityPercentage.toFixed(2)});
          JanArray.push({name: name.name?name.name:'',  hrs:janemployeeHrs, data:janemployeeArray, availability: janAvailabilityPercentage.toFixed(2) + '%'});

          // let janAvailabilityPercentage = ((janemployeeHrs / (9 * 7 * janemployeeArray.length)) * 100).toFixed(2) + '%';
          //   JanArray[JanArray.length - 1].availabilityPercentage = janAvailabilityPercentage;
          
          break;
        case 2:
          febemployeeArray.push({weekEnding:'Total',  hrs:febemployeeHrs, avail:febAvailabilityPercentage.toFixed(2)});
          FebArray.push({name: name.name?name.name:'',  hrs:febemployeeHrs, data:febemployeeArray, availability: febAvailabilityPercentage.toFixed(2) + '%'});

          // let febAvailabilityPercentage = ((febemployeeHrs / (9 * 7 * febemployeeArray.length)) * 100).toFixed(2) + '%';
          //   FebArray[FebArray.length - 1].availabilityPercentage = febAvailabilityPercentage;
            
          break;
        case 3:
          maremployeeArray.push({weekEnding:'Total',  hrs:maremployeeHrs, avail:marAvailabilityPercentage.toFixed(2)});
          MarArray.push({name: name.name?name.name:'',  hrs:maremployeeHrs, data:maremployeeArray, availability: marAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 4:
          apremployeeArray.push({weekEnding:'Total',  hrs:apremployeeHrs, avail:aprAvailabilityPercentage.toFixed(2)});
          AprArray.push({name: name.name?name.name:'',  hrs:apremployeeHrs, data:apremployeeArray, availability: aprAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 5:
          mayemployeeArray.push({weekEnding:'Total',  hrs:mayemployeeHrs, avail:mayAvailabilityPercentage.toFixed(2)});
          MayArray.push({name: name.name?name.name:'',  hrs:mayemployeeHrs, data:mayemployeeArray, availability: mayAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 6:
          junemployeeArray.push({weekEnding:'Total',  hrs:junemployeeHrs, avail:junAvailabilityPercentage.toFixed(2)});
          JunArray.push({name: name.name?name.name:'',  hrs:junemployeeHrs, data:junemployeeArray, availability: junAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 7:
          julemployeeArray.push({weekEnding:'Total',  hrs:julemployeeHrs, avail:julAvailabilityPercentage.toFixed(2)});
          JulArray.push({name: name.name?name.name:'',  hrs:julemployeeHrs, data:julemployeeArray, availability: julAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 8:
          augemployeeArray.push({weekEnding:'Total',  hrs:augemployeeHrs, avail:augAvailabilityPercentage.toFixed(2)});
          AugArray.push({name: name.name?name.name:'',  hrs:augemployeeHrs, data:augemployeeArray, availability: augAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 9:
          sepemployeeArray.push({weekEnding:'Total',  hrs:sepemployeeHrs, avail:sepAvailabilityPercentage.toFixed(2)});
          SepArray.push({name: name.name?name.name:'',  hrs:sepemployeeHrs, data:sepemployeeArray, availability: sepAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 10:
          octemployeeArray.push({weekEnding:'Total',  hrs:octemployeeHrs, avail:octAvailabilityPercentage.toFixed(2)});
          OctArray.push({name: name.name?name.name:'',  hrs:octemployeeHrs, data:octemployeeArray, availability: octAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 11:
          novemployeeArray.push({weekEnding:'Total',  hrs:novemployeeHrs, avail:novAvailabilityPercentage.toFixed(2)});
          NovArray.push({name: name.name?name.name:'',  hrs:novemployeeHrs, data:novemployeeArray, availability: novAvailabilityPercentage.toFixed(2) + '%'});
          break;
        case 12:
          decemployeeArray.push({weekEnding:'Total',  hrs:decemployeeHrs, avail:decAvailabilityPercentage.toFixed(2)});
          DecArray.push({name: name.name?name.name:'',  hrs:decemployeeHrs, data:decemployeeArray, availability: decAvailabilityPercentage.toFixed(2) + '%'});
          break;

      }}
      // CategoryArray.push({name: name.name?name.name:'',  hrs:employeeHrs, data:employeeArray});
      // employeeTotalHours = {};
let object={};
let validateCurrentMonth=new Date().getMonth();
       object['name'] = name.name?name.name:'';
       object['capability']=capBO[i].name?capBO[i].name:'NA';
        object['JanHrs']= (0>Number(validateCurrentMonth))?janAvailabilityPercentage.toFixed(2):(100-janAvailabilityPercentage).toFixed(2);
        object['janData']= janemployeeArray;
        object['FebHrs']= (1>Number(validateCurrentMonth))?febAvailabilityPercentage.toFixed(2):(100-febAvailabilityPercentage).toFixed(2);
        object['febData']= febemployeeArray;
        object['MarHrs']= (2>Number(validateCurrentMonth))?marAvailabilityPercentage.toFixed(2):(100-marAvailabilityPercentage).toFixed(2);
        object['marData']= maremployeeArray;
        object['AprHrs']= (3>Number(validateCurrentMonth))?aprAvailabilityPercentage.toFixed(2):(100-aprAvailabilityPercentage).toFixed(2);
        object['aprData']= apremployeeArray;
        object['MayHrs']= (4>Number(validateCurrentMonth))?mayAvailabilityPercentage.toFixed(2):(100-mayAvailabilityPercentage).toFixed(2);
        object['mayData']= mayemployeeArray;
        object['JunHrs']= (5>Number(validateCurrentMonth))?junAvailabilityPercentage.toFixed(2):(100-junAvailabilityPercentage).toFixed(2);
        object['junData']= junemployeeArray;
        object['JulHrs']= (6>Number(validateCurrentMonth))?julAvailabilityPercentage.toFixed(2):(100-julAvailabilityPercentage).toFixed(2);
        object['julData']= julemployeeArray;
        object['AugHrs']= (7>Number(validateCurrentMonth))?augAvailabilityPercentage.toFixed(2):(100-augAvailabilityPercentage).toFixed(2);
        object['augData']= augemployeeArray;
        object['SepHrs']= (8>Number(validateCurrentMonth))?sepAvailabilityPercentage.toFixed(2):(100-sepAvailabilityPercentage).toFixed(2);
        object['sepData']= sepemployeeArray;
        object['OctHrs']= (9>Number(validateCurrentMonth))?octAvailabilityPercentage.toFixed(2):(100-octAvailabilityPercentage).toFixed(2);
        object['octData']= octemployeeArray;
        object['NovHrs']= (10>Number(validateCurrentMonth))?novAvailabilityPercentage.toFixed(2):(100-novAvailabilityPercentage).toFixed(2);
        object['novData']= novemployeeArray;
        object['DecHrs']= (11>Number(validateCurrentMonth))?decAvailabilityPercentage.toFixed(2):(100-decAvailabilityPercentage).toFixed(2);
        object['decData']= decemployeeArray;
        // object['total']=Number(janemployeeHrs)+ Number(febemployeeHrs)+ Number(maremployeeHrs)+ Number(apremployeeHrs)+ Number(mayemployeeHrs)+ Number(junemployeeHrs)+ Number(julemployeeHrs)+ Number(augemployeeHrs)+ Number(sepemployeeHrs)+ Number(octemployeeHrs)+ Number(novemployeeHrs)+ Number(decemployeeHrs);
        // object['percentage']='';
        array.push(object);
        TotalHrs +=Number(janemployeeHrs)+ Number(febemployeeHrs)+ Number(maremployeeHrs)+ Number(apremployeeHrs)+ Number(mayemployeeHrs)+ Number(junemployeeHrs)+ Number(julemployeeHrs)+ Number(augemployeeHrs)+ Number(sepemployeeHrs)+ Number(octemployeeHrs)+ Number(novemployeeHrs)+ Number(decemployeeHrs);
 
    }}
      //  JanArray.push({name: 'Total',  hrs:JanTotal});
      //  FebArray.push({name: 'Total',  hrs:FebTotal});
      //  MarArray.push({name: 'Total',  hrs:MarTotal});
      //  AprArray.push({name: 'Total',  hrs:AprTotal});
      //  MayArray.push({name: 'Total',  hrs:MayTotal});
      //  JunArray.push({name: 'Total',  hrs:JunTotal});
      //  JulArray.push({name: 'Total',  hrs:JulTotal});
      //  AugArray.push({name: 'Total',  hrs:AugTotal});
      //  SepArray.push({name: 'Total',  hrs:SepTotal});
      //  OctArray.push({name: 'Total',  hrs:OctTotal});
      //  NovArray.push({name: 'Total',  hrs:NovTotal});
      //  DecArray.push({name: 'Total',  hrs:DecTotal});

      //  TotalHrs = Number(TotalHrs)+ Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);
        // let object={};
        
        //object['name']= empData[i].name;
        // object['name'] = capBO[i].name;;
        // object['JanHrs']= JanHrs;
        // object['janData']= JanArray;
        // object['FebHrs']= FebHrs;
        // object['febData']= FebArray;
        // object['MarHrs']= MarHrs;
        // object['marData']= MarArray;
        // object['AprHrs']= AprHrs;
        // object['aprData']= AprArray;
        // object['MayHrs']= MayHrs;
        // object['mayData']= MayArray;
        // object['JunHrs']= JunHrs;
        // object['junData']= JunArray;
        // object['JulHrs']= JulHrs;
        // object['julData']= JulArray;
        // object['AugHrs']= AugHrs;
        // object['augData']= AugArray;
        // object['SepHrs']= SepHrs;
        // object['sepData']= SepArray;
        // object['OctHrs']= OctHrs;
        // object['octData']= OctArray;
        // object['NovHrs']= NovHrs;
        // object['novData']= NovArray;
        // object['DecHrs']= DecHrs;
        // object['decData']= DecArray;
        // object['total']=Number(JanHrs)+ Number(FebHrs)+ Number(MarHrs)+ Number(AprHrs)+ Number(MayHrs)+ Number(JunHrs)+ Number(JulHrs)+ Number(AugHrs)+ Number(SepHrs)+ Number(OctHrs)+ Number(NovHrs)+ Number(DecHrs);;
        // object['percentage']='';
        // array.push(object);

      
    }
    // for(let x=0;x<array.length;x++){

    //   array[x].percentage=((Number(array[x].total)*100)/(Number(TotalHrs)===0?1:Number(TotalHrs))).toFixed(2)+'%';
    // }
   
        // let object3={};
        // object3['name']= 'Grand Total';
        // object3['JanHrs']= TotJanHrs;
        // object3['FebHrs']= TotFebHrs;
        // object3['MarHrs']= TotMarHrs;
        // object3['AprHrs']= TotAprHrs;
        // object3['MayHrs']= TotMayHrs;
        // object3['JunHrs']= TotJunHrs;
        // object3['JulHrs']= TotJulHrs;
        // object3['AugHrs']= TotAugHrs;
        // object3['SepHrs']= TotSepHrs;
        // object3['OctHrs']= TotOctHrs;
        // object3['NovHrs']= TotNovHrs;
        // object3['DecHrs']= TotDecHrs;
        // object3['total']=TotalHrs;
        // object3['percentage']=TotalHrs===0?0:100+'%';
        // array.push(object3);
      return array;
      
    };

  PageModule.prototype.bardata = function (data,month) {
      let HeadArray=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
     if(month.includes("ALL")){
      month=[0,1,2,3,4,5,6,7,8,9,10,11];
    }
    else{
      month.sort(function(a, b){return a-b;});
    }

     let info=[];
     for(let i=0; i<data.length; i++){
      // let namePayload=[];
      // namePayload.push(data[i].name);
      for(let j=0; j<month.length; j++){
        let x=HeadArray[month[j]];
     let retpayload={};
      retpayload['name']=data[i].name;
     retpayload['month']=x;
     retpayload['value']= Number(data[i][x+'Hrs']);
     if(retpayload['value']<100){}
     info.push(retpayload);
      }
      
     }

     return info;
    };

 return PageModule;
});
 