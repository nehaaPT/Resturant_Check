define(['knockout', 'ojs/ojresponsiveknockoututils', 'ojs/ojresponsiveutils', "ojs/ojanimation"], function (ko, ResponsiveKnockoutUtils, ResponsiveUtils, AnimationUtils) {
  'use strict';


  class PageModule {

    animate(selector, open, delay) {
      const el = document.querySelector(selector);
      el.style.transitionDelay = delay;
      if (open) {
        el.classList.remove("fold-closed");
      }
    }

    toggle() {
      const rootElement = document.querySelector(".fold-panel1");
      const parentElement = document.querySelector(".fold-panels-parent");
      if (rootElement.classList.contains("fold-closed")) {
        parentElement.classList.remove("fold-panels-parent-closed");
        let self = this;
        let show = function () {
          self.animate(".fold-panel1", true, "0ms");
          self.animate(".fold-panel2", true, "217ms");
          self.animate(".fold-panel3", true, "467ms");
          self.animate(".fold-panel4", true, "700ms");
        };
        setTimeout(() => {
          // wait for animation of "fold-panels-parent-closed" to be finished
          // and then unfold action panels:
          show();
        }, 300);
      }
    }

    updateNavigateFromSummary() {
      const today = new Date();
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(today.getDate() - 7);
      return ("(" + "lastUpdateDate BETWEEN '" + sevenDaysAgo + "' AND '" + today + "'" + ")");
    }

    activepursuits(activeBO, dialogBO) {
      let d = [];
      for (var t = 0; t < activeBO.length; t++) {
        let w = {};
        if (activeBO[t].manStageGrp === 'PIPE' && activeBO[t].bidStatus === 'WIP') {
          w['manBu'] = activeBO[t].manBu;
          w['manMu'] = activeBO[t].manMu;
          w['manOptyID'] = activeBO[t].manOptyID;
          w['manSLId'] = activeBO[t].manSLId;
          w['manAccount'] = activeBO[t].manAccount;
          w['manPursuitname'] = activeBO[t].manPursuitname;
          w['manStageGrp'] = activeBO[t].manStageGrp;
          w['manClosemonth'] = activeBO[t].manClosemonth;



          d.push(w);
        }
      }
      return d;
    };


    ststusCount(data) {
      var arrayobj = Object.values(data);
      let statuses = [];
      statuses = ['Orals', 'Submission', 'Deal Review', 'MU Solution Review', 'OBL Review', 'Solution & Estimation', 'Wintheme'];

      const arrayUniqueByKey = [...new Map(data.map(item => [item['status'], item])).values()];

      let info = [];
      for (let i = 0; i < arrayUniqueByKey.length; i++) {
        if (arrayUniqueByKey[i].status !== null || arrayUniqueByKey[i].status !== '') {
          let retpayload = {};
          retpayload['status'] = arrayUniqueByKey[i].status;
          retpayload['count'] = data.filter(ele => ele.status === arrayUniqueByKey[i].status).length;
          info.push(retpayload);
        }
      }
      //   info.sort((a, b) => {
      //     if (a.status < b.status) {
      //         return -1;
      //     }
      //     if (a.status > b.status) {
      //         return 1;
      //     }
      //     return 0;
      // });
      console.log('info', info);
      return info;
    }

    newStatusCount(data, dialogStatusBO) {
      let statuses = [];
      let info = [];
      statuses = ['Orals', 'Submission', 'Deal Review', 'MU Solution Review', 'OBL Review', 'Solution & Estimation', 'Wintheme'];
      let ids = [0];
      let totalCvCount = 0;
      let getRecordsOrals = [], getRecordsSubmission = [], getRecordsDealReview = [], getRecordsMUSolutionReview = [], getRecordsOBLReview = [], getRecordsSolutionEstimation = [], getRecordsWintheme = [];
      let cvCountOrals = 0, cvCountSubmission = 0, cvCountDealReview = 0, cvCountMUSolutionReview = 0, cvCountOBLReview = 0, cvCountSolutionEstimation = 0, cvCountWintheme = 0;

      for (let j = 0; j < data.length; j++) {
        let Status = dialogStatusBO.filter(ele => ele.optyID == data[j].id);

        let DiaStatusCheck = 0;
        let finalStatus;
        for (let m = 0; m < Status.length; m++) {
          if (DiaStatusCheck < Status[m].id) {
            DiaStatusCheck = Status[m].id;
            finalStatus = Status[m].dealCycle;
          }
        }

        switch (finalStatus) {
          case 'Orals': getRecordsOrals.push(data[j]); cvCountOrals += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'Submission': getRecordsSubmission.push(data[j]); cvCountSubmission += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'Deal Review': getRecordsDealReview.push(data[j]); cvCountDealReview += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'MU Solution Review': getRecordsMUSolutionReview.push(data[j]); cvCountMUSolutionReview += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'OBL Review': getRecordsOBLReview.push(data[j]); cvCountOBLReview += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'Solution & Estimation': getRecordsSolutionEstimation.push(data[j]); cvCountSolutionEstimation += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
          case 'Wintheme': getRecordsWintheme.push(data[j]); cvCountWintheme += (data[j].manStageGrp == 'SOLD' || data[j].manStageGrp == 'LDQ') ? Number(data[j].convertedBkg) : Number(data[j].manTCVoracle); break;
        }
        // totalCvCount+=(data[j].manStageGrp=='SOLD' ||data[j].manStageGrp=='LDQ') ? Number(data[j].convertedBkg):Number(data[j].manTCVoracle);
      }
      totalCvCount = Number(getRecordsOrals.length) + Number(getRecordsSubmission.length) + Number(getRecordsDealReview.length) + Number(getRecordsMUSolutionReview.length) + Number(getRecordsOBLReview.length) + Number(getRecordsSolutionEstimation.length) + Number(getRecordsWintheme.length);
      let retpayload0 = {};
      retpayload0['status'] = statuses[0];
      retpayload0['count'] = getRecordsOrals.length;
      retpayload0['cvCount'] = cvCountOrals;
      retpayload0['percentage'] = ((Number(getRecordsOrals.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload0);

      let retpayload1 = {};
      retpayload1['status'] = statuses[1];
      retpayload1['count'] = getRecordsSubmission.length;
      retpayload1['cvCount'] = cvCountSubmission;
      retpayload1['percentage'] = ((Number(getRecordsSubmission.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload1);

      let retpayload2 = {};
      retpayload2['status'] = statuses[2];
      retpayload2['count'] = getRecordsDealReview.length;
      retpayload2['cvCount'] = cvCountDealReview;
      retpayload2['percentage'] = ((Number(getRecordsDealReview.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload2);

      let retpayload3 = {};
      retpayload3['status'] = statuses[3];
      retpayload3['count'] = getRecordsMUSolutionReview.length;
      retpayload3['cvCount'] = cvCountMUSolutionReview;
      retpayload3['percentage'] = ((Number(getRecordsMUSolutionReview.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload3);

      let retpayload4 = {};
      retpayload4['status'] = statuses[4];
      retpayload4['count'] = getRecordsOBLReview.length;
      retpayload4['cvCount'] = cvCountOBLReview;
      retpayload4['percentage'] = ((Number(getRecordsOBLReview.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload4);

      let retpayload5 = {};
      retpayload5['status'] = statuses[5];
      retpayload5['count'] = getRecordsSolutionEstimation.length;
      retpayload5['cvCount'] = cvCountSolutionEstimation;
      retpayload5['percentage'] = ((Number(getRecordsSolutionEstimation.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload5);

      let retpayload6 = {};
      retpayload6['status'] = statuses[6];
      retpayload6['count'] = getRecordsWintheme.length;
      retpayload6['cvCount'] = cvCountWintheme;
      retpayload6['percentage'] = ((Number(getRecordsWintheme.length) * 100) / Number(totalCvCount)).toFixed(2)
      info.push(retpayload6);

      console.log('newinfo', info);
      return info;
    }

    // for(let a=0; a<p.length; a++){
    //   if(!ids.includes(p[a].optyID)){
    //     ids.push(p[a].optyID);
    //    getRecords.push(p[a]);
    //    let p1=data.find(e=>e.id==p[a].optyID);
    //    cvCount+=(p1.manStageGrp=='SOLD' ||p1.manStageGrp=='LDQ') ? Number(p1.convertedBkg):Number(p1.manTCVoracle);
    //    totalCvCount+=(p1.manStageGrp=='SOLD' ||p1.manStageGrp=='LDQ') ? Number(p1.convertedBkg):Number(p1.manTCVoracle);
    //   }
    // }
    //  if(getRecords.length>0){


    //  } 
    //   info.sort((a, b) => {
    //     if (a.status < b.status) {
    //         return -1;
    //     }
    //     if (a.status > b.status) {
    //         return 1;
    //     }
    //     return 0;
    // });
    // for(let x=0;x<info.length;x++){
    //     info[x].percentage= ((Number(info[x].cvCount)*100)/Number(totalCvCount)).toFixed(2)
    // }



    dealststusCount(data) {
      var arrayobj = Object.values(data);
      let statuses = [];
      statuses = ['Submitted', 'WIP', 'Early Stage', 'Won', 'Hold/Drpped/Qualified Out', 'Lost'];
      const arrayUniqueByKey = [...new Map(data.map(item => [item['bidStatus'], item])).values()];

      let info = [];
      for (let i = 0; i < statuses.length; i++) {
        // if(arrayUniqueByKey[i].bidStatus!==null){
        let retpayload = {};
        retpayload['status'] = statuses[i];
        retpayload['count'] = data.filter(ele => ele.bidStatus === statuses[i]).length;
        let sum = data.filter(ele => ele.bidStatus === statuses[i])
          .reduce((sum, ele) => {
            let valueToSum = (ele.manStageGrp === 'SOLD' || ele.manStageGrp === 'LDQ')
              ? Number(ele.convertedBkg) || 0
              : Number(ele.mantcvOracle) || 0;
            return sum + valueToSum;
          }, 0);


        retpayload['sum'] = Number(sum);
        info.push(retpayload);
        // }
      }
      //   info.sort((a, b) => {
      //     if (a.status < b.status) {
      //         return -1;
      //     }
      //     if (a.status > b.status) {
      //         return 1;
      //     }
      //     return 0;
      // });
      console.log('info', info);
      return info;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    bardata(data) {
      let statuses = [];
      statuses = ['Must Win Deal', 'Pipe', 'Received Verbals', 'Confident Deals'];

      let info = [];
      for (let i = 0; i < statuses.length; i++) {
        // if(arrayUniqueByKey[i].pStatus!==null){
        let retpayload = {};
        retpayload['status'] = statuses[i];
        retpayload['value'] = data.filter(ele => ele.pStatus === statuses[i]).length;
        let sum = data.filter(ele => ele.pStatus === statuses[i])
          .reduce((sum, ele) => {
            let valueToSum = (ele.manStageGrp === 'SOLD' || ele.manStageGrp === 'LDQ')
              ? Number(ele.convertedBkg) || 0
              : Number(ele.mantcvOracle) || 0;
            return sum + valueToSum;
          }, 0);

        // Convert to 2 decimal places and back to number
        retpayload['sum'] = Number(sum);
        info.push(retpayload);
        // }
      }
      //  var batchProcessingVariableArray = new Array();
      // let BOName='PursuitChartBO';
      // let operation='create';
      // for (var index = 0; index < info.length; index++) {
      //   // var clientID=clientBO.find(ele=> ele.clientName==dataBO[index].clientName);
      //   let data = '{"id": "part' + index + '","path": "/' + BOName + '/","operation": "' + operation + '",		"payload":  '+JSON.stringify(info[index])+'}';

      //   batchProcessingVariableArray.push(data);

      // }
      // return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
      return info;
    };

    notUpdatedpursuits(activeBO, dialogBO) {
      let d = [];
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      for (var t = 0; t < activeBO.length; t++) {
        let w = {};
        if (activeBO[t].manStageGrp === 'PIPE' && activeBO[t].bidStatus === 'WIP') {

          let notUpdatedRecords = dialogBO.find(ele => ele.optyID == activeBO[t].id);

          if (notUpdatedRecords) {
            let lastUpdatedDate = new Date(notUpdatedRecords.lastUpdateDate);

            // Check if the last updated date is more than 7 days ago
            if (lastUpdatedDate < sevenDaysAgo) {
              w['manBu'] = activeBO[t].manBu;
              w['manMu'] = activeBO[t].manMu;
              w['manOptyID'] = activeBO[t].manOptyID;
              w['manSLId'] = activeBO[t].manSLId;
              w['manAccount'] = activeBO[t].manAccount;
              w['manStageGrp'] = activeBO[t].manStageGrp;
              w['manClosemonth'] = activeBO[t].manClosemonth;
              w['manPursuitname'] = activeBO[t].manPursuitname;
              w['lastUpdateDate'] = lastUpdatedDate;
              w['id'] = activeBO[t].id;
              w['slId'] = activeBO[t].slId;
              d.push(w);
            }
          }
        }
      }
      return d;
    };

    fetchRecentActivities(data, active) {

      let info = [];
      for (let i = 0; i < 20; i++) {
        let retpayload = {};
        if (data[i].type1 == 'Pursuit Created Manually') {
          retpayload['activity'] = data[i].username + ' created ' + (active.find(e => e.id == data[i].optyID)).manAccount + ' -> ' + (active.find(e => e.id == data[i].optyID)).manPursuitname;
        }
        else {
          retpayload['activity'] = data[i].username + ' updated ' + data[i].type1 + ' to ' + data[i].newValue + ' on ' + (active.find(e => e.id == data[i].optyID)).manAccount + ' -> ' + (active.find(e => e.id == data[i].optyID)).manPursuitname;
        }
        retpayload['id'] = active.find(e => e.id == data[i].optyID).id;
        retpayload['manPursuitname'] = active.find(e => e.id == data[i].optyID).manPursuitname;
        retpayload['manOptyID'] = active.find(e => e.id == data[i].optyID).manOptyID;
        retpayload['manSLId'] = active.find(e => e.id == data[i].optyID).manSLId;
        retpayload['manMu'] = active.find(e => e.id == data[i].optyID).manMu;
        retpayload['manBu'] = active.find(e => e.id == data[i].optyID).manBu;
        retpayload['manPursuitlead'] = active.find(e => e.id == data[i].optyID).manPursuitlead;
        retpayload['bidStatus'] = active.find(e => e.id == data[i].optyID).bidStatus;
        retpayload['manSubSector'] = active.find(e => e.id == data[i].optyID).manSubSector;
        retpayload['manPillar'] = active.find(e => e.id == data[i].optyID).manPillar;
        retpayload['manPursuitlead'] = active.find(e => e.id == data[i].optyID).manPursuitlead;
        retpayload['manTCV'] = active.find(e => e.id == data[i].optyID).manTCV;
        retpayload['manTCVoracle'] = active.find(e => e.id == data[i].optyID).manTCVoracle;
        //  retpayload['updated']=active.find(e=>e.id== data[i].optyID).updated;
        //  retpayload['teamLink']=active.find(e=>e.id== data[i].optyID)teamLink;
        //  retpayload['intercoFlag']=active.find(e=>e.id== data[i].optyID).intercoFlag;
        retpayload['created'] = active.find(e => e.id == data[i].optyID).created;
        retpayload['convertedBkg'] = active.find(e => e.id == data[i].optyID).convertedBkg;


        info.push(retpayload);
      }
      console.log('info', info);
      return info;
    };

    countShowing(arg1, updateLog, bidSatges) {
      let data = {};
      function getDatesWithinLast7Days(objectsArray, dateProperty, updatelog) {
        const today = new Date();
        var dayToday = today.getDate() < 9 ? '0' + (today.getDate()) : '' + (today.getDate());
        var monthToday = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1)
        var yearToday = today.getFullYear();
        var formattedtoday = `${yearToday}-${monthToday}-${dayToday}`;

        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(today.getDate() - 7);
        var daysevenDaysAgo = sevenDaysAgo.getDate() < 9 ? '0' + (sevenDaysAgo.getDate()) : '' + (sevenDaysAgo.getDate());
        var monthsevenDaysAgo = sevenDaysAgo.getMonth() < 9 ? '0' + (sevenDaysAgo.getMonth() + 1) : '' + (sevenDaysAgo.getMonth() + 1)
        var yearsevenDaysAgo = sevenDaysAgo.getFullYear();
        var formattedsevenDaysAgo = `${yearsevenDaysAgo}-${monthsevenDaysAgo}-${daysevenDaysAgo}`;

        if (dateProperty == 'creationDate') {
          return objectsArray.filter(obj => {
            const dateObj = new Date(obj[dateProperty]);
            var daydateObj = dateObj.getDate() < 9 ? '0' + (dateObj.getDate()) : '' + (dateObj.getDate());
            var monthdateObj = dateObj.getMonth() < 9 ? '0' + (dateObj.getMonth() + 1) : '' + (dateObj.getMonth() + 1)
            var yeardateObj = dateObj.getFullYear();
            var formatteddateObj = `${yeardateObj}-${monthdateObj}-${daydateObj}`;

            let ValidateUpdateLogCreate = updatelog.find(e => e.optyID === obj['id'] && (e.type1 === 'Pursuit Created Manually' || e.type1 === 'Pursuit Created'))

            return formatteddateObj >= formattedsevenDaysAgo && formatteddateObj <= formattedtoday && ValidateUpdateLogCreate !== undefined;
          });
        }
        else {
          return objectsArray.filter(obj => {
            let crosscheck = updatelog.filter(e => e.optyID === obj['id'])
            if (crosscheck.length > 0) {
              let latestUpdated;
              for (let x = 0; x < crosscheck.length; x++) {
                let checkDate = new Date(crosscheck[x].lastUpdateDate)
                if (latestUpdated < checkDate || latestUpdated == undefined) {
                  latestUpdated = new Date(crosscheck[x].lastUpdateDate)
                }
              }
              const dateObj = new Date(latestUpdated);
              var daydateObj = dateObj.getDate() < 9 ? '0' + (dateObj.getDate()) : '' + (dateObj.getDate());
              var monthdateObj = dateObj.getMonth() < 9 ? '0' + (dateObj.getMonth() + 1) : '' + (dateObj.getMonth() + 1)
              var yeardateObj = dateObj.getFullYear();
              var formatteddateObj = `${yeardateObj}-${monthdateObj}-${daydateObj}`;

              let ValidateUpdateLogUpdate = updatelog.filter(e => e.optyID === obj['id'] && (e.type1 !== 'Pursuit Created Manually' && e.type1 !== 'Pursuit Created'))
              return ((formatteddateObj >= formattedsevenDaysAgo) && (formatteddateObj <= formattedtoday) && (ValidateUpdateLogUpdate.length > 0));
            }
          });
        }
      }

      let wipcount = arg1.filter(ele => ele.bidStatus == 'WIP' && ele.manStageGrp == 'PIPE');
      let submissionData = [];
      for (let m = 0; m < bidSatges.length; m++) {
        if (bidSatges[m].dealCycle == 'Orals') {
          continue;
        }
        else if (bidSatges[m].dealCycle == 'Submission') {
          submissionData.push(bidSatges[m]);
        }
      }
      function filterNextSevenDays(submissionData) {
        const today = new Date();
        const nextSevenDays = new Date();
        nextSevenDays.setDate(today.getDate() + 7);
        var day1 = nextSevenDays.getDate() < 9 ? '0' + (nextSevenDays.getDate()) : '' + (nextSevenDays.getDate());
        var month1 = nextSevenDays.getMonth() < 9 ? '0' + (nextSevenDays.getMonth() + 1) : '' + (nextSevenDays.getMonth() + 1)
        var year1 = nextSevenDays.getFullYear();
        var currentDate1 = `${year1}-${month1}-${day1}`;


        var day1 = today.getDate() < 9 ? '0' + (today.getDate()) : '' + (today.getDate());
        var month1 = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1)
        var year1 = today.getFullYear();
        var currentDate2 = `${year1}-${month1}-${day1}`;

        return submissionData.filter(record => {
          const recordDate = new Date(record.effectiveDate);

          var day1 = recordDate.getDate() < 9 ? '0' + (recordDate.getDate()) : '' + (recordDate.getDate());
          var month1 = recordDate.getMonth() < 9 ? '0' + (recordDate.getMonth() + 1) : '' + (recordDate.getMonth() + 1)
          var year1 = recordDate.getFullYear();
          var formattedRecordDate = `${year1}-${month1}-${day1}`;

          return formattedRecordDate >= currentDate2 && formattedRecordDate <= currentDate1;
        });
      }

      function filterNextSevenDays1(submissionData, arg1) {
        return arg1.filter(record => {
          let validate = submissionData.find(e => e.optyID === record.id)
          return validate !== undefined;
        });
      }
      let dueRecords1 = filterNextSevenDays(submissionData);
      let dueRecords = filterNextSevenDays1(dueRecords1, arg1);
      let updatedRecords = getDatesWithinLast7Days(arg1, 'lastUpdateDate', updateLog);
      let createdRecords = getDatesWithinLast7Days(arg1, 'creationDate', updateLog);
      let lastUpdatedRecords = getDatesWithinLast7Days(arg1, 'lastUpdateDate', updateLog).length;
      let lastCreatedRecords = getDatesWithinLast7Days(arg1, 'creationDate', updateLog).length;

      return { lastUpdatedRecords, lastCreatedRecords, updatedRecords, createdRecords, wipcount, dueRecords };

    };


    sortingDueRecords(pursuit, dialogStatus, emp) {
      let dealStagesArray = ['MU Solution Review', 'Deal Review', 'Submission', 'Orals'];
      let stageArray1 = [], stageArray2 = [], stageArray3 = [], stageArray4 = [], finalArray = [];

      for (let b = 0; b < pursuit.length; b++) {
        let Status = dialogStatus.filter(e => e.optyID == pursuit[b].id);
        let DiaStatusCheck = 0;
        let finalStatus, proposedDate, odts, owner;

        if (Status.length > 0) {
          for (let m = 0; m < Status.length; m++) {
            if (DiaStatusCheck < Status[m].id) {
              DiaStatusCheck = Status[m].id;
              finalStatus = Status[m].dealCycle;
              proposedDate = new Date(Status[m].effectiveDate);
              odts = emp.find(ele => ele.id == Status[m].owner);
              owner = odts != undefined ? odts.name : '';// Get the owner
            }
          }
        }

        if (proposedDate) {
          var day = proposedDate.getDate() < 9 ? '0' + (proposedDate.getDate()) : '' + (proposedDate.getDate());
          var month = proposedDate.getMonth() < 9 ? '0' + (proposedDate.getMonth() + 1) : '' + (proposedDate.getMonth() + 1);
          var year = proposedDate.getFullYear();
          var formatedProposedDate = `${year}-${month}-${day}`;

          var today = new Date();

          // Add 7 days to today's date
          var next7days = new Date();
          next7days.setDate(today.getDate() + 7);

          var day1 = next7days.getDate() < 9 ? '0' + (next7days.getDate()) : '' + (next7days.getDate());
          var month1 = next7days.getMonth() < 9 ? '0' + (next7days.getMonth() + 1) : '' + (next7days.getMonth() + 1);
          var year1 = next7days.getFullYear();
          var currentDate1 = `${year1}-${month1}-${day1}`;

          var currentDate = new Date();
          var day1 = currentDate.getDate() < 9 ? '0' + (currentDate.getDate()) : '' + (currentDate.getDate());
          var month1 = currentDate.getMonth() < 9 ? '0' + (currentDate.getMonth() + 1) : '' + (currentDate.getMonth() + 1);
          var year1 = currentDate.getFullYear();
          var currentDate2 = `${year1}-${month1}-${day1}`;

          if (dealStagesArray.includes(finalStatus) && formatedProposedDate >= currentDate2 && formatedProposedDate <= currentDate1) {
            // Create an object that includes the pursuit data, owner, and effectiveDate
            let record = {
              ...pursuit[b],
              owner: owner,
              effectiveDate: formatedProposedDate
            };

            if (finalStatus == dealStagesArray[0]) {
              stageArray1.push(record);
            } else if (finalStatus == dealStagesArray[1]) {
              stageArray2.push(record);
            } else if (finalStatus == dealStagesArray[2]) {
              stageArray3.push(record);
            } else if (finalStatus == dealStagesArray[3]) {
              stageArray4.push(record);
            }
          }
        }
      }

      // Prepare final payloads for each stage
      let finalpayload1 = {
        stage: dealStagesArray[0],
        count: stageArray1.length,
        data: stageArray1
      };
      finalArray.push(finalpayload1);

      let finalpayload2 = {
        stage: dealStagesArray[1],
        count: stageArray2.length,
        data: stageArray2
      };
      finalArray.push(finalpayload2);

      let finalpayload3 = {
        stage: dealStagesArray[2],
        count: stageArray3.length,
        data: stageArray3
      };
      finalArray.push(finalpayload3);

      let finalpayload4 = {
        stage: dealStagesArray[3],
        count: stageArray4.length,
        data: stageArray4
      };
      finalArray.push(finalpayload4);
      let totalCount = stageArray1.length + stageArray2.length + stageArray3.length + stageArray4.length;

      return { data: finalArray, tc: totalCount };
    };

    getDataWinRate(pursuit) {
      let pillar = ['OnPrem', 'Cloud', 'OCI/PaaS', 'NetSuite', 'AMS'];
      let data = [];
      let totalPayload = {
        winRatio: 'Total',
        SOLD: 0,
        LDQ: 0,
        lostL: 0,
        withDQ: 0,
        withoutDQ: 0
      };

      for (let i = 0; i < pillar.length; i++) {
        let payload = {};
        payload['winRatio'] = pillar[i];
        payload['SOLD'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.manStageGrp == 'SOLD').length;
        payload['LDQ'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.manStageGrp == 'LDQ').length;
        payload['lostL'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.stg == 'L').length;
        payload['withDQ'] = Number(payload['SOLD']) == 0 || Number(payload['LDQ']) == 0 ? 0 : Number(payload['SOLD']) / (Number(payload['SOLD']) + Number(payload['LDQ']));
        payload['withoutDQ'] = Number(payload['SOLD']) == 0 || Number(payload['lostL']) == 0 ? 0 : Number(payload['SOLD']) / (Number(payload['SOLD']) + Number(payload['lostL']));
        data.push(payload)
        // Accumulate totals
        totalPayload['SOLD'] += payload['SOLD'];
        totalPayload['LDQ'] += payload['LDQ'];
        totalPayload['lostL'] += payload['lostL'];
      }

      // Calculate withDQ and withoutDQ for totalPayload
      totalPayload['withDQ'] = Number(totalPayload['SOLD']) == 0 || Number(totalPayload['LDQ']) == 0 ? 0 : Number(totalPayload['SOLD']) / (Number(totalPayload['SOLD']) + Number(totalPayload['LDQ']));
      totalPayload['withoutDQ'] = Number(totalPayload['SOLD']) == 0 || Number(totalPayload['lostL']) == 0 ? 0 : Number(totalPayload['SOLD']) / (Number(totalPayload['SOLD']) + Number(totalPayload['lostL']));

      data.push(totalPayload);
      console.log(">>", data);
      return data;
    }


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getDataConBkg(pursuit) {
      let pillar = ['OnPrem', 'Cloud', 'OCI/PaaS', 'NetSuite', 'AMS'];
      let data = [];
      let totalPayload = {
        winRatio: 'Total',
        SOLD: 0,
        LDQ: 0,
        lostL: 0,
        withDQ: 0,
        withoutDQ: 0
      };

      for (let i = 0; i < pillar.length; i++) {
        let payload = {};
        payload['winRatio'] = pillar[i];
        payload['SOLD'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.manStageGrp == 'SOLD').reduce((sum, obj) => sum + obj.manTCVoracle, 0);
        payload['LDQ'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.manStageGrp == 'LDQ').reduce((sum, obj) => sum + obj.manTCVoracle, 0);
        payload['lostL'] = pursuit.filter(ele => ele.manPillar == pillar[i] && ele.stg == 'L').reduce((sum, obj) => sum + obj.manTCVoracle, 0);
        payload['withDQ'] = Number(payload['SOLD']) == 0 || Number(payload['LDQ']) == 0 ? 0 : Number(payload['SOLD']) / (Number(payload['SOLD']) + Number(payload['LDQ']));
        payload['withoutDQ'] = Number(payload['SOLD']) == 0 || Number(payload['lostL']) == 0 ? 0 : Number(payload['SOLD']) / (Number(payload['SOLD']) + Number(payload['lostL']));

        // Accumulate totals
        totalPayload['SOLD'] += payload['SOLD'];
        totalPayload['LDQ'] += payload['LDQ'];
        totalPayload['lostL'] += payload['lostL'];
        // totalPayload['withDQ'] += payload['withDQ'];
        // totalPayload['withoutDQ'] += payload['withoutDQ'];

        data.push(payload);
      }
      totalPayload['withDQ'] = Number(totalPayload['SOLD']) == 0 || Number(totalPayload['LDQ']) == 0 ? 0 : Number(totalPayload['SOLD']) / (Number(totalPayload['SOLD']) + Number(totalPayload['LDQ']));
      totalPayload['withoutDQ'] = Number(totalPayload['SOLD']) == 0 || Number(totalPayload['lostL']) == 0 ? 0 : Number(totalPayload['SOLD']) / (Number(totalPayload['SOLD']) + Number(totalPayload['lostL']));



      data.push(totalPayload);

      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    qDate(year, from, to) {
      // Ensure valid inputs
      year = Number(year);
      if (typeof year !== 'number' || (!from && to) || (from && !to)) {
        return null;
      }

      // If both from and to are blank, generate a date range for the entire year
      if (!from && !to) {
        const fromDate = `'${new Date(year, 0, 1).toISOString().split('T')[0]}'`;
        const toDate = `'${new Date(year, 11, 31).toISOString().split('T')[0]}'`;

        return `manClosemonth BETWEEN ${fromDate} AND ${toDate}`;
      }

      // Ensure valid months
      const validMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      if ((from && !validMonths.includes(from)) || (to && !validMonths.includes(to))) {
        return null;
      }

      // Get the index of 'from' and 'to' months
      const fromIndex = from ? validMonths.indexOf(from) : 0;
      const toIndex = to ? validMonths.indexOf(to) + 1 : 12;

      // Construct the date strings without single quotes
      const fromDate = new Date(year, fromIndex, 1).toISOString().split('T')[0];
      const toDate = new Date(year, toIndex, 1).toISOString().split('T')[0];

      // Return the formatted string
      return `manClosemonth BETWEEN '${fromDate}' AND '${toDate}'`;
    }



    getDataDLS(act) {
      var data = [];

      // Initialize arrays to store the sum of manTCVOracle for each month
      var soldMonthSum = new Array(12).fill(0);
      var pipeMonthSum = new Array(12).fill(0);

      for (var i = 0; i < act.length; i++) {
        const date = new Date(act[i].manClosemonth);
        const monthNumber = date.getMonth();

        if (act[i].stgGroup === 'SOLD') {
          soldMonthSum[monthNumber] += act[i].manTCVoracle;
        } else if (act[i].stgGroup === 'PIPE') {
          pipeMonthSum[monthNumber] += act[i].manTCVoracle;
        }
      }

      // Use abbreviated month names
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

      // Initialize the retpayload objects for 'DLS' and 'YTD DLS' summaries
      var dlsSummary = { 'Summary': 'DLS' };
      var ytdDlsSummary = { 'Summary': 'YTD DLS' };

      for (var monthNumber = 0; monthNumber < 12; monthNumber++) {
        dlsSummary[monthNames[monthNumber]] = soldMonthSum[monthNumber];
        ytdDlsSummary[monthNames[monthNumber]] = pipeMonthSum[monthNumber];
      }

      // Push the 'DLS' and 'YTD DLS' summary objects into the data array
      data.push(dlsSummary);
      data.push(ytdDlsSummary);

      return data;
    }

    exportDLSTable(empData, dataArray) {
      var data = new Array();
      var header = new Array();
      for (let i = 0; i < dataArray.length; i++) {
        header.push(dataArray[i].headerName);
      }
      data.push(header);
      for (let i = 0; i < empData.length; i++) {
        var instanceArray = [];
        instanceArray.push(empData[i].optyId);
        instanceArray.push(empData[i].slId);
        instanceArray.push(empData[i].bU);
        instanceArray.push(empData[i].bidType);
        instanceArray.push(empData[i].account);
        instanceArray.push(empData[i].opportunity);
        instanceArray.push(empData[i].bookVal);
        instanceArray.push(empData[i].closeMonth);
        instanceArray.push(empData[i].stgGrp);
        instanceArray.push(empData[i].leadSource);
        instanceArray.push(empData[i].inThor);
        instanceArray.push(empData[i].iReceived);
        instanceArray.push(empData[i].DLS);
        instanceArray.push(empData[i].teamMembers);
        instanceArray.push(empData[i].comments);
        instanceArray.push(empData[i].pid);

        data.push(instanceArray);
      }
      var wb = XLSX.utils.book_new();
      wb.SheetNames.push("DLS Tracker");
      var ws = XLSX.utils.aoa_to_sheet(data);
      wb.Sheets["DLS Tracker"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "DLS Tracker_" + new Date().toISOString().split('T')[0] + ".xlsx";

      if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, filename);
      } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
          // Browsers that support HTML5 download attribute
          var url = URL.createObjectURL(blob);
          link.setAttribute("href", url);
          link.setAttribute("download", filename);
          link.setAttribute("target", "_blank");
          link.style.visibility = 'hidden';
          document.body.appendChild(link);
          link.click();
          //console.log('Link'+JSON.stringify(link));
          // var win = window.open(url, "_blank");
          //  win.focus();
          document.body.removeChild(link);
        }
      }
    }


    bidManagerLossComp(pursuit, emp, YEar) {
      var tableData = [];
      var arrayobj = Object.values(pursuit);
      const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitgovernance'], item])).values()];
      var uni = arrayUniqueByKey;
      for (var i = 0; i < uni.length; i++) {

        var pl = pursuit.filter(ele => ele.manPursuitgovernance == uni[i].manPursuitgovernance);

        var jan1 = []; var feb1 = []; var mar1 = []; var apr1 = []; var may1 = []; var jun1 = []; var jul1 = []; var aug1 = []; var sep1 = []; var oct1 = []; var nov1 = []; var dec1 = [];
        var jan = 0; var feb = 0; var mar = 0; var apr = 0; var may = 0; var jun = 0; var jul = 0; var aug = 0; var sep = 0; var oct = 0; var nov = 0; var dec = 0;

        var retpayload = {};
        for (var j = 0; j < pl.length; j++) {

          var today = new Date((pl[j].closeMonth != null && pl[j].closeMonth != '') ? pl[j].closeMonth : pl[j].manClosemonth);


          if ((pl[j].lost == null || pl[j].lost == '') && (today.getFullYear() == YEar) || (YEar == '1')) {


            if (pl[j].manPursuitgovernance === uni[i].manPursuitgovernance) {
              var month = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1);

              switch (Number(month)) {
                case 1: jan++; jan1.push(pl[j]); break;
                case 2: feb++; feb1.push(pl[j]); break;
                case 3: mar++; mar1.push(pl[j]); break;
                case 4: apr++; apr1.push(pl[j]); break;
                case 5: may++; may1.push(pl[j]); break;
                case 6: jun++; jun1.push(pl[j]); break;
                case 7: jul++; jul1.push(pl[j]); break;
                case 8: aug++; aug1.push(pl[j]); break;
                case 9: sep++; sep1.push(pl[j]); break;
                case 10: oct++; oct1.push(pl[j]); break;
                case 11: nov++; nov1.push(pl[j]); break;
                case 12: dec++; dec1.push(pl[j]); break;
              }
            }
          }
        }


        // Add data to the row
        var employee;
        if (uni[i].manPursuitgovernance) {
          employee = emp.find(ele => ele.id == uni[i].manPursuitgovernance) != undefined ? emp.find(ele => ele.id == uni[i].manPursuitgovernance).name : undefined;
        }
        retpayload['bU'] = employee != undefined ? employee : 'Not Assigned';
        retpayload['jan'] = jan;
        retpayload['jan1'] = jan1;
        retpayload['feb'] = feb;
        retpayload['feb1'] = feb1;
        retpayload['mar'] = mar;
        retpayload['mar1'] = mar1;
        retpayload['apr'] = apr;
        retpayload['apr1'] = apr1;
        retpayload['may'] = may;
        retpayload['may1'] = may1;
        retpayload['jun'] = jun;
        retpayload['jun1'] = jun1;
        retpayload['jul'] = jul;
        retpayload['jul1'] = jul1;
        retpayload['aug'] = aug;
        retpayload['aug1'] = aug1;
        retpayload['sep'] = sep;
        retpayload['sep1'] = sep1;
        retpayload['oct'] = oct;
        retpayload['oct1'] = oct1;
        retpayload['nov'] = nov;
        retpayload['nov1'] = nov1;
        retpayload['dec'] = dec;
        retpayload['dec1'] = dec1;

        tableData.push(retpayload);
      }

      return tableData;
    }

    plLossComp(pursuit, emp, YEar) {
      var tableData = [];
      var arrayobj = Object.values(pursuit);
      const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitlead'], item])).values()];
      var uni = arrayUniqueByKey;
      for (var i = 0; i < uni.length; i++) {

        var pl = pursuit.filter(ele => ele.manPursuitlead == uni[i].manPursuitlead)

        var jan1 = []; var feb1 = []; var mar1 = []; var apr1 = []; var may1 = []; var jun1 = []; var jul1 = []; var aug1 = []; var sep1 = []; var oct1 = []; var nov1 = []; var dec1 = [];
        var jan = 0; var feb = 0; var mar = 0; var apr = 0; var may = 0; var jun = 0; var jul = 0; var aug = 0; var sep = 0; var oct = 0; var nov = 0; var dec = 0;

        var retpayload = {};
        for (var j = 0; j < pl.length; j++) {

          var today = new Date((pl[j].closeMonth != null && pl[j].closeMonth != '') ? pl[j].closeMonth : pl[j].manClosemonth);


          if ((pl[j].lost == null || pl[j].lost == '') && (today.getFullYear() == YEar) || (YEar == '1')) {


            if (pl[j].manPursuitlead === uni[i].manPursuitlead) {
              var month = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1);

              switch (Number(month)) {
                case 1: jan++; jan1.push(pl[j]); break;
                case 2: feb++; feb1.push(pl[j]); break;
                case 3: mar++; mar1.push(pl[j]); break;
                case 4: apr++; apr1.push(pl[j]); break;
                case 5: may++; may1.push(pl[j]); break;
                case 6: jun++; jun1.push(pl[j]); break;
                case 7: jul++; jul1.push(pl[j]); break;
                case 8: aug++; aug1.push(pl[j]); break;
                case 9: sep++; sep1.push(pl[j]); break;
                case 10: oct++; oct1.push(pl[j]); break;
                case 11: nov++; nov1.push(pl[j]); break;
                case 12: dec++; dec1.push(pl[j]); break;
              }
            }
          }
        }


        // Add data to the row
        var employee;
        if (uni[i].manPursuitlead) {
          employee = emp.find(ele => ele.id == uni[i].manPursuitlead) != undefined ? emp.find(ele => ele.id == uni[i].manPursuitlead).name : undefined;
        }
        retpayload['bU'] = employee != undefined ? employee : 'Not Assigned';
        retpayload['jan'] = jan;
        retpayload['jan1'] = jan1;
        retpayload['feb'] = feb;
        retpayload['feb1'] = feb1;
        retpayload['mar'] = mar;
        retpayload['mar1'] = mar1;
        retpayload['apr'] = apr;
        retpayload['apr1'] = apr1;
        retpayload['may'] = may;
        retpayload['may1'] = may1;
        retpayload['jun'] = jun;
        retpayload['jun1'] = jun1;
        retpayload['jul'] = jul;
        retpayload['jul1'] = jul1;
        retpayload['aug'] = aug;
        retpayload['aug1'] = aug1;
        retpayload['sep'] = sep;
        retpayload['sep1'] = sep1;
        retpayload['oct'] = oct;
        retpayload['oct1'] = oct1;
        retpayload['nov'] = nov;
        retpayload['nov1'] = nov1;
        retpayload['dec'] = dec;
        retpayload['dec1'] = dec1;

        tableData.push(retpayload);
      }

      return tableData;
    }




    getLossComp(pursuit, YEar) {


      var bU = ['CANADA', 'CPR&S', 'R&ET', 'LATAM', 'MALS', 'SOGETI', 'TMT'];

      // Initialize the data structure with column names
      // var tableData = [
      //   ['BU','7days', '14days', '30days']
      // ];
      var tableData = [];

      for (var i = 0; i < bU.length; i++) {
        var jan1 = []; var feb1 = []; var mar1 = []; var apr1 = []; var may1 = []; var jun1 = []; var jul1 = []; var aug1 = []; var sep1 = []; var oct1 = []; var nov1 = []; var dec1 = [];
        var jan = 0; var feb = 0; var mar = 0; var apr = 0; var may = 0; var jun = 0; var jul = 0; var aug = 0; var sep = 0; var oct = 0; var nov = 0; var dec = 0;
        var retpayload = {};
        for (var j = 0; j < pursuit.length; j++) {

          if (pursuit[j].manMu === bU[i]) {

            var today = new Date((pursuit[j].closeMonth != null && pursuit[j].closeMonth != '') ? pursuit[j].closeMonth : pursuit[j].manClosemonth);
            if ((pursuit[j].lost == null || pursuit[j].lost == '') && (today.getFullYear() == YEar) || (YEar == '1')) {
              var month = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1);

              switch (Number(month)) {
                case 1: jan++; jan1.push(pursuit[j]); break;
                case 2: feb++; feb1.push(pursuit[j]); break;
                case 3: mar++; mar1.push(pursuit[j]); break;
                case 4: apr++; apr1.push(pursuit[j]); break;
                case 5: may++; may1.push(pursuit[j]); break;
                case 6: jun++; jun1.push(pursuit[j]); break;
                case 7: jul++; jul1.push(pursuit[j]); break;
                case 8: aug++; aug1.push(pursuit[j]); break;
                case 9: sep++; sep1.push(pursuit[j]); break;
                case 10: oct++; oct1.push(pursuit[j]); break;
                case 11: nov++; nov1.push(pursuit[j]); break;
                case 12: dec++; dec1.push(pursuit[j]); break;
              }
            }
          }
        }
        // Iterate through the pursuits and check the ranges for the current bU


        // Add data to the row
        retpayload['bU'] = bU[i]
        retpayload['jan'] = jan;
        retpayload['jan1'] = jan1;
        retpayload['feb'] = feb;
        retpayload['feb1'] = feb1;
        retpayload['mar'] = mar;
        retpayload['mar1'] = mar1;
        retpayload['apr'] = apr;
        retpayload['apr1'] = apr1;
        retpayload['may'] = may;
        retpayload['may1'] = may1;
        retpayload['jun'] = jun;
        retpayload['jun1'] = jun1;
        retpayload['jul'] = jul;
        retpayload['jul1'] = jul1;
        retpayload['aug'] = aug;
        retpayload['aug1'] = aug1;
        retpayload['sep'] = sep;
        retpayload['sep1'] = sep1;
        retpayload['oct'] = oct;
        retpayload['oct1'] = oct1;
        retpayload['nov'] = nov;
        retpayload['nov1'] = nov1;
        retpayload['dec'] = dec;
        retpayload['dec1'] = dec1;

        tableData.push(retpayload);
      }

      return tableData;
    }


    getDLSData(pursuit, dls) {
      var data = []
      var totalTCV = 0;
      for (var i = 0; i < pursuit.length; i++) {
        var dlsData = dls.find(ele => ele.slID == pursuit[i].id);
        var retpayload = {};
        retpayload['optyId'] = pursuit[i].manOptyID;
        retpayload['slId'] = pursuit[i].manSLId;
        retpayload['bU'] = pursuit[i].manMu;
        retpayload['bidType'] = pursuit[i].bus;
        retpayload['account'] = pursuit[i].manAccount;
        retpayload['opportunity'] = pursuit[i].manPursuitname;
        retpayload['bookVal'] = (pursuit[i].manStageGrp == 'SOLD' || pursuit[i].manStageGrp == 'LDQ') ? Number(pursuit[i].convertedBkg) : pursuit[i].manTCVoracle;
        totalTCV = totalTCV + Number(retpayload['bookVal']);
        retpayload['totalTCV'] = totalTCV;
        retpayload['closeMonth'] = pursuit[i].manClosemonth;
        retpayload['stgGrp'] = pursuit[i].manStageGrp;
        retpayload['leadSource'] = pursuit[i].leadSource;
        retpayload['cM'] = pursuit[i].cM;
        retpayload['flag'] = pursuit[i].flag;

        retpayload['id'] = pursuit[i].id;

        if (pursuit[i].flag == 'UpdateThor') {
          retpayload['inThor'] = 'Yes';
        }
        else if (pursuit[i].flag == 'Manual') {
          retpayload['inThor'] = 'No';
        }
        retpayload['iReceived'] = dlsData != undefined ? dlsData.iReceived : '';
        retpayload['DLS'] = dlsData != undefined ? dlsData.DLS : '';
        retpayload['teamMembers'] = dlsData != undefined ? dlsData.teamMembers : '';
        retpayload['comments'] = dlsData != undefined ? dlsData.comments : '';
        retpayload['pid'] = dlsData != undefined ? dlsData.pid : '';
        retpayload['soldCMP'] = dlsData != undefined ? dlsData.soldCMP : ''
        retpayload['actualCMP'] = dlsData != undefined ? dlsData.actualCMP : '';
        retpayload['CMIP'] = dlsData != undefined ? dlsData.CMIP : '';
        data.push(retpayload)
      }
      console.log(">>123", data)
      return data;
    }
    teamMemberString(arg1, presentString) {
      var queryString = "";
      var dateRanges = [];

      for (var i = 0; i < arg1.length; i++) {
        var MU = arg1[i];

        dateRanges.push(MU);
      }
      if (presentString == "") {
        if (dateRanges.length == 1) {
          queryString = dateRanges[0];
        }
        else if (dateRanges.length > 1) {
          queryString = dateRanges.join(", ");
        }
      }
      else {
        if (dateRanges.length == 1) {
          queryString = presentString + ', ' + dateRanges[0];
        }
        else if (dateRanges.length > 1) {
          queryString = presentString + ', ' + (dateRanges.join(", "));
        }
      }

      console.log(queryString);
      return queryString;
    }
    CalCM(sold, actual) {
      var result = (100 * Number(sold)) - (100 * Number(actual));
      return result;
    }
  }
  PageModule.prototype.bidManagerDoc = function (pursuit, emp, Doc, YEar, validateComp) {
    var tableData = [];
    let grandtotalArraySold = [], grandtotalArraySt5 = [], grandtotalArrayLost = [], grandtotalArray = [], grandtotalCountSold = 0, grandtotalCountSt5 = 0, grandtotalCountLost = 0, grandtotalCount = 0;
    var arrayobj = Object.values(pursuit);
    const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitgovernance'], item])).values()];
    var uni = arrayUniqueByKey;
    for (var i = 0; i < uni.length; i++) {
      var today = new Date();
      var pl = pursuit.filter(ele => ele.manPursuitgovernance == uni[i].manPursuitgovernance)

      var sold = 0,
        st5 = 0,
        lost = 0,
        rowArray = [];

      var retpayload = {}
      for (var j = 0; j < pl.length; j++) {
        if (((new Date((pl[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) && (pl[j].bidStatus == 'Submitted' || pl[j].bidStatus == 'WIP')) {
          var Validate;
          var doc = Doc.filter(ele1 => ele1.optyID == pl[j].id);
          {
            var count = 0;
            var nonCount = 0;
            for (var z = 0; z < doc.length; z++) {
              if (doc[z].uploadedBy != null) {
                count++;
                if (doc[z].notApplicability == 'Not Applicable') {
                  nonCount++;
                }

              }
            }
            if (count >= doc.length && nonCount < doc.length) {
              Validate = '1';
            }
            else if ((count > 0 && count < doc.length) && nonCount >= 0) {
              Validate = '1/2';
            }
            else {
              Validate = '0';
            }
          }
          if (validateComp == 'comp' ? Validate == '1' : validateComp == 'partial' ? Validate == '1/2' : Validate == '0') {
            if (pl[j].manPursuitgovernance === uni[i].manPursuitgovernance) {
              if (pl[j].manStageGrp === 'SOLD') {
                sold++;
                rowArray.push(pl[j]);
                grandtotalCountSold++;
                grandtotalArraySold.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);

              } else if (pl[j].status === '5-Submitted – Awaiting Decision') {
                st5++;
                rowArray.push(pl[j]);
                grandtotalCountSt5++;
                grandtotalArraySt5.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);

              } else if (pl[j].status === '6.2-Lost') {
                lost++;
                rowArray.push(pl[j]);
                grandtotalCountLost++;
                grandtotalArrayLost.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);

              }
            }
          }
        }
      }

      // Add data to the row
      var employee;
      if (uni[i].manPursuitgovernance) {
        let test = emp.find(ele => ele.id == uni[i].manPursuitgovernance)
        employee = test.name;
      }
      retpayload['bu'] = uni[i].manPursuitgovernance != undefined ? employee : 'Not Assigned';
      retpayload['sold'] = sold;
      retpayload['sub'] = st5;
      retpayload['lost'] = lost;
      retpayload['total'] = Number(sold) + Number(st5) + Number(lost);
      retpayload['totalArray'] = rowArray;
      tableData.push(retpayload);
    }
    tableData.sort(function (a, b) {
      return b['sold'] - a['sold'];
    });

    let totalPayload = {};
    totalPayload['bu'] = 'Grand Total';
    totalPayload['sold'] = grandtotalCountSold;
    totalPayload['soldArray'] = grandtotalArraySold;
    totalPayload['sub'] = grandtotalCountSt5;
    totalPayload['subArray'] = grandtotalArraySt5;
    totalPayload['lost'] = grandtotalCountLost;
    totalPayload['lostArray'] = grandtotalArrayLost;
    totalPayload['total'] = Number(grandtotalCountSold) + Number(grandtotalCountSt5) + Number(grandtotalCountLost);
    totalPayload['totalArray'] = grandtotalArray;
    tableData.push(totalPayload);

    return tableData;
  };

  PageModule.prototype.activePursuitQuery = function (activePursuit, query) {
    var matchingItems = [];

    var transformedBidStatusList = Array.from(query.matchAll(/bidStatus='(\w+)'/g), match => match[1]);
    var bidStatusList = transformedBidStatusList.map(bidStatus => ({ bidStatus }));

    var bidS = bidStatusList[0].bidStatus;
    var bidSt = bidStatusList[1].bidStatus;

    var transformedIdList = Array.from(query.matchAll(/id='(\d+)'/g), match => match[1]);
    var idList = transformedIdList.map(id => ({ id }));


    for (var i = 0; i < idList.length; i++) {

      var idLt = activePursuit.find(ele => ele.id == idList[i].id && (ele.bidStatus == bidS || ele.bidStatus == bidSt));

      if (idLt) {
        matchingItems.push(idLt);
      }


    }

    var bidFetch = matchingItems;

    return bidFetch;
  };

  PageModule.prototype.pursuitLeaderDoc = function (pursuit, emp, Doc, YEar, validateComp) {
    var tableData = [];
    let grandtotalArraySold = [], grandtotalArraySt5 = [], grandtotalArrayLost = [], grandtotalArray = [], grandtotalCountSold = 0, grandtotalCountSt5 = 0, grandtotalCountLost = 0, grandtotalCount = 0;
    var arrayobj = Object.values(pursuit);
    const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitlead'], item])).values()];
    var uni = arrayUniqueByKey;
    for (var i = 0; i < uni.length; i++) {
      var today = new Date();
      var pl = pursuit.filter(ele => ele.manPursuitlead == uni[i].manPursuitlead)

      var sold = 0,
        st5 = 0,
        lost = 0,
        rowArray = [];

      var retpayload = {}
      for (var j = 0; j < pl.length; j++) {
        if (((new Date((pl[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) && (pl[j].bidStatus == 'Submitted' || pl[j].bidStatus == 'WIP')) {
          var Validate;
          var doc = Doc.filter(ele1 => ele1.optyID == pl[j].id);
          {
            var count = 0;
            var nonCount = 0;
            for (var z = 0; z < doc.length; z++) {
              if (doc[z].uploadedBy != null) {
                count++;
                if (doc[z].notApplicability == 'Not Applicable') {
                  nonCount++;
                }

              }
            }
            if (count >= doc.length && nonCount < doc.length) {
              Validate = '1';
            }
            else if ((count > 0 && count < doc.length) && nonCount >= 0) {
              Validate = '1/2';
            }
            else {
              Validate = '0';
            }
          }
          if (validateComp == 'comp' ? Validate == '1' : validateComp == 'partial' ? Validate == '1/2' : Validate == '0') {

            if (pl[j].manPursuitlead === uni[i].manPursuitlead) {
              if (pl[j].manStageGrp === 'SOLD') {
                sold++;
                rowArray.push(pl[j]);
                grandtotalCountSold++;
                grandtotalArraySold.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);
              } else if (pl[j].status === '5-Submitted – Awaiting Decision') {
                st5++;
                rowArray.push(pl[j]);
                grandtotalCountSt5++;
                grandtotalArraySt5.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);
              } else if (pl[j].status === '6.2-Lost') {
                lost++;
                rowArray.push(pl[j]);
                grandtotalCountLost++;
                grandtotalArrayLost.push(pl[j]);
                grandtotalCount++;
                grandtotalArray.push(pl[j]);
              }
            }
          }
        }
      }

      // Add data to the row
      var employee;
      if (uni[i].manPursuitlead) {
        employee = emp.find(ele => ele.id == uni[i].manPursuitlead).name
      }
      retpayload['bu'] = uni[i].manPursuitlead != undefined ? employee : 'Not Assigned'
      retpayload['sold'] = sold;
      retpayload['sub'] = st5;
      retpayload['lost'] = lost;
      retpayload['total'] = Number(sold) + Number(st5) + Number(lost);
      retpayload['totalArray'] = rowArray;
      tableData.push(retpayload);
    }
    tableData.sort(function (a, b) {
      return b['sold'] - a['sold'];
    });

    let totalPayload = {};
    totalPayload['bu'] = 'Grand Total';
    totalPayload['sold'] = grandtotalCountSold;
    totalPayload['soldArray'] = grandtotalArraySold;
    totalPayload['sub'] = grandtotalCountSt5;
    totalPayload['subArray'] = grandtotalArraySt5;
    totalPayload['lost'] = grandtotalCountLost;
    totalPayload['lostArray'] = grandtotalArrayLost;
    totalPayload['total'] = Number(grandtotalCountSold) + Number(grandtotalCountSt5) + Number(grandtotalCountLost);
    totalPayload['totalArray'] = grandtotalArray;
    tableData.push(totalPayload);

    return tableData;
  };
  PageModule.prototype.getDataStaleReport = function (active, emp, YEar) {
    var data = [];
    for (var x = 0; x < active.length; x++) {
      if ((new Date((active[x].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
        var retpayload = {};
        var pLead = emp.find(ele => ele.id == active[x].manPursuitlead);
        var pGov = emp.find(ele => ele.id == active[x].manPursuitgovernance);

        retpayload['manProb'] = active[x].stgGroup == 'SOLD' ? Number(active[x].probability) : Number(active[x].manProb);
        retpayload['manStaffing'] = active[x].manStaffing;
        retpayload['manMu'] = active[x].manMu;
        retpayload['manBu'] = active[x].manBu;
        retpayload['manAccount'] = active[x].manAccount;
        retpayload['manPillar'] = active[x].manPillar;
        retpayload['manNLCategory'] = active[x].manNLCategory;
        retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
        retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
        retpayload['manClosemonth'] = active[x].manClosemonth;
        retpayload['manTCV'] = active[x].manTCV;
        retpayload['id'] = active[x].id;
        retpayload['manTCVoracle'] = (active[x].stgGroup == 'SOLD' || active[x].stgGroup == 'LDQ') ? Number(active[x].convertedBkg) : active[x].manTCVoracle;
        //  totalTCV=totalTCV+ Number( retpayload['manTCVoracle']);
        //  retpayload['totalTCV']=totalTCV;
        retpayload['manPursuitname'] = active[x].manPursuitname;
        retpayload['manOptyID'] = active[x].manOptyID;
        retpayload['optyID'] = active[x].manOptyID;
        retpayload['manSLId'] = active[x].manSLId;
        retpayload['manStageGrp'] = active[x].manStageGrp;
        retpayload['status'] = active[x].status;
        //retpayload['Z']=z;

        data.push(retpayload);
      }
    }
    return data;
  };
  PageModule.prototype.getDataStaleReport1 = function (Active, emp, status, YEar) {
    var data = [];
    for (var a = 0; a < status.length; a++) {
      var active = Active.find(ele => ele.id == status[a].id);
      {
        if ((new Date((active.manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          var retpayload = {};
          var pLead = emp.find(ele => ele.id == active.manPursuitlead);
          var pGov = emp.find(ele => ele.id == active.manPursuitgovernance);

          retpayload['manProb'] = active.stgGroup == 'SOLD' ? Number(active.probability) : Number(active.manProb);
          retpayload['manStaffing'] = active.manStaffing;
          retpayload['manMu'] = active.manMu;
          retpayload['manBu'] = active.manBu;
          retpayload['manAccount'] = active.manAccount;
          retpayload['manPillar'] = active.manPillar;
          retpayload['manNLCategory'] = active.manNLCategory;
          retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
          retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['manClosemonth'] = active.manClosemonth;
          retpayload['manTCV'] = active.manTCV;
          retpayload['manTCVoracle'] = (active.stgGroup == 'SOLD' || active.stgGroup == 'LDQ') ? Number(active.convertedBkg) : active.manTCVoracle;
          //  totalTCV=totalTCV+ Number( retpayload['manTCVoracle']);
          //  retpayload['totalTCV']=totalTCV;
          retpayload['manPursuitname'] = active.manPursuitname;
          retpayload['manOptyID'] = active.manOptyID;
          retpayload['optyID'] = active.manOptyID;
          retpayload['manSLId'] = active.manSLId;
          retpayload['manStageGrp'] = active.manStageGrp;
          retpayload['status'] = active.status;
          retpayload['lastUpdatedDate'] = active.lastUpdateDate;

          //retpayload['Z']=z;

          data.push(retpayload);
        }
      }
    }
    return data;
  };
  PageModule.prototype.date71430daystab2 = function (date, bu, so, emp) {
    var today = new Date();
    var next30Days = new Date();
    var empBM;
    if (bu != 'Not Assigned' && emp != '10') {
      empBM = emp.find(ele => ele.id == emp[0].id).id;
    }
    if (so == 'bu') {
      if (date == '3') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        var sqlQuery = "optyIDObject.status='6.2-Lost' AND optyIDObject.manMu='" + bu + "'";
        return sqlQuery;
      }
      if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        var sqlQuery = " optyIDObject.status='5-Submitted – Awaiting Decision' AND optyIDObject.manMu='" + bu + "'";
        return sqlQuery;
      }
      else if (date == '1') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];

        var sqlQuery = "optyIDObject.manStageGrp='SOLD' AND optyIDObject.manMu='" + bu + "'";
        return sqlQuery;
      }
    }
    else if (so == 'bm') {
      if (date == '3') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.status='6.2-Lost' AND optyIDObject.manPursuitgovernance='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.status='6.2-Lost' AND optyIDObject.manPursuitgovernance IS NULL";
        }
        return sqlQuery;
      }
      if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.status='5-Submitted – Awaiting Decision' AND optyIDObject.manPursuitgovernance='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.status='5-Submitted – Awaiting Decision' AND optyIDObject.manPursuitgovernance IS NULL";
        }
        return sqlQuery;
      }
      else if (date == '1') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.manStageGrp='SOLD' AND optyIDObject.manPursuitgovernance='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.manStageGrp='SOLD' AND optyIDObject.manPursuitgovernance IS NULL";
        }
        return sqlQuery;
      }
    }
    else if (so == 'pl') {
      if (date == '3') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.status='6.2-Lost' AND optyIDObject.manPursuitlead='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.status='6.2-Lost' AND optyIDObject.manPursuitlead IS NULL";
        }
        return sqlQuery;
      }
      if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.status='5-Submitted – Awaiting Decision' AND optyIDObject.manPursuitlead='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.status='5-Submitted – Awaiting Decision' AND optyIDObject.manPursuitlead IS NULL";
        }
        return sqlQuery;
      }
      else if (date == '1') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "optyIDObject.manStageGrp='SOLD' AND optyIDObject.manPursuitlead='" + empBM + "'";
        }
        else {
          var sqlQuery = "optyIDObject.manStageGrp='SOLD' AND optyIDObject.manPursuitlead IS NULL";
        }
        return sqlQuery;
      }
    }
  };

  PageModule.prototype.BU1 = function (date1) {
    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var BU = date1[i];

      dateRanges.push("(" + "manMu ='" + BU + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };
  PageModule.prototype.dueDateFunction1 = function (date1) {

    var selectedMonths = date1;
    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < selectedMonths.length; i++) {
      var month = selectedMonths[i];
      var startDate, endDate;

      if (month === 'Jan') {
        startDate = '2023-01-01';
        endDate = '2023-01-31';
      } else if (month === 'Feb') {
        startDate = '2023-02-01';
        endDate = '2023-02-28';
      } else if (month === 'Mar') {
        startDate = '2023-03-01';
        endDate = '2023-03-31';
      } else if (month === 'Apr') {
        startDate = '2023-04-01';
        endDate = '2023-04-30';
      } else if (month === 'May') {
        startDate = '2023-05-01';
        endDate = '2023-05-31';
      } else if (month === 'Jun') {
        startDate = '2023-06-01';
        endDate = '2023-06-30';
      } else if (month === 'Jul') {
        startDate = '2023-07-01';
        endDate = '2023-07-31';
      } else if (month === 'Aug') {
        startDate = '2023-08-01';
        endDate = '2023-08-31';
      } else if (month === 'Sep') {
        startDate = '2023-09-01';
        endDate = '2023-09-30';
      } else if (month === 'Oct') {
        startDate = '2023-10-01';
        endDate = '2023-10-31';
      } else if (month === 'Nov') {
        startDate = '2023-11-01';
        endDate = '2023-11-30';
      } else if (month === 'Dec') {
        startDate = '2023-12-01';
        endDate = '2023-12-31';
      }

      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }
    if (dateRanges.length == 1) {
      queryString = dateRanges + "AND ";
    }
    else if (dateRanges.length > 1) {
      queryString = "(" + dateRanges.join(" OR ") + ")AND";
    }

    console.log(queryString);
    return queryString;
  };
  PageModule.prototype.documentRepoValidate = function (data, validateComp) {
    var dateRanges = [];
    var sqlQuery = "";
    if (data.length > 0) {
      var arrayobj = Object.values(data);
      const arrayUniqueByKey = [...new Map(data.map(item => [item['optyID'], item])).values()];
      var uni = arrayUniqueByKey;
      for (var i = 0; i < uni.length; i++) {
        var Validate;
        var doc = data.filter(ele => ele.optyID == uni[i].optyID)
        {
          var count = 0;
          var nonCount = 0;
          for (var z = 0; z < doc.length; z++) {
            if (doc[z].uploadedBy != null) {
              count++;
              if (doc[z].notApplicability == 'Not Applicable') {
                nonCount++;
              }

            }
          }
          if (count >= doc.length && nonCount < doc.length) {
            Validate = '1';
          }
          else if ((count > 0 && count < doc.length) && nonCount >= 0) {
            Validate = '1/2';
          }
          else {
            Validate = '0';
          }
        }
        if (validateComp == 'comp' ? Validate == '1' : validateComp == 'partial' ? Validate == '1/2' : Validate == '0') {
          dateRanges.push("(" + "id='" + uni[i].optyID + "'" + ")");
        }
      }

      if (dateRanges.length == 1) {
        sqlQuery = dateRanges[0] + "AND ( bidStatus='Submitted' OR bidStatus='WIP')";
        return sqlQuery;
      } else if (dateRanges.length > 1) {
        sqlQuery = "(" + dateRanges.join(" OR ") + ")AND ( bidStatus='Submitted' OR bidStatus='WIP')";
        return sqlQuery;
      }
      else if (dateRanges.length == 0) {
        sqlQuery = ("(" + "id='-1'" + ")");
        return sqlQuery;
      }
    }
    else {
      sqlQuery = ("(" + "id='-1'" + ")");
      return sqlQuery;
    }
  };

  PageModule.prototype.PursuitStatusValidate = function (data, status) {
    var dateRanges = [];
    // var sqlQuery = "";
    if (data.length > 0) {
      // var arrayobj=Object.values(data); 
      //     const arrayUniqueByKey = [...new Map(data.map(item =>  [item['optyID'], item])).values()];   
      //     var uni=arrayUniqueByKey;
      for (var i = 0; i < data.length; i++) {
        var count = 0;
        var count1 = 0;
        var act = status.filter(ele => ele.optyID == data[i].id)
        {

          if (act.length > 0) {
            for (var x = 0; x < act.length; x++) {

              var date1 = new Date(act[x].creationDate);
              var today1 = new Date();

              var day2 = date1.getDate() < 10 ? '0' + date1.getDate() : date1.getDate();
              var month2 = date1.getMonth() < 9 ? '0' + (date1.getMonth() + 1) : '' + (date1.getMonth() + 1);
              var year2 = date1.getFullYear();
              var currentDate2 = `${year2}-${month2}-${day2}`;

              var day = today1.getDate() > '7' ? (today1.getDate() < '17' ? '0' + (today1.getDate() - 7) : today1.getDate() - 7) : (30 - (7 - today1.getDate()));
              var month1 = today1.getMonth() < 9 ? '0' + (today1.getMonth() + 1) : '' + (today1.getMonth() + 1);
              var month = today1.getDate() > '7' ? month1 : (Number(month1) - 1);
              var year = month1 == 1 ? Number(today1.getFullYear()) - 1 : today1.getFullYear();
              var currentDate = `${year}-${month}-${day}`;

              if (currentDate2 > currentDate) {
                count++;
              }


            }
          }
          else {
            count1++;
          }
        }
        if (count == '0' || count1 > '0') {
          var ret = {};
          ret['id'] = data[i].id;
          dateRanges.push(ret);
        }
      }

      // if (dateRanges.length == 1) {
      //     sqlQuery = dateRanges[0];
      //   } else if (dateRanges.length > 1) {
      //     sqlQuery = "(" + dateRanges.join(" OR ") + ")";
      //   }
      // return sqlQuery;
    }
    // else{
    //   sqlQuery = ("("+"id='-1'" +")");
    //   return sqlQuery;
    // }
    return dateRanges;
  };
  PageModule.prototype.date71430days = function (date, bu, so, emp) {
    var today = new Date();
    var next30Days = new Date();
    var empBM;
    if (bu != 'Not Assigned' && emp != '10') {
      empBM = emp.find(ele => ele.id == emp[0].id).id;
    }
    if (so == 'bu') {
      if (date == '1') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manMu='" + bu + "')";
        return sqlQuery;
      }
      else if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manMu='" + bu + "')";
        return sqlQuery;
      }
      else if (date == '3') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];

        var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manMu='" + bu + "')";
        return sqlQuery;
      }
    }
    else if (so == 'bm') {
      if (date == '1') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance IS NULL)";
        }
        return sqlQuery;
      }
      else if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance IS NULL)";
        }
        return sqlQuery;
      }
      else if (date == '3') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitgovernance IS NULL)";
        }
        return sqlQuery;
      }
    }
    else if (so == 'pl') {
      if (date == '1') {
        next30Days.setDate(today.getDate() + 30);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead IS NULL)";
        }
        return sqlQuery;
      }
      else if (date == '2') {
        next30Days.setDate(today.getDate() + 14);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead IS NULL)";
        }
        return sqlQuery;
      }
      else if (date == '3') {
        next30Days.setDate(today.getDate() + 7);
        var todayFormatted = today.toISOString().split('T')[0];
        var next30DaysFormatted = next30Days.toISOString().split('T')[0];
        if (bu != 'Not Assigned') {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead='" + empBM + "')";
        }
        else {
          var sqlQuery = "(manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "') AND (manPursuitlead IS NULL)";
        }
        return sqlQuery;
      }
    }
  };

  PageModule.prototype.getDoc = function (pursuit, Doc, YEar, validateComp) {
    var data = [];
    let grandtotalArraySold = [], grandtotalArraySt5 = [], grandtotalArrayLost = [], grandtotalArray = [], grandtotalCountSold = 0, grandtotalCountSt5 = 0, grandtotalCountLost = 0, grandtotalCount = 0;
    var bU = ['CANADA', 'CPR&S', 'R&ET', 'LATAM', 'MALS', 'SOGETI', 'TMT'];

    for (var i = 0; i < bU.length; i++) {
      var retpayload = {};
      var soldc = 0,
        st5 = 0,
        lost = 0,
        rowArray = [];

      for (var j = 0; j < pursuit.length; j++) {
        if (((new Date((pursuit[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) && (pursuit[j].bidStatus == 'Submitted' || pursuit[j].bidStatus == 'WIP')) {
          var Validate;
          var doc = Doc.filter(ele1 => ele1.optyID == pursuit[j].id);
          {
            var count = 0;
            var nonCount = 0;
            for (var z = 0; z < doc.length; z++) {
              if (doc[z].uploadedBy != null) {
                count++;
                if (doc[z].notApplicability == 'Not Applicable') {
                  nonCount++;
                }

              }
            }
            if (count >= doc.length && nonCount < doc.length) {
              Validate = '1';
            }
            else if ((count > 0 && count < doc.length) && nonCount >= 0) {
              Validate = '1/2';
            }
            else {
              Validate = '0';
            }
          }
          if (validateComp == 'comp' ? Validate == '1' : validateComp == 'partial' ? Validate == '1/2' : Validate == '0') {
            if (pursuit[j].manMu === bU[i]) {
              if (pursuit[j].manStageGrp === 'SOLD') {
                soldc++;
                rowArray.push(pursuit[j]);
                grandtotalCountSold++;
                grandtotalArraySold.push(pursuit[j]);
                grandtotalCount++;
                grandtotalArray.push(pursuit[j]);
              } else if (pursuit[j].status === '5-Submitted – Awaiting Decision') {
                st5++;
                rowArray.push(pursuit[j]);
                grandtotalCountSt5++;
                grandtotalArraySt5.push(pursuit[j]);
                grandtotalCount++;
                grandtotalArray.push(pursuit[j]);
              } else if (pursuit[j].status === '6.2-Lost') {
                lost++;
                rowArray.push(pursuit[j]);
                grandtotalCountLost++;
                grandtotalArrayLost.push(pursuit[j]);
                grandtotalCount++;
                grandtotalArray.push(pursuit[j]);
              }
            }
          }
        }
      }

      retpayload['bu'] = bU[i];
      retpayload['sold'] = soldc;
      retpayload['sub'] = st5;
      retpayload['lost'] = lost;
      retpayload['total'] = Number(soldc) + Number(st5) + Number(lost);
      retpayload['totalArray'] = rowArray;
      data.push(retpayload);
    }
    data.sort(function (a, b) {
      return b['sold'] - a['sold'];
    });

    let totalPayload = {};
    totalPayload['bu'] = 'Grand Total';
    totalPayload['sold'] = grandtotalCountSold;
    totalPayload['soldArray'] = grandtotalArraySold;
    totalPayload['sub'] = grandtotalCountSt5;
    totalPayload['subArray'] = grandtotalArraySt5;
    totalPayload['lost'] = grandtotalCountLost;
    totalPayload['lostArray'] = grandtotalArrayLost;
    totalPayload['total'] = Number(grandtotalCountSold) + Number(grandtotalCountSt5) + Number(grandtotalCountLost);
    totalPayload['totalArray'] = grandtotalArray;
    data.push(totalPayload);

    return data;
  };
  PageModule.prototype.date30days = function () {
    // Get today's date
    var today = new Date();

    // Add 30 days to today's date
    var next30Days = new Date();
    next30Days.setDate(today.getDate() + 30);

    // Format the dates in the required format
    var todayFormatted = today.toISOString().split('T')[0];
    var next30DaysFormatted = next30Days.toISOString().split('T')[0];

    // Create the SQL query
    var sqlQuery = "(" + "manClosemonth BETWEEN '" + todayFormatted + "' AND '" + next30DaysFormatted + "'" + ")";

    // Print the SQL query
    console.log(sqlQuery);

    return sqlQuery;

  };
  PageModule.prototype.bidManagerStatusStale = function (pursuit, emp, status, YEar) {

    var tableData = [];
    var arrayobj = Object.values(pursuit);
    const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitgovernance'], item])).values()];
    var uni = arrayUniqueByKey;
    for (var i = 0; i < uni.length; i++) {
      var today = new Date();
      var pl = pursuit.filter(ele => ele.manPursuitgovernance == uni[i].manPursuitgovernance);
      var oneWeekAgo = new Date();
      oneWeekAgo.setDate(today.getDate() + 7);

      var twoWeeksAgo = new Date();
      twoWeeksAgo.setDate(today.getDate() + 14);

      var oneMonthAgo = new Date();
      oneMonthAgo.setDate(today.getDate() + 30);

      var dt7 = 0,
        dt14 = 0,
        dt30 = 0;
      var retpayload = {};
      for (var j = 0; j < pl.length; j++) {
        if ((new Date((pl[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          var count = 0;
          var count1 = 0;
          {
            var act = status.filter(ele => ele.optyID == pl[j].id);
            {

              if (act.length > 0) {
                for (var x = 0; x < act.length; x++) {

                  var date1 = new Date(act[x].creationDate);
                  var today1 = new Date();

                  var day2 = date1.getDate() < 10 ? '0' + date1.getDate() : date1.getDate();
                  var month2 = date1.getMonth() < 9 ? '0' + (date1.getMonth() + 1) : '' + (date1.getMonth() + 1);
                  var year2 = date1.getFullYear();
                  var currentDate2 = `${year2}-${month2}-${day2}`;

                  var day = today1.getDate() > '7' ? (today1.getDate() < '17' ? '0' + (today1.getDate() - 7) : today1.getDate() - 7) : (30 - (7 - today1.getDate()));
                  var month1 = today1.getMonth() < 9 ? '0' + (today1.getMonth() + 1) : '' + (today1.getMonth() + 1);
                  var month = today1.getDate() > '7' ? month1 : (Number(month1) - 1);
                  var year = month1 == 1 ? Number(today1.getFullYear()) - 1 : today1.getFullYear();
                  var currentDate = `${year}-${month}-${day}`;

                  if (currentDate2 > currentDate) {
                    count++;
                  }


                }
              }
              else {
                count1++;
              }
            }
          }
          if (count == '0' || count1 > '0') {

            if (pl[j].manPursuitgovernance === uni[i].manPursuitgovernance) {
              var date = new Date(pl[j].manClosemonth);

              if ((date.toISOString().split('T')[0] <= oneWeekAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt7++;
              }

              if ((date.toISOString().split('T')[0] <= twoWeeksAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt14++;
              }

              if ((date.toISOString().split('T')[0] <= oneMonthAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt30++;
              }
            }
          }
        }
      }

      // Add data to the row
      var employee;
      if (uni[i].manPursuitgovernance) {
        employee = emp.find(ele => ele.id == uni[i].manPursuitgovernance).name;
      }
      retpayload['bU'] = uni[i].manPursuitgovernance != undefined ? employee : 'Not Assigned';
      retpayload['7days'] = dt7;
      retpayload['14days'] = dt14;
      retpayload['30days'] = dt30;
      tableData.push(retpayload);
    }
    tableData.sort(function (a, b) {
      return b['30days'] - a['30days'];
    });
    return tableData;

  };
  PageModule.prototype.getStatusStale = function (pursuit, status, YEar) {

    var data = [];

    var bU = ['CANADA', 'CPR&S', 'R&ET', 'LATAM', 'MALS', 'SOGETI', 'TMT'];

    // Initialize the data structure with column names
    // var tableData = [
    //   ['BU','7days', '14days', '30days']
    // ];
    var tableData = []

    for (var i = 0; i < bU.length; i++) {

      var today = new Date();

      // Calculate the date ranges
      var oneWeekAgo = new Date();
      oneWeekAgo.setDate(today.getDate() + 7);

      var twoWeeksAgo = new Date();
      twoWeeksAgo.setDate(today.getDate() + 14);

      var oneMonthAgo = new Date();
      oneMonthAgo.setDate(today.getDate() + 30);

      var dt7 = 0,
        dt14 = 0,
        dt30 = 0;
      var retpayload = {}
      // Iterate through the pursuits and check the ranges for the current bU
      for (var j = 0; j < pursuit.length; j++) {
        if ((new Date((pursuit[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          var count = 0;
          var count1 = 0;
          if (pursuit[j].manMu === bU[i]) {
            {
              var act = status.filter(ele => ele.optyID == pursuit[j].id);
              {

                if (act.length > 0) {
                  for (var x = 0; x < act.length; x++) {

                    var date1 = new Date(act[x].creationDate);
                    var today1 = new Date();

                    var day2 = date1.getDate() < 10 ? '0' + date1.getDate() : date1.getDate();
                    var month2 = date1.getMonth() < 9 ? '0' + (date1.getMonth() + 1) : '' + (date1.getMonth() + 1);
                    var year2 = date1.getFullYear();
                    var currentDate2 = `${year2}-${month2}-${day2}`;

                    var day = today1.getDate() > '7' ? (today1.getDate() < '17' ? '0' + (today1.getDate() - 7) : today1.getDate() - 7) : (30 - (7 - today1.getDate()));
                    var month1 = today1.getMonth() < 9 ? '0' + (today1.getMonth() + 1) : '' + (today1.getMonth() + 1);
                    var month = today1.getDate() > '7' ? month1 : (Number(month1) - 1);
                    // month = month < 10 ? '0' + month : month;
                    var year = month1 == 1 ? Number(today1.getFullYear()) - 1 : today1.getFullYear();
                    var currentDate = `${year}-${month}-${day}`;

                    if (currentDate2 > currentDate) {
                      count++;
                    }


                  }
                }
                else {
                  count1++;
                }
              }
            }
            if (count == '0' || count1 > '0') {
              var date = new Date(pursuit[j].manClosemonth);

              if ((date.toISOString().split('T')[0] <= oneWeekAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt7++;
              }

              if ((date.toISOString().split('T')[0] <= twoWeeksAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt14++;
              }

              if ((date.toISOString().split('T')[0] <= oneMonthAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt30++;
              }
            }
          }
        }
      }

      // Add data to the row
      retpayload['bU'] = bU[i];
      retpayload['7days'] = dt7;
      retpayload['14days'] = dt14;
      retpayload['30days'] = dt30;
      tableData.push(retpayload);
    }
    tableData.sort(function (a, b) {
      return b['30days'] - a['30days'];
    });

    return tableData;
  };
  PageModule.prototype.getCloseMonth = function (dateID) {
    var month = ['2023-01-01', '2023-02-01', '2023-03-01', '2023-04-01', '2023-05-01', '2023-06-01', '2023-07-01', '2023-08-01', '2023-09-01', '2023-10-01', '2023-11-01', '2023-12-01'];
    var id = dateID - 1;
    return month[id];
  };
  PageModule.prototype.plStatusStale = function (pursuit, emp, status, YEar) {
    var tableData = [];
    var arrayobj = Object.values(pursuit);
    const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manPursuitlead'], item])).values()];
    var uni = arrayUniqueByKey;
    for (var i = 0; i < uni.length; i++) {
      var today = new Date();
      var pl = pursuit.filter(ele => ele.manPursuitlead == uni[i].manPursuitlead);
      var oneWeekAgo = new Date();
      oneWeekAgo.setDate(today.getDate() + 7);

      var twoWeeksAgo = new Date();
      twoWeeksAgo.setDate(today.getDate() + 14);

      var oneMonthAgo = new Date();
      oneMonthAgo.setDate(today.getDate() + 31);

      var dt7 = 0,
        dt14 = 0,
        dt30 = 0;
      var retpayload = {};
      for (var j = 0; j < pl.length; j++) {
        if ((new Date((pl[j].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          var count = 0;
          var count1 = 0;

          {
            var act = status.filter(ele => ele.optyID == pl[j].id);
            {

              if (act.length > 0) {
                for (var x = 0; x < act.length; x++) {

                  var date1 = new Date(act[x].creationDate);
                  var today1 = new Date();

                  var day2 = date1.getDate() < 10 ? '0' + date1.getDate() : date1.getDate();
                  var month2 = date1.getMonth() < 9 ? '0' + (date1.getMonth() + 1) : '' + (date1.getMonth() + 1);
                  var year2 = date1.getFullYear();
                  var currentDate2 = `${year2}-${month2}-${day2}`;

                  var day = today1.getDate() > '7' ? (today1.getDate() < '17' ? '0' + (today1.getDate() - 7) : today1.getDate() - 7) : (30 - (7 - today1.getDate()));
                  var month1 = today1.getMonth() < 9 ? '0' + (today1.getMonth() + 1) : '' + (today1.getMonth() + 1);
                  var month = today1.getDate() > '7' ? month1 : (Number(month1) - 1);
                  var year = month1 == 1 ? Number(today1.getFullYear()) - 1 : today1.getFullYear();
                  var currentDate = `${year}-${month}-${day}`;

                  if (currentDate2 > currentDate) {
                    count++;
                  }


                }
              }
              else {
                count1++;
              }
            }
          }
          if (count == '0' || count1 > '0') {


            if (pl[j].manPursuitlead === uni[i].manPursuitlead) {
              var date = new Date(pl[j].manClosemonth);

              if ((date.toISOString().split('T')[0] <= oneWeekAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt7++;
              }

              if ((date.toISOString().split('T')[0] <= twoWeeksAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt14++;
              }

              if ((date.toISOString().split('T')[0] <= oneMonthAgo.toISOString().split('T')[0]) && (date.toISOString().split('T')[0] >= today.toISOString().split('T')[0])) {
                dt30++;
              }
            }
          }
        }
      }


      // Add data to the row
      var employee;
      if (uni[i].manPursuitlead) {
        employee = emp.find(ele => ele.id == uni[i].manPursuitlead).name;
      }
      retpayload['bU'] = uni[i].manPursuitlead != undefined ? employee : 'Not Assigned'
      retpayload['7days'] = dt7;
      retpayload['14days'] = dt14;
      retpayload['30days'] = dt30;
      tableData.push(retpayload);
    }
    tableData.sort(function (a, b) {
      return b['30days'] - a['30days'];
    });
    return tableData;
  };

  PageModule.prototype.report = function (ActiveBO) {
    var data = [];
    var data2 = [];
    var payload = {};

    var MU;
    var month = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    for (var i = 0; i < ActiveBO.length; i++) {

      var retpayload = {};

      MU = ActiveBO.filter(ele => ele.manMu == ActiveBO[i].manMu);
      if (!data2.includes(ActiveBO[i].manMu)) {

        data2.push(ActiveBO[i].manMu);
        retpayload['bu'] = ActiveBO[i].manMu;
        for (var b = 0; b < month.length; b++) {
          var grandTotal = 0;
          var total = 0;

          for (var a = 0; a < MU.length; a++) {

            var nn = (MU[a].manStageGrp == 'SOLD' || MU[a].manStageGrp == 'LDQ') ? Number(MU[a].convertedBkg) : MU[a].manTCVoracle;
            var date = new Date(MU[a].manClosemonth);
            var month1 = month[date.getMonth()];
            grandTotal += nn;
            if (month1 == month[b]) {

              total += nn;
              retpayload[month[b]] = total;

            }

          }

          retpayload['Total'] = grandTotal;

        }

        data.push(retpayload);
      }


    }

    payload['bu'] = 'TOTAL';
    var grosstotal = 0;
    for (var j = 0; j < month.length; j++) {
      var gtotal = 0;
      for (var k = 0; k < data.length; k++) {
        var pp;
        if (data[k][month[j]]) {
          pp = data[k][month[j]];
        } else {
          pp = 0;
        }
        gtotal = gtotal + pp;
      }
      payload[month[j]] = gtotal;
      console.log('99#', gtotal);
      grosstotal = grosstotal + gtotal;
      payload['Total'] = grosstotal;
    }
    data.push(payload);
    console.log('55#', data);
    return data;
  };

  PageModule.prototype.getData1 = function (pursuit, revenueBO, inputPillar, inputSummary, InputYear) {
    const quarters = {
      Q1: ['Jan', 'Feb', 'Mar'],
      Q2: ['Apr', 'May', 'Jun'],
      Q3: ['Jul', 'Aug', 'Sep'],
      Q4: ['Oct', 'Nov', 'Dec']
    };

    const payload = {
      'Won (Booked till date)': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'NL Category A': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business2': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring2': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'UnWt. Upside': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business3': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring3': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'Wt. Upside': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business4': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring4': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'Sold Oracle Number': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business5': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring5': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'Pipe Number': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      }

    };

    for (const item of pursuit) {
      const dateToCheck = new Date(item.manClosemonth);
      const year = dateToCheck.getFullYear();
      if (year === parseInt(InputYear)) {
        const month = dateToCheck.toLocaleString('default', { month: 'short' });
        const isEbus = item.bus === 'E-BUS(renewals)';
        const isNbus = item.bus === 'N-BUS(NewLogo)' || item.bus === 'E-BUS(NetNew)';
        const isSold = item.manStageGrp === 'SOLD';
        const ispipeN = (item.manStageGrp === 'PIPE' && (item.bus == 'E-BUS(NetNew)' || item.bus == 'N-BUS(NewLogo)') && (item.flag == 'UpdateThor' || item.flag == 'Manual') && (item.manNLCategory == 'Y-Extensions HP (NL Cat. A) 99%' || item.manNLCategory == 'Y-Extensions MP (NL Cat. A) 80%' || item.manNLCategory == 'Y-Deal Rev. HP (NL Cat. B) 90%' || item.manNLCategory == 'Y-Deal Rev. MP (NL Cat. B) 60%' || item.manNLCategory == 'Y-Firm') && item.pStatus != 'Verbal Received')
        const ispipeY = (item.manStageGrp === 'PIPE' && (item.flag == 'UpdateThor' || item.flag == 'Manual') && (item.bus == 'E-BUS(renewals)' || item.pStatus == 'Verbal Received'));
        const ispipe = item.manStageGrp === 'PIPE';
        const isSoldNumber = (item.manStageGrp === 'SOLD' || item.manStageGrp === 'PIPE') && item.soldOracleNumber != undefined;
        const pipe = item.manStageGrp === 'PIPE' && (item.flag == 'UpdateThor' || item.flag == 'Manual') && (item.manNLCategory == 'N-Deal Rev. LP (NL Cat. B) 10%' || item.manNLCategory == 'N-Extensions LP (NL Cat. A) 30%') && item.pStatus != 'Verbal Received' && (item.bus == 'E-BUS(NetNew)' || item.bus == 'N-BUS(NewLogo)');

        const wtbkg = (Number(item.manTCVoracle) * Number(item.manProb)) / 100;

        const amount = Number(item.manTCVoracle);

        const soldNumber = item.soldOracleNumber != undefined ? Number(item.soldOracleNumber) : Number(item.manTCVoracle);

        const pipeNumber = Number(item.manTCVoracle);

        if (isSold) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Won (Booked till date)'][q] += amount;
              if (isEbus) payload['Recurring'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipeN) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['UnWt. Upside'][q] += amount;
              if (isEbus) payload['Recurring2'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business2'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipeY) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['NL Category A'][q] += amount;
              if (isEbus) payload['Recurring3'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business3'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipe) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Wt. Upside'][q] += wtbkg;
              if (isEbus) payload['Recurring4'][q + 'Ebus'] += wtbkg;
              if (isNbus) payload['New Business4'][q + 'Nbus'] += wtbkg;
            }
          }
        }

        if (isSold || isSoldNumber) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Sold Oracle Number'][q] += soldNumber;
              if (isEbus) payload['Recurring5'][q + 'Ebus'] += soldNumber;
              if (isNbus) payload['New Business5'][q + 'Nbus'] += soldNumber;
            }
          }
        }
        if (pipe) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Pipe Number'][q] += pipeNumber;
              // if (isEbus) payload['Recurring5'][q + 'Ebus'] += soldNumber;
              // if (isNbus) payload['New Business5'][q + 'Nbus'] += soldNumber;
            }
          }
        }


      }
      console.log(">>", payload);
    }


    const data = [];
    var payload01 = {};
    var payload02 = {};

    var a1 = 0, a2 = 0, a3 = 0, a4 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0;
    for (var i = 0; i < revenueBO.length; i++) {
      if (inputPillar == '') {
        inputPillar = 'All';
      }

      if (revenueBO[i].summary == 'Budget' && revenueBO[i].pillar == inputPillar) {
        a1 = (revenueBO[i].jan + revenueBO[i].feb + revenueBO[i].mar) / 1000000;
        a2 = (revenueBO[i].apr + revenueBO[i].may + revenueBO[i].jun) / 1000000;
        a3 = (revenueBO[i].jul + revenueBO[i].aug + revenueBO[i].sep) / 1000000;
        a4 = (revenueBO[i].oct + revenueBO[i].nov + revenueBO[i].dec1) / 1000000;
      }
      else if (revenueBO[i].summary == 'Forecast' && revenueBO[i].pillar == inputPillar) {

        b1 = (revenueBO[i].jan + revenueBO[i].feb + revenueBO[i].mar) / 1000000;
        b2 = (revenueBO[i].apr + revenueBO[i].may + revenueBO[i].jun) / 1000000;
        b3 = (revenueBO[i].jul + revenueBO[i].aug + revenueBO[i].sep) / 1000000;
        b4 = (revenueBO[i].oct + revenueBO[i].nov + revenueBO[i].dec1) / 1000000;
      }
    }

    payload02['Summary'] = 'Budget';
    payload02['Q1'] = a1;
    payload02['Q2'] = a2;
    payload02['H1'] = Number(payload02['Q1']) + Number(payload02['Q2']);
    payload02['Q3'] = a3;
    payload02['Q4'] = a4;
    payload02['H2'] = Number(payload02['Q3']) + Number(payload02['Q4']);
    payload02['FY'] = Number(payload02['H1']) + Number(payload02['H2']);
    data.push(payload02);

    payload01['Summary'] = 'Forecast';
    payload01['Q1'] = b1;
    payload01['Q2'] = b2;
    payload01['H1'] = Number(payload01['Q1']) + Number(payload01['Q2']);
    payload01['Q3'] = b3;
    payload01['Q4'] = b4;
    payload01['H2'] = Number(payload01['Q3']) + Number(payload01['Q4']);
    payload01['FY'] = Number(payload01['H1']) + Number(payload01['H2']);
    data.push(payload01);

    var load = {};
    load['Summary'] = 'Sold';
    load['Q1'] = (payload['Sold Oracle Number'].Q1) / 1000000;
    load['Q2'] = (payload['Sold Oracle Number'].Q2) / 1000000;
    load['H1'] = Number(load['Q1']) + Number(load['Q2']);
    load['Q3'] = (payload['Sold Oracle Number'].Q3) / 1000000;
    load['Q4'] = (payload['Sold Oracle Number'].Q4) / 1000000;
    load['H2'] = Number(load['Q3']) + Number(load['Q4']);
    load['FY'] = Number(load['H1']) + Number(load['H2']);
    data.push(load);

    var load1 = {};
    load1['Summary'] = 'New Business';
    load1['Q1'] = (payload['New Business5'].Q1Nbus) / 1000000;
    load1['Q2'] = (payload['New Business5'].Q2Nbus) / 1000000;
    load1['H1'] = Number(load1['Q1']) + Number(load1['Q2']);
    load1['Q3'] = (payload['New Business5'].Q3Nbus) / 1000000;
    load1['Q4'] = (payload['New Business5'].Q4Nbus) / 1000000;
    load1['H2'] = Number(load1['Q3']) + Number(load1['Q4']);
    load1['FY'] = Number(load1['H1']) + Number(load1['H2']);
    data.push(load1);

    var load2 = {};
    load2['Summary'] = 'Recurring';
    load2['Q1'] = (payload['Recurring5'].Q1Ebus) / 1000000;
    load2['Q2'] = (payload['Recurring5'].Q2Ebus) / 1000000;
    load2['H1'] = Number(load2['Q1']) + Number(load2['Q2']);
    load2['Q3'] = (payload['Recurring5'].Q3Ebus) / 1000000;
    load2['Q4'] = (payload['Recurring5'].Q4Ebus) / 1000000;
    load2['H2'] = Number(load2['Q3']) + Number(load2['Q4']);
    load2['FY'] = Number(load2['H1']) + Number(load2['H2']);
    data.push(load2);

    var payload2 = {};
    payload2['Summary'] = 'Booked';
    payload2['Q1'] = (payload['Won (Booked till date)'].Q1) / 1000000;
    payload2['Q2'] = (payload['Won (Booked till date)'].Q2) / 1000000;
    payload2['H1'] = Number(payload2['Q1']) + Number(payload2['Q2']);
    payload2['Q3'] = (payload['Won (Booked till date)'].Q3) / 1000000;
    payload2['Q4'] = (payload['Won (Booked till date)'].Q4) / 1000000;
    payload2['H2'] = Number(payload2['Q3']) + Number(payload2['Q4']);
    payload2['FY'] = Number(payload2['H1']) + Number(payload2['H2']);
    data.push(payload2);
    var payload3 = {};
    payload3['Summary'] = 'New Business';
    payload3['Q1'] = (payload['New Business'].Q1Nbus) / 1000000;
    payload3['Q2'] = (payload['New Business'].Q2Nbus) / 1000000;
    payload3['H1'] = Number(payload3['Q1']) + Number(payload3['Q2']);
    payload3['Q3'] = (payload['New Business'].Q3Nbus) / 1000000;
    payload3['Q4'] = (payload['New Business'].Q4Nbus) / 1000000;
    payload3['H2'] = Number(payload3['Q3']) + Number(payload3['Q4']);
    payload3['FY'] = Number(payload3['H1']) + Number(payload3['H2']);
    data.push(payload3);
    var payload4 = {};
    payload4['Summary'] = 'Recurring';
    payload4['Q1'] = (payload['Recurring'].Q1Ebus) / 1000000;
    payload4['Q2'] = (payload['Recurring'].Q2Ebus) / 1000000;
    payload4['H1'] = Number(payload4['Q1']) + Number(payload4['Q2']);
    payload4['Q3'] = (payload['Recurring'].Q3Ebus) / 1000000;
    payload4['Q4'] = (payload['Recurring'].Q4Ebus) / 1000000;
    payload4['H2'] = Number(payload4['Q3']) + Number(payload4['Q4']);
    payload4['FY'] = Number(payload4['H1']) + Number(payload4['H2']);
    data.push(payload4);

    var payload5 = {};
    payload5['Summary'] = 'Name Likely Category A';
    payload5['Q1'] = (payload['NL Category A'].Q1) / 1000000;
    payload5['Q2'] = (payload['NL Category A'].Q2) / 1000000;
    payload5['H1'] = Number(payload5['Q1']) + Number(payload5['Q2']);
    payload5['Q3'] = (payload['NL Category A'].Q3) / 1000000;
    payload5['Q4'] = (payload['NL Category A'].Q4) / 1000000;
    payload5['H2'] = Number(payload5['Q3']) + Number(payload5['Q4']);
    payload5['FY'] = Number(payload5['H1']) + Number(payload5['H2']);
    data.push(payload5);

    var payload0 = {};
    payload0['Summary'] = 'New Business';
    payload0['Q1'] = (payload['New Business3'].Q1Nbus) / 1000000;
    payload0['Q2'] = (payload['New Business3'].Q2Nbus) / 1000000;
    payload0['H1'] = Number(payload0['Q1']) + Number(payload0['Q2']);
    payload0['Q3'] = (payload['New Business3'].Q3Nbus) / 1000000;
    payload0['Q4'] = (payload['New Business3'].Q4Nbus) / 1000000;
    payload0['H2'] = Number(payload0['Q3']) + Number(payload0['Q4']);
    payload0['FY'] = Number(payload0['H1']) + Number(payload0['H2']);
    data.push(payload0);

    var payload55 = {};
    payload55['Summary'] = 'Recurring';
    payload55['Q1'] = (payload['Recurring3'].Q1Ebus) / 1000000;
    payload55['Q2'] = (payload['Recurring3'].Q2Ebus) / 1000000;
    payload55['H1'] = Number(payload55['Q1']) + Number(payload55['Q2']);
    payload55['Q3'] = (payload['Recurring3'].Q3Ebus) / 1000000;
    payload55['Q4'] = (payload['Recurring3'].Q4Ebus) / 1000000;
    payload55['H2'] = Number(payload55['Q3']) + Number(payload55['Q4']);
    payload55['FY'] = Number(payload55['H1']) + Number(payload55['H2']);
    data.push(payload55);

    var payload20 = {};
    payload20['Summary'] = 'Name Likely Category B';
    payload20['Q1'] = (payload['UnWt. Upside'].Q1) / 1000000;
    payload20['Q2'] = (payload['UnWt. Upside'].Q2) / 1000000;
    payload20['H1'] = Number(payload20['Q1']) + Number(payload20['Q2']);
    payload20['Q3'] = (payload['UnWt. Upside'].Q3) / 1000000;
    payload20['Q4'] = (payload['UnWt. Upside'].Q4) / 1000000;
    payload20['H2'] = Number(payload20['Q3']) + Number(payload20['Q4']);
    payload20['FY'] = Number(payload20['H1']) + Number(payload20['H2']);
    data.push(payload20);

    var payloadGap3 = {};
    payloadGap3['Summary'] = 'Total';
    payloadGap3['Q1'] = payload20['Q1'] + payload5['Q1'] + payload2['Q1'];
    payloadGap3['Q2'] = payload20['Q2'] + payload5['Q2'] + payload2['Q2'];
    payloadGap3['H1'] = payload20['H1'] + payload5['H1'] + payload2['H1'];
    payloadGap3['Q3'] = payload20['Q3'] + payload5['Q3'] + payload2['Q3'];
    payloadGap3['Q4'] = payload20['Q4'] + payload5['Q4'] + payload2['Q4'];
    payloadGap3['H2'] = payload20['H2'] + payload5['H2'] + payload2['H2'];
    payloadGap3['FY'] = payload20['FY'] + payload5['FY'] + payload2['FY'];
    data.push(payloadGap3);

    var payloadGap2 = {};
    payloadGap2['Summary'] = 'Attainment to Forecast';
    payloadGap2['Q1'] = ((payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload01['Q1']) === Infinity || isNaN((payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload01['Q1']) ? 0 : (payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload01['Q1'];
    payloadGap2['Q2'] = ((payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload01['Q2']) === Infinity || isNaN((payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload01['Q2']) ? 0 : (payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload01['Q2'];
    payloadGap2['H1'] = ((payload2['H1'] + payload5['H1'] + payload20['H1']) / payload01['H1']) === Infinity || isNaN((payload2['H1'] + payload5['H1'] + payload20['H1']) / payload01['H1']) ? 0 : (payload2['H1'] + payload5['H1'] + payload20['H1']) / payload01['H1'];
    payloadGap2['Q3'] = ((payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload01['Q3']) === Infinity || isNaN((payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload01['Q3']) ? 0 : (payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload01['Q3'];
    payloadGap2['Q4'] = ((payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload01['Q4']) === Infinity || isNaN((payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload01['Q4']) ? 0 : (payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload01['Q4'];
    payloadGap2['H2'] = ((payload2['H2'] + payload5['H2'] + payload20['H2']) / payload01['H2']) === Infinity || isNaN((payload2['H2'] + payload5['H2'] + payload20['H2']) / payload01['H2']) ? 0 : (payload2['H2'] + payload5['H2'] + payload20['H2']) / payload01['H2'];
    payloadGap2['FY'] = ((payload2['FY'] + payload5['FY'] + payload20['FY']) / payload01['FY']) === Infinity || isNaN((payload2['FY'] + payload5['FY'] + payload20['FY']) / payload01['FY']) ? 0 : (payload2['FY'] + payload5['FY'] + payload20['FY']) / payload01['FY'];
    data.push(payloadGap2);


    var payloadGap3 = {};
    payloadGap3['Summary'] = 'Attainment to Budget';
    payloadGap3['Q1'] = ((payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload02['Q1']) === Infinity || isNaN((payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload02['Q1']) ? 0 : (payload2['Q1'] + payload5['Q1'] + payload20['Q1']) / payload02['Q1'];
    payloadGap3['Q2'] = ((payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload02['Q2']) === Infinity || isNaN((payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload02['Q2']) ? 0 : (payload2['Q2'] + payload5['Q2'] + payload20['Q2']) / payload02['Q2'];
    payloadGap3['H1'] = ((payload2['H1'] + payload5['H1'] + payload20['H1']) / payload02['H1']) === Infinity || isNaN((payload2['H1'] + payload5['H1'] + payload20['H1']) / payload02['H1']) ? 0 : (payload2['H1'] + payload5['H1'] + payload20['H1']) / payload02['H1'];
    payloadGap3['Q3'] = ((payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload02['Q3']) === Infinity || isNaN((payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload02['Q3']) ? 0 : (payload2['Q3'] + payload5['Q3'] + payload20['Q3']) / payload02['Q3'];
    payloadGap3['Q4'] = ((payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload02['Q4']) === Infinity || isNaN((payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload02['Q4']) ? 0 : (payload2['Q4'] + payload5['Q4'] + payload20['Q4']) / payload02['Q4'];
    payloadGap3['H2'] = ((payload2['H2'] + payload5['H2'] + payload20['H2']) / payload02['H2']) === Infinity || isNaN((payload2['H2'] + payload5['H2'] + payload20['H2']) / payload02['H2']) ? 0 : (payload2['H2'] + payload5['H2'] + payload20['H2']) / payload02['H2'];
    payloadGap3['FY'] = ((payload2['FY'] + payload5['FY'] + payload20['FY']) / payload02['FY']) === Infinity || isNaN((payload2['FY'] + payload5['FY'] + payload20['FY']) / payload02['FY']) ? 0 : (payload2['FY'] + payload5['FY'] + payload20['FY']) / payload02['FY'];
    data.push(payloadGap3);

    var payloadGap1 = {};
    payloadGap1['Summary'] = 'Pipe';
    payloadGap1['Q1'] = payload['Pipe Number'].Q1 / 1000000;
    payloadGap1['Q2'] = payload['Pipe Number'].Q2 / 1000000;
    payloadGap1['H1'] = Number(payloadGap1['Q1']) + Number(payloadGap1['Q2']);
    payloadGap1['Q3'] = payload['Pipe Number'].Q3 / 1000000;
    payloadGap1['Q4'] = payload['Pipe Number'].Q4 / 1000000;
    payloadGap1['H2'] = Number(payloadGap1['Q3']) + Number(payloadGap1['Q4']);
    payloadGap1['FY'] = Number(payloadGap1['H1']) + Number(payloadGap1['H2']);
    data.push(payloadGap1);

    console.log("22#", data);
    return data;

  };
  PageModule.prototype.getData = function (pursuit, revenueBO, inputPillar, inputSummary, InputYear) {
    const quarters = {
      Q1: ['Jan', 'Feb', 'Mar'],
      Q2: ['Apr', 'May', 'Jun'],
      Q3: ['Jul', 'Aug', 'Sep'],
      Q4: ['Oct', 'Nov', 'Dec']
    };

    const payload = {
      'Won (Booked till date)': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'Forecast / Named Likely': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business2': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring2': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'UnWt. Upside': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business3': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring3': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },
      'Wt. Upside': {
        Q1: 0,
        Q2: 0,
        Q3: 0,
        Q4: 0
      },
      'New Business4': {
        Q1Nbus: 0,
        Q2Nbus: 0,
        Q3Nbus: 0,
        Q4Nbus: 0
      },
      'Recurring4': {
        Q1Ebus: 0,
        Q2Ebus: 0,
        Q3Ebus: 0,
        Q4Ebus: 0
      },

    };

    for (const item of pursuit) {
      const dateToCheck = new Date(item.manClosemonth);
      const year = dateToCheck.getFullYear();
      if (year === parseInt(InputYear)) {
        const month = dateToCheck.toLocaleString('default', { month: 'short' });
        const isEbus = item.bus === 'E-BUS(renewals)';
        const isNbus = item.bus === 'N-BUS(NewLogo)' || item.bus === 'E-BUS(NetNew)';
        const isSold = item.manStageGrp === 'SOLD';
        const ispipeN = item.manStageGrp === 'PIPE' && (item.flag == 'UpdateThor' || item.flag == 'Manual') && (item.manNLCategory == 'N-Deal Rev. LP (NL Cat. B) 10%' || item.manNLCategory == 'N-Extensions LP (NL Cat. A) 30%')
        const ispipeY = item.manStageGrp === 'PIPE' && (item.flag == 'UpdateThor' || item.flag == 'Manual') && (item.manNLCategory == 'Y-Extensions HP (NL Cat. A) 99%' || item.manNLCategory == 'Y-Extensions MP (NL Cat. A) 80%' || item.manNLCategory == 'Y-Deal Rev. HP (NL Cat. B) 90%' || item.manNLCategory == 'Y-Deal Rev. MP (NL Cat. B) 60%' || item.manNLCategory == 'Y-Firm')
        const ispipe = item.manStageGrp === 'PIPE';

        const wtbkg = (Number(item.manTCVoracle) * Number(item.manProb)) / 100;

        const amount = Number(item.manTCVoracle);

        if (isSold) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Won (Booked till date)'][q] += amount;
              if (isEbus) payload['Recurring'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipeN) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['UnWt. Upside'][q] += amount;
              if (isEbus) payload['Recurring3'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business3'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipeY) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Forecast / Named Likely'][q] += amount;
              if (isEbus) payload['Recurring2'][q + 'Ebus'] += amount;
              if (isNbus) payload['New Business2'][q + 'Nbus'] += amount;
            }
          }
        }
        if (ispipeN) {
          for (const [q, months] of Object.entries(quarters)) {
            if (months.includes(month)) {
              payload['Wt. Upside'][q] += wtbkg;
              if (isEbus) payload['Recurring4'][q + 'Ebus'] += wtbkg;
              if (isNbus) payload['New Business4'][q + 'Nbus'] += wtbkg;
            }
          }
        }


      }
      console.log(">>", payload);

    }

    const data = [];
    var payload01 = {};
    var payload02 = {};
    for (var i = 0; i < revenueBO.length; i++) {
      if (inputPillar == '') {
        inputPillar = 'All';
      }
      if (revenueBO[i].summary == 'Ambition Assignment' && revenueBO[i].pillar == inputPillar) {
        payload01['Summary'] = 'Ambition Assignment';
        payload01['Q1'] = (revenueBO[i].jan + revenueBO[i].feb + revenueBO[i].mar) / 1000000;
        payload01['Q2'] = (revenueBO[i].apr + revenueBO[i].may + revenueBO[i].jun) / 1000000;
        payload01['H1'] = Number(payload01['Q1']) + Number(payload01['Q2']);
        payload01['Q3'] = (revenueBO[i].jul + revenueBO[i].aug + revenueBO[i].sep) / 1000000;
        payload01['Q4'] = (revenueBO[i].oct + revenueBO[i].nov + revenueBO[i].dec1) / 1000000;
        payload01['H2'] = Number(payload01['Q3']) + Number(payload01['Q4']);
        payload01['FY'] = Number(payload01['H1']) + Number(payload01['H2']);
        data.push(payload01);
      }
      else if (revenueBO[i].summary == 'Forecast' && revenueBO[i].pillar == inputPillar) {

        payload02['Summary'] = 'Forecast';
        payload02['Q1'] = (revenueBO[i].jan + revenueBO[i].feb + revenueBO[i].mar) / 1000000;
        payload02['Q2'] = (revenueBO[i].apr + revenueBO[i].may + revenueBO[i].jun) / 1000000;
        payload02['H1'] = Number(payload02['Q1']) + Number(payload02['Q2']);
        payload02['Q3'] = (revenueBO[i].jul + revenueBO[i].aug + revenueBO[i].sep) / 1000000;
        payload02['Q4'] = (revenueBO[i].oct + revenueBO[i].nov + revenueBO[i].dec1) / 1000000;
        payload02['H2'] = Number(payload02['Q3']) + Number(payload02['Q4']);
        payload02['FY'] = Number(payload02['H1']) + Number(payload02['H2']);
        data.push(payload02);
      }
    }
    var payload2 = {};
    payload2['Summary'] = 'Won (Booked till date)';
    payload2['Q1'] = (payload['Won (Booked till date)'].Q1) / 1000000;
    payload2['Q2'] = (payload['Won (Booked till date)'].Q2) / 1000000;
    payload2['H1'] = Number(payload2['Q1']) + Number(payload2['Q2']);
    payload2['Q3'] = (payload['Won (Booked till date)'].Q3) / 1000000;
    payload2['Q4'] = (payload['Won (Booked till date)'].Q4) / 1000000;
    payload2['H2'] = Number(payload2['Q3']) + Number(payload2['Q4']);
    payload2['FY'] = Number(payload2['H1']) + Number(payload2['H2']);
    data.push(payload2);
    var payload3 = {};
    payload3['Summary'] = 'New Business';
    payload3['Q1'] = (payload['New Business'].Q1Nbus) / 1000000;
    payload3['Q2'] = (payload['New Business'].Q2Nbus) / 1000000;
    payload3['H1'] = Number(payload3['Q1']) + Number(payload3['Q2']);
    payload3['Q3'] = (payload['New Business'].Q3Nbus) / 1000000;
    payload3['Q4'] = (payload['New Business'].Q4Nbus) / 1000000;
    payload3['H2'] = Number(payload3['Q3']) + Number(payload3['Q4']);
    payload3['FY'] = Number(payload3['H1']) + Number(payload3['H2']);
    data.push(payload3);
    var payload4 = {};
    payload4['Summary'] = 'Recurring';
    payload4['Q1'] = (payload['Recurring'].Q1Ebus) / 1000000;
    payload4['Q2'] = (payload['Recurring'].Q2Ebus) / 1000000;
    payload4['H1'] = Number(payload4['Q1']) + Number(payload4['Q2']);
    payload4['Q3'] = (payload['Recurring'].Q3Ebus) / 1000000;
    payload4['Q4'] = (payload['Recurring'].Q4Ebus) / 1000000;
    payload4['H2'] = Number(payload4['Q3']) + Number(payload4['Q4']);
    payload4['FY'] = Number(payload4['H1']) + Number(payload4['H2']);
    data.push(payload4);
    var payload5 = {};
    payload5['Summary'] = 'Forecast / Named Likely';
    payload5['Q1'] = (payload['Forecast / Named Likely'].Q1) / 1000000;
    payload5['Q2'] = (payload['Forecast / Named Likely'].Q2) / 1000000;
    payload5['H1'] = Number(payload5['Q1']) + Number(payload5['Q2']);
    payload5['Q3'] = (payload['Forecast / Named Likely'].Q3) / 1000000;
    payload5['Q4'] = (payload['Forecast / Named Likely'].Q4) / 1000000;
    payload5['H2'] = Number(payload5['Q3']) + Number(payload5['Q4']);
    payload5['FY'] = Number(payload5['H1']) + Number(payload5['H2']);
    data.push(payload5);

    var payload6 = {};
    payload6['Summary'] = 'New Business';
    payload6['Q1'] = (payload['New Business2'].Q1Nbus) / 1000000;
    payload6['Q2'] = (payload['New Business2'].Q2Nbus) / 1000000;
    payload6['H1'] = Number(payload6['Q1']) + Number(payload6['Q2']);
    payload6['Q3'] = (payload['New Business2'].Q3Nbus) / 1000000;
    payload6['Q4'] = (payload['New Business2'].Q4Nbus) / 1000000;
    payload6['H2'] = Number(payload6['Q3']) + Number(payload6['Q4']);
    payload6['FY'] = Number(payload6['H1']) + Number(payload6['H2']);

    data.push(payload6);
    var payload7 = {};
    payload7['Summary'] = 'Recurring';
    payload7['Q1'] = (payload['Recurring2'].Q1Ebus) / 1000000;
    payload7['Q2'] = (payload['Recurring2'].Q2Ebus) / 1000000;
    payload7['H1'] = Number(payload7['Q1']) + Number(payload7['Q2']);
    payload7['Q3'] = (payload['Recurring2'].Q3Ebus) / 1000000;
    payload7['Q4'] = (payload['Recurring2'].Q4Ebus) / 1000000;
    payload7['H2'] = Number(payload7['Q3']) + Number(payload7['Q4']);
    payload7['FY'] = Number(payload7['H1']) + Number(payload7['H2']);
    data.push(payload7);

    var payload11 = {};
    payload11['Summary'] = 'Total (Won+Forecast)';
    payload11['Q1'] = Number(payload2['Q1']) + Number(payload5['Q1']);
    payload11['Q2'] = Number(payload2['Q2']) + Number(payload5['Q2']);
    payload11['H1'] = Number(payload11['Q1']) + Number(payload11['Q2']);
    payload11['Q3'] = Number(payload2['Q3']) + Number(payload5['Q3']);
    payload11['Q4'] = Number(payload2['Q4']) + Number(payload5['Q4']);
    payload11['H2'] = Number(payload11['Q3']) + Number(payload11['Q4']);
    payload11['FY'] = Number(payload11['H1']) + Number(payload11['H2']);
    data.push(payload11);

    var payload12 = {};
    if (inputSummary == "Ambition Assignment") {
      payload12['Summary'] = 'Attainment against Ambition';
      payload12['Q1'] = (Number(payload11['Q1']) / Number(payload01['Q1'])) === Infinity ? 0 : Number(payload11['Q1']) / Number(payload01['Q1']);
      payload12['Q2'] = (Number(payload11['Q2']) / Number(payload01['Q2'])) === Infinity ? 0 : Number(payload11['Q2']) / Number(payload01['Q2']);
      payload12['H1'] = (Number(payload11['H1']) / Number(payload01['H1'])) === Infinity ? 0 : Number(payload11['H1']) / Number(payload01['H1']);
      payload12['Q3'] = (Number(payload11['Q3']) / Number(payload01['Q3'])) === Infinity ? 0 : Number(payload11['Q3']) / Number(payload01['Q3']);
      payload12['Q4'] = (Number(payload11['Q4']) / Number(payload01['Q4'])) === Infinity ? 0 : Number(payload11['Q4']) / Number(payload01['Q4']);
      payload12['H2'] = (Number(payload11['H2']) / Number(payload01['H2'])) === Infinity ? 0 : Number(payload11['H2']) / Number(payload01['H2']);
      payload12['FY'] = (Number(payload11['FY']) / Number(payload01['FY'])) === Infinity ? 0 : Number(payload11['FY']) / Number(payload01['FY']);
      data.push(payload12);
    }
    else if (inputSummary == "Forecast") {
      payload12['Summary'] = 'Attainment against Forecast';
      payload12['Q1'] = (Number(payload11['Q1']) / Number(payload02['Q1'])) === Infinity ? 0 : Number(payload11['Q1']) / Number(payload02['Q1']);
      payload12['Q2'] = (Number(payload11['Q2']) / Number(payload02['Q2'])) === Infinity ? 0 : Number(payload11['Q2']) / Number(payload02['Q2']);
      payload12['H1'] = (Number(payload11['H1']) / Number(payload02['H1'])) === Infinity ? 0 : Number(payload11['H1']) / Number(payload02['H1']);
      payload12['Q3'] = (Number(payload11['Q3']) / Number(payload02['Q3'])) === Infinity ? 0 : Number(payload11['Q3']) / Number(payload02['Q3']);
      payload12['Q4'] = (Number(payload11['Q4']) / Number(payload02['Q4'])) === Infinity ? 0 : Number(payload11['Q4']) / Number(payload02['Q4']);
      payload12['H2'] = (Number(payload11['H2']) / Number(payload02['H2'])) === Infinity ? 0 : Number(payload11['H2']) / Number(payload02['H2']);
      payload12['FY'] = (Number(payload11['FY']) / Number(payload02['FY'])) === Infinity ? 0 : Number(payload11['FY']) / Number(payload02['FY']);
      data.push(payload12);
    }

    var payload13 = {};
    if (inputSummary == "Ambition Assignment") {
      payload13['Summary'] = 'Gap to Ambition';
      payload13['Q1'] = Number(payload11['Q1']) - Number(payload01['Q1']);
      payload13['Q2'] = Number(payload11['Q2']) - Number(payload01['Q2']);
      payload13['H1'] = Number(payload11['H1']) - Number(payload01['H1']);
      payload13['Q3'] = Number(payload11['Q3']) - Number(payload01['Q3']);
      payload13['Q4'] = Number(payload11['Q4']) - Number(payload01['Q4']);
      payload13['H2'] = Number(payload11['H2']) - Number(payload01['H2']);
      payload13['FY'] = Number(payload11['FY']) - Number(payload01['FY']);
      data.push(payload13);
    }
    else if (inputSummary == "Forecast") {
      payload13['Summary'] = 'Gap to Forecast';
      payload13['Q1'] = Number(payload11['Q1']) - Number(payload02['Q1']);
      payload13['Q2'] = Number(payload11['Q2']) - Number(payload02['Q2']);
      payload13['H1'] = Number(payload11['H1']) - Number(payload02['H1']);
      payload13['Q3'] = Number(payload11['Q3']) - Number(payload02['Q3']);
      payload13['Q4'] = Number(payload11['Q4']) - Number(payload02['Q4']);
      payload13['H2'] = Number(payload11['H2']) - Number(payload02['H2']);
      payload13['FY'] = Number(payload11['FY']) - Number(payload02['FY']);
      data.push(payload13);
    }
    var payloadGap1 = {};
    payloadGap1['Summary'] = '';
    payloadGap1['Q1'] = '';
    payloadGap1['Q2'] = '';
    payloadGap1['H1'] = '';
    payloadGap1['Q3'] = '';
    payloadGap1['Q4'] = '';
    payloadGap1['H2'] = '';
    payloadGap1['FY'] = '';
    data.push(payloadGap1);



    var payload20 = {};
    payload20['Summary'] = 'Wt. Upside';
    payload20['Q1'] = (payload['Wt. Upside'].Q1) / 1000000;
    payload20['Q2'] = (payload['Wt. Upside'].Q2) / 1000000;
    payload20['H1'] = Number(payload20['Q1']) + Number(payload20['Q2']);
    payload20['Q3'] = (payload['Wt. Upside'].Q3) / 1000000;
    payload20['Q4'] = (payload['Wt. Upside'].Q4) / 1000000;
    payload20['H2'] = Number(payload20['Q3']) + Number(payload20['Q4']);
    payload20['FY'] = Number(payload20['H1']) + Number(payload20['H2']);

    data.push(payload20);
    var payload21 = {};
    payload21['Summary'] = 'New Business';
    payload21['Q1'] = (payload['New Business4'].Q1Nbus) / 1000000;
    payload21['Q2'] = (payload['New Business4'].Q2Nbus) / 1000000;
    payload21['H1'] = Number(payload21['Q1']) + Number(payload21['Q2']);
    payload21['Q3'] = (payload['New Business4'].Q3Nbus) / 1000000;
    payload21['Q4'] = (payload['New Business4'].Q4Nbus) / 1000000;
    payload21['H2'] = Number(payload21['Q3']) + Number(payload21['Q4']);
    payload21['FY'] = Number(payload21['H1']) + Number(payload21['H2']);

    data.push(payload21);
    var payload22 = {};
    payload22['Summary'] = 'Recurring';
    payload22['Q1'] = (payload['Recurring4'].Q1Ebus) / 1000000;
    payload22['Q2'] = (payload['Recurring4'].Q2Ebus) / 1000000;
    payload22['H1'] = Number(payload22['Q1']) + Number(payload22['Q2']);
    payload22['Q3'] = (payload['Recurring4'].Q3Ebus) / 1000000;
    payload22['Q4'] = (payload['Recurring4'].Q4Ebus) / 1000000;
    payload22['H2'] = Number(payload22['Q3']) + Number(payload22['Q4']);
    payload22['FY'] = Number(payload22['H1']) + Number(payload22['H2']);

    data.push(payload22)
    var payload23 = {};
    payload23['Summary'] = 'Projected Landing';
    payload23['Q1'] = payload11['Q1'] + payload20['Q1']
    payload23['Q2'] = payload11['Q2'] + payload20['Q2']
    payload23['H1'] = payload11['H1'] + payload20['H1']
    payload23['Q3'] = payload11['Q3'] + payload20['Q3']
    payload23['Q4'] = payload11['Q4'] + payload20['Q4']
    payload23['H2'] = payload11['H2'] + payload20['H2']
    payload23['FY'] = payload11['FY'] + payload20['FY']

    data.push(payload23);
    var payload24 = {};
    if (inputSummary == "Ambition Assignment") {
      payload24['Summary'] = 'Attainment against Ambition';
      payload24['Q1'] = (Number(payload23['Q1']) / Number(payload01['Q1'])) === Infinity ? 0 : Number(payload23['Q1']) / Number(payload01['Q1']);
      payload24['Q2'] = (Number(payload23['Q2']) / Number(payload01['Q2'])) === Infinity ? 0 : Number(payload23['Q2']) / Number(payload01['Q2']);
      payload24['H1'] = (Number(payload23['H1']) / Number(payload01['H1'])) === Infinity ? 0 : Number(payload23['H1']) / Number(payload01['H1']);
      payload24['Q3'] = (Number(payload23['Q3']) / Number(payload01['Q3'])) === Infinity ? 0 : Number(payload23['Q3']) / Number(payload01['Q3']);
      payload24['Q4'] = (Number(payload23['Q4']) / Number(payload01['Q4'])) === Infinity ? 0 : Number(payload23['Q4']) / Number(payload01['Q4']);
      payload24['H2'] = (Number(payload23['H2']) / Number(payload01['H2'])) === Infinity ? 0 : Number(payload23['H2']) / Number(payload01['H2']);
      payload24['FY'] = (Number(payload23['FY']) / Number(payload01['FY'])) === Infinity ? 0 : Number(payload23['FY']) / Number(payload01['FY']);

      data.push(payload24);
    }
    else if (inputSummary == "Forecast") {
      payload24['Summary'] = 'Attainment against Forecast';
      payload24['Q1'] = (Number(payload23['Q1']) / Number(payload02['Q1'])) === Infinity ? 0 : Number(payload23['Q1']) / Number(payload02['Q1']);
      payload24['Q2'] = (Number(payload23['Q2']) / Number(payload02['Q2'])) === Infinity ? 0 : Number(payload23['Q2']) / Number(payload02['Q2']);
      payload24['H1'] = (Number(payload23['H1']) / Number(payload02['H1'])) === Infinity ? 0 : Number(payload23['H1']) / Number(payload02['H1']);
      payload24['Q3'] = (Number(payload23['Q3']) / Number(payload02['Q3'])) === Infinity ? 0 : Number(payload23['Q3']) / Number(payload02['Q3']);
      payload24['Q4'] = (Number(payload23['Q4']) / Number(payload02['Q4'])) === Infinity ? 0 : Number(payload23['Q4']) / Number(payload02['Q4']);
      payload24['H2'] = (Number(payload23['H2']) / Number(payload02['H2'])) === Infinity ? 0 : Number(payload23['H2']) / Number(payload02['H2']);
      payload24['FY'] = (Number(payload23['FY']) / Number(payload02['FY'])) === Infinity ? 0 : Number(payload23['FY']) / Number(payload02['FY']);

      data.push(payload24);

    }
    var payload25 = {};
    if (inputSummary == "Ambition Assignment") {
      payload25['Summary'] = 'Gap to Ambition';
      payload25['Q1'] = Number(payload23['Q1']) - Number(payload01['Q1']);
      payload25['Q2'] = Number(payload23['Q2']) - Number(payload01['Q2']);
      payload25['H1'] = Number(payload23['H1']) - Number(payload01['H1']);
      payload25['Q3'] = Number(payload23['Q3']) - Number(payload01['Q3']);
      payload25['Q4'] = Number(payload23['Q4']) - Number(payload01['Q4']);
      payload25['H2'] = Number(payload23['H2']) - Number(payload01['H2']);
      payload25['FY'] = Number(payload23['FY']) - Number(payload01['FY']);
      data.push(payload25)
    }
    else if (inputSummary == "Forecast") {
      payload25['Summary'] = 'Gap to Forecast';
      payload25['Q1'] = Number(payload23['Q1']) - Number(payload02['Q1']);
      payload25['Q2'] = Number(payload23['Q2']) - Number(payload02['Q2']);
      payload25['H1'] = Number(payload23['H1']) - Number(payload02['H1']);
      payload25['Q3'] = Number(payload23['Q3']) - Number(payload02['Q3']);
      payload25['Q4'] = Number(payload23['Q4']) - Number(payload02['Q4']);
      payload25['H2'] = Number(payload23['H2']) - Number(payload02['H2']);
      payload25['FY'] = Number(payload23['FY']) - Number(payload02['FY']);
      data.push(payload25)
    }
    var payloadGap2 = {};
    payloadGap2['Summary'] = '';
    payloadGap2['Q1'] = ''
    payloadGap2['Q2'] = ''
    payloadGap2['H1'] = ''
    payloadGap2['Q3'] = ''
    payloadGap2['Q4'] = ''
    payloadGap2['H2'] = ''
    payloadGap2['FY'] = ''
    data.push(payloadGap2);


    var payload8 = {};
    payload8['Summary'] = 'UnWt. Upside';
    payload8['Q1'] = (payload['UnWt. Upside'].Q1) / 1000000;
    payload8['Q2'] = (payload['UnWt. Upside'].Q2) / 1000000;
    payload8['H1'] = Number(payload8['Q1']) + Number(payload8['Q2']);
    payload8['Q3'] = (payload['UnWt. Upside'].Q3) / 1000000;
    payload8['Q4'] = (payload['UnWt. Upside'].Q4) / 1000000;
    payload8['H2'] = Number(payload8['Q3']) + Number(payload8['Q4']);
    payload8['FY'] = Number(payload8['H1']) + Number(payload8['H2']);

    data.push(payload8)
    var payload9 = {};
    payload9['Summary'] = 'New Business';
    payload9['Q1'] = (payload['New Business3'].Q1Nbus) / 1000000;
    payload9['Q2'] = (payload['New Business3'].Q2Nbus) / 1000000;
    payload9['H1'] = Number(payload9['Q1']) + Number(payload9['Q2']);
    payload9['Q3'] = (payload['New Business3'].Q3Nbus) / 1000000;
    payload9['Q4'] = (payload['New Business3'].Q4Nbus) / 1000000;
    payload9['H2'] = Number(payload9['Q3']) + Number(payload9['Q4']);
    payload9['FY'] = Number(payload9['H1']) + Number(payload9['H2']);

    data.push(payload9)
    var payload10 = {};
    payload10['Summary'] = 'Recurring';
    payload10['Q1'] = (payload['Recurring3'].Q1Ebus) / 1000000;
    payload10['Q2'] = (payload['Recurring3'].Q2Ebus) / 1000000;
    payload10['H1'] = Number(payload10['Q1']) + Number(payload10['Q2']);
    payload10['Q3'] = (payload['Recurring3'].Q3Ebus) / 1000000;
    payload10['Q4'] = (payload['Recurring3'].Q4Ebus) / 1000000;
    payload10['H2'] = Number(payload10['Q3']) + Number(payload10['Q4']);
    payload10['FY'] = Number(payload10['H1']) + Number(payload10['H2']);

    data.push(payload10)
    var payload14 = {};
    payload14['Summary'] = 'Projected Landing';
    payload14['Q1'] = payload11['Q1'] + payload8['Q1'];
    payload14['Q2'] = payload11['Q2'] + payload8['Q2'];
    payload14['H1'] = payload11['H1'] + payload8['H1'];
    payload14['Q3'] = payload11['Q3'] + payload8['Q3'];
    payload14['Q4'] = payload11['Q4'] + payload8['Q4'];
    payload14['H2'] = payload11['H2'] + payload8['H2'];
    payload14['FY'] = payload11['FY'] + payload8['FY'];

    data.push(payload14)
    var payload15 = {};
    if (inputSummary == "Ambition Assignment") {
      payload15['Summary'] = 'Attainment against Ambition';
      payload15['Q1'] = (Number(payload14['Q1']) / Number(payload01['Q1'])) === Infinity ? 0 : Number(payload14['Q1']) / Number(payload01['Q1']);
      payload15['Q2'] = (Number(payload14['Q2']) / Number(payload01['Q2'])) === Infinity ? 0 : Number(payload14['Q2']) / Number(payload01['Q2']);
      payload15['H1'] = (Number(payload14['H1']) / Number(payload01['H1'])) === Infinity ? 0 : Number(payload14['H1']) / Number(payload01['H1']);
      payload15['Q3'] = (Number(payload14['Q3']) / Number(payload01['Q3'])) === Infinity ? 0 : Number(payload14['Q3']) / Number(payload01['Q3']);
      payload15['Q4'] = (Number(payload14['Q4']) / Number(payload01['Q4'])) === Infinity ? 0 : Number(payload14['Q4']) / Number(payload01['Q4']);
      payload15['H2'] = (Number(payload14['H2']) / Number(payload01['H2'])) === Infinity ? 0 : Number(payload14['H2']) / Number(payload01['H2']);
      payload15['FY'] = (Number(payload14['FY']) / Number(payload01['FY'])) === Infinity ? 0 : Number(payload14['FY']) / Number(payload01['FY']);

      data.push(payload15);
    }
    else if (inputSummary == "Forecast") {
      payload15['Summary'] = 'Attainment against Forecast';
      payload15['Q1'] = (Number(payload14['Q1']) / Number(payload02['Q1'])) === Infinity ? 0 : Number(payload14['Q1']) / Number(payload02['Q1']);
      payload15['Q2'] = (Number(payload14['Q2']) / Number(payload02['Q2'])) === Infinity ? 0 : Number(payload14['Q2']) / Number(payload02['Q2']);
      payload15['H1'] = (Number(payload14['H1']) / Number(payload02['H1'])) === Infinity ? 0 : Number(payload14['H1']) / Number(payload02['H1']);
      payload15['Q3'] = (Number(payload14['Q3']) / Number(payload02['Q3'])) === Infinity ? 0 : Number(payload14['Q3']) / Number(payload02['Q3']);
      payload15['Q4'] = (Number(payload14['Q4']) / Number(payload02['Q4'])) === Infinity ? 0 : Number(payload14['Q4']) / Number(payload02['Q4']);
      payload15['H2'] = (Number(payload14['H2']) / Number(payload02['H2'])) === Infinity ? 0 : Number(payload14['H2']) / Number(payload02['H2']);
      payload15['FY'] = (Number(payload14['FY']) / Number(payload02['FY'])) === Infinity ? 0 : Number(payload14['FY']) / Number(payload02['FY']);

      data.push(payload15);
    }
    var payload16 = {};
    if (inputSummary == "Ambition Assignment") {
      payload16['Summary'] = 'Gap to Ambition';
      payload16['Q1'] = Number(payload14['Q1']) + Number(payload01['Q1']);
      payload16['Q2'] = Number(payload14['Q2']) + Number(payload01['Q2']);
      payload16['H1'] = Number(payload14['H1']) + Number(payload01['H1']);
      payload16['Q3'] = Number(payload14['Q3']) + Number(payload01['Q3']);
      payload16['Q4'] = Number(payload14['Q4']) + Number(payload01['Q4']);
      payload16['H2'] = Number(payload14['H2']) + Number(payload01['H2']);
      payload16['FY'] = Number(payload14['FY']) + Number(payload01['FY']);
      data.push(payload16);
    }
    else if (inputSummary == "Forecast") {
      payload16['Summary'] = 'Gap to Forecast';
      payload16['Q1'] = Number(payload14['Q1']) + Number(payload02['Q1']);
      payload16['Q2'] = Number(payload14['Q2']) + Number(payload02['Q2']);
      payload16['H1'] = Number(payload14['H1']) + Number(payload02['H1']);
      payload16['Q3'] = Number(payload14['Q3']) + Number(payload02['Q3']);
      payload16['Q4'] = Number(payload14['Q4']) + Number(payload02['Q4']);
      payload16['H2'] = Number(payload14['H2']) + Number(payload02['H2']);
      payload16['FY'] = Number(payload14['FY']) + Number(payload02['FY']);
      data.push(payload16);

    }
    console.log("22#", data);
    return data;

  };
  //  PageModule.prototype.revenue=function(revenueObject,total){
  //  total.totalRevenue=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar)+parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun)+parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep)+parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.Q1=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar);
  //  total.Q2=parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun);
  //  total.Q3=parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep);
  //  total.Q4=parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.H1=total.Q1+total.Q2;
  //  total.H2=total.Q3+total.Q4;

  //  return total;
  // };
  PageModule.prototype.AllrevenueAmbition = function (revenueObject, Bo) {
    for (var i = 0; i < Bo.length; i++) {
      if (Bo[i].summary == 'Ambition Assignment') {
        revenueObject.jan += Bo[i].jan;
        revenueObject.feb += Bo[i].feb;
        revenueObject.mar += Bo[i].mar;
        revenueObject.apr += Bo[i].apr;
        revenueObject.may += Bo[i].may;
        revenueObject.jun += Bo[i].jun;
        revenueObject.jul += Bo[i].jul;
        revenueObject.aug += Bo[i].aug;
        revenueObject.sep += Bo[i].sep;
        revenueObject.oct += Bo[i].oct;
        revenueObject.nov += Bo[i].nov;
        revenueObject.dec1 += Bo[i].dec1;
      }

    }
    console.log("22#", revenueObject);
    return revenueObject;

  };
  PageModule.prototype.revenue = function (revenueObject, total) {
    total.totalRevenue = parseInt(revenueObject.jan) + parseInt(revenueObject.feb) + parseInt(revenueObject.mar) + parseInt(revenueObject.apr) + parseInt(revenueObject.may) + parseInt(revenueObject.jun) + parseInt(revenueObject.jul) + parseInt(revenueObject.aug) + parseInt(revenueObject.sep) + parseInt(revenueObject.oct) + parseInt(revenueObject.nov) + parseInt(revenueObject.dec1);
    total.Q1 = parseInt(revenueObject.jan) + parseInt(revenueObject.feb) + parseInt(revenueObject.mar);
    total.Q2 = parseInt(revenueObject.apr) + parseInt(revenueObject.may) + parseInt(revenueObject.jun);
    total.Q3 = parseInt(revenueObject.jul) + parseInt(revenueObject.aug) + parseInt(revenueObject.sep);
    total.Q4 = parseInt(revenueObject.oct) + parseInt(revenueObject.nov) + parseInt(revenueObject.dec1);
    total.H1 = total.Q1 + total.Q2;
    total.H2 = total.Q3 + total.Q4;

    return total;
  };
  PageModule.prototype.AllrevenueAmbition = function (revenueObject, Bo) {
    for (var i = 0; i < Bo.length; i++) {
      if (Bo[i].summary == 'Ambition Assignment') {
        revenueObject.jan += Bo[i].jan;
        revenueObject.feb += Bo[i].feb;
        revenueObject.mar += Bo[i].mar;
        revenueObject.apr += Bo[i].apr;
        revenueObject.may += Bo[i].may;
        revenueObject.jun += Bo[i].jun;
        revenueObject.jul += Bo[i].jul;
        revenueObject.aug += Bo[i].aug;
        revenueObject.sep += Bo[i].sep;
        revenueObject.oct += Bo[i].oct;
        revenueObject.nov += Bo[i].nov;
        revenueObject.dec1 += Bo[i].dec1;
      }

    }
    console.log("44#", revenueObject);
  };
  PageModule.prototype.AllrevenueBudget = function (revenueObject, Bo) {
    for (var i = 0; i < Bo.length; i++) {
      if (Bo[i].summary == 'Budget') {
        revenueObject.jan += Bo[i].jan;
        revenueObject.feb += Bo[i].feb;
        revenueObject.mar += Bo[i].mar;
        revenueObject.apr += Bo[i].apr;
        revenueObject.may += Bo[i].may;
        revenueObject.jun += Bo[i].jun;
        revenueObject.jul += Bo[i].jul;
        revenueObject.aug += Bo[i].aug;
        revenueObject.sep += Bo[i].sep;
        revenueObject.oct += Bo[i].oct;
        revenueObject.nov += Bo[i].nov;
        revenueObject.dec1 += Bo[i].dec1;
      }

    }
    console.log("44#", revenueObject);
  };




  PageModule.prototype.exportHRTable = function (empHRData, metaDataArray, emp, rev, stg, Doc) {

    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < metaDataArray.length; i++) {
      header.push(metaDataArray[i].headerName);
    }
    multidata.push(header);
    const d = new Date();
    for (let i = 0; i < empHRData.length; i++) {

      var pl = emp.find(ele => ele.id == empHRData[i].manPursuitlead);
      var pg = emp.find(ele => ele.id == empHRData[i].manPursuitgovernance);
      var pDE = emp.find(ele => ele.id == empHRData[i].pDEName);
      var month = rev.filter(ele => ele.sLID == empHRData[i].id);
      var Q1 = 0, Q2 = 0, Q3 = 0, Q4 = 0, H1 = 0, H2 = 0;
      var q1 = 0, q2 = 0, q3 = 0, q4 = 0, h1 = 0, h2 = 0;
      var Q11 = 0, Q22 = 0, Q33 = 0, Q44 = 0;

      var instanceArray = [];
      instanceArray.push(empHRData[i].region);
      instanceArray.push(empHRData[i].manPillar);
      instanceArray.push(empHRData[i].manOptyID);
      instanceArray.push(empHRData[i].manSLId);
      instanceArray.push(empHRData[i].manMu);
      instanceArray.push(empHRData[i].manBu);
      instanceArray.push(empHRData[i].manSubSector);
      instanceArray.push(empHRData[i].manAccount);
      instanceArray.push(empHRData[i].manPursuitname);
      instanceArray.push(pg != undefined ? pg.name : '-');
      // manPursuitgovernanceObject
      // instanceArray.push(empHRData[i].manComments!=undefined?empHRData[i].manComments:'NA');
      // instanceArray.push(empHRData[i].upcomingReviews!=undefined?empHRData[i].upcomingReviews:'NA');
      instanceArray.push(empHRData[i].manClosemonth != undefined ? dateFormat(empHRData[i].manClosemonth) : 'NA');
      instanceArray.push((empHRData[i].manStageGrp == 'SOLD' || empHRData[i].manStageGrp == 'LQD') ? empHRData[i].convertedBkg : empHRData[i].manTCVoracle);
      instanceArray.push(empHRData[i].soldOracleNumber);
      instanceArray.push(empHRData[i].pStatus);

      let doc = Doc.filter(ele1 => ele1.optyID == empHRData[i].id);

      let count = 0;
      let nonCount = 0;
      for (let z = 0; z < doc.length; z++) {
        if (doc[z].uploadedBy != null) {
          count++;
          if (doc[z].notApplicability == 'Not Applicable') {
            nonCount++;
          }

        }
      }
      if (count >= '8' && nonCount < '8') {
        instanceArray.push('Yes');
      }
      else {
        instanceArray.push('No');
      }

      instanceArray.push(pl != undefined ? pl.name : 'NA');
      instanceArray.push(empHRData[i].manProb);
      instanceArray.push(empHRData[i].manStageGrp);
      instanceArray.push(empHRData[i].bus != undefined ? empHRData[i].bus : 'NA');
      instanceArray.push(empHRData[i].cM != undefined ? empHRData[i].cM : 'NA');
      instanceArray.push(empHRData[i].manNLCategory);
      instanceArray.push(empHRData[i].status != undefined ? empHRData[i].status : 'NA');
      instanceArray.push(empHRData[i].bidStatus);
      instanceArray.push(empHRData[i].probability);
      instanceArray.push(empHRData[i].leadBy);
      instanceArray.push(empHRData[i].manStaffing);
      instanceArray.push(empHRData[i].pDE);
      instanceArray.push(pDE != undefined ? pDE.name : '-');
      instanceArray.push(empHRData[i].dealQualified);
      instanceArray.push(empHRData[i].proactivePursuit);
      instanceArray.push(empHRData[i].manComments);
      instanceArray.push(empHRData[i].local);
      instanceArray.push(empHRData[i].india);
      instanceArray.push(empHRData[i].gx);
      instanceArray.push(empHRData[i].subconLocal);
      instanceArray.push(empHRData[i].subconIndia);
      //  if (month.length != 0) {

      // var data23= month.find(ele=>ele.year=='2023')

      // if (data23) {
      //  instanceArray.push(data23.revenueCategory);
      //   instanceArray.push(data23.jan);
      //   instanceArray.push(data23.feb);
      //   instanceArray.push(data23.mar);
      //   instanceArray.push(data23.apr);
      //   instanceArray.push(data23.may);
      //   instanceArray.push(data23.jun);
      //   instanceArray.push(data23.jul);
      //   instanceArray.push(data23.aug);
      //   instanceArray.push(data23.sep);
      //   instanceArray.push(data23.oct);
      //   instanceArray.push(data23.nov);
      //   instanceArray.push(data23.dec1);
      //   instanceArray.push(Q1 = Number(data23.jan) + Number(data23.feb) + Number(data23.mar));
      //   instanceArray.push(Q2 = Number(data23.apr) + Number(data23.may) + Number(data23.jun));
      //   instanceArray.push(Q3 = Number(data23.jul) + Number(data23.aug) + Number(data23.sep));
      //   instanceArray.push(Q4 = Number(data23.oct) + Number(data23.nov) + Number(data23.dec1));
      //   instanceArray.push(Q1 + Q2);
      //   instanceArray.push(Q3 + Q4);
      //   instanceArray.push(Q1 + Q2 + Q3 + Q4);
      // } 
      // else{
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('');
      //   instanceArray.push('')
      //   instanceArray.push('')
      //   instanceArray.push('');

      // }

      var data24 = month.find(ele => ele.year == '2024')

      if (data24) {
        instanceArray.push(data24.revenueCategory);
        instanceArray.push(data24.jan);
        instanceArray.push(data24.feb);
        instanceArray.push(data24.mar);
        instanceArray.push(data24.apr);
        instanceArray.push(data24.may);
        instanceArray.push(data24.jun);
        instanceArray.push(data24.jul);
        instanceArray.push(data24.aug);
        instanceArray.push(data24.sep);
        instanceArray.push(data24.oct);
        instanceArray.push(data24.nov);
        instanceArray.push(data24.dec1);
        instanceArray.push(Q1 = Number(data24.jan) + Number(data24.feb) + Number(data24.mar));
        instanceArray.push(Q2 = Number(data24.apr) + Number(data24.may) + Number(data24.jun));
        instanceArray.push(Q3 = Number(data24.jul) + Number(data24.aug) + Number(data24.sep));
        instanceArray.push(Q4 = Number(data24.oct) + Number(data24.nov) + Number(data24.dec1));
        instanceArray.push(Q1 + Q2);
        instanceArray.push(Q3 + Q4);
        instanceArray.push(Q1 + Q2 + Q3 + Q4);
      }
      else {
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');

      }

      var data25 = month.find(ele => ele.year == '2025')
      if (data25) {
        instanceArray.push(data25.revenueCategory);
        instanceArray.push(data25.jan);
        instanceArray.push(data25.feb);
        instanceArray.push(data25.mar);
        instanceArray.push(data25.apr);
        instanceArray.push(data25.may);
        instanceArray.push(data25.jun);
        instanceArray.push(data25.jul);
        instanceArray.push(data25.aug);
        instanceArray.push(data25.sep);
        instanceArray.push(data25.oct);
        instanceArray.push(data25.nov);
        instanceArray.push(data25.dec1);
        instanceArray.push(Q11 = Number(data25.jan) + Number(data25.feb) + Number(data25.mar));
        instanceArray.push(Q22 = Number(data25.apr) + Number(data25.may) + Number(data25.jun));
        instanceArray.push(Q33 = Number(data25.jul) + Number(data25.aug) + Number(data25.sep));
        instanceArray.push(Q44 = Number(data25.oct) + Number(data25.nov) + Number(data25.dec1));
        instanceArray.push(Q11 + Q22);
        instanceArray.push(Q33 + Q44);
        instanceArray.push(Q11 + Q22 + Q33 + Q44);
        // instanceArray.push(Number(data25.jan) + Number(data25.feb) + Number(data25.mar)+ Number(data25.apr) + Number(data25.may) + Number(data25.jun)+ Number(data25.jul) + Number(data25.aug) + Number(data25.sep)+ Number(data25.oct) + Number(data25.nov) + Number(data25.dec1))
      }
      else {
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
        instanceArray.push('');
      }


      multidata.push(instanceArray);
    }

    var wb = XLSX.utils.book_new();
    var filename;
    var blob;

    if (stg) {
      wb.SheetNames.push("Pursuit_" + stg);
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Pursuit_" + stg] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      blob = new Blob([fileBytes], { type: 'octet/stream' });
      filename = "Pursuit_" + stg + "_" + new Date().toISOString().split('T')[0] + ".xlsx";

    }

    else {
      wb.SheetNames.push("Pursuit");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Pursuit"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      blob = new Blob([fileBytes], { type: 'octet/stream' });
      filename = "Pursuit_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }



    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };

  PageModule.prototype.exportPursuitUpdate = function (Update, head) {

    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < head.length; i++) {
      header.push(head[i].headerName);
    }
    multidata.push(header);

    for (let i = 0; i < Update.length; i++) {
      var instanceArray = [];
      instanceArray.push(Update[i].optyIDObject.items[0].manOptyID);
      instanceArray.push(Update[i].optyIDObject.items[0].manSLId);
      instanceArray.push(Update[i].optyIDObject.items[0].manPursuitname);
      instanceArray.push(Update[i].type1);
      instanceArray.push(Update[i].type1 == 'Due Date' ? dateFormat(Update[i].newValue) : Update[i].newValue);
      instanceArray.push(Update[i].type1 == 'Due Date' ? dateFormat(Update[i].oldValue) : Update[i].oldValue);
      instanceArray.push(Update[i].username);
      Update[i].date1 != null ? instanceArray.push(dateFormat(Update[i].date1)) : instanceArray.push(Update[i].date1);
      multidata.push(instanceArray);
    }

    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Pursuit Update");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Pursuit Update"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Pursuit Update_" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }


  PageModule.prototype.eventSearch = function (Event, Employee, Pursuit, YEar) {

    var data = [];
    var data2 = [];

    var arrayobj = Object.values(Event);

    const arrayUniqueByKey = [...new Map(Event.map(item => [item['optyID'], item])).values()];
    var uni = arrayUniqueByKey;

    for (var i = 0; i < Event.length; i++) {
      if (Event[i].date1 != undefined) {



        var ele2 = Pursuit.find(ele2 => ele2.id == Event[i].optyID);
        if (ele2) {
          var pl = Employee.find(ele => ele.id == ele2.manPursuitlead);
          var pg = Employee.find(ele => ele.id == ele2.manPursuitgovernance);
          var retpayload = {};
          //           if(Event[i].date1>=from && Event[i].date1 <= to){


          //      retpayload['eventName']=Event[i].eventName;

          //      retpayload['date1']=Event[i].date1;

          //       retpayload['updatedBy']=Event[i].updatedBy;
          //      retpayload['optyID']=ele2.manOptyID;
          //      retpayload['sLID']=ele2.manSLId;
          //      retpayload['mU']=ele2.manMu;
          //      retpayload['bu']=ele2.manBu;
          //      retpayload['id']=ele2.id;
          //      retpayload['pillar']=ele2.manPillar;
          //      retpayload['account']=ele2.manAccount;
          //      retpayload['pursuitName']=ele2.manPursuitname;
          //      retpayload['comments']=ele2.manComments;
          //      retpayload['dueDate']=ele2.manClosemonth;
          //      retpayload['pursuitLead']=pl!=undefined?pl.name:'';
          //      retpayload['pursuitGovernance']=pg!=undefined?pg.name:'';
          //      retpayload['tvc']=ele2.manTCV;
          //      retpayload['status']=ele2.status;



          //  data.push(retpayload);


          //           }

          if ((new Date((ele2.manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
            retpayload['eventName'] = Event[i].eventName;
            retpayload['date1'] = Event[i].date1;
            retpayload['updatedBy'] = Event[i].updatedBy;
            retpayload['optyID'] = ele2.manOptyID;
            retpayload['sLID'] = ele2.manSLId;
            retpayload['mU'] = ele2.manMu;
            retpayload['bu'] = ele2.manBu;
            retpayload['id'] = ele2.id;
            retpayload['pillar'] = ele2.manPillar;
            retpayload['account'] = ele2.manAccount;
            retpayload['pursuitName'] = ele2.manPursuitname;
            retpayload['comments'] = ele2.manComments;
            retpayload['dueDate'] = ele2.manClosemonth;
            retpayload['pursuitLead'] = pl != undefined ? pl.name : '';
            retpayload['pursuitGovernance'] = pg != undefined ? pg.name : '';
            retpayload['tvc'] = ele2.manTCV;
            retpayload['status'] = ele2.status;

            data.push(retpayload);
          }
        }
      }
    }
    return data;
  }
  PageModule.prototype.statusSearch = function (Status, Pursuit, Emp, YEar) {

    var data = [];





    for (var i = 0; i < Status.length; i++) {

      var monthNo = (new Date(Status[i].lastUpdateDate).getMonth() < 9 ? '0' + (new Date(Status[i].lastUpdateDate).getMonth() + 1) : '' + (new Date(Status[i].lastUpdateDate).getMonth() + 1));
      var year = new Date(Status[i].lastUpdateDate).getFullYear();
      var day = (new Date(Status[i].lastUpdateDate).getDate() <= 9 ? '0' + (new Date(Status[i].lastUpdateDate).getDate()) : '' + (new Date(Status[i].lastUpdateDate).getDate()));
      var lDateValue = (year.toString() + "-" + monthNo.toString() + "-" + day.toString());
      var abc = new Date(Status[i].lastUpdateDate).getDate();
      var ele = Pursuit.find(ele2 => ele2.id == Status[i].optyID);

      if (ele) {
        var emp = Emp.find(emp => emp.id == ele.pursuitLead);
        var pl = Emp.find(ele5 => ele5.id == ele.manPursuitlead);
        var pg = Emp.find(ele5 => ele5.id == ele.manPursuitgovernance);
        var retpayload = {};

        //       if(lDateValue>=from && lDateValue <= to){

        //        retpayload['status']=Status[i].status;
        //        retpayload['comments']=Status[i].comments;
        //        retpayload['lastUpdateDate']=Status[i].lastUpdateDate;
        //        retpayload['lastUpdatedBy']=Status[i].commentedBy;
        //        retpayload['optyID']=ele.manOptyID;
        //       retpayload['sLID']=ele.manSLId;
        //  retpayload['id']=ele.id;
        //  retpayload['mU']=ele.manMu;
        //  retpayload['pillar']=ele.manPillar;
        //  retpayload['account']=ele.manAccount;
        //  retpayload['pursuitLead']=pl!=undefined?pl.name:'';
        //  retpayload['comments2']=ele.manComments;
        //  retpayload['dueDate']=ele.manClosemonth;
        //  retpayload['pursuitName']=ele.manPursuitname;
        //  retpayload['pursuitGovernance']=pg!=undefined?pg.name:'';
        //  retpayload['tvc']=ele.manTCV;
        //  retpayload['status2']=ele.status;
        //        data.push(retpayload);
        //       }

        if ((new Date((ele.manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          retpayload['status'] = Status[i].status;
          retpayload['comments'] = Status[i].comments;
          retpayload['lastUpdateDate'] = new Date(Status[i].lastUpdateDate);
          retpayload['lastUpdatedBy'] = Status[i].commentedBy;
          retpayload['optyID'] = ele.manOptyID;
          retpayload['mU'] = ele.manMu;
          retpayload['sLID'] = ele.manSLId;
          //  retpayload['manSLId']=ele.manSLId;
          retpayload['pillar'] = ele.manPillar;
          retpayload['account'] = ele.manAccount;
          retpayload['pursuitLead'] = pl != undefined ? pl.name : '';
          retpayload['comments2'] = ele.manComments;
          retpayload['dueDate'] = ele.manClosemonth;
          retpayload['pursuitName'] = ele.manPursuitname;
          retpayload['id'] = ele.id;

          retpayload['pursuitGovernance'] = pg != undefined ? pg.name : '';
          retpayload['tvc'] = ele.manTCV;
          retpayload['status2'] = ele.status;
          data.push(retpayload);
        }
      }

    }
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.pursuitLeadADPFunction = function (purEmp, emp, excelpayload) {
    // var data = new Array();
    for (var i = 0; i < purEmp.length; i++) {
      var retpayload = {};
      var ele = emp.find(ele => ele.id == purEmp[i].employeeName)
      if (purEmp[i].type1 == "Pursuit Lead") {
        if (ele != undefined) {
          retpayload['name'] = ele.name;
          excelpayload.purLead.push(retpayload);

        }
        else if (ele == undefined) {
          retpayload['name'] = purEmp[i].nonOracle;
          excelpayload.purLead.push(retpayload);
        }
      }
      else if (purEmp[i].type1 == "Pursuit Governance") {
        if (ele != undefined) {
          retpayload['name'] = ele.name;
          excelpayload.gov.push(retpayload);

        }
        else if (ele == undefined) {
          retpayload['name'] = purEmp[i].nonOracle;
          excelpayload.gov.push(retpayload);
        }

      }
      else if (purEmp[i].type1 == "Reviwer Name") {
        if (ele != undefined) {
          retpayload['name'] = ele.name;
          excelpayload.review.push(retpayload);

        }
        else if (ele == undefined) {
          retpayload['name'] = purEmp[i].nonOracle;
          excelpayload.review.push(retpayload);
        }

      }
    }
    return excelpayload;
  }
  PageModule.prototype.uni = function (data) {
    var arrayobj = Object.values(data);

    const arrayUniqueByKey = [...new Map(data.map(item => [item['optyID'], item])).values()];
    var uni = arrayUniqueByKey;
    return uni;

  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */


  //Role Access
  PageModule.prototype.returnVisibillity = function (roleAccessArray, screen, type) {

    var data = roleAccessArray.find(element => element.functionality == screen)

    if (data.accessType == type) {

      return false;

    }

    else {

      return true;

    }



  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.teamLeadADP = function (emp, role, data) {

    for (var i = 0; i < role.length; i++) {
      if (role[i].roleId == 2) {
        var abc = emp.find(ele => ele.id == role[i].employeeId)
        var retpayload = {};
        retpayload['name'] = abc.name;

        data.lead.push(retpayload);
      }
      else if (role[i].roleId == 55) {
        var abc = emp.find(ele => ele.id == role[i].employeeId)
        var retpayload = {};
        retpayload['name'] = abc.name;

        data.gov.push(retpayload);
      }
    }
    console.log(">>", data)
    return data;


  }
  PageModule.prototype.date = function () {
    let today = new Date().toISOString().slice(0, 10)
    return today;

  };
  PageModule.prototype.getAccountName = function (cli) {

    var data = new Array();
    var data1 = new Array(), data2 = new Array();
    var ret = {};
    ret['clientName'] = 'Other';
    ret['id'] = 'Other';

    data1.push(ret);
    for (var i = 0; i < cli.length; i++) {
      if (cli[i].clientName !== '-' && cli[i].clientName !== '0' && cli[i].clientName !== '1' && cli[i].clientName !== '10063238') {
        var retpayload = {};
        retpayload['clientName'] = cli[i].clientName;
        retpayload['id'] = cli[i].id;


        data2.push(retpayload);
      }
    }
    // data2.sort();
    data2.sort(function (a, b) {
      var nameA = a.clientName.toUpperCase(); // ignore upper and lowercase
      var nameB = b.clientName.toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    });

    data = data1.concat(data2)
    return data;

  }


  PageModule.prototype.salestoDeliveryComp = function (pursuit, approval) {


    var tableData = [];

    var arrayobj1 = Object.values(approval);
    const arrayUniqueByKey1 = [...new Map(approval.map(item => [item['pursuitID'], item])).values()];
    var uni1 = arrayUniqueByKey1;

    var arrayobj = Object.values(pursuit);
    const arrayUniqueByKey = [...new Map(pursuit.map(item => [item['manMu'], item])).values()];
    var uni = arrayUniqueByKey;
    for (var i = 0; i < uni.length; i++) {
      if (uni[i].manMu != null || uni[i].manMu != undefined) {

        var pl = pursuit.filter(ele => ele.manMu == uni[i].manMu);
        var details = [];
        var count = 0;
        var retpayload = {};

        // Iterate through the pursuits and check the ranges for the current bU
        // var approvalToBu= approval.filter()
        for (var j = 0; j < uni1.length; j++) {
          var App = approval.filter(ele => ele.pursuitID == uni1[j].pursuitID);
          if (App) {
            var active = pl.find(ele => ele.id == uni1[j].pursuitID);
            var validateReviewS = App.find(ele => ele.reviewName == 'Sales to Delivery Handover complete');
            var validateReviewD = App.find(ele => ele.reviewName == 'Delivery Review');
            if (validateReviewS == undefined && validateReviewD) {
              if (active) {
                if (active.status == '6.1-Won') {
                  if (validateReviewD.approvalStatus == 'Yes') {
                    count++;
                    details.push(active);
                  }
                }
              }
            }
          }
        }

        // Add data to the row
        retpayload['bU'] = uni[i].manMu;
        retpayload['count'] = count;
        retpayload['details'] = details;

        tableData.push(retpayload);
      }
    }
    return tableData;
  };


  PageModule.prototype.EventCalenderADP = function (event) {
    var ADP = [];

    var nameArray = ['Win Theme Discussion', 'PQA Review', 'Delivery Review', 'Overall OBL Review', 'MU Solution Review', 'MU Deal Review', 'Oral']
    for (var i = 0; i < nameArray.length; i++) {
      var eventFind = event.filter(ele => ele.eventName == nameArray[i]);

      if (eventFind.length > 0) {
        for (var j = 0; j < eventFind.length; j++) {
          var retpayload = {};
          retpayload['eventName'] = eventFind[j].eventName;
          retpayload['date1'] = eventFind[j].date1;
          retpayload['applicablity'] = eventFind[j].applicablity;
          retpayload['reviewStatus'] = eventFind[j].reviewStatus;
          retpayload['updatedBy'] = eventFind[j].updatedBy;
          retpayload['lastUpdateDate'] = eventFind[j].lastUpdateDate;
          retpayload['pQAReviewer'] = eventFind[j].pQAReviewer;
          retpayload['id'] = eventFind[j].id;
          ADP.push(retpayload);
        }
      }
      else {
        var retpayload = {};
        retpayload['eventName'] = nameArray[i];
        retpayload['date1'] = null;
        retpayload['applicablity'] = nameArray[i] == 'Delivery Review' ? 'Yes' : nameArray[i] == 'PQA Review' ? '' : 'Not Applicable';
        retpayload['reviewStatus'] = null;
        retpayload['updatedBy'] = null;
        retpayload['lastUpdateDate'] = null;
        retpayload['pQAReviewer'] = null;
        retpayload['id'] = '0';

        ADP.push(retpayload);
      }
    }
    return ADP;
  };

  PageModule.prototype.ValidatePQAFile = function (File, event) {
    var eve = event.find(ele => ele.reviewName == 'PQA Review');
    if (eve) {
      var file = File.find(ele => ele.docType == 'PQA Review');
      if (file) {
        if (file.uploadedBy != null || file.uploadedBy != '') {
          return 1;
        }
        else {
          return 0;
        }
      }
      else {
        return 0;
      }
    }
    else {
      return 1;
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getSearchData = function (P_emp, P_main, revenueBO, YEar, dialogStatus, statusFilter) {
    var data = new Array();
    var totalTCV = 0;
    var toalRevenueForecast = 0;
    for (var i = 0; i < P_main.length; i++) {
      var pLead = P_emp.find(ele => ele.id == P_main[i].manPursuitlead);
      var pGov = P_emp.find(ele => ele.id == P_main[i].manPursuitgovernance);
      var PDE = P_emp.find(ele => ele.id == P_main[i].pDEName);
      var revenue = revenueBO.find(ele => ele.sLID == P_main[i].id);
      let Status = dialogStatus.filter(e => e.optyID == P_main[i].id);
      let DiaStatusCheck = 0;
      let finalStatus;
      for (let m = 0; m < Status.length; m++) {
        if (DiaStatusCheck < Status[m].id) {
          DiaStatusCheck = Status[m].id;
          finalStatus = Status[m].dealCycle;
        }
      }
      if (statusFilter == '') {
        statusFilter = 1;
      }

      // var module=moduleBO.find(ele=>ele.id==P_main[i].module1);
      //  var mu=P_mu.find(ele=>ele.id==P_main[i].mUAltName)
      //  var client=P_client.find(ele=>ele.id==P_main[i].account)
      var retpayload = {};
      var res = "";
      if (P_main[i].amOrIm == null && P_main[i].ovrdAM == null && (P_main[i].flag == "UpdateThor" || P_main[i].flag == "thor")) {
        res = 'AD';
      }
      else if (P_main[i].amOrIm == 'Yes') {
        res = 'AM';
      }
      else if (P_main[i].ovrdAM != undefined) {
        res = P_main[i].ovrdAM;
      }


      var date = new Date();
      var date2 = new Date(date.getFullYear(), date.getMonth(), 1);
      var day = date2.getDate() < 9 ? '0' + (date2.getDate()) : '' + (date2.getDate());
      var month = date2.getMonth() < 9 ? '0' + (date2.getMonth() + 1) : '' + (date2.getMonth() + 1)
      var year = date2.getFullYear();
      var currentDate = `${year}-${month}-${day}`;

      // var nextWeek= new Date(date.getTime()+ 31 * 24 * 60 * 60 * 1000)
      var nextWeek = new Date(date.getFullYear(), date.getMonth() + 1, 0);
      // var next3month= new Date(date.getTime()+ 90 * 24 * 60 * 60 * 1000)
      var next3month = new Date(date.getFullYear(), date.getMonth() + 2, 1);
      var day1 = nextWeek.getDate();
      var month1 = nextWeek.getMonth() < 9 ? '0' + (nextWeek.getMonth() + 1) : '' + (nextWeek.getMonth() + 1)
      var year1 = nextWeek.getFullYear();
      var nextWeek1 = `${year1}-${month1}-${day1}`;

      var day2 = next3month.getDate();
      var month2 = next3month.getMonth() < 9 ? '0' + (next3month.getMonth() + 1) : '' + (next3month.getMonth() + 1)
      var year2 = next3month.getFullYear();
      var next3month1 = `${year2}-${month2}-${day2}`;
      var color = false;
      var color2 = false;
      if (P_main[i].manClosemonth >= currentDate && P_main[i].manClosemonth <= nextWeek1) {
        color = true;
      }
      if (P_main[i].manStaffing == 'No' && (P_main[i].manClosemonth >= currentDate && P_main[i].manClosemonth <= next3month1) && P_main[i].bus != 'E-BUS(renewals)') {
        color2 = true;
      }

      if (((new Date((P_main[i].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) && (statusFilter == finalStatus || statusFilter == 1)) {

        retpayload['manProb'] = P_main[i].stgGroup == 'SOLD' ? Number(P_main[i].probability) : Number(P_main[i].manProb);
        retpayload['color'] = color;
        retpayload['color2'] = color2;
        retpayload['manStaffing'] = P_main[i].manStaffing;
        retpayload['flag'] = P_main[i].flag;
        retpayload['bus'] = P_main[i].bus;
        retpayload['optyID'] = P_main[i].optyId;
        retpayload['sLID'] = P_main[i].slId;
        retpayload['mU'] = P_main[i].mU;
        retpayload['bu'] = P_main[i].ovrdSubSector != undefined ? P_main[i].ovrdSubSector : P_main[i].subSector;
        // retpayload['account']=client!=undefined?client.clientName:'';
        // retpayload['pillar']=P_main[i].pillar;
        // retpayload['pursuitName']=P_main[i].pursuitName!=undefined?P_main[i].pursuitName.trim():'NA'
        retpayload['pursuitLead'] = pLead != undefined ? pLead.name : '';
        retpayload['pursuitGovernance'] = pGov != undefined ? pGov.name : '';
        retpayload['dueDate'] = P_main[i].closeMonth != undefined ? P_main[i].closeMonth : P_main[i].ovrdCloseMonth;
        retpayload['tCV'] = Number(P_main[i].convertedBkg) != undefined ? Number(P_main[i].convertedBkg) : Number(P_main[i].ovrdConvBkg);
        retpayload['status'] = finalStatus;
        retpayload['id'] = P_main[i].id;
        retpayload['plId'] = P_main[i].oldPursuitLead;
        retpayload['govId'] = P_main[i].manPursuitgovernance;
        retpayload['muId'] = P_main[i].mU;
        retpayload['accountId'] = P_main[i].mU;
        retpayload['lost'] = P_main[i].lost;
        retpayload['revenueForecast'] = revenue != undefined ? revenue.totalRevenue : '0';
        retpayload['manSubSector'] = P_main[i].manSubSector;
        retpayload['module'] = P_main[i].module1;
        retpayload['slTcv'] = Number(P_main[i].slTcv) ? Number(P_main[i].slTcv) : '';
        retpayload['pDE'] = P_main[i].pDE;
        retpayload['pDEName'] = PDE != undefined ? PDE.name : '';
        retpayload['pDEName1'] = P_main[i].pDEName;
        retpayload['proactivePursuit'] = P_main[i].proactivePursuit;
        retpayload['dealQualified'] = P_main[i].dealQualified;
        retpayload['pursuitConfidentiality'] = P_main[i].pursuitConfidentiality;
        retpayload['connectWithOracle'] = P_main[i].connectWithOracle;


        retpayload['manMu'] = P_main[i].manMu;
        retpayload['leadSource'] = P_main[i].leadSource;
        retpayload['pStatus'] = P_main[i].pStatus;
        retpayload['manBu'] = P_main[i].manBu;
        retpayload['leadBy'] = P_main[i].leadBy;
        retpayload['manAccount'] = P_main[i].manAccount;
        retpayload['manPillar'] = P_main[i].manPillar;
        retpayload['manNLCategory'] = P_main[i].manNLCategory;
        retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
        retpayload['manPlead'] = P_main[i].manPursuitlead;
        retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
        retpayload['manClosemonth'] = P_main[i].manClosemonth;
        retpayload['manTCV'] = P_main[i].manTCV;
        retpayload['manTCVoracle'] = (P_main[i].manStageGrp == 'SOLD' || P_main[i].manStageGrp == 'LDQ') ? Number(P_main[i].convertedBkg) : P_main[i].manTCVoracle;
        totalTCV = totalTCV + Number(retpayload['manTCVoracle']);
        retpayload['totalTCV'] = totalTCV;
        toalRevenueForecast = toalRevenueForecast + Number(retpayload['revenueForecast']);
        retpayload['toalRevenueForecast'] = toalRevenueForecast;
        retpayload['manPursuitname'] = P_main[i].manPursuitname;
        retpayload['manOptyID'] = P_main[i].manOptyID;
        retpayload['manSLId'] = P_main[i].manSLId;
        retpayload['manStageGrp'] = P_main[i].manStageGrp;
        retpayload['region'] = P_main[i].region;
        retpayload['pillar'] = P_main[i].strategicOffer;
        retpayload['amOrIm'] = res;
        retpayload['optyId'] = P_main[i].optyId;
        retpayload['slId'] = P_main[i].slId;
        retpayload['subSector'] = P_main[i].ovrdSubSector != undefined ? P_main[i].ovrdSubSector : P_main[i].subSector;
        retpayload['oldPursuitLead'] = P_main[i].ovrdPurrsuitLead != undefined ? P_main[i].ovrdPurrsuitLead : P_main[i].oldPursuitLead;
        // retpayload['region']=P_main[i].site;
        retpayload['account'] = P_main[i].account;
        retpayload['opportunity'] = P_main[i].opportunity;
        retpayload['ovrdConvBkg'] = P_main[i].ovrdConvBkg;

        retpayload['demandsCreatedOffshore'] = P_main[i].demandsCreatedOffshore;
        retpayload['demandsCreatedOnshore'] = P_main[i].demandsCreatedOnshore;
        retpayload['demandsCancelledOffshore'] = P_main[i].demandsCancelledOffshore;
        retpayload['demandsCancelledOnshore'] = P_main[i].demandsCancelledOnshore;
        retpayload['demandsRemarks'] = P_main[i].demandsRemarks;
        retpayload['bidStatus'] = P_main[i].bidStatus;
        retpayload['manComments'] = P_main[i].manComments == null ? 'NA' : P_main[i].manComments;

        retpayload['convertedBkg'] = P_main[i].convertedBkg;
        retpayload['convertedWeightedBkg'] = P_main[i].convertedWeightedBkg;
        retpayload['ovrdCloseMonth'] = P_main[i].ovrdCloseMonth;
        retpayload['closeMonth'] = P_main[i].closeMonth;
        retpayload['category'] = P_main[i].category;
        retpayload['P_mainCategory'] = P_main[i].P_mainCategory;
        retpayload['dealCat'] = P_main[i].dealCat;
        retpayload['forecastType'] = P_main[i].forecastType;
        retpayload['keyDealFlag'] = P_main[i].keyDealFlag;
        retpayload['ovrdProb'] = P_main[i].ovrdProb;
        retpayload['probability'] = P_main[i].probability;
        retpayload['groupAccount'] = P_main[i].groupAccount;
        retpayload['staffingRisk'] = P_main[i].staffingRisk;
        retpayload['oSLComments'] = P_main[i].oSLComments;
        retpayload['bidType'] = P_main[i].bidType;
        // retpayload['mU']=P_main[i].mUAltName!=undefined?P_main[i].mUAltName:P_main[i].mU;
        retpayload['mUAltName'] = P_main[i].mUAltName != undefined ? P_main[i].mUAltName : P_main[i].mU;
        retpayload['salesPlay'] = P_main[i].salesPlay;
        retpayload['offer'] = P_main[i].solution;
        retpayload['coE'] = P_main[i].coE;
        retpayload['askHelpNeeded'] = P_main[i].askHelpNeeded;
        retpayload['stepsToClose'] = P_main[i].stepsToClose;
        retpayload['actionDueDate'] = P_main[i].actionDueDate;
        retpayload['winTheme'] = P_main[i].winTheme;
        //retpayload['bDE']=P_main[i].;
        retpayload['oracleLicenceInfluence'] = P_main[i].oracleLicenceInfluence;
        retpayload['stg'] = P_main[i].stg;
        retpayload['stgGroup'] = P_main[i].stgGroup;
        retpayload['revCategory'] = P_main[i].revCategory;
        retpayload['ovrdCM'] = P_main[i].ovrdCM;
        retpayload['cM'] = P_main[i].ovrdCM != undefined ? P_main[i].ovrdCM : P_main[i].cM;
        retpayload['accountSegment'] = P_main[i].accountSegment;
        retpayload['primaryERP'] = P_main[i].primaryERP;
        retpayload['multiERP'] = P_main[i].multiERP;
        retpayload['likelyStart'] = P_main[i].likelyStart;
        retpayload['localIINCRHCmon1'] = P_main[i].localIINCRHCmon1;
        retpayload['gXINCRHCmon1'] = P_main[i].gXINCRHCmon1;
        retpayload['indiaINCRHCmon1'] = P_main[i].indiaINCRHCmon1;
        retpayload['source'] = P_main[i].source;
        retpayload['site'] = P_main[i].site;
        retpayload['gTMCallYN'] = P_main[i].gTMCallYN;
        retpayload['mP_mainiewYN'] = P_main[i].mP_mainiewYN;
        // retpayload['muSubsector']=P_main[i].muSubsector;
        retpayload['offerCategory'] = P_main[i].offerCategory;
        retpayload['IsDUP_ofID'] = P_main[i].IsDUP_ofID;
        retpayload['thorMU'] = P_main[i].thorMU;
        retpayload['nLCategory'] = P_main[i].nLCategory;
        retpayload['nLRule'] = P_main[i].nLRule;
        retpayload['ovrdAM'] = res;
        retpayload['ovrdPursuitLead'] = P_main[i].ovrdPursuitLead != undefined ? P_main[i].ovrdAM : P_main[i].oldPursuitLead;
        // retpayload['ovrdStgGrp']=P_main[i].ovrdStgGrp!=undefined?P_main[i].ovrdAM:P_main[i].stg;
        retpayload['ovrdSubSector'] = P_main[i].ovrdSubSector != undefined ? P_main[i].ovrdSubSector : P_main[i].subSector;

        retpayload['wtBkg'] = P_main[i].wtBkg;
        data.push(retpayload);
      }
    }

    console.log(">>", data);
    return data;
  };

  PageModule.prototype.validateFile = function (ext) {
    var extt = ext.split('.').pop();
    //console.log('@@uu :' + extt);
    if (extt == "pdf" || extt == "docx" || extt == "jpg" || extt == "jpeg" || extt == "xlsx" || extt == "pptx" || extt == "xlsb" || extt == "zip") {
      //console.log('@@uu11 :' + extt);
      return 'valid';

    }

    return 'non-valid';
  };

  PageModule.prototype.fileName = function (accountName, type, slid, objectName) {
    var fileName;
    var sd = slid.split("#");
    slid = sd[0] + sd[1];

    fileName = type.concat("_", accountName, "/", slid);
    var ext = objectName.split(".");
    fileName = fileName + '.' + ext[ext.length - 1];
    return fileName;
  };


  PageModule.prototype.downloadFile = function (base64File, filename) {
    console.log('@@File Name' + filename);

    var fileBytes = atob(base64File);
    fileBytes = FileToBytes(fileBytes);
    console.log(fileBytes);
    // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
    //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    var blob = new Blob([fileBytes], {
      type: 'octet/stream'
    });
    //var filename = "CDE.xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }

  };

  PageModule.prototype.createPay = function (fileObj, bucketName, fileName) {

    var form = new FormData();
    form.append('file', fileObj, fileName);
    form.append('json', '{"filename":"' + fileName + '", "bucket_name" : "' + bucketName + '"}');

    return form;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createPayloadEventDate = function (id) {

    var data = [];
    var abc = ['PQA Review', 'Delivery Review', 'Win Theme Discussion', 'Overall OBL Review', 'Solution Review', 'MU Deal Review', 'Oral']
    for (var i = 0; i < abc.length; i++) {
      var payload = {}
      if (i == 0) {
        payload['eventName'] = abc[i];
        payload['date1'] = '';
        payload['optyID'] = id;
        payload['updatedBy'] = '';
        data.push(payload);
      }

      else if (i == 1) {
        payload['eventName'] = abc[i];
        payload['date1'] = '';
        payload['optyID'] = id;
        payload['updatedBy'] = '';
        payload['applicablity'] = 'Yes';
        data.push(payload);
      }

      else {
        payload['eventName'] = abc[i];
        payload['date1'] = '';
        payload['optyID'] = id;
        payload['updatedBy'] = '';
        payload['applicablity'] = 'Not Applicable';
        data.push(payload);
      }

    }
    return data;
    console.log(">>", data)
  }
  PageModule.prototype.createPayloadUpload = function (id) {

    var data = [];
    var abc = ['Proposal', 'Effort PT/ ADMT', 'MU Deal Review Deck', 'Orals', 'SoW', 'Additonal Document(Others)', 'RFP']
    for (var i = 0; i < abc.length; i++) {
      var payload = {}
      payload['docType'] = abc[i];
      payload['optyID'] = id;
      data.push(payload);
    }
    return data;
    console.log(">>", data)
  }


  function createBatchesUploadApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      var data = '{"id": "part' + innerIndex + '","path": "/EventPursuitBO/","operation": "create","payload": ' + JSON.stringify(dataArray[innerIndex]) + '}';
      console.log('#90', data);
      innerArray.push(JSON.parse(data));

    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  }
  PageModule.prototype.processBatchReqsapp = function (dataArray) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = createBatchesUploadApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }

    console.log('#80' + JSON.stringify(batchArray));

    return batchArray;

  };
  PageModule.prototype.SizeOFArray = function (dataArray) {
    var size = dataArray.length;
    return size;
  };


  function createBatchesUploadApp2(batchThresholdStart, batchThresholdEnd, batchArray, dataArray) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      var data = '{"id": "part' + innerIndex + '","path": "/DocRepoBO/","operation": "create","payload": ' + JSON.stringify(dataArray[innerIndex]) + '}';
      console.log('#90', data);
      innerArray.push(JSON.parse(data));

    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  }
  PageModule.prototype.processBatchReqsapp2 = function (dataArray) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = createBatchesUploadApp2(batchThresholdStart, batchThresholdEnd, batchArray, dataArray);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }

    console.log('#80' + JSON.stringify(batchArray));

    return batchArray;

  };


  function DeleteBatchesEventPursuitApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      var data = '{"id": "part' + innerIndex + '","path": "/EventPursuitBO/' + (dataArray[innerIndex]).id + '","operation": "delete"}';
      console.log('#90', data);
      innerArray.push(JSON.parse(data));

    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  }

  PageModule.prototype.processBatchReqsapp4 = function (dataArray) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = DeleteBatchesEventPursuitApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }

    console.log('#80' + JSON.stringify(batchArray));

    return batchArray;

  };

  function DeleteBatchesPursuitStatusApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      var data = '{"id": "part' + innerIndex + '","path": "/PursuitStatusBO/' + (dataArray[innerIndex]).id + '","operation": "delete"}';
      console.log('#90', data);
      innerArray.push(JSON.parse(data));

    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  };

  PageModule.prototype.processBatchReqsapp5 = function (dataArray) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = DeleteBatchesPursuitStatusApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }
    return batchArray;

  };


  function DeleteBatchesPursuitDetailsUpdateApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      var data = '{"id": "part' + innerIndex + '","path": "/PursuitDetailsUpdateBO/' + (dataArray[innerIndex]).id + '","operation": "delete"}';
      console.log('#90', data);
      innerArray.push(JSON.parse(data));

    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  };

  PageModule.prototype.processBatchReqsapp6 = function (dataArray) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = DeleteBatchesPursuitDetailsUpdateApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }

    console.log('#80' + JSON.stringify(batchArray));

    return batchArray;

  };


  function DeleteBatchesDocRepoApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray, RepoBO, eventBo, approvBo, statusBo, UpdatestatusBo, revenue, refreshAnalysisBO) {

    var innerArray = new Array();
    var partsData = {};
    for (var innerIndex = batchThresholdStart; innerIndex < batchThresholdEnd; innerIndex++) {

      if (RepoBO.length > '0') {
        for (var j = 0; j < RepoBO.length; j++) {
          var deta = '{"id": "part' + innerIndex + '","path":"/DocRepoBO/' + RepoBO[j].id + '","operation": "delete"}';
          console.log("#80", deta);
          innerArray.push(JSON.parse(deta));
        }
      }

      if (eventBo.length > '0') {
        for (var a = 0; a < eventBo.length; a++) {
          var deta1 = '{"id": "part' + innerIndex + '","path":"/EventPursuitBO/' + eventBo[a].id + '","operation": "delete"}';
          console.log("#80", deta1);
          innerArray.push(JSON.parse(deta1));
        }
      }
      if (approvBo.length > '0') {
        for (var d = 0; d < approvBo.length; d++) {
          var deta3 = '{"id": "part' + innerIndex + '","path":"/PursuitApprovalBO/' + approvBo[d].id + '","operation": "delete"}';
          console.log("#80", deta3);
          innerArray.push(JSON.parse(deta3));
        }
      }

      if (statusBo.length > '0') {
        for (var e = 0; e < statusBo.length; e++) {
          var deta4 = '{"id": "part' + innerIndex + '","path":"/PursuitStatusBO/' + statusBo[e].id + '","operation": "delete"}';
          console.log("#80", deta4);
          innerArray.push(JSON.parse(deta4));
        }
      }

      if (UpdatestatusBo.length > '0') {
        for (var f = 0; f < UpdatestatusBo.length; f++) {
          var deta5 = '{"id": "part' + innerIndex + '","path":"/PursuitDetailsUpdateBO/' + UpdatestatusBo[f].id + '","operation": "delete"}';
          console.log("#80", deta5);
          innerArray.push(JSON.parse(deta5));
        }
      }

      if (revenue.length > '0') {
        for (var f = 0; f < revenue.length; f++) {
          var deta6 = '{"id": "part' + innerIndex + '","path":"/RevenueForcastBO/' + revenue[f].id + '","operation": "delete"}';
          console.log("#80", deta6);
          innerArray.push(JSON.parse(deta6));
        }
      }

      if (refreshAnalysisBO.length > '0') {
        for (var i = 0; i < refreshAnalysisBO.length; i++) {
          var deta7 = '{"id": "part' + innerIndex + '","path":"/RefreshAnalysisBO/' + refreshAnalysisBO[i].id + '","operation": "delete"}';
          console.log("#80", deta7);
          innerArray.push(JSON.parse(deta7));
        }
      }

      var deta7 = '{"id": "part' + innerIndex + '","path":"/ActivePursuit/' + dataArray[innerIndex].id + '","operation": "delete"}';
      console.log("#80", deta7);
      innerArray.push(JSON.parse(deta7));
    }
    JSON.stringify(innerArray);
    partsData['parts'] = innerArray;
    batchArray.push(partsData);

    return batchArray;

  };

  PageModule.prototype.processBatchReqsapp3 = function (dataArray, RepoBO, eventBo, approvBo, statusBo, UpdatestatusBo, revenue, refreshAnalysisBO) {

    // console.log('$$$$$$164'+JSON.stringify(dataArray));
    var batchSize = 1000;
    var batchArray = new Array();
    var buffer = true;
    var index = 0;
    // var batchSeq=dataArray.length/batchSize;
    var bufferIndex = 1;
    var batchThresholdStart = 0;

    var batchThresholdEnd = dataArray.length < batchSize ? dataArray.length : batchSize;
    while (buffer) {


      batchArray = DeleteBatchesDocRepoApp(batchThresholdStart, batchThresholdEnd, batchArray, dataArray, RepoBO, eventBo, approvBo, statusBo, UpdatestatusBo, revenue, refreshAnalysisBO);
      if (batchThresholdEnd == dataArray.length) {
        buffer = false;
      }
      batchThresholdStart += batchSize;
      batchThresholdEnd = dataArray.length < (batchSize + batchThresholdEnd) ? dataArray.length : (batchSize + batchThresholdEnd);


    }

    console.log('#80' + JSON.stringify(batchArray));

    return batchArray;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.roleAccess = function (roleBO, userID) {

    for (var i = 0; i <= roleBO.length; i++) {
      if (roleBO[i].employeeId == userID && roleBO[i].roleIdObject.items[0].roleName == 'Delivery Review') {
        return 'Delivery Review';
      }
      else if (roleBO[i].employeeId == userID && roleBO[i].roleIdObject.items[0].roleName == 'Overall OBL Review') {
        return 'Overall OBL Review';
      }
      else if (roleBO[i].employeeId == userID && roleBO[i].roleIdObject.items[0].roleName == 'PQA Review') {
        return 'PQA Review';
      }
      else if (roleBO[i].employeeId == userID && roleBO[i].roleIdObject.items[0].roleName == 'Solution Review') {
        return 'Solution Review';
      }
    }
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  //   PageModule.prototype.dueDateFunction=function(date1) {
  //     var payload={};
  //     var date = new Date();
  //     var day = date.getDate()<9?'0'+(date.getDate()):''+(date.getDate());
  //     var month = date.getMonth()<9?'0'+(date.getMonth()+1):''+(date.getMonth()+1)
  //     var year = date.getFullYear();
  //     var currentDate = `${year}-${month}-${day}`;
  //     if(date1=='1W')
  //     {
  //        var nextWeek;
  //       nextWeek= new Date(date.getTime()+ 30 * 24 * 60 * 60 * 1000)
  //       var day = nextWeek.getDate();
  //     var month = nextWeek.getMonth()<9?'0'+(nextWeek.getMonth()+1):''+(nextWeek.getMonth()+1)
  //     var year = nextWeek.getFullYear();
  //     var nextWeek1 = `${year}-${month}-${day}`;

  //       payload['from']=currentDate;
  //       payload['to']=nextWeek1;

  //     }
  //     else if(date1=='2W')
  //     {
  //       var nextWeek;
  //       nextWeek= new Date(date.getTime()+ 60 * 24 * 60 * 60 * 1000)
  //       var day = nextWeek.getDate();
  //     var month = nextWeek.getMonth()<9?'0'+(nextWeek.getMonth()+1):''+(nextWeek.getMonth()+1)
  //     var year = nextWeek.getFullYear();
  //     var nextWeek1 = `${year}-${month}-${day}`;

  //       payload['from']=currentDate;
  //       payload['to']=nextWeek1;
  //     }
  //     else if(date1=='1M')
  //     {
  //                 var nextWeek;
  //       nextWeek= new Date(date.getTime()+ 90 * 24 * 60 * 60 * 1000)
  //       var day = nextWeek.getDate();
  //     var month = nextWeek.getMonth()<9?'0'+(nextWeek.getMonth()+1):''+(nextWeek.getMonth()+1)
  //     var year = nextWeek.getFullYear();
  //     var nextWeek1 = `${year}-${month}-${day}`;

  //       payload['from']=currentDate;
  //       payload['to']=nextWeek1;
  //     }
  //     return payload;
  // };

  PageModule.prototype.dueDateFunction = function (date1, currentYear) {
    let myarray = date1;  //['Q1','Q2','H1']

    let Q1 = ['Jan', 'Feb', 'Mar'];
    let Q2 = ['Apr', 'May', 'Jun'];
    let Q3 = ['Jul', 'Aug', 'Sep'];
    let Q4 = ['Oct', 'Nov', 'Dec'];
    let H1 = [...Q1, ...Q2];     
    let H2 = [...Q3, ...Q4];


    let selectedmonths = [];

    for (let i = 0; i < myarray.length; i++) {        
      if (myarray[i] == 'Q1') {
        selectedmonths.push(...Q1);
      } else if (myarray[i] == 'Q2') {
        selectedmonths.push(...Q2);
      } else if (myarray[i] == 'H1') {
        selectedmonths.push(...H1);
      } else if (myarray[i] == 'Q3') {
        selectedmonths.push(...Q3);
      } else if (myarray[i] == 'Q4') {
        selectedmonths.push(...Q4);
      } else if (myarray[i] == 'H2') {
        selectedmonths.push(...H2);
      }
    }

    // Remove duplicates using Set
    let SelectedMonths = [...new Set(selectedmonths)];  
    // console.log(SelectedMonths);



    var queryString = "";
    var dateRanges = [];


    for (var i = 0; i < SelectedMonths.length; i++) {
      var month = SelectedMonths[i];
      var startDate, endDate;

      if (month === 'Jan') {
        startDate = currentYear + '-01-01';
        endDate = currentYear + '-01-31';
      } else if (month === 'Feb') {
        startDate = currentYear + '-02-01';
        endDate = currentYear + '-02-28';
      } else if (month === 'Mar') {
        startDate = currentYear + '-03-01';
        endDate = currentYear + '-03-31';
      } else if (month === 'Apr') {
        startDate = currentYear + '-04-01';
        endDate = currentYear + '-04-30';
      } else if (month === 'May') {
        startDate = currentYear + '-05-01';
        endDate = currentYear + '-05-31';
      } else if (month === 'Jun') {
        startDate = currentYear + '-06-01';
        endDate = currentYear + '-06-30';
      } else if (month === 'Jul') {
        startDate = currentYear + '-07-01';
        endDate = currentYear + '-07-31';
      } else if (month === 'Aug') {
        startDate = currentYear + '-08-01';
        endDate = currentYear + '-08-31';
      } else if (month === 'Sep') {
        startDate = currentYear + '-09-01';
        endDate = currentYear + '-09-30';
      } else if (month === 'Oct') {
        startDate = currentYear + '-10-01';
        endDate = currentYear + '-10-31';
      } else if (month === 'Nov') {
        startDate = currentYear + '-11-01';
        endDate = currentYear + '-11-30';
      } else if (month === 'Dec') {
        startDate = currentYear + '-12-01';
        endDate = currentYear + '-12-31';
      }

      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }

    if (dateRanges.length == 1) {
      queryString = dateRanges[0] + "AND ";
    } else if (dateRanges.length > 1) {
      queryString = "(" + dateRanges.join(" OR ") + ") AND";
    }

    console.log(queryString);
    return queryString;
  }


  PageModule.prototype.closeyear = function (closemonth) {
    const firstFourChars = closemonth != undefined ? closemonth.substring(0, 4) : "";
    return firstFourChars;
  };


  PageModule.prototype.closeyear = function (closemonth) {

    const firstFourChars = closemonth != undefined ? closemonth.substring(0, 4) : '';
    return firstFourChars;
  }










  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.tcvCal = function (data1, tcv, YEar, tcvmin) {
    var data = []
    for (var i = 0; i < data1.length; i++) {
      var payload = {};
      var validate = (data1[i].manStageGrp == 'SOLD' || data1[i].manStageGrp == 'LDQ') ? '1' : '2';
      if (validate == '1') {

        if (data1[i].convertedBkg != null) {
          if (data1[i].convertedBkg >= (Number(tcvmin) * 1000000) && data1[i].convertedBkg <= Number(tcv) * 1000000) {
            if ((new Date((data1[i].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
              payload['optyID'] = data1[i].manOptyID;
              payload['slId'] = data1[i].manSLId;
              payload['Account'] = data1[i].manAccount;
              payload['PursuitName'] = data1[i].manPursuitname;
              payload['TCV'] = data1[i].convertedBkg;
              payload['dueDate'] = data1[i].manClosemonth;

              data.push(payload);
            }
          }

        }

      }
      else {
        if (data1[i].manTCVoracle != null) {
          if (data1[i].manTCVoracle >= (Number(tcvmin) * 1000000) && data1[i].manTCVoracle <= Number(tcv) * 1000000) {
            if ((new Date((data1[i].manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
              payload['optyID'] = data1[i].manOptyID;
              payload['slId'] = data1[i].manSLId;
              payload['Account'] = data1[i].manAccount;
              payload['PursuitName'] = data1[i].manPursuitname;
              payload['TCV'] = data1[i].manTCVoracle;
              payload['dueDate'] = data1[i].manClosemonth;

              data.push(payload);
            }
          }

        }
      }
    }

    return data;

  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */



  PageModule.prototype.ReportsDateFunction = function (date1, currentYear) {
    var selectedMonths = date1;
    var queryString = "";
    var dateRanges = [];


    for (var i = 0; i < selectedMonths.length; i++) {
      var month = selectedMonths[i];
      var startDate, endDate;

      if (month === 'Jan') {
        startDate = currentYear + '-01-01';
        endDate = currentYear + '-01-31';
      } else if (month === 'Feb') {
        startDate = currentYear + '-02-01';
        endDate = currentYear + '-02-28';
      } else if (month === 'Mar') {
        startDate = currentYear + '-03-01';
        endDate = currentYear + '-03-31';
      } else if (month === 'Apr') {
        startDate = currentYear + '-04-01';
        endDate = currentYear + '-04-30';
      } else if (month === 'May') {
        startDate = currentYear + '-05-01';
        endDate = currentYear + '-05-31';
      } else if (month === 'Jun') {
        startDate = currentYear + '-06-01';
        endDate = currentYear + '-06-30';
      } else if (month === 'Jul') {
        startDate = currentYear + '-07-01';
        endDate = currentYear + '-07-31';
      } else if (month === 'Aug') {
        startDate = currentYear + '-08-01';
        endDate = currentYear + '-08-31';
      } else if (month === 'Sep') {
        startDate = currentYear + '-09-01';
        endDate = currentYear + '-09-30';
      } else if (month === 'Oct') {
        startDate = currentYear + '-10-01';
        endDate = currentYear + '-10-31';
      } else if (month === 'Nov') {
        startDate = currentYear + '-11-01';
        endDate = currentYear + '-11-30';
      } else if (month === 'Dec') {
        startDate = currentYear + '-12-01';
        endDate = currentYear + '-12-31';
      }

      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }

    if (selectedMonths.length === 0) {
      startDate = currentYear + '-01-01';
      endDate = currentYear + '-12-31';
      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges[0];
    } else if (dateRanges.length > 1) {
      queryString = "AND(" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };


  PageModule.prototype.ReportsDateFunction2 = function (date1, currentYear) {
    var selectedMonths = date1;
    var queryString = "";
    var dateRanges = [];


    for (var i = 0; i < selectedMonths.length; i++) {
      var month = selectedMonths[i];
      var startDate, endDate;

      if (month === 'Jan') {
        startDate = currentYear + '-01-01';
        endDate = currentYear + '-01-31';
      } else if (month === 'Feb') {
        startDate = currentYear + '-02-01';
        endDate = currentYear + '-02-28';
      } else if (month === 'Mar') {
        startDate = currentYear + '-03-01';
        endDate = currentYear + '-03-31';
      } else if (month === 'Apr') {
        startDate = currentYear + '-04-01';
        endDate = currentYear + '-04-30';
      } else if (month === 'May') {
        startDate = currentYear + '-05-01';
        endDate = currentYear + '-05-31';
      } else if (month === 'Jun') {
        startDate = currentYear + '-06-01';
        endDate = currentYear + '-06-30';
      } else if (month === 'Jul') {
        startDate = currentYear + '-07-01';
        endDate = currentYear + '-07-31';
      } else if (month === 'Aug') {
        startDate = currentYear + '-08-01';
        endDate = currentYear + '-08-31';
      } else if (month === 'Sep') {
        startDate = currentYear + '-09-01';
        endDate = currentYear + '-09-30';
      } else if (month === 'Oct') {
        startDate = currentYear + '-10-01';
        endDate = currentYear + '-10-31';
      } else if (month === 'Nov') {
        startDate = currentYear + '-11-01';
        endDate = currentYear + '-11-30';
      } else if (month === 'Dec') {
        startDate = currentYear + '-12-01';
        endDate = currentYear + '-12-31';
      }

      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }
    if (selectedMonths.length === 0) {
      startDate = currentYear + '-01-01';
      endDate = currentYear + '-12-31';
      dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");
    }

    if (dateRanges.length == 1) {
      queryString = dateRanges[0];
    } else if (dateRanges.length > 1) {
      queryString = "(" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };


  PageModule.prototype.probabilyCal = function (prob) {
    if (prob >= 0 && prob <= 50) {
      return 'Low'
    }
    else if (prob >= 51 && prob <= 80) {
      return 'Medium'
    }
    else if (prob >= 81 && prob <= 100) {
      return 'High'
    }

  }
  PageModule.prototype.approver = function (date, ref) {

    var date1 = new Date();
    var day = date1.getDate();
    var month = date1.getMonth() < 9 ? '0' + (date1.getMonth() + 1) : '' + (date1.getMonth() + 1)
    var year = date1.getFullYear();
    var currentDate = `${year}-${month}-${day}`;
    var payaload = {};
    var PQA = date.find(ele => ele.eventName == 'PQA Review' && ele.date1 != undefined)
    var Del = date.find(ele => ele.eventName == 'Delivery Review' && ele.date1 != undefined)
    var OBL = date.find(ele => ele.eventName == 'Overall OBL Review' && ele.date1 != undefined)

    if (PQA != undefined) {
      if (PQA.date1 <= currentDate && ref == 'PQA Review') {
        payaload['PQA'] = 'true';
      }
    }
    if (Del != undefined) {
      if (Del.date1 <= currentDate && ref == 'Delivery Review') {
        payaload['DEL'] = 'true';
      }
    }
    if (OBL != undefined) {
      if (OBL.date1 <= currentDate && ref == 'Overall OBL Review') {
        payaload['OBL'] = 'true';
      }
    }
    payaload['DEL'] = payaload['DEL'] != undefined ? payaload['DEL'] : 'false'
    payaload['PQA'] = payaload['PQA'] != undefined ? payaload['PQA'] : 'false'
    payaload['OBL'] = payaload['OBL'] != undefined ? payaload['OBL'] : 'false'
    return payaload;
  }




  PageModule.prototype.getProbability = function (bus, prob) {
    if (bus == 'E-BUS(renewals)' || bus == 'E-BUS(NetNew)') {
      if (prob >= 0 && prob <= 30) {
        return 'Low';
      }
      else if (prob >= 31 && prob <= 80) {
        return 'Medium';
      }
      else if (prob >= 81 && prob <= 100) {
        return 'High';
      }

    }
    else if (bus == 'N-BUS(NewLogo)') {
      if (prob >= 0 && prob <= 10) {
        return 'Low';
      }
      else if (prob >= 11 && prob <= 60) {
        return 'Medium';
      }
      else if (prob >= 61 && prob <= 90) {
        return 'High';
      }

    }
  };
  PageModule.prototype.employeeData = function (empBo, roleBo) {
    var array = [];
    for (var i = 0; i < empBo.length; i++) {
      var retpayload = {};
      var employee = roleBo.find(ele => ele.id == empBo[i].employeeId);
      array.push(employee.employeeID)
    }
    return array;
  };


  PageModule.prototype.AccessCompare = function (roleBo, roleEmployee, approval) {
    var array = [];

    for (var i = 0; i < approval.length; i++) {

      var store = roleBo.find(ele => ele.roleName == approval[i].reviewName);
      var access = (roleEmployee.find(ele1 => ele1.roleId == store.id)) != undefined ? roleEmployee.find(ele1 => ele1.roleId == store.id) : 'NA';
      if (access != 'NA') {
        array.push(approval[i].id);

      }
      else {
        array.push('0');
      }


    }
    return array;
  };
  PageModule.prototype.SalesMasterRole = function (roleEmployee) {
    var pp = roleEmployee.find(ele => ele.roleId == 105);
    if (pp != undefined) {
      return pp.roleId;
    }
    else {
      return 0;
    }
  };

  PageModule.prototype.haha = function (row, rowID, x) {

    var mod = row;
    var i = x;

    for (i in mod) {
      if (mod[x] == rowID) {

        return 1;

      }

      else {
        return 0;
      }


    }



  };

  PageModule.prototype.getUniqueAccountName = function (data) {
    var arrayobj = Object.values(data);

    const arrayUniqueByKey = [...new Map(data.map(item => [item['account'], item])).values()];
    var uni = arrayUniqueByKey;
    var data1 = []
    for (var i = 0; i < uni.length; i++) {
      var retpayload = {}
      if (uni[i].account != null) {
        retpayload['account'] = uni[i].account;
        data1.push(retpayload)
      }
    }
    return data1;
  };

  PageModule.prototype.PursuitDetailsMatch = function (old, New, Date, username, create, employee) {
    var array = [];

    if (create == "Pursuit Created Manually") {
      var retpayload = {};
      retpayload['type1'] = create;
      retpayload['oldValue'] = 'NA';
      retpayload['newValue'] = 'NA';
      retpayload['optyID'] = old.id;
      retpayload['date1'] = Date;
      retpayload['username'] = username;
      return retpayload;
    }
    else if (create == "Pursuit Created") {
      var retpayload = {};
      retpayload['type1'] = create;
      retpayload['oldValue'] = 'NA';
      retpayload['newValue'] = 'NA';
      retpayload['optyID'] = old.id;
      retpayload['date1'] = Date;
      retpayload['username'] = username;
      return retpayload;
    }


    else {
      if (old.manPillar != New.manPillar) {
        var retpayload = {};
        retpayload['type1'] = 'Pillar';
        retpayload['oldValue'] = old.manPillar;
        retpayload['newValue'] = New.manPillar;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manClosemonth != New.manClosemonth) {
        var retpayload = {};
        retpayload['type1'] = 'Due Date';
        retpayload['oldValue'] = old.manClosemonth;
        retpayload['newValue'] = New.manClosemonth;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manTCV != New.manTCV) {
        var retpayload = {};
        retpayload['type1'] = 'TCV Overall($)';
        retpayload['oldValue'] = old.manTCV;
        retpayload['newValue'] = New.manTCV;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manTCVoracle != New.manTCVoracle) {
        var retpayload = {};
        retpayload['type1'] = 'CV Oracle($)';
        retpayload['oldValue'] = old.manTCVoracle;
        retpayload['newValue'] = New.manTCVoracle;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.status != New.status) {
        var retpayload = {};
        retpayload['type1'] = 'Status';
        retpayload['oldValue'] = old.status;
        retpayload['newValue'] = New.status;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.bus != New.bus) {
        var retpayload = {};
        retpayload['type1'] = 'Opportunity Type';
        retpayload['oldValue'] = old.bus;
        retpayload['newValue'] = New.bus;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manProb != New.manProb) {
        var retpayload = {};
        retpayload['type1'] = 'Probability';
        retpayload['oldValue'] = old.manProb;
        retpayload['newValue'] = New.manProb;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manPursuitname != New.manPursuitname) {
        var retpayload = {};
        retpayload['type1'] = 'Pursuit Name';
        retpayload['oldValue'] = old.manPursuitname;
        retpayload['newValue'] = New.manPursuitname;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manStaffing != New.manStaffing) {
        var retpayload = {};
        retpayload['type1'] = 'Staffing';
        retpayload['oldValue'] = old.manStaffing;
        retpayload['newValue'] = New.manStaffing;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manOptyID != New.manOptyID) {
        var retpayload = {};
        retpayload['type1'] = 'Opportunity ID';
        retpayload['oldValue'] = old.manOptyID;
        retpayload['newValue'] = New.manOptyID;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manSLId != New.manSLId) {
        var retpayload = {};
        retpayload['type1'] = 'Service Line ID';
        retpayload['oldValue'] = old.manSLId;
        retpayload['newValue'] = New.manSLId;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manMu != New.manMu) {
        var retpayload = {};
        retpayload['type1'] = 'BU';
        retpayload['oldValue'] = old.manMu;
        retpayload['newValue'] = New.manMu;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manBu != New.manBu) {
        var retpayload = {};
        retpayload['type1'] = 'MU';
        retpayload['oldValue'] = old.manBu;
        retpayload['newValue'] = New.manBu;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if (old.manAccount != New.manAccount) {
        var retpayload = {};
        retpayload['type1'] = 'Account';
        retpayload['oldValue'] = old.manAccount;
        retpayload['newValue'] = New.manAccount;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.bidStatus != New.bidStatus) {
        var retpayload = {};
        retpayload['type1'] = 'Bid Status';
        retpayload['oldValue'] = old.bidStatus;
        retpayload['newValue'] = New.bidStatus;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.demandsCancelledOffshore != New.demandsCancelledOffshore) {
        var retpayload = {};
        retpayload['type1'] = 'Demands Cancelled Offshore';
        retpayload['oldValue'] = old.demandsCancelledOffshore;
        retpayload['newValue'] = New.demandsCancelledOffshore;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.demandsCancelledOnshore != New.demandsCancelledOnshore) {
        var retpayload = {};
        retpayload['type1'] = 'Demands Cancelled Onshore';
        retpayload['oldValue'] = old.demandsCancelledOnshore;
        retpayload['newValue'] = New.demandsCancelledOnshore;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.demandsCreatedOffshore != New.demandsCreatedOffshore) {
        var retpayload = {};
        retpayload['type1'] = 'Demands Created Offshore';
        retpayload['oldValue'] = old.demandsCreatedOffshore;
        retpayload['newValue'] = New.demandsCreatedOffshore;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.demandsCreatedOnshore != New.demandsCreatedOnshore) {
        var retpayload = {};
        retpayload['type1'] = 'demands Created Onshore';
        retpayload['oldValue'] = old.demandsCreatedOnshore;
        retpayload['newValue'] = New.demandsCreatedOnshore;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.demandsRemarks != New.demandsRemarks) {
        var retpayload = {};
        retpayload['type1'] = 'Demands Remarks';
        retpayload['oldValue'] = old.demandsRemarks;
        retpayload['newValue'] = New.demandsRemarks;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.ovarallRevenueForecast != New.ovarallRevenueForecast) {
        var retpayload = {};
        retpayload['type1'] = 'Ovarall Revenue Forecast';
        retpayload['oldValue'] = old.ovarallRevenueForecast;
        retpayload['newValue'] = New.ovarallRevenueForecast;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if (old.pStatus != New.pStatus) {
        var retpayload = {};
        retpayload['type1'] = 'Pursuit Status';
        retpayload['oldValue'] = old.pStatus;
        retpayload['newValue'] = New.pStatus;
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }
      if ((old.manPursuitlead ? employee.find(e => e.name == old.manPursuitlead).id : 'NA') != New.manPursuitlead) {
        var retpayload = {};
        retpayload['type1'] = 'Pursuit Lead';
        retpayload['oldValue'] = old.manPursuitlead ? old.manPursuitlead : 'NA';
        retpayload['newValue'] = New.manPursuitlead ? employee.find(e => e.id == New.manPursuitlead).name : 'NA';
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

      if ((old.manPursuitgovernance ? employee.find(e => e.name == old.manPursuitgovernance).id : 'NA') != New.manPursuitgovernance) {
        var retpayload = {};
        retpayload['type1'] = 'Bid Manager';
        retpayload['oldValue'] = old.manPursuitgovernance ? old.manPursuitgovernance : 'NA';
        retpayload['newValue'] = New.manPursuitgovernance ? employee.find(e => e.id == New.manPursuitgovernance).name : 'NA';
        retpayload['optyID'] = old.id;
        retpayload['date1'] = Date;
        retpayload['username'] = username;
        array.push(retpayload);
      }

    }


    return array;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createmail = function (EmpId, BU) {
    var retpayload;
    let Buemail;
    if (BU) {
      if (BU.length > 0) {
        Buemail = BU[0].businessUnitLeaderObject.items[0].email;
      }
    }
    var data = Buemail ? "amit.a.nayak@capgemini.com,david.mobbs@capgemini.com,debalin.das@capgemini.com," + Buemail : "amit.a.nayak@capgemini.com,david.mobbs@capgemini.com,debalin.das@capgemini.com";

    if (EmpId.manPursuitgovernance != null) {
      if (data.includes(EmpId.manPursuitgovernanceObject.items[0].email) == false) {
        data += ',' + EmpId.manPursuitgovernanceObject.items[0].email;
      }
    }
    if (EmpId.manPursuitleadObject != null) {
      if (data.includes(EmpId.manPursuitleadObject.items[0].email) == false) {
        data += ',' + EmpId.manPursuitleadObject.items[0].email;
      }
    }

    console.log(">>", data);
    return data;


  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.exportDemand = function (data, headers) {
    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < headers.length; i++) {
      header.push(headers[i].headerName);
    }
    multidata.push(header);
    for (let i = 0; i < data.length; i++) {
      let array = [];
      array.push(data[i].region);
      array.push(data[i].pillar);
      array.push(data[i].OptyID);
      array.push(data[i].SLID);
      array.push(data[i].account);
      array.push(data[i].PursuitName);
      array.push(data[i].Closemonth);
      array.push(data[i].tcvOracle);
      array.push(data[i].probability);
      array.push(data[i].stg);
      array.push(data[i].pStatus);
      array.push(data[i].demandsCreatedOnshore);
      array.push(data[i].demandsCreatedOffshore);
      array.push(data[i].demandsCancelledOnshore);
      array.push(data[i].demandsCancelledOffshore);
      array.push(data[i].demandsRemarks);
      multidata.push(array);
    }
    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Demand Dashboard");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Demand Dashboard"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    function FileToBytes(s) {
      var buf = new ArrayBuffer(s.length);
      var view = new Uint8Array(buf);
      for (var i = 0; i < s.length; i++)
        view[i] = s.charCodeAt(i) & 0xFF;
      return buf;
    }

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Demand Dashboard_" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }

  };

  PageModule.prototype.email = function (empBo, active, assign1, assign2) {
    var array = assign2 + ',';
    if (assign2 != 1) {
      if (active.manPursuitgovernance != null) {
        if (array.includes((empBo.find(ele => ele.id == active.manPursuitgovernance)).email) == false) {
          array += (empBo.find(ele => ele.id == active.manPursuitgovernance)).email + ',';
        }
      }
      if (active.manPursuitlead != null) {
        if (array.includes((empBo.find(ele => ele.id == active.manPursuitlead)).email) == false) {
          array += (empBo.find(ele => ele.id == active.manPursuitlead)).email;
        }
      }
      return array;
    }
    else {

      if (active.manPursuitgovernance != null) {
        if (array.includes((empBo.find(ele => ele.id == active.manPursuitgovernance)).email) == false) {
          array = (empBo.find(ele => ele.id == active.manPursuitgovernance)).email + ',';
        }
      }
      if (active.manPursuitlead != null) {
        if (array.includes((empBo.find(ele => ele.id == active.manPursuitlead)).email) == false) {
          if (active.manPursuitgovernance == null) {
            array = (empBo.find(ele => ele.id == active.manPursuitlead)).email + ',';
          }
          else {
            array += (empBo.find(ele => ele.id == active.manPursuitlead)).email + ',';
          }
        }
      }

      for (var i = 0; i < assign1.length; i++) {

        if (i == assign1.length - 1) {
          if (array.includes((empBo.find(ele => ele.employeeID == assign1[i])).email) == false) {
            array += (empBo.find(ele => ele.employeeID == assign1[i])).email;
          }
        }

        else {
          if (array.includes((empBo.find(ele => ele.employeeID == assign1[i])).email) == false) {
            array += (empBo.find(ele => ele.employeeID == assign1[i])).email + ',';
          }
        }
      }
      return array;
    }


  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.approvalmail = function (EmpId, Approval, PQA_review, role, review_name) {
    var retpayload;
    var data1 = '';
    if (EmpId.manPursuitgovernanceObject.items[0] != undefined) {
      data1 = EmpId.manPursuitgovernanceObject.items[0].email;
    }
    if (EmpId.manPursuitleadObject.items[0] != undefined) {
      if (data1.includes(EmpId.manPursuitleadObject.items[0].email) == false) {
        data1 == '' ? data1 = EmpId.manPursuitleadObject.items[0].email : data1 += ',' + EmpId.manPursuitleadObject.items[0].email;
      }
    }

    if (PQA_review == 1) {
      if (Approval.approvedByObject.items[0] != undefined) {
        if (data1.includes(Approval.approvedByObject.items[0].email) == false) {
          data1 += ',' + Approval.approvedByObject.items[0].email;
        }
      }
    }

    else {
      for (var i = 0; i < role.length; i++) {
        if (review_name == 'Delivery Review') {
          if (role[i].roleId == 96) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }
        if (review_name == 'Overall OBL Review') {
          if (role[i].roleId == 98) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }
        if (review_name == 'Solution Review') {
          if (role[i].roleId == 99) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }

      }
    }
    console.log(">>", data1);
    return data1;


  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.Totalapproval = function (EmpId, Approval, BU, PQA_review, role, review_name) {
    var retpayload;
    var data1 = "amit.a.nayak@capgemini.com,david.mobbs@capgemini.com,debalin.das@capgemini.com,arun.dharbal@capgemini.com," + BU[0].businessUnitLeaderObject.items[0].email + ',' + EmpId.manPursuitgovernanceObject.items[0].email;
    if (EmpId.manPursuitgovernanceObject.items[0] != undefined) {
      if (data1.includes(EmpId.manPursuitgovernanceObject.items[0].email) == false) {
        data1 += ',' + EmpId.manPursuitleadObject.items[0].email;
      }
    }

    if (PQA_review == 1) {
      if (Approval.approvedByObject.items[0] != undefined) {
        if (data1.includes(Approval.approvedByObject.items[0].email) == false) {
          data1 += ',' + Approval.approvedByObject.items[0].email;
        }
      }

    }
    else {
      for (var i = 0; i < role.length; i++) {
        if (review_name == 'Delivery Review') {
          if (role[i].roleId == 96) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }
        if (review_name == 'Overall OBL Review') {
          if (role[i].roleId == 98) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }
        if (review_name == 'Solution Review') {
          if (role[i].roleId == 99) {
            if (data1.includes(role[i].employeeIdObject.items[0].email) == false) {
              data1 += ',' + role[i].employeeIdObject.items[0].email;
            }

          }

        }
      }
    }
    console.log(">>", data1);
    return data1;


  };
  // PageModule.prototype.revenue=function(revenueObject,total){
  //  total.totalRevenue=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar)+parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun)+parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep)+parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.Q1=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar);
  //  total.Q2=parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun);
  //  total.Q3=parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep);
  //  total.Q4=parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.H1=total.Q1+total.Q2;
  //  total.H2=total.Q3+total.Q4;

  //  return total;
  // };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.moredetails = function (details) {

    //  var columnStyle = "text-align: center; vertical-align: middle;";
    var body = '';

    body += "<head> <style> sty{text-align: center; vertical-align: middle;} table { font-family: arial, sans-serif; border-collapse: collapse; width: 60%; } td, th { border: 1px solid; text-align:left; padding: 10px; } th { background-color: #ADD8E6; text-align:center; } </style> </head> <br>";

    var approver1 = details.find(ele => ele.reviewName == 'PQA Review');
    var approver2 = details.find(ele1 => ele1.reviewName == 'Delivery Review');
    var approver3 = details.find(ele2 => ele2.reviewName == 'Solution Review');
    var approver4 = details.find(ele3 => ele3.reviewName == 'Overall OBL Review');

    body += "<table><tr> <th>Review Name</th> <th>Approver Name</th> <th>Approval Date</th> </tr>";
    if (approver1) {
      if (approver1.approvedByObject.items[0]) {
        body += "<tr><td>" + 'PQA Review' + "</td><td>" + approver1.approvedByObject.items[0].name + "</td><td>" + dateFormat(approver1.approvalDate) + "</td></tr>";
      }
    }

    if (approver2) {
      if (approver2.approvedByObject.items[0]) {
        body += "<tr><td>" + 'Delivery Review' + "</td><td>" + approver2.approvedByObject.items[0].name + "</td><td>" + dateFormat(approver2.approvalDate) + "</td></tr>";
      }
    }

    if (approver3) {
      if (approver3.approvedByObject.items[0]) {
        body += "<tr><td>" + 'Solution Review' + "</td><td>" + approver3.approvedByObject.items[0].name + "</td><td>" + dateFormat(approver3.approvalDate) + "</td></tr>";
      }
    }

    if (approver4) {
      if (approver4.approvedByObject.items[0]) {
        body += "<tr><td>" + 'Overall OBL Review' + "</td><td>" + approver4.approvedByObject.items[0].name + "</td><td>" + dateFormat(approver4.approvalDate) + "</td></tr>";
      }
    }


    body += "</table><br><br>";

    return body;
  };


  PageModule.prototype.UpdateNLcatagory = function (bus, prob) {

    prob = prob.trim();

    if ((prob == '0' || prob == null || prob == undefined || prob == '' || prob == '10' || prob == '20' || prob == '30' || prob == '40') && (bus == 'E-BUS(NetNew)' || bus == 'N-BUS(NewLogo)')) {
      return 'N-Deal Rev. LP (NL Cat. B) 10%';
    }
    else if ((prob == '50' || prob == '60' || prob == '70') && (bus == 'E-BUS(NetNew)' || bus == 'N-BUS(NewLogo)')) {
      return 'Y-Deal Rev. MP (NL Cat. B) 60%';
    }
    else if ((prob == '80' || prob == '90' || prob == '99') && (bus == 'E-BUS(NetNew)' || bus == 'N-BUS(NewLogo)')) {
      return 'Y-Deal Rev. HP (NL Cat. B) 90%'
    }
    else if (prob == '100' && (bus == 'E-BUS(NetNew)' || bus == 'N-BUS(NewLogo)')) {
      return 'Y-Firm'
    }
    else if ((prob == '0' || prob == null || prob == undefined || prob == '' || prob == '10' || prob == '20' || prob == '30' || prob == '40') && (bus == 'E-BUS(renewals)')) {
      return 'N-Extensions LP (NL Cat. A) 30%'
    }
    else if ((prob == '50' || prob == '60' || prob == '70' || prob == '80') && (bus == 'E-BUS(renewals)')) {
      return 'Y-Extensions MP (NL Cat. A) 80%'
    }
    else if ((prob == '90' || prob == '99') && (bus == 'E-BUS(renewals)')) {
      return 'Y-Extensions HP (NL Cat. A) 99%'
    }
    else if (prob == '100' && (bus == 'E-BUS(renewals)')) {
      return 'Y-Firm'
    }



  };

  PageModule.prototype.bus = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var month = date1[i];

      dateRanges.push("(" + "bus ='" + month + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND(" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };

  //  PageModule.prototype.revenue=function(revenueObject,total){
  //  total.totalRevenue=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar)+parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun)+parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep)+parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.Q1=parseInt(revenueObject.jan)+parseInt(revenueObject.feb)+parseInt(revenueObject.mar);
  //  total.Q2=parseInt(revenueObject.apr)+parseInt(revenueObject.may)+parseInt(revenueObject.jun);
  //  total.Q3=parseInt(revenueObject.jul)+parseInt(revenueObject.aug)+parseInt(revenueObject.sep);
  //  total.Q4=parseInt(revenueObject.oct)+parseInt(revenueObject.nov)+parseInt(revenueObject.dec1);
  //  total.H1=total.Q1+total.Q2;
  //  total.H2=total.Q3+total.Q4;

  //  return total;
  // };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  PageModule.prototype.BU = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var BU = date1[i];

      dateRanges.push("(" + "manMu ='" + BU + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };




  PageModule.prototype.accountname = function (accntname, adpvar) {


    var queryString = "";
    var acctnamearray = [];

    for (var i = 0; i < adpvar.length; i++) {
      if (adpvar[i].AccountName.toLowerCase().startsWith(accntname.toLowerCase())) {
        acctnamearray.push("(" + "manAccount ='" + adpvar[i].AccountName + "' " + ")");
      }
    }

    if (acctnamearray.length == 1) {
      queryString = "AND " + acctnamearray[0];
    }
    else if (acctnamearray.length > 1) {
      queryString = "AND (" + acctnamearray.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };












  PageModule.prototype.Regionfun = function (regionarray) {
    var queryString = "";
    var regiondata = [];
    var defaultdata = ['North America', 'APAC', 'NCE', 'SCE'];

    for (var i = 0; i < regionarray.length; i++) {
      var reg = regionarray[i];

      regiondata.push("(" + "region ='" + reg + "' " + ")");
    }

    if (regionarray.length == 0) {
      // queryString = "AND (" + "(region = 'North America' )" + "OR" + "(region = 'APAC' )" + "OR" + "(region = 'SCE' )" + "OR" + "(region = 'NCE'" + )"
      queryString = `AND ( (region = '${defaultdata[0]}') OR (region = '${defaultdata[1]}') OR (region = '${defaultdata[2]}') OR (region = '${defaultdata[3]}'))`;
    }
    if (regiondata.length == 1) {
      queryString = "AND " + regiondata[0];
    }
    else if (regiondata.length > 1) {
      queryString = "AND (" + regiondata.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  }







  PageModule.prototype.pillar = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var BU = date1[i];

      dateRanges.push("(" + "manPillar ='" + BU + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };



  PageModule.prototype.StageGroup = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var BU = date1[i];

      dateRanges.push("(" + "manStageGrp ='" + BU + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };

  PageModule.prototype.MU = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var MU = date1[i];

      dateRanges.push("(" + "manBu ='" + MU + "' " + ")");
    }
    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };

  PageModule.prototype.Domain1 = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var MU = date1[i];

      dateRanges.push("(" + "module1Object.shortName ='" + MU + "' " + ")");
    }
    if (dateRanges.length == 1) {
      queryString = "AND " + dateRanges;
    }
    else if (dateRanges.length > 1) {
      queryString = "AND (" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };


  PageModule.prototype.ReportsBU = function (date1) {


    var queryString = "";
    var dateRanges = [];

    for (var i = 0; i < date1.length; i++) {
      var BU = date1[i];

      dateRanges.push("(" + "manMu ='" + BU + "' " + ")");
    }

    if (dateRanges.length == 1) {
      queryString = dateRanges[0];
    }
    else if (dateRanges.length > 1) {
      queryString = "(" + dateRanges.join(" OR ") + ")";
    }

    console.log(queryString);
    return queryString;
  };


  PageModule.prototype.AccountADP = function (actAcc) {

    var data = new Array();


    for (var i = 0; i < actAcc.length; i++) {
      var ret = {};
      var acc = data.find(ele => ele.AccountName == actAcc[i].manAccount);
      if (acc == undefined && actAcc[i].manAccount != null) {


        ret['AccountName'] = actAcc[i].manAccount;
        ret['id'] = actAcc[i].id;


        data.push(ret);
      }
    }
    return data;

  };

  PageModule.prototype.exportTable = function (empData, dataArray) {
    var data = new Array();
    var header = new Array();
    for (let i = 0; i < dataArray.length; i++) {
      header.push(dataArray[i].headerName);
    }
    data.push(header);
    for (let i = 0; i < empData.length; i++) {
      var instanceArray = [];
      instanceArray.push(empData[i].region);
      instanceArray.push(empData[i].optyId);
      instanceArray.push(empData[i].slId);
      instanceArray.push(empData[i].opportunity);
      instanceArray.push(empData[i].account);
      instanceArray.push(empData[i].mU);
      instanceArray.push(empData[i].primaryTechnology);
      instanceArray.push(empData[i].closeMonth != undefined ? dateFormat(empData[i].closeMonth) : 'NA');
      instanceArray.push(empData[i].convertedBkg);
      instanceArray.push(empData[i].probability);
      data.push(instanceArray);
    }
    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Non Qualified Pursuit");
    var ws = XLSX.utils.aoa_to_sheet(data);
    wb.Sheets["Non Qualified Pursuit"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Non Qualified Pursuit_" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }


  };

  function dateFormat(bo_date) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var date = new Date(bo_date);
    var reqd_date = (date.getDate() < 10 ? '0' + date.getDate() : '' + date.getDate()) + '-' + months[date.getMonth()] + '-' + date.getFullYear();
    return reqd_date;
  }




  PageModule.prototype.SixtyDayRep = function () {

    // var selectedMonths = date1;
    var queryString = "";
    var dateRanges = [];

    // for (var i = 0; i < selectedMonths.length; i++) {
    // var month = selectedMonths[i];
    var startDate, endDate;

    var date1 = new Date();
    var dAy = date1.getDate();
    var day = dAy < '15' ? '15' : '01';
    var month = date1.getMonth() < 9 ? (dAy < '15' ? '0' + (date1.getMonth()) : '0' + (date1.getMonth() + 1)) : (dAy < '15' ? '' + (date1.getMonth()) : '' + (date1.getMonth() + 1));
    var year = date1.getFullYear();
    var currentDate = `${year}-${month}-${day}`;

    var month1 = month == '12' ? '01' : (month < '9' ? '0' + (Number(month) + 1) : '' + (Number(month) + 1));
    // var day1 = day;
    var year1 = month == '12' ? Number(year) + 1 : year;
    var day1 = (getLastDayOfMonth(year1, 0)).getDate();


    var currentDate1 = `${year1}-${month1}-${day1}`;
    startDate = currentDate;
    endDate = currentDate1;

    dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ") ");

    if (dateRanges.length > 0) {
      queryString = "(" + dateRanges.join(" OR ") + ")AND ";
    }

    console.log(queryString);
    return queryString;
  };


  function getLastDayOfMonth(year, month) {
    return new Date(year, month + 1, 0);
  };


  PageModule.prototype.TwoMonthReport = function (active, status, emp) {

    var data = new Array();

    for (var x = 0; x < active.length; x++) {
      var act = status.filter(ele => ele.optyID == active[x].id);
      {
        var count = 0;
        var count1 = 0;
        //  var z;
        if (act.length > 0) {
          for (var i = 0; i < act.length; i++) {
            // if(act[i] !=undefined ){
            var date = new Date(act[i].creationDate);
            var today = new Date();

            var day2 = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
            var month2 = date.getMonth() < 9 ? '0' + (date.getMonth() + 1) : '' + (date.getMonth() + 1);
            var year2 = date.getFullYear();
            var currentDate2 = `${year2}-${month2}-${day2}`;

            var day = today.getDate() > '7' ? (today.getDate() < '17' ? '0' + (today.getDate() - 7) : today.getDate() - 7) : (30 - (7 - today.getDate()));
            var month1 = today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : '' + (today.getMonth() + 1);
            var month = today.getDate() > '7' ? month1 : (Number(month1) - 1);
            var year = month1 == 1 ? Number(today.getFullYear()) - 1 : today.getFullYear();
            var currentDate = `${year}-${month}-${day}`;

            if (currentDate2 > currentDate) {
              count++;
            }


          }
        }
        else {
          count1++;
        }


        if (count == '0' || count1 > '0') {
          var retpayload = {};
          var pLead = emp.find(ele => ele.id == active[x].manPursuitlead);
          var pGov = emp.find(ele => ele.id == active[x].manPursuitgovernance);

          retpayload['manProb'] = active[x].stgGroup == 'SOLD' ? Number(active[x].probability) : Number(active[x].manProb);
          retpayload['manStaffing'] = active[x].manStaffing;
          retpayload['manMu'] = active[x].manMu;
          retpayload['manBu'] = active[x].manBu;
          retpayload['manAccount'] = active[x].manAccount;
          retpayload['manPillar'] = active[x].manPillar;
          retpayload['manNLCategory'] = active[x].manNLCategory;
          retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
          retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['manClosemonth'] = active[x].manClosemonth;
          retpayload['manTCV'] = active[x].manTCV;
          retpayload['manTCVoracle'] = (active[x].stgGroup == 'SOLD' || active[x].stgGroup == 'LDQ') ? Number(active[x].convertedBkg) : active[x].manTCVoracle;
          //  totalTCV=totalTCV+ Number( retpayload['manTCVoracle']);
          //  retpayload['totalTCV']=totalTCV;
          retpayload['manPursuitname'] = active[x].manPursuitname;
          retpayload['optyID'] = active[x].manOptyID;
          retpayload['manSLId'] = active[x].manSLId;
          retpayload['manStageGrp'] = active[x].manStageGrp;
          retpayload['status'] = active[x].status;
          // retpayload['Z']=z;

          data.push(retpayload);
        }
      }
    }
    return data;

  };

  PageModule.prototype.SixtyDayDownload = function (Status, metaDataArray, x) {

    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < metaDataArray.length; i++) {
      header.push(metaDataArray[i].headerName);
    }
    multidata.push(header);
    const d = new Date();
    for (let i = 0; i < Status.length; i++) {




      var instanceArray = [];

      instanceArray.push(Status[i].manOptyID);
      instanceArray.push(Status[i].manSLId);
      instanceArray.push(Status[i].manPursuitlead);
      instanceArray.push(Status[i].manBu);
      instanceArray.push(Status[i].manMu);


      instanceArray.push(Status[i].manAccount);
      instanceArray.push(Status[i].manPursuitname);
      instanceArray.push(Status[i].manPillar);
      instanceArray.push(Status[i].manNLCategory);
      instanceArray.push(Status[i].manClosemonth != undefined ? dateFormat(Status[i].manClosemonth) : 'NA');
      instanceArray.push(Status[i].manTCV);
      instanceArray.push(Status[i].manTCVoracle);
      instanceArray.push(Status[i].manStageGrp);
      instanceArray.push(Status[i].manProb);
      instanceArray.push(Status[i].manStaffing);

      multidata.push(instanceArray);
    }
    var wb = XLSX.utils.book_new();
    if (x == '1') {
      wb.SheetNames.push("Active Pursuit Status Stale");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Active Pursuit Status Stale"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Active Pursuit_Status Stale_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }


    else if (x == '2') {
      wb.SheetNames.push("Active Pursuit Doc Repository");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Active Pursuit Doc Repository"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Active Pursuit_Document Repository_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }


    else if (x == '3') {
      wb.SheetNames.push("Active Pursuit Event Pursuit");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Active Pursuit Event Pursuit"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Active Pursuit_Event Pursuit_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }



    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };

  PageModule.prototype.EventPursuitReport = function (active, Event, emp) {
    var data = new Array();
    var Count = 0;
    for (var x = 0; x < active.length; x++) {
      var event = Event.filter(ele => ele.optyID == active[x].id);
      {
        Count = 0;
        for (var i = 0; i < event.length; i++) {
          if (event[i].date1 != null && event[i].applicablity != null) {
            Count++;
          }
        }
        if (Count == '0') {
          var retpayload = {};
          var pLead = emp.find(ele => ele.id == active[x].manPursuitlead);
          var pGov = emp.find(ele => ele.id == active[x].manPursuitgovernance);

          retpayload['manProb'] = active[x].stgGroup == 'SOLD' ? Number(active[x].probability) : Number(active[x].manProb);
          retpayload['manStaffing'] = active[x].manStaffing;
          retpayload['manMu'] = active[x].manMu;
          retpayload['manBu'] = active[x].manBu;
          retpayload['manAccount'] = active[x].manAccount;
          retpayload['manPillar'] = active[x].manPillar;
          retpayload['manNLCategory'] = active[x].manNLCategory;
          retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
          retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['manClosemonth'] = active[x].manClosemonth;
          retpayload['manTCV'] = active[x].manTCV;
          retpayload['manTCVoracle'] = (active[x].stgGroup == 'SOLD' || active[x].stgGroup == 'LDQ') ? Number(active[x].convertedBkg) : active[x].manTCVoracle;
          //  totalTCV=totalTCV+ Number( retpayload['manTCVoracle']);
          //  retpayload['totalTCV']=totalTCV;
          retpayload['manPursuitname'] = active[x].manPursuitname;
          retpayload['optyID'] = active[x].manOptyID;
          retpayload['manSLId'] = active[x].manSLId;
          retpayload['manStageGrp'] = active[x].manStageGrp;
          retpayload['status'] = active[x].status;


          data.push(retpayload);

        }
      }
    }
    return data;

  };

  PageModule.prototype.DocRepoReport = function (active, DocRepo, emp) {
    var data = new Array();
    var Count = 0;
    for (var x = 0; x < active.length; x++) {
      var Doc = DocRepo.filter(ele => ele.optyID == active[x].id);
      {
        Count = 0;
        for (var i = 0; i < Doc.length; i++) {
          if (Doc[i].uploadedDate != null) {
            Count++;
          }

        }
        if (Count < '8') {
          var retpayload = {};
          var pLead = emp.find(ele => ele.id == active[x].manPursuitlead);
          var pGov = emp.find(ele => ele.id == active[x].manPursuitgovernance);

          retpayload['manProb'] = active[x].stgGroup == 'SOLD' ? Number(active[x].probability) : Number(active[x].manProb);
          retpayload['manStaffing'] = active[x].manStaffing;
          retpayload['manMu'] = active[x].manMu;
          retpayload['manBu'] = active[x].manBu;
          retpayload['manAccount'] = active[x].manAccount;
          retpayload['manPillar'] = active[x].manPillar;
          retpayload['manNLCategory'] = active[x].manNLCategory;
          retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
          retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['manClosemonth'] = active[x].manClosemonth;
          retpayload['manTCV'] = active[x].manTCV;
          retpayload['manTCVoracle'] = (active[x].stgGroup == 'SOLD' || active[x].stgGroup == 'LDQ') ? Number(active[x].convertedBkg) : active[x].manTCVoracle;
          //  totalTCV=totalTCV+ Number( retpayload['manTCVoracle']);
          //  retpayload['totalTCV']=totalTCV;
          retpayload['manPursuitname'] = active[x].manPursuitname;
          retpayload['optyID'] = active[x].manOptyID;
          retpayload['manSLId'] = active[x].manSLId;
          retpayload['manStageGrp'] = active[x].manStageGrp;
          retpayload['status'] = active[x].status;


          data.push(retpayload);

        }
      }

    }
    return data;

  };

  PageModule.prototype.TCVreport = function (pursuitBO) {
    var data = [];
    var totalTCV = 0;
    var retpayload = {};
    var retpayload1 = {};
    var retpayload2 = {};
    var retpayload3 = {};
    var retpayload4 = {};
    var retpayload5 = {};
    var retpayload6 = {};
    var tcvJan = 0; var tcvFeb = 0; var tcvMar = 0; var tcvApr = 0; var tcvMay = 0; var tcvJun = 0; var tcvJul = 0; var tcvAug = 0; var tcvSep = 0; var tcvOct = 0; var tcvNov = 0; var tcvDec = 0;
    var tcvJanM = 0; var tcvFebM = 0; var tcvMarM = 0; var tcvAprM = 0; var tcvMayM = 0; var tcvJunM = 0; var tcvJulM = 0; var tcvAugM = 0; var tcvSepM = 0; var tcvOctM = 0; var tcvNovM = 0; var tcvDecM = 0;
    var tcvJanE = 0; var tcvFebE = 0; var tcvMarE = 0; var tcvAprE = 0; var tcvMayE = 0; var tcvJunE = 0; var tcvJulE = 0; var tcvAugE = 0; var tcvSepE = 0; var tcvOctE = 0; var tcvNovE = 0; var tcvDecE = 0;
    var tcvJanL = 0; var tcvFebL = 0; var tcvMarL = 0; var tcvAprL = 0; var tcvMayL = 0; var tcvJunL = 0; var tcvJulL = 0; var tcvAugL = 0; var tcvSepL = 0; var tcvOctL = 0; var tcvNovL = 0; var tcvDecL = 0;
    var tcvJanS = 0; var tcvFebS = 0; var tcvMarS = 0; var tcvAprS = 0; var tcvMayS = 0; var tcvJunS = 0; var tcvJulS = 0; var tcvAugS = 0; var tcvSepS = 0; var tcvOctS = 0; var tcvNovS = 0; var tcvDecS = 0;
    var tcvJanR = 0; var tcvFebR = 0; var tcvMarR = 0; var tcvAprR = 0; var tcvMayR = 0; var tcvJunR = 0; var tcvJulR = 0; var tcvAugR = 0; var tcvSepR = 0; var tcvOctR = 0; var tcvNovR = 0; var tcvDecR = 0;
    var tcvJanT = 0; var tcvFebT = 0; var tcvMarT = 0; var tcvAprT = 0; var tcvMayT = 0; var tcvJunT = 0; var tcvJulT = 0; var tcvAugT = 0; var tcvSepT = 0; var tcvOctT = 0; var tcvNovT = 0; var tcvDecT = 0;
    var totalTCVtmt = 0;
    var totalTCVcanada = 0;
    var totalTCVsogeti = 0;
    var totalTCVmals = 0;
    var totalTCVcprs = 0;
    var totalTCVeuc = 0;
    var totalTCVlatam = 0;
    var month;
    for (var i = 0; i < pursuitBO.length; i++) {

      if (pursuitBO[i].manClosemonth == undefined) {
        month = 0;
      }
      else { month = pursuitBO[i].manClosemonth.substring(5, 7); }

      var nn = (pursuitBO[i].manStageGrp == 'SOLD' || pursuitBO[i].manStageGrp == 'LDQ') ? Number(pursuitBO[i].convertedBkg) : pursuitBO[i].manTCVoracle;

      if (pursuitBO[i].manMu == "CANADA" || pursuitBO[i].manMu == "Canada") {

        totalTCVcanada = totalTCVcanada + Number(nn);
        if (month == "01") {
          tcvJan = tcvJan + Number(nn);
        }
        else if (month == "02") {
          tcvFeb = tcvFeb + Number(nn);
        }
        else if (month == "03") {
          tcvMar = tcvMar + Number(nn);
        }
        else if (month == "04") {
          tcvApr = tcvApr + Number(nn);
        }
        else if (month == "05") {
          tcvMay = tcvMay + Number(nn);
        }
        else if (month == "06") {
          tcvJun = tcvJun + Number(nn);
        }
        else if (month == "07") {
          tcvJul = tcvJul + Number(nn);
        }
        else if (month == "08") {
          tcvAug = tcvAug + Number(nn);
        }
        else if (month == "09") {
          tcvSep = tcvSep + Number(nn);
        }
        else if (month == "10") {
          tcvOct = tcvOct + Number(nn);
        }
        else if (month == "11") {
          tcvNov = tcvNov + Number(nn);
        }
        else if (month == "12") {
          tcvDec = tcvDec + Number(nn);
        }

      }
      else if (pursuitBO[i].manMu == "MALS" || pursuitBO[i].manMu == "Mals") {

        totalTCVmals = totalTCVmals + Number(nn);
        if (month == "01") {
          tcvJanM = tcvJanM + Number(nn);
        }
        else if (month == "02") {
          tcvFebM = tcvFebM + Number(nn);
        }
        else if (month == "03") {
          tcvMarM = tcvMarM + Number(nn);
        }
        else if (month == "04") {
          tcvAprM = tcvAprM + Number(nn);
        }
        else if (month == "05") {
          tcvMayM = tcvMayM + Number(nn);
        }
        else if (month == "06") {
          tcvJunM = tcvJunM + Number(nn);
        }
        else if (month == "07") {
          tcvJulM = tcvJulM + Number(nn);
        }
        else if (month == "08") {
          tcvAugM = tcvAugM + Number(nn);
        }
        else if (month == "09") {
          tcvSepM = tcvSepM + Number(nn);
        }
        else if (month == "10") {
          tcvOctM = tcvOctM + Number(nn);
        }
        else if (month == "11") {
          tcvNovM = tcvNovM + Number(nn);
        }
        else if (month == "12") {
          tcvDecM = tcvDecM + Number(nn);
        }
      }
      else if (pursuitBO[i].manMu == "R&ET" || pursuitBO[i].manMu == "EUC") {

        totalTCVeuc = totalTCVeuc + Number(nn);
        if (month == "01") {
          tcvJanE = tcvJanE + Number(nn);
        }
        else if (month == "02") {
          tcvFebE = tcvFebE + Number(nn);
        }
        else if (month == "03") {
          tcvMarE = tcvMarE + Number(nn);
        }
        else if (month == "04") {
          tcvAprE = tcvAprE + Number(nn);
        }
        else if (month == "05") {
          tcvMayE = tcvMayE + Number(nn);
        }
        else if (month == "06") {
          tcvJunE = tcvJunE + Number(nn);
        }
        else if (month == "07") {
          tcvJulE = tcvJulE + Number(nn);
        }
        else if (month == "08") {
          tcvAugE = tcvAugE + Number(nn);
        }
        else if (month == "09") {
          tcvSepE = tcvSepE + Number(pursuitBO[i].manTCVoracle);
        }
        else if (month == "10") {
          tcvOctE = tcvOctE + Number(nn);
        }
        else if (month == "11") {
          tcvNovE = tcvNovE + Number(nn);
        }
        else if (month == "12") {
          tcvDecE = tcvDecE + Number(nn);
        }
      }
      else if (pursuitBO[i].manMu == "LATAM" || pursuitBO[i].manMu == "Latam") {

        totalTCVlatam = totalTCVlatam + Number(nn);
        if (month == "01") {
          tcvJanL = tcvJanL + Number(nn);
        }
        else if (month == "02") {
          tcvFebL = tcvFebL + Number(nn);
        }
        else if (month == "03") {
          tcvMarL = tcvMarL + Number(nn);
        }
        else if (month == "04") {
          tcvAprL = tcvAprL + Number(nn);
        }
        else if (month == "05") {
          tcvMayL = tcvMayL + Number(nn);
        }
        else if (month == "06") {
          tcvJunL = tcvJunL + Number(nn);
        }
        else if (month == "07") {
          tcvJulL = tcvJulL + Number(nn);
        }
        else if (month == "08") {
          tcvAugL = tcvAugL + Number(nn);
        }
        else if (month == "09") {
          tcvSepL = tcvSepL + Number(nn);
        }
        else if (month == "10") {
          tcvOctL = tcvOctL + Number(nn);
        }
        else if (month == "11") {
          tcvNovL = tcvNovL + Number(nn);
        }
        else if (month == "12") {
          tcvDecL = tcvDecL + Number(nn);
        }
      }
      else if (pursuitBO[i].manMu == "SOGETI" || pursuitBO[i].manMu == "Sogeti") {

        totalTCVsogeti = totalTCVsogeti + Number(nn);
        if (month == "01") {
          tcvJanS = tcvJanS + Number(nn);
        }
        else if (month == "02") {
          tcvFebS = tcvFebS + Number(nn);
        }
        else if (month == "03") {
          tcvMarS = tcvMarS + Number(nn);
        }
        else if (month == "04") {
          tcvAprS = tcvAprS + Number(nn);
        }
        else if (month == "05") {
          tcvMayS = tcvMayS + Number(nn);
        }
        else if (month == "06") {
          tcvJunS = tcvJunS + Number(nn);
        }
        else if (month == "07") {
          tcvJulS = tcvJulS + Number(nn);
        }
        else if (month == "08") {
          tcvAugS = tcvAugS + Number(nn);
        }
        else if (month == "09") {
          tcvSepS = tcvSepS + Number(nn);
        }
        else if (month == "10") {
          tcvOctS = tcvOctS + Number(nn);
        }
        else if (month == "11") {
          tcvNovS = tcvNovS + Number(nn);
        }
        else if (month == "12") {
          tcvDecS = tcvDecS + Number(nn);
        }
      }
      else if (pursuitBO[i].manMu == "CPR&S") {


        totalTCVcprs = totalTCVcprs + Number(nn);
        if (month == "01") {
          tcvJanR = tcvJanR + Number(nn);
        }
        else if (month == "02") {
          tcvFebR = tcvFebR + Number(nn);
        }
        else if (month == "03") {
          tcvMarR = tcvMarR + Number(nn);
        }
        else if (month == "04") {
          tcvAprR = tcvAprR + Number(nn);
        }
        else if (month == "05") {
          tcvMayR = tcvMayR + Number(nn);
        }
        else if (month == "06") {
          tcvJunR = tcvJunR + Number(nn);
        }
        else if (month == "07") {
          tcvJulR = tcvJulR + Number(nn);
        }
        else if (month == "08") {
          tcvAugR = tcvAugR + Number(nn);
        }
        else if (month == "09") {
          tcvSepR = tcvSepR + Number(nn);
        }
        else if (month == "10") {
          tcvOctR = tcvOctR + Number(nn);
        }
        else if (month == "11") {
          tcvNovR = tcvNovR + Number(nn);
        }
        else if (month == "12") {
          tcvDecR = tcvDecR + Number(nn);
        }
      }
      else if (pursuitBO[i].manMu == "TMT") {

        totalTCVtmt = totalTCVtmt + Number(nn);
        if (month == "01") {
          tcvJanT = tcvJanT + Number(nn);
        }
        else if (month == "02") {
          tcvFebT = tcvFebT + Number(nn);
        }
        else if (month == "03") {
          tcvMarT = tcvMarT + Number(nn);
        }
        else if (month == "04") {
          tcvAprT = tcvAprT + Number(nn);
        }
        else if (month == "05") {
          tcvMayT = tcvMayT + Number(nn);
        }
        else if (month == "06") {
          tcvJunT = tcvJunT + Number(nn);
        }
        else if (month == "07") {
          tcvJulT = tcvJulT + Number(nn);
        }
        else if (month == "08") {
          tcvAugT = tcvAugT + Number(nn);
        }
        else if (month == "09") {
          tcvSepT = tcvSepT + Number(nn);
        }
        else if (month == "10") {
          tcvOctT = tcvOctT + Number(nn);
        }
        else if (month == "11") {
          tcvNovT = tcvNovT + Number(nn);
        }
        else if (month == "12") {
          tcvDecT = tcvDecT + Number(nn);
        }
      }

    }
    retpayload1["bu"] = "SOGETI";
    retpayload1["Total"] = totalTCVsogeti;
    retpayload1["jan"] = tcvJanS; retpayload1["feb"] = tcvFebS; retpayload1["mar"] = tcvMarS; retpayload1["apr"] = tcvAprS; retpayload1["may"] = tcvMayS; retpayload1["jun"] = tcvJunS; retpayload1["jul"] = tcvJulS; retpayload1["aug"] = tcvAugS; retpayload1["sep"] = tcvSepS; retpayload1["oct"] = tcvOctS; retpayload1["nov"] = tcvNovS; retpayload1["dec"] = tcvDecS;

    retpayload2["bu"] = "MALS";
    retpayload2["Total"] = totalTCVmals;
    retpayload2["jan"] = tcvJanM; retpayload2["feb"] = tcvFebM; retpayload2["mar"] = tcvMarM; retpayload2["apr"] = tcvAprM; retpayload2["may"] = tcvMayM; retpayload2["jun"] = tcvJunM; retpayload2["jul"] = tcvJulM; retpayload2["aug"] = tcvAugM; retpayload2["sep"] = tcvSepM; retpayload2["oct"] = tcvOctM; retpayload2["nov"] = tcvNovM; retpayload2["dec"] = tcvDecM;

    retpayload3["bu"] = "R&ET";
    retpayload3["Total"] = totalTCVeuc;
    retpayload3["jan"] = tcvJanE; retpayload3["feb"] = tcvFebE; retpayload3["mar"] = tcvMarE; retpayload3["apr"] = tcvAprE; retpayload3["may"] = tcvMayE; retpayload3["jun"] = tcvJunE; retpayload3["jul"] = tcvJulE; retpayload3["aug"] = tcvAugE; retpayload3["sep"] = tcvSepE; retpayload3["oct"] = tcvOctE; retpayload3["nov"] = tcvNovE; retpayload3["dec"] = tcvDecE;

    retpayload6["bu"] = "LATAM";
    retpayload6["Total"] = totalTCVlatam;
    retpayload6["jan"] = tcvJanL; retpayload6["feb"] = tcvFebL; retpayload6["mar"] = tcvMarL; retpayload6["apr"] = tcvAprL; retpayload6["may"] = tcvMayL; retpayload6["jun"] = tcvJunL; retpayload6["jul"] = tcvJulL; retpayload6["aug"] = tcvAugL; retpayload6["sep"] = tcvSepL; retpayload6["oct"] = tcvOctL; retpayload6["nov"] = tcvNovL; retpayload6["dec"] = tcvDecL;

    retpayload5["bu"] = "CPR&S";
    retpayload5["Total"] = totalTCVcprs;
    retpayload5["jan"] = tcvJanR; retpayload5["feb"] = tcvFebR; retpayload5["mar"] = tcvMarR; retpayload5["apr"] = tcvAprR; retpayload5["may"] = tcvMayR; retpayload5["jun"] = tcvJunR; retpayload5["jul"] = tcvJulR; retpayload5["aug"] = tcvAugR; retpayload5["sep"] = tcvSepR; retpayload5["oct"] = tcvOctR; retpayload5["nov"] = tcvNovR; retpayload5["dec"] = tcvDecR;

    retpayload4["bu"] = "CANADA";
    retpayload4["jan"] = tcvJan; retpayload4["feb"] = tcvFeb; retpayload4["mar"] = tcvMar; retpayload4["apr"] = tcvApr; retpayload4["may"] = tcvMay; retpayload4["jun"] = tcvJun; retpayload4["jul"] = tcvJul; retpayload4["aug"] = tcvAug; retpayload4["sep"] = tcvSep; retpayload4["oct"] = tcvOct; retpayload4["nov"] = tcvNov; retpayload4["dec"] = tcvDec;
    retpayload4["Total"] = totalTCVcanada;

    retpayload["bu"] = "TMT";
    retpayload["Total"] = totalTCVtmt;
    retpayload["jan"] = tcvJanT; retpayload["feb"] = tcvFebT; retpayload["mar"] = tcvMarT; retpayload["apr"] = tcvAprT; retpayload["may"] = tcvMayT; retpayload["jun"] = tcvJunT; retpayload["jul"] = tcvJulT; retpayload["aug"] = tcvAugT; retpayload["sep"] = tcvSepT; retpayload["oct"] = tcvOctT; retpayload["nov"] = tcvNovT; retpayload["dec"] = tcvDecT;

    data.push(retpayload4);
    data.push(retpayload5);
    data.push(retpayload3);
    data.push(retpayload2);
    data.push(retpayload1);
    data.push(retpayload6);
    data.push(retpayload);
    var ret = {};
    ret['bu'] = 'TOTAL';
    ret['jan'] = Number(tcvJanS) + Number(tcvJanM) + Number(tcvJanE) + Number(tcvJanL) + Number(tcvJanR) + Number(tcvJan) + Number(tcvJanT);
    ret['feb'] = Number(tcvFebS) + Number(tcvFebM) + Number(tcvFebE) + Number(tcvFebL) + Number(tcvFebR) + Number(tcvFeb) + Number(tcvFebT);
    ret['mar'] = Number(tcvMarS) + Number(tcvMarM) + Number(tcvMarE) + Number(tcvMarL) + Number(tcvMarR) + Number(tcvMar) + Number(tcvMarT);
    ret['apr'] = Number(tcvAprS) + Number(tcvAprM) + Number(tcvAprE) + Number(tcvAprL) + Number(tcvAprR) + Number(tcvApr) + Number(tcvAprT);
    ret['may'] = Number(tcvMayS) + Number(tcvMayM) + Number(tcvMayE) + Number(tcvMayL) + Number(tcvMayR) + Number(tcvMay) + Number(tcvMayT);
    ret['jun'] = Number(tcvJunS) + Number(tcvJunM) + Number(tcvJunE) + Number(tcvJunL) + Number(tcvJunR) + Number(tcvJun) + Number(tcvJunT);
    ret['jul'] = Number(tcvJulS) + Number(tcvJulM) + Number(tcvJulE) + Number(tcvJulL) + Number(tcvJulR) + Number(tcvJul) + Number(tcvJulT);
    ret['aug'] = Number(tcvAugS) + Number(tcvAugM) + Number(tcvAugE) + Number(tcvAugL) + Number(tcvAugR) + Number(tcvAug) + Number(tcvAugT);
    ret['sep'] = Number(tcvSepS) + Number(tcvSepM) + Number(tcvSepE) + Number(tcvSepL) + Number(tcvSepR) + Number(tcvSep) + Number(tcvSepT);
    ret['oct'] = Number(tcvOctS) + Number(tcvOctM) + Number(tcvOctE) + Number(tcvOctL) + Number(tcvOctR) + Number(tcvOct) + Number(tcvOctT);
    ret['nov'] = Number(tcvNovS) + Number(tcvNovM) + Number(tcvNovE) + Number(tcvNovL) + Number(tcvNovR) + Number(tcvNov) + Number(tcvNovT);
    ret['dec'] = Number(tcvDecS) + Number(tcvDecM) + Number(tcvDecE) + Number(tcvDecL) + Number(tcvDecR) + Number(tcvDec) + Number(tcvDecT);
    ret['Total'] = Number(totalTCVsogeti) + Number(totalTCVmals) + Number(totalTCVeuc) + Number(totalTCVlatam) + Number(totalTCVcprs) + Number(totalTCVcanada) + Number(totalTCVtmt);
    data.push(ret);
    console.log("55#", data);
    return data;
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  //   month1() {
  // // var date1="Jan";
  // var selectedMonths = "Jan";
  // var queryString = "";
  // var dateRanges = [];


  //   var startDate="2023-01-01";
  //   var endDate="2023-12-31";



  //   dateRanges.push("(" + "manClosemonth BETWEEN '" + startDate + "' AND '" + endDate + "'" + ")");


  // if (dateRanges.length > 0) {
  //   queryString = "(" + dateRanges.join(" OR ") + ")AND";
  // }
  // return queryString;
  //   }

  PageModule.prototype.lostAnalysis = function (Active) {

    var data = [];
    var jan = 0;
    var feb = 0;
    var mar = 0;
    var apr = 0;
    var may = 0;
    var jun = 0;
    var jul = 0;
    var aug = 0;
    var sep = 0;
    var oct = 0;
    var nov = 0;
    var dec = 0;

    var reasons = ['Articulation of Value proposition', 'Understanding of Client Business Case', 'Pricing and High Rates',
      'Appropriated reference', 'Decision Impacted Analyst Ratings', 'Key differentiators compared to Competitors', 'Impact of Subcon Usage',
      'Staffing Issue', '3rd Party Vendor Relationship', 'Others'];


    for (var i = 0; i < reasons.length; i++) {
      var one = Active.filter(ele => ele.lost == reasons[i]);
      var ret = {};
      ret['Reason'] = reasons[i];
      ret['Jan'] = one.filter(ele => ele.manClosemonth == '2023-01-01').length;
      jan += ret['Jan'];
      ret['Feb'] = one.filter(ele => ele.manClosemonth == '2023-02-01').length;
      feb += ret['Feb'];
      ret['Mar'] = one.filter(ele => ele.manClosemonth == '2023-03-01').length;
      mar += ret['Mar'];
      ret['Apr'] = one.filter(ele => ele.manClosemonth == '2023-04-01').length;
      apr += ret['Apr'];
      ret['May'] = one.filter(ele => ele.manClosemonth == '2023-05-01').length;
      may += ret['May'];
      ret['Jun'] = one.filter(ele => ele.manClosemonth == '2023-06-01').length;
      jun += ret['Jun'];
      ret['Jul'] = one.filter(ele => ele.manClosemonth == '2023-07-01').length;
      jul += ret['Jul'];
      ret['Aug'] = one.filter(ele => ele.manClosemonth == '2023-08-01').length;
      aug += ret['Aug'];
      ret['Sep'] = one.filter(ele => ele.manClosemonth == '2023-09-01').length;
      sep += ret['Sep'];
      ret['Oct'] = one.filter(ele => ele.manClosemonth == '2023-10-01').length;
      oct += ret['Oct'];
      ret['Nov'] = one.filter(ele => ele.manClosemonth == '2023-11-01').length;
      nov += ret['Nov'];
      ret['Dec'] = one.filter(ele => ele.manClosemonth == '2023-12-01').length;
      dec += ret['Dec'];
      ret['total'] = Number(ret['Jan']) + Number(ret['Feb']) + Number(ret['Mar']) + Number(ret['Apr']) + Number(ret['May']) + Number(ret['Jun']) + Number(ret['Jul']) + Number(ret['Aug']) + Number(ret['Sep']) + Number(ret['Oct']) + Number(ret['Nov']) + Number(ret['Dec']);

      data.push(ret);
    }
    {
      var ret = {};

      ret['Reason'] = 'TOTAL';
      ret['Jan'] = jan;
      ret['Feb'] = feb;
      ret['Mar'] = mar;
      ret['Apr'] = apr;
      ret['May'] = may;
      ret['Jun'] = jun;
      ret['Jul'] = jul;
      ret['Aug'] = aug;
      ret['Sep'] = sep;
      ret['Oct'] = oct;
      ret['Nov'] = nov;
      ret['Dec'] = dec;
      ret['total'] = Number(ret['Jan']) + Number(ret['Feb']) + Number(ret['Mar']) + Number(ret['Apr']) + Number(ret['May']) + Number(ret['Jun']) + Number(ret['Jul']) + Number(ret['Aug']) + Number(ret['Sep']) + Number(ret['Oct']) + Number(ret['Nov']) + Number(ret['Dec']);

      data.push(ret);
    }
    return data;

  };

  PageModule.prototype.getReportsData = function (P_emp, report, active, revenueBO, input, status) {
    var data = new Array();
    var totalTCV = 0;
    var toalRevenueForecast = 0;
    var P_main;
    var statusBO;
    for (var j = 0; j < report.length; j++) {
      if (input == '2') {
        P_main = active.find(ele33 => ele33.id == report[j].optyID);
      }
      if (input != '2') {
        P_main = active.find(ele33 => ele33.manSLId == report[j].manSLId);
      }

      if (input == '4') {
        P_main = active.find(ele33 => ele33.manSLId == report[j].slId);
      }

      if (input == '6') {
        P_main = active.find(ele33 => ele33.manSLId == report[j].manSLId);
        statusBO = status.find(ele => ele.optyID == P_main.id)
      }
      if (input == '1') {
        P_main = active.find(ele33 => ele33.manSLId == report[j].sLID);
      }

      // for(var i=0;i<P_main.length;i++)

      {
        var pLead = P_main.manPursuitlead ? P_emp.find(ele => ele.id == P_main.manPursuitlead) : undefined;
        var pGov = P_main.manPursuitgovernance ? P_emp.find(ele => ele.id == P_main.manPursuitgovernance) : undefined;
        var revenue = revenueBO.find(ele => ele.sLID == P_main.id);
        //  var mu=P_mu.find(ele=>ele.id==P_main[i].mUAltName)
        //  var client=P_client.find(ele=>ele.id==P_main[i].account)
        var retpayload = {};
        var res = "";
        if (P_main.amOrIm == null && P_main.ovrdAM == null && (P_main.flag == "UpdateThor" || P_main.flag == "thor")) {
          res = 'AD';
        }
        else if (P_main.amOrIm == 'Yes') {
          res = 'AM';
        }
        else if (P_main.ovrdAM != undefined) {
          res = P_main.ovrdAM;
        }


        var date = new Date();
        var date2 = new Date(date.getFullYear(), date.getMonth(), 1);
        var day = date2.getDate() < 9 ? '0' + (date2.getDate()) : '' + (date2.getDate());
        var month = date2.getMonth() < 9 ? '0' + (date2.getMonth() + 1) : '' + (date2.getMonth() + 1)
        var year = date2.getFullYear();
        var currentDate = `${year}-${month}-${day}`;

        // var nextWeek= new Date(date.getTime()+ 31 * 24 * 60 * 60 * 1000)
        var nextWeek = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        // var next3month= new Date(date.getTime()+ 90 * 24 * 60 * 60 * 1000)
        var next3month = new Date(date.getFullYear(), date.getMonth() + 2, 1);
        var day1 = nextWeek.getDate();
        var month1 = nextWeek.getMonth() < 9 ? '0' + (nextWeek.getMonth() + 1) : '' + (nextWeek.getMonth() + 1)
        var year1 = nextWeek.getFullYear();
        var nextWeek1 = `${year1}-${month1}-${day1}`;

        var day2 = next3month.getDate();
        var month2 = next3month.getMonth() < 9 ? '0' + (next3month.getMonth() + 1) : '' + (next3month.getMonth() + 1)
        var year2 = next3month.getFullYear();
        var next3month1 = `${year2}-${month2}-${day2}`;
        var color = false;
        var color2 = false;
        if (P_main.manClosemonth >= currentDate && P_main.manClosemonth <= nextWeek1) {
          color = true;
        }
        if (P_main.manStaffing == 'No' && (P_main.manClosemonth >= currentDate && P_main.manClosemonth <= next3month1) && P_main.bus != 'E-BUS(renewals)') {
          color2 = true;
        }
        retpayload['manProb'] = P_main.stgGroup == 'SOLD' ? (P_main.probability != '-' ? Number(P_main.probability) : 0) : (P_main.manProb != '-' ? Number(P_main.manProb) : 0);
        retpayload['color'] = color;
        retpayload['color2'] = color2;
        retpayload['manStaffing'] = P_main.manStaffing;
        retpayload['flag'] = P_main.flag;
        retpayload['bus'] = P_main.bus;
        retpayload['optyID'] = P_main.optyId;
        retpayload['sLID'] = P_main.slId;
        retpayload['mU'] = P_main.mU;
        retpayload['bu'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;
        // retpayload['account']=client!=undefined?client.clientName:'';
        // retpayload['pillar']=P_main.pillar;
        // retpayload['pursuitName']=P_main.pursuitName!=undefined?P_main.pursuitName.trim():'NA'
        retpayload['pursuitLead'] = pLead != undefined ? pLead.name : '';
        retpayload['pursuitGovernance'] = pGov != undefined ? pGov.name : '';
        retpayload['dueDate'] = P_main.closeMonth != undefined ? P_main.closeMonth : P_main.ovrdCloseMonth;
        retpayload['tCV'] = Number(P_main.convertedBkg) != undefined ? Number(P_main.convertedBkg) : Number(P_main.ovrdConvBkg);
        retpayload['status'] = P_main.status;
        retpayload['id'] = P_main.id;
        retpayload['plId'] = P_main.oldPursuitLead;
        retpayload['govId'] = P_main.manPursuitgovernance;
        retpayload['muId'] = P_main.mU;
        retpayload['accountId'] = P_main.mU;
        retpayload['lost'] = P_main.lost;
        retpayload['revenueForecast'] = P_main.ovarallRevenueForecast;
        retpayload['manSubSector'] = P_main.manSubSector;

        retpayload['manMu'] = P_main.manMu;
        retpayload['manBu'] = P_main.manBu;
        retpayload['manAccount'] = P_main.manAccount;
        retpayload['manPillar'] = P_main.manPillar;
        retpayload['manNLCategory'] = P_main.manNLCategory;
        retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
        retpayload['manPlead'] = P_main.manPursuitlead;
        retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
        retpayload['manClosemonth'] = P_main.manClosemonth;
        retpayload['manTCV'] = P_main.manTCV;
        retpayload['manTCVtcv'] = P_main.manTCVoracle;
        retpayload['manTCVoracle'] = (P_main.manStageGrp == 'SOLD' || P_main.manStageGrp == 'LDQ') ? Number(P_main.convertedBkg) : P_main.manTCVoracle;
        totalTCV = totalTCV + Number(retpayload['manTCVoracle']);
        retpayload['totalTCV'] = totalTCV;
        toalRevenueForecast = toalRevenueForecast + Number(retpayload['revenueForecast']);
        retpayload['toalRevenueForecast'] = toalRevenueForecast;
        retpayload['manPursuitname'] = P_main.manPursuitname;
        retpayload['manOptyID'] = P_main.manOptyID;
        retpayload['manSLId'] = P_main.manSLId;
        retpayload['manStageGrp'] = P_main.manStageGrp;

        retpayload['pillar'] = P_main.strategicOffer;
        retpayload['amOrIm'] = res;
        retpayload['optyId'] = P_main.optyId;
        retpayload['slId'] = P_main.slId;
        retpayload['subSector'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;
        retpayload['oldPursuitLead'] = P_main.ovrdPurrsuitLead != undefined ? P_main.ovrdPurrsuitLead : P_main.oldPursuitLead;
        retpayload['region'] = P_main.site;
        retpayload['account'] = P_main.account;
        retpayload['opportunity'] = P_main.opportunity;
        retpayload['ovrdConvBkg'] = P_main.ovrdConvBkg;

        retpayload['convertedBkg'] = P_main.convertedBkg;
        retpayload['convertedWeightedBkg'] = P_main.convertedWeightedBkg;
        retpayload['ovrdCloseMonth'] = P_main.ovrdCloseMonth;
        retpayload['closeMonth'] = P_main.closeMonth;
        retpayload['category'] = P_main.category;
        retpayload['P_mainCategory'] = P_main.P_mainCategory;
        retpayload['dealCat'] = P_main.dealCat;
        retpayload['forecastType'] = P_main.forecastType;
        retpayload['keyDealFlag'] = P_main.keyDealFlag;
        retpayload['ovrdProb'] = P_main.ovrdProb;
        retpayload['probability'] = P_main.probability;
        retpayload['groupAccount'] = P_main.groupAccount;
        retpayload['staffingRisk'] = P_main.staffingRisk;
        retpayload['oSLComments'] = P_main.oSLComments;
        retpayload['bidType'] = P_main.bidType;
        // retpayload['mU']=P_main.mUAltName!=undefined?P_main.mUAltName:P_main.mU;
        retpayload['mUAltName'] = P_main.mUAltName != undefined ? P_main.mUAltName : P_main.mU;
        retpayload['salesPlay'] = P_main.salesPlay;
        retpayload['offer'] = P_main.solution;
        retpayload['coE'] = P_main.coE;
        retpayload['askHelpNeeded'] = P_main.askHelpNeeded;
        retpayload['stepsToClose'] = P_main.stepsToClose;
        retpayload['actionDueDate'] = P_main.actionDueDate;
        retpayload['winTheme'] = P_main.winTheme;
        //retpayload['bDE']=P_main.;
        retpayload['oracleLicenceInfluence'] = P_main.oracleLicenceInfluence;
        retpayload['stg'] = P_main.stg;
        retpayload['stgGroup'] = P_main.stgGroup;
        retpayload['revCategory'] = P_main.revCategory;
        retpayload['ovrdCM'] = P_main.ovrdCM;
        retpayload['cM'] = P_main.ovrdCM != undefined ? P_main.ovrdCM : P_main.cM;
        retpayload['accountSegment'] = P_main.accountSegment;
        retpayload['primaryERP'] = P_main.primaryERP;
        retpayload['multiERP'] = P_main.multiERP;
        retpayload['likelyStart'] = P_main.likelyStart;
        retpayload['localIINCRHCmon1'] = P_main.localIINCRHCmon1;
        retpayload['gXINCRHCmon1'] = P_main.gXINCRHCmon1;
        retpayload['indiaINCRHCmon1'] = P_main.indiaINCRHCmon1;
        retpayload['source'] = P_main.source;
        retpayload['site'] = P_main.site;
        retpayload['gTMCallYN'] = P_main.gTMCallYN;
        retpayload['mP_mainiewYN'] = P_main.mP_mainiewYN;
        // retpayload['muSubsector']=P_main.muSubsector;
        retpayload['offerCategory'] = P_main.offerCategory;
        retpayload['IsDUP_ofID'] = P_main.IsDUP_ofID;
        retpayload['thorMU'] = P_main.thorMU;
        retpayload['nLCategory'] = P_main.nLCategory;
        retpayload['nLRule'] = P_main.nLRule;
        retpayload['ovrdAM'] = res;
        retpayload['ovrdPursuitLead'] = P_main.ovrdPursuitLead != undefined ? P_main.ovrdAM : P_main.oldPursuitLead;
        // retpayload['ovrdStgGrp']=P_main.ovrdStgGrp!=undefined?P_main.ovrdAM:P_main.stg;
        retpayload['ovrdSubSector'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;

        retpayload['wtBkg'] = P_main.wtBkg;


        if (input == 1) {
          retpayload['status'] = report[j].status;
          retpayload['comments'] = report[j].comments;
          retpayload['lastUpdateDate'] = P_main.lastUpdateDate;
          retpayload['lastUpdatedBy'] = report[j].lastUpdatedBy;
          //  data.push(retpayload); 

        }
        if (input == 2) {
          retpayload['type1'] = report[j].type1;
          retpayload['oldValue'] = report[j].oldValue;
          retpayload['newValue'] = report[j].newValue;
          retpayload['username'] = report[j].username;
          retpayload['date1'] = report[j].date1;

        }
        if (input == 0) {
          retpayload['updatedBy'] = report[j].updatedBy;
          retpayload['eventName'] = report[j].eventName;
          retpayload['date1'] = report[j].date1;

        }
        if (input == 6) {
          if (statusBO !== undefined) {
            const creationDate = new Date(statusBO.creationDate);
            const year = creationDate.getFullYear();
            const month = String(creationDate.getMonth() + 1).padStart(2, '0');
            const day = String(creationDate.getDate()).padStart(2, '0');
            const formattedDate = `${year}-${month}-${day}`;
            retpayload['lastUpdatedDate'] = formattedDate;
          } else {
            retpayload['lastUpdatedDate'] = '';
          }

        }
        data.push(retpayload);
      }
    }

    console.log(">>", data);
    return data;
  };

  PageModule.prototype.getReportsDataUpdatelog = function (P_emp, report, active, revenueBO, input, YEar, updateNavigateCheck, monIn) {
    var data = new Array();
    var totalTCV = 0;
    var toalRevenueForecast = 0;
    var P_main;

    const monthMapping = {
      Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6,
      Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12
    };

    if (monIn !== undefined && monIn !== '' && monIn !== null) {
      if(monIn.length=0){
    var targetMonth = monthMapping[monIn];
     if (targetMonth) {
        // Filter the records and update the existing Report array
        report = report.filter(item => {
            const [day, month, year] = item.date1.split('-'); // Extract the month from date
            return parseInt(month, 10) === targetMonth; // Match with target month
        });
    } 
      }else if(monIn.length>0){
         var targetMonths = monthMapping[monIn];
           targetMonths = monIn.map(month => monthMapping[month]);

    if (targetMonths.every(month => month !== undefined)) {
        // Filter the records and update the existing Report array
        report = report.filter(item => {
            const [day, month, year] = item.date1; // Extract the month from date
            return targetMonths.includes(parseInt(month, 10)); // Check if month is in targetMonths
        });
    } 
      }
    }
    else{
      report;
    }

     

    for (var j = 0; j < report.length; j++) {
      if (input == '2') {
        P_main = active.find(ele33 => ele33.id == report[j].optyID);
      }
      if (input != '2') {
        P_main = active.find(ele33 => ele33.manSLId == report[j].manSLId);
      }

      var compareDate;

      let compareDate1 = P_main ? new Date(P_main.lastUpdateDate) : '';

      if (compareDate1 != '') {
        compareDate = `${compareDate1.getFullYear()}-${compareDate1.getMonth() < 9 ? '0' + (compareDate1.getMonth() + 1) : '' + (compareDate1.getMonth() + 1)}-${compareDate1.getDate() < 10 ? '0' + (compareDate1.getDate()) : '' + (compareDate1.getDate())}`;
      } else {
        compareDate = '';
      }

      // let compareDate1 = P_main ? new Date(P_main.lastUpdateDate) : '';
      // var compareDate = `${compareDate1.getFullYear()}-${compareDate1.getMonth() < 9 ? '0' + (compareDate1.getMonth() + 1) : '' + (compareDate1.getMonth() + 1)}-${compareDate1.getDate() < 10 ? '0' + (compareDate1.getDate()) : '' + (compareDate1.getDate())}`;
      const today1 = new Date();
      var today = `${today1.getFullYear()}-${today1.getMonth() < 9 ? '0' + (today1.getMonth() + 1) : '' + (today1.getMonth() + 1)}-${today1.getDate() < 10 ? '0' + (today1.getDate()) : '' + (today1.getDate())}`;
      const sevenDaysAgo1 = new Date();
      sevenDaysAgo1.setDate(today1.getDate() - 7);
      var sevenDaysAgo = `${sevenDaysAgo1.getFullYear()}-${sevenDaysAgo1.getMonth() < 9 ? '0' + (sevenDaysAgo1.getMonth() + 1) : '' + (sevenDaysAgo1.getMonth() + 1)}-${sevenDaysAgo1.getDate() < 10 ? '0' + (sevenDaysAgo1.getDate()) : '' + (sevenDaysAgo1.getDate())}`;
      let updateNavigateCheckReturn;
      if (updateNavigateCheck === true) {
        if (compareDate >= sevenDaysAgo && compareDate <= today && report[j].type1 !== 'Pursuit Created Manually' && report[j].type1 !== 'Pursuit Created' && report[j].date1 >= sevenDaysAgo && report[j].date1 <= today) {
          updateNavigateCheckReturn = true;
        }
        else { updateNavigateCheckReturn = false; }
      }
      else { updateNavigateCheckReturn = true; }

      // for(var i=0;i<P_main.length;i++)

      if (P_main && updateNavigateCheckReturn === true) {
        if ((new Date((P_main.manClosemonth)).getFullYear() == YEar) || (YEar == '1')) {
          var pLead = P_emp.find(ele => ele.id == P_main.manPursuitlead);
          var pGov = P_emp.find(ele => ele.id == P_main.manPursuitgovernance);
          var revenue = revenueBO.find(ele => ele.sLID == P_main.id);
          //  var mu=P_mu.find(ele=>ele.id==P_main[i].mUAltName)
          //  var client=P_client.find(ele=>ele.id==P_main[i].account)
          var retpayload = {};
          var res = "";
          if (P_main.amOrIm == null && P_main.ovrdAM == null && (P_main.flag == "UpdateThor" || P_main.flag == "thor")) {
            res = 'AD';
          }
          else if (P_main.amOrIm == 'Yes') {
            res = 'AM';
          }
          else if (P_main.ovrdAM != undefined) {
            res = P_main.ovrdAM;
          }


          var date = new Date();
          var date2 = new Date(date.getFullYear(), date.getMonth(), 1);
          var day = date2.getDate() < 10 ? '0' + (date2.getDate()) : '' + (date2.getDate());
          var month = date2.getMonth() < 9 ? '0' + (date2.getMonth() + 1) : '' + (date2.getMonth() + 1)
          var year = date2.getFullYear();
          var currentDate = `${year}-${month}-${day}`;

          // var nextWeek= new Date(date.getTime()+ 31 * 24 * 60 * 60 * 1000)
          var nextWeek = new Date(date.getFullYear(), date.getMonth() + 1, 0);
          // var next3month= new Date(date.getTime()+ 90 * 24 * 60 * 60 * 1000)
          var next3month = new Date(date.getFullYear(), date.getMonth() + 2, 1);
          var day1 = nextWeek.getDate() < 10 ? '0' + nextWeek.getDate() : nextWeek.getDate();
          var month1 = nextWeek.getMonth() < 9 ? '0' + (nextWeek.getMonth() + 1) : '' + (nextWeek.getMonth() + 1)
          var year1 = nextWeek.getFullYear();
          var nextWeek1 = `${year1}-${month1}-${day1}`;

          var day2 = next3month.getDate() < 10 ? '0' + next3month.getDate() : next3month.getDate();
          var month2 = next3month.getMonth() < 9 ? '0' + (next3month.getMonth() + 1) : '' + (next3month.getMonth() + 1)
          var year2 = next3month.getFullYear();
          var next3month1 = `${year2}-${month2}-${day2}`;
          var color = false;
          var color2 = false;
          if (P_main.manClosemonth >= currentDate && P_main.manClosemonth <= nextWeek1) {
            color = true;
          }
          if (P_main.manStaffing == 'No' && (P_main.manClosemonth >= currentDate && P_main.manClosemonth <= next3month1) && P_main.bus != 'E-BUS(renewals)') {
            color2 = true;
          }
          retpayload['manProb'] = P_main.stgGroup == 'SOLD' ? (P_main.probability != '-' ? Number(P_main.probability) : 0) : (P_main.manProb != '-' ? Number(P_main.manProb) : 0);
          retpayload['color'] = color;
          retpayload['color2'] = color2;
          retpayload['manStaffing'] = P_main.manStaffing;
          retpayload['flag'] = P_main.flag;
          retpayload['bus'] = P_main.bus;
          retpayload['optyID'] = P_main.optyId;
          retpayload['sLID'] = P_main.slId;
          retpayload['mU'] = P_main.mU;
          retpayload['bu'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;
          // retpayload['account']=client!=undefined?client.clientName:'';
          // retpayload['pillar']=P_main.pillar;
          // retpayload['pursuitName']=P_main.pursuitName!=undefined?P_main.pursuitName.trim():'NA'
          retpayload['pursuitLead'] = pLead != undefined ? pLead.name : '';
          retpayload['pursuitGovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['dueDate'] = P_main.closeMonth != undefined ? P_main.closeMonth : P_main.ovrdCloseMonth;
          retpayload['tCV'] = Number(P_main.convertedBkg) != undefined ? Number(P_main.convertedBkg) : Number(P_main.ovrdConvBkg);
          retpayload['status'] = P_main.status;
          retpayload['id'] = P_main.id;
          retpayload['plId'] = P_main.oldPursuitLead;
          retpayload['govId'] = P_main.manPursuitgovernance;
          retpayload['muId'] = P_main.mU;
          retpayload['accountId'] = P_main.mU;
          retpayload['lost'] = P_main.lost;
          retpayload['revenueForecast'] = P_main.ovarallRevenueForecast;
          retpayload['manSubSector'] = P_main.manSubSector;

          retpayload['manMu'] = P_main.manMu;
          retpayload['manBu'] = P_main.manBu;
          retpayload['manAccount'] = P_main.manAccount;
          retpayload['manPillar'] = P_main.manPillar;
          retpayload['manNLCategory'] = P_main.manNLCategory;
          retpayload['manPursuitlead'] = pLead != undefined ? pLead.name : '';
          retpayload['manPlead'] = P_main.manPursuitlead;
          retpayload['manPursuitgovernance'] = pGov != undefined ? pGov.name : '';
          retpayload['manClosemonth'] = P_main.manClosemonth;
          retpayload['manTCV'] = P_main.manTCV;
          retpayload['manTCVoracle'] = (P_main.manStageGrp == 'SOLD' || P_main.manStageGrp == 'LDQ') ? Number(P_main.convertedBkg) : P_main.manTCVoracle;
          totalTCV = totalTCV + Number(retpayload['manTCVoracle']);
          retpayload['totalTCV'] = totalTCV;
          toalRevenueForecast = toalRevenueForecast + Number(retpayload['revenueForecast']);
          retpayload['toalRevenueForecast'] = toalRevenueForecast;
          retpayload['manPursuitname'] = P_main.manPursuitname;
          retpayload['manOptyID'] = P_main.manOptyID;
          retpayload['manSLId'] = P_main.manSLId;
          retpayload['manStageGrp'] = P_main.manStageGrp;

          retpayload['pillar'] = P_main.strategicOffer;
          retpayload['amOrIm'] = res;
          retpayload['optyId'] = P_main.optyId;
          retpayload['slId'] = P_main.slId;
          retpayload['subSector'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;
          retpayload['oldPursuitLead'] = P_main.ovrdPurrsuitLead != undefined ? P_main.ovrdPurrsuitLead : P_main.oldPursuitLead;
          retpayload['region'] = P_main.site;
          retpayload['account'] = P_main.account;
          retpayload['opportunity'] = P_main.opportunity;
          retpayload['ovrdConvBkg'] = P_main.ovrdConvBkg;

          retpayload['convertedBkg'] = P_main.convertedBkg;
          retpayload['convertedWeightedBkg'] = P_main.convertedWeightedBkg;
          retpayload['ovrdCloseMonth'] = P_main.ovrdCloseMonth;
          retpayload['closeMonth'] = P_main.closeMonth;
          retpayload['category'] = P_main.category;
          retpayload['P_mainCategory'] = P_main.P_mainCategory;
          retpayload['dealCat'] = P_main.dealCat;
          retpayload['forecastType'] = P_main.forecastType;
          retpayload['keyDealFlag'] = P_main.keyDealFlag;
          retpayload['ovrdProb'] = P_main.ovrdProb;
          retpayload['probability'] = P_main.probability;
          retpayload['groupAccount'] = P_main.groupAccount;
          retpayload['staffingRisk'] = P_main.staffingRisk;
          retpayload['oSLComments'] = P_main.oSLComments;
          retpayload['bidType'] = P_main.bidType;
          // retpayload['mU']=P_main.mUAltName!=undefined?P_main.mUAltName:P_main.mU;
          retpayload['mUAltName'] = P_main.mUAltName != undefined ? P_main.mUAltName : P_main.mU;
          retpayload['salesPlay'] = P_main.salesPlay;
          retpayload['offer'] = P_main.solution;
          retpayload['coE'] = P_main.coE;
          retpayload['askHelpNeeded'] = P_main.askHelpNeeded;
          retpayload['stepsToClose'] = P_main.stepsToClose;
          retpayload['actionDueDate'] = P_main.actionDueDate;
          retpayload['winTheme'] = P_main.winTheme;
          //retpayload['bDE']=P_main.;
          retpayload['oracleLicenceInfluence'] = P_main.oracleLicenceInfluence;
          retpayload['stg'] = P_main.stg;
          retpayload['stgGroup'] = P_main.stgGroup;
          retpayload['revCategory'] = P_main.revCategory;
          retpayload['ovrdCM'] = P_main.ovrdCM;
          retpayload['cM'] = P_main.ovrdCM != undefined ? P_main.ovrdCM : P_main.cM;
          retpayload['accountSegment'] = P_main.accountSegment;
          retpayload['primaryERP'] = P_main.primaryERP;
          retpayload['multiERP'] = P_main.multiERP;
          retpayload['likelyStart'] = P_main.likelyStart;
          retpayload['localIINCRHCmon1'] = P_main.localIINCRHCmon1;
          retpayload['gXINCRHCmon1'] = P_main.gXINCRHCmon1;
          retpayload['indiaINCRHCmon1'] = P_main.indiaINCRHCmon1;
          retpayload['source'] = P_main.source;
          retpayload['site'] = P_main.site;
          retpayload['gTMCallYN'] = P_main.gTMCallYN;
          retpayload['mP_mainiewYN'] = P_main.mP_mainiewYN;
          // retpayload['muSubsector']=P_main.muSubsector;
          retpayload['offerCategory'] = P_main.offerCategory;
          retpayload['IsDUP_ofID'] = P_main.IsDUP_ofID;
          retpayload['thorMU'] = P_main.thorMU;
          retpayload['nLCategory'] = P_main.nLCategory;
          retpayload['nLRule'] = P_main.nLRule;
          retpayload['ovrdAM'] = res;
          retpayload['ovrdPursuitLead'] = P_main.ovrdPursuitLead != undefined ? P_main.ovrdAM : P_main.oldPursuitLead;
          // retpayload['ovrdStgGrp']=P_main.ovrdStgGrp!=undefined?P_main.ovrdAM:P_main.stg;
          retpayload['ovrdSubSector'] = P_main.ovrdSubSector != undefined ? P_main.ovrdSubSector : P_main.subSector;

          retpayload['wtBkg'] = P_main.wtBkg;


          if (input == 1) {
            retpayload['status'] = report[j].status;
            retpayload['comments'] = report[j].comments;
            retpayload['lastUpdateDate'] = report[j].lastUpdateDate;
            retpayload['lastUpdatedBy'] = report[j].lastUpdatedBy;
            //  data.push(retpayload); 

          }
          if (input == 2) {
            retpayload['type1'] = report[j].type1;
            retpayload['oldValue'] = report[j].oldValue;
            retpayload['newValue'] = report[j].newValue;
            retpayload['username'] = report[j].username;
            retpayload['date1'] = report[j].date1;

          }
          if (input == 0) {
            retpayload['updatedBy'] = report[j].updatedBy;
            retpayload['eventName'] = report[j].eventName;
            retpayload['date1'] = report[j].date1;

          }
          data.push(retpayload);
        }
      }
    }

    console.log(">>", data);
    return data;
  };

  PageModule.prototype.mergeDate = function (approved, date) {
    var final = approved + "(" + new Date(date).toISOString().split('T')[0] + ")";
    return final;

  };

  PageModule.prototype.ValidateDoc = function (doc) {
    var count = 0;
    for (var i = 0; i < doc.length; i++) {
      if (doc[i].uploadedBy != null) {
        count++;

      }
    }
    if (count >= '8') {
      return 1;
    }
    else {
      return 0;
    }
  };

  PageModule.prototype.isFormValid = function (detail, event) {
    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      return true;
    }

    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
    var table = event.target;
    var editables = table.querySelectorAll('.editable');
    for (var i = 0; i < editables.length; i++) {
      var editable = editables.item(i);
      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        return false;
      }
    }
    return true;
  };

  PageModule.prototype.areDifferent = function (oldValue, newValue) {
    if (JSON.stringify(newValue) === JSON.stringify(oldValue))
      return false
    else
      return true;
  };
  PageModule.prototype.getMU = function (manMu) {
    if (manMu == "CPR&S") {
      return "CPRD"

    }
    else if (manMu == "R&ET") {
      return "R&ET"
    }
    else if (manMu == "CANADA" || manMu == "Canada") {
      return "CANADA"
    } else if (manMu == "LATAM" || manMu == "Latam") {
      return "LATAM"
    } else if (manMu == "MALS" || manMu == "Mals") {
      return "MALS"
    } else if (manMu == "SOGETI" || manMu == "Sogeti") {
      return "SOGETI"
    } else if (manMu == "TMT") {
      return "TMT"
    }
  };
  PageModule.prototype.createBatchPayload = function (empArray, rowStatus) {
    var payloads = [];

    var uniqueId = (new Date().getTime());
    Object.keys(rowStatus).forEach(key => {
      var change = rowStatus[key];
      key = parseInt(key);
      if (change === 'deleted') {
        payloads.push(PageModule.generateBatchSnippet("/ActivePursui/" +
          key, {}, 'delete'));
      }
      // else if (change === 'inserted') {
      //   record = empArray.find(e => e.id === key);
      //   delete record.employeeObject;
      //   delete record.approverObject;
      //   delete record.projectObject;
      //   delete record.id;
      //   // default some required fields:
      //   // record.email = 'person' + (++uniqueId) + '@company.com';
      //   record.taggingStatus ='PENDING PSC APPROVAL';
      //    record.requestedDate =rdate;
      //     record.actionBy =actionby;
      //     if(record.newTagging =='No'){
      //       record.demandID=' ';
      //     }
      //   // record.department = 1;
      //   payloads.push(PageModule.generateBatchSnippet("/TaggingBO",
      //     record, 'create'));
      // } 
      else if (change === 'modified') {
        var record = empArray.find(e => e.id == key);
        delete record.bus;
        delete record.manAccount;
        delete record.manClosemonth;
        delete record.manMu;
        delete record.manNLCategory;
        delete record.manOptyID;
        delete record.manPillar;
        delete record.manProb;
        delete record.manPursuitlead;
        delete record.manPursuitname;
        delete record.manSLId;
        delete record.manStaffing;
        delete record.manTCVoracle;
        delete record.status;
        delete record.pursuitGovernance;
        delete record.revenueForecast;

        payloads.push(PageModule.generateBatchSnippet("/ActivePursuit/" +
          key, record, 'update'));
      }
    });

    return {
      parts: payloads
    };
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  /**
   *
   * @param {String} arg1
   * @return {String}
   */


  /**
   *
   * @param {String} arg1
   * @return {String}
   */


  PageModule.domain = function (date) {

  };

  PageModule.generateBatchSnippet = function (url, payload, operation, id) {
    return {
      id: id ? id : "someID",
      path: url,
      operation: operation,
      payload: payload ? { 'pStatus': payload.pStatus } : {}
    };
  };

  PageModule.prototype.demandReplortData = function (pursuitBO, year) {
    let data = [];
    for (let i = 0; i < pursuitBO.length; i++) {
      let retpayload = {};
      let validateYear = new Date(pursuitBO[i].manClosemonth).getFullYear();
      if (validateYear == year) {
        retpayload['region'] = pursuitBO[i].region;
        retpayload['pillar'] = pursuitBO[i].manPillar;
        retpayload['OptyID'] = pursuitBO[i].manOptyID;
        retpayload['SLID'] = pursuitBO[i].manSLId;
        retpayload['account'] = pursuitBO[i].manAccount;
        retpayload['PursuitName'] = pursuitBO[i].manPursuitname;
        retpayload['Closemonth'] = pursuitBO[i].manClosemonth;
        retpayload['tcvOracle'] = pursuitBO[i].manTCVoracle;
        retpayload['probability'] = pursuitBO[i].manProb;
        retpayload['stg'] = pursuitBO[i].manStageGrp;
        retpayload['pStatus'] = pursuitBO[i].pStatus;
        retpayload['demandsCreatedOnshore'] = pursuitBO[i].demandsCreatedOnshore;
        retpayload['demandsCreatedOffshore'] = pursuitBO[i].demandsCreatedOffshore;
        retpayload['demandsCancelledOnshore'] = pursuitBO[i].demandsCancelledOnshore;
        retpayload['demandsCancelledOffshore'] = pursuitBO[i].demandsCancelledOffshore;
        retpayload['demandsRemarks'] = pursuitBO[i].demandsRemarks;
        data.push(retpayload);
      }
    }
    console.log('demandData', data);
    return data;
  }

  PageModule.prototype.RefreshAnalysisReportADP = function (BOData) {
    let adp1 = [], adp2 = [], adp3 = [], adp4 = [], adp5 = [], adp6 = [], adp7 = [];

    for (let i = 0; i < BOData.length; i++) {
      if (BOData[i].flag === 'Create') {
        adp4.push(BOData[i]);
      }
      else if (BOData[i].flag === 'Update') {
        if (BOData[i].stageGroup === 'PIPE') {
          adp1.push(BOData[i]);
        }
        else if (BOData[i].stageGroup === 'LDQ') {
          adp3.push(BOData[i]);
        }
        else if (BOData[i].stageGroup === 'SOLD' && BOData[i].stageGroup === 'SOLD') {
          adp2.push(BOData[i]);
        }
      }
      else if (BOData[i].flag === 'UpdatePlatform') {
        adp5.push(BOData[i]);
      }
      else if (BOData[i].flag === 'ThorSOLD' || BOData[i].flag == 'ThorLDQ') {
        adp6.push(BOData[i]);
      }
      else if (BOData[i].flag === 'PlatformDelete') {
        adp7.push(BOData[i]);
      }

    }
    let returnarray = [];
    returnarray.push(adp1);
    returnarray.push(adp2);
    returnarray.push(adp3);
    returnarray.push(adp4);
    returnarray.push(adp5);
    returnarray.push(adp6);
    returnarray.push(adp7);
    return returnarray;
  }

  PageModule.prototype.RefreshDownload = function (Update, head, key) {

    var multidata = new Array();
    var header = new Array();

    for (let i = 0; i < head.length; i++) {
      header.push(head[i].headerName);
    }
    multidata.push(header);

    for (let i = 0; i < Update.length; i++) {
      let updateDate = new Date(Update[i].creationDate).toISOString().split('T')[0]
      if (key === 'Pipe') {
        var instanceArray = [];
        instanceArray.push(Update[i].optyIDObject.items[0].manOptyID);
        instanceArray.push(Update[i].sLID);
        instanceArray.push(Update[i].account);
        instanceArray.push(Update[i].BU);
        instanceArray.push(Update[i].opportunity);
        instanceArray.push(Update[i].type1);
        instanceArray.push(Update[i].oldValue);
        instanceArray.push(Update[i].newValue);
        instanceArray.push(updateDate);

        multidata.push(instanceArray);
      }

      else if (key === 'Other') {
        var instanceArray = [];
        instanceArray.push(Update[i].optyIDObject.items[0].manOptyID);
        instanceArray.push(Update[i].sLID);
        instanceArray.push(Update[i].account);
        instanceArray.push(Update[i].BU);
        instanceArray.push(Update[i].opportunity);
        instanceArray.push(Update[i].stageGroup);
        instanceArray.push(Update[i].oldValue);
        instanceArray.push(Update[i].newValue);
        instanceArray.push(updateDate);

        multidata.push(instanceArray);
      }

      else if (key === 'Create') {
        var instanceArray = [];
        instanceArray.push(Update[i].optyIDObject.items[0].optyId);
        instanceArray.push(Update[i].sLID);
        instanceArray.push(Update[i].account);
        instanceArray.push(Update[i].BU);
        instanceArray.push(Update[i].opportunity);
        instanceArray.push(Update[i].closeMonth);
        instanceArray.push(Update[i].stageGroup);
        instanceArray.push(Update[i].prob);
        instanceArray.push(Update[i].tcv);
        instanceArray.push(updateDate);
        multidata.push(instanceArray);
      }
    }

    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Refresh Analysis");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Refresh Analysis"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Refresh Analysis_" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };



  PageModule.prototype.documentcomplianceDownload = function (data, metaDataArray, x, emp, reference) {

    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < metaDataArray.length; i++) {
      header.push(metaDataArray[i].headerName);
    }
    multidata.push(header);
    const d = new Date();
    for (let i = 0; i < data.length; i++) {




      var instanceArray = [];

      instanceArray.push(data[i].manOptyID);
      instanceArray.push(data[i].manSLId);

      instanceArray.push(data[i].manBu);
      instanceArray.push(data[i].manMu);


      instanceArray.push(data[i].manAccount);
      instanceArray.push(data[i].manPursuitname);
      instanceArray.push(data[i].manPillar);
      instanceArray.push(data[i].manPursuitlead ? emp.find(e => e.id === data[i].manPursuitlead).name : 'NA');
      instanceArray.push(data[i].manPursuitgovernance ? emp.find(e => e.id === data[i].manPursuitgovernance).name : 'NA');
      instanceArray.push(data[i].status);
      instanceArray.push(data[i].manNLCategory);
      instanceArray.push(data[i].manClosemonth != undefined ? dateFormat(data[i].manClosemonth) : 'NA');
      instanceArray.push(data[i].manTCV);
      instanceArray.push(data[i].manTCVoracle);
      instanceArray.push(data[i].manStageGrp);
      instanceArray.push(data[i].manProb);
      instanceArray.push(data[i].manStaffing);

      multidata.push(instanceArray);
    }
    var wb = XLSX.utils.book_new();
    if (x == 'comp') {
      wb.SheetNames.push("Document Compliance");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Document Compliance"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Document Compliance_" + reference + "_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }

    if (x == 'partial') {
      wb.SheetNames.push("Document Partial Compliance");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Document Partial Compliance"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Document Partial Compliance_" + reference + "_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }

    if (x == 'noncomp') {
      wb.SheetNames.push("Document Non-compliance");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Document Non-compliance"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Document Non-compliance_" + reference + "-" + new Date().toISOString().split('T')[0] + ".xlsx";
    }



    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };


  PageModule.prototype.RefreshDownloading = function (adp1, adp2, adp3, adp4, adp5, adp6, head) {

    var multidata = new Array();
    var header = new Array();

    for (let i = 0; i < head.length; i++) {
      header.push(head[i].headerName);
    }
    multidata.push(header);

    for (let i = 0; i < adp1.length; i++) {
      let updateDate = new Date(adp1[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp1[i].optyIDObject.items[0].flag == 'UpdateThor' || adp1[i].optyIDObject.items[0].flag == 'Manual' ? adp1[i].optyIDObject.items[0].manOptyID : (adp1[i].optyIDObject.items[0].flag == 'thor' ? adp1[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp1[i].sLID);
      instanceArray.push(adp1[i].account);
      instanceArray.push(adp1[i].BU);
      instanceArray.push(adp1[i].opportunity);
      instanceArray.push(adp1[i].optyIDObject.items[0].flag == 'thor' ? adp1[i].closeMonth : 'NA');
      instanceArray.push(adp1[i].flag);
      instanceArray.push(adp1[i].stageGroup);
      instanceArray.push(adp1[i].type1);
      instanceArray.push(adp1[i].oldValue);
      instanceArray.push(adp1[i].newValue);
      instanceArray.push(adp1[i].optyIDObject.items[0].flag == 'thor' ? adp1[i].prob : 'NA');
      instanceArray.push(adp1[i].optyIDObject.items[0].flag == 'thor' ? adp1[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }
    for (let i = 0; i < adp2.length; i++) {
      let updateDate = new Date(adp2[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp2[i].optyIDObject.items[0].flag == 'UpdateThor' || adp2[i].optyIDObject.items[0].flag == 'Manual' ? adp2[i].optyIDObject.items[0].manOptyID : (adp2[i].optyIDObject.items[0].flag == 'thor' ? adp2[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp2[i].sLID);
      instanceArray.push(adp2[i].account);
      instanceArray.push(adp2[i].BU);
      instanceArray.push(adp2[i].opportunity);
      instanceArray.push(adp2[i].optyIDObject.items[0].flag == 'thor' ? adp2[i].closeMonth : 'NA');
      instanceArray.push(adp2[i].flag);
      instanceArray.push(adp2[i].stageGroup);
      instanceArray.push(adp2[i].type1);
      instanceArray.push(adp2[i].oldValue);
      instanceArray.push(adp2[i].newValue);
      instanceArray.push(adp2[i].optyIDObject.items[0].flag == 'thor' ? adp2[i].prob : 'NA');
      instanceArray.push(adp2[i].optyIDObject.items[0].flag == 'thor' ? adp2[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }
    for (let i = 0; i < adp3.length; i++) {
      let updateDate = new Date(adp3[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp3[i].optyIDObject.items[0].flag == 'UpdateThor' || adp3[i].optyIDObject.items[0].flag == 'Manual' ? adp3[i].optyIDObject.items[0].manOptyID : (adp3[i].optyIDObject.items[0].flag == 'thor' ? Update[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp3[i].sLID);
      instanceArray.push(adp3[i].account);
      instanceArray.push(adp3[i].BU);
      instanceArray.push(adp3[i].opportunity);
      instanceArray.push(adp3[i].optyIDObject.items[0].flag == 'thor' ? adp3[i].closeMonth : 'NA');
      instanceArray.push(adp3[i].flag);
      instanceArray.push(adp3[i].stageGroup);
      instanceArray.push(adp3[i].type1);
      instanceArray.push(adp3[i].oldValue);
      instanceArray.push(adp3[i].newValue);
      instanceArray.push(adp3[i].optyIDObject.items[0].flag == 'thor' ? adp3[i].prob : 'NA');
      instanceArray.push(adp3[i].optyIDObject.items[0].flag == 'thor' ? adp3[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }
    for (let i = 0; i < adp4.length; i++) {
      let updateDate = new Date(adp4[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp4[i].optyIDObject.items[0].flag == 'UpdateThor' || adp4[i].optyIDObject.items[0].flag == 'Manual' ? adp4[i].optyIDObject.items[0].manOptyID : (adp4[i].optyIDObject.items[0].flag == 'thor' ? adp4[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp4[i].sLID);
      instanceArray.push(adp4[i].account);
      instanceArray.push(adp4[i].BU);
      instanceArray.push(adp4[i].opportunity);
      instanceArray.push(adp4[i].optyIDObject.items[0].flag == 'thor' ? adp4[i].closeMonth : 'NA');
      instanceArray.push(adp4[i].flag);
      instanceArray.push(adp4[i].stageGroup);
      instanceArray.push(adp4[i].type1);
      instanceArray.push(adp4[i].oldValue);
      instanceArray.push(adp4[i].newValue);
      instanceArray.push(adp4[i].optyIDObject.items[0].flag == 'thor' ? adp4[i].prob : 'NA');
      instanceArray.push(adp4[i].optyIDObject.items[0].flag == 'thor' ? adp4[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }
    for (let i = 0; i < adp5.length; i++) {
      let updateDate = new Date(adp5[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp5[i].optyIDObject.items[0].flag == 'UpdateThor' || adp5[i].optyIDObject.items[0].flag == 'Manual' ? adp5[i].optyIDObject.items[0].manOptyID : (adp5[i].optyIDObject.items[0].flag == 'thor' ? adp5[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp5[i].sLID);
      instanceArray.push(adp5[i].account);
      instanceArray.push(adp5[i].BU);
      instanceArray.push(adp5[i].opportunity);
      instanceArray.push(adp5[i].optyIDObject.items[0].flag == 'thor' ? adp5[i].closeMonth : 'NA');
      instanceArray.push(adp5[i].flag);
      instanceArray.push(adp5[i].stageGroup);
      instanceArray.push(adp5[i].type1);
      instanceArray.push(adp5[i].oldValue);
      instanceArray.push(adp5[i].newValue);
      instanceArray.push(adp5[i].optyIDObject.items[0].flag == 'thor' ? adp5[i].prob : 'NA');
      instanceArray.push(adp5[i].optyIDObject.items[0].flag == 'thor' ? adp5[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }
    for (let i = 0; i < adp6.length; i++) {
      let updateDate = new Date(adp6[i].creationDate).toISOString().split('T')[0]
      // let optyid=active.find(e=>e.id==Update[i].optyID)
      var instanceArray = [];
      instanceArray.push(adp6[i].optyIDObject.items[0].flag == 'UpdateThor' || adp6[i].optyIDObject.items[0].flag == 'Manual' ? adp6[i].optyIDObject.items[0].manOptyID : (adp6[i].optyIDObject.items[0].flag == 'thor' ? adp6[i].optyIDObject.items[0].optyId : ''));
      instanceArray.push(adp6[i].sLID);
      instanceArray.push(adp6[i].account);
      instanceArray.push(adp6[i].BU);
      instanceArray.push(adp6[i].opportunity);
      instanceArray.push(adp6[i].optyIDObject.items[0].flag == 'thor' ? adp6[i].closeMonth : 'NA');
      instanceArray.push(adp6[i].flag);
      instanceArray.push(adp6[i].stageGroup);
      instanceArray.push(adp6[i].type1);
      instanceArray.push(adp6[i].oldValue);
      instanceArray.push(adp6[i].newValue);
      instanceArray.push(adp6[i].optyIDObject.items[0].flag == 'thor' ? adp6[i].prob : 'NA');
      instanceArray.push(adp6[i].optyIDObject.items[0].flag == 'thor' ? adp6[i].tcv : 'NA');
      instanceArray.push(updateDate);
      multidata.push(instanceArray);
    }

    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Refresh Analysis");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Refresh Analysis"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    fileBytes = FileToBytes(fileBytes);

    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Refresh Analysis_" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  PageModule.prototype.dealsReport = function (act, emp, inputType) {
    let data = []
    if (inputType === 'Deals with PDE involvement') {
      for (let a = 0; a < act.length; a++) {
        if (act[a].pDE === 'Yes') {
          let name = emp.find(e => e.id === act[a].pDEName)
          act[a].pDEName = name ? name.name ? name.name : '' : '';

          let pl = emp.find(e => e.id === act[a].manPursuitlead)
          act[a].manPursuitlead = pl ? pl.name ? pl.name : '' : '';

          let bm = emp.find(e => e.id === act[a].manPursuitgovernance)
          act[a].manPursuitgovernance = bm ? bm.name ? bm.name : '' : '';

          data.push(act[a]);
        }
      }
    }
    else if (inputType === 'Deals by Pursuit Lead') { }
    else if (inputType === 'Deals by Pursuit Type') { }
    else if (inputType === 'Proactive Pursuits') {
      for (let a = 0; a < act.length; a++) {
        if (act[a].proactivePursuit === 'Yes') {

          let pl = emp.find(e => e.id === act[a].manPursuitlead)
          act[a].manPursuitlead = pl ? pl.name ? pl.name : '' : '';

          let bm = emp.find(e => e.id === act[a].manPursuitgovernance)
          act[a].manPursuitgovernance = bm ? bm.name ? bm.name : '' : '';

          data.push(act[a]);
        }
      }
    }

    return data;

  }


  PageModule.prototype.DealsReportDownload = function (Status, metaDataArray, x) {

    var multidata = new Array();
    var header = new Array();
    for (let i = 0; i < metaDataArray.length; i++) {
      header.push(metaDataArray[i].headerName);
    }
    multidata.push(header);
    const d = new Date();
    for (let i = 0; i < Status.length; i++) {




      var instanceArray = [];
      if (x == 1) {
        instanceArray.push(Status[i].manOptyID);
        instanceArray.push(Status[i].manSLId);
        instanceArray.push(Status[i].manPursuitlead);
        instanceArray.push(Status[i].manPursuitgovernance);
        instanceArray.push(Status[i].manBu);
        instanceArray.push(Status[i].manMu);


        instanceArray.push(Status[i].manAccount);
        instanceArray.push(Status[i].manPursuitname);
        instanceArray.push(Status[i].pDE);
        instanceArray.push(Status[i].pDEName);
        instanceArray.push(Status[i].manPillar);
        instanceArray.push(Status[i].manNLCategory);
        instanceArray.push(Status[i].manClosemonth != undefined ? dateFormat(Status[i].manClosemonth) : 'NA');
        instanceArray.push(Status[i].manTCV);
        instanceArray.push(Status[i].manTCVoracle);
        instanceArray.push(Status[i].manStageGrp);
        instanceArray.push(Status[i].manProb);
        instanceArray.push(Status[i].manStaffing);
        instanceArray.push(Status[i].manComments);
      }
      else if (x == 2) {
        instanceArray.push(Status[i].manOptyID);
        instanceArray.push(Status[i].manSLId);
        instanceArray.push(Status[i].manPursuitlead);
        instanceArray.push(Status[i].manPursuitgovernance);
        instanceArray.push(Status[i].manBu);
        instanceArray.push(Status[i].manMu);


        instanceArray.push(Status[i].manAccount);
        instanceArray.push(Status[i].manPursuitname);
        instanceArray.push(Status[i].proactivePursuit);
        instanceArray.push(Status[i].manPillar);
        instanceArray.push(Status[i].manNLCategory);
        instanceArray.push(Status[i].manClosemonth != undefined ? dateFormat(Status[i].manClosemonth) : 'NA');
        instanceArray.push(Status[i].manTCV);
        instanceArray.push(Status[i].manTCVoracle);
        instanceArray.push(Status[i].manStageGrp);
        instanceArray.push(Status[i].manProb);
        instanceArray.push(Status[i].manStaffing);
        instanceArray.push(Status[i].manComments);
      }
      multidata.push(instanceArray);
    }
    var wb = XLSX.utils.book_new();
    if (x == 1) {
      wb.SheetNames.push("Deals Report PDE");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Deals Report PDE"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Active Pursuit_DealsReport_PDE_" + new Date().toISOString().split('T')[0] + ".xlsx";
    }


    else if (x == 2) {
      wb.SheetNames.push("Deals Report Proactive");
      var ws = XLSX.utils.aoa_to_sheet(multidata);
      wb.Sheets["Deals Report Proactive"] = ws;
      var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      fileBytes = FileToBytes(fileBytes);

      var blob = new Blob([fileBytes], { type: 'octet/stream' });
      var filename = "Active Pursuit_DealsReport_Proactive_Pursuit" + new Date().toISOString().split('T')[0] + ".xlsx";
    }






    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        //console.log('Link'+JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };

  PageModule.prototype.dialogStatusAdp = function (DialogStatus) {
    let data = [];
    let array = ['Win Theme', 'Solution & Estimation', 'OBL Review', 'MU Solution Review', 'Deal Review', 'Submission', 'Orals']
    // 'Pursuit Creation','Wintheme','Solution Strawman','Solution Buid','Estimation','Staffing','Effort Models','Response Authoring','Delivery Review','PQA Review','OBL Review','MU Solution Review','MU Deal Review','GBU Review','GEB Approval','Submission','Orals','Decision'

    for (let a = 0; a < array.length; a++) {
      let check = DialogStatus.find(e => e.dealCycle === array[a])
      if (check) {
        data.push(check);
      }
      else {
        let payload = {};
        payload['dealCycle'] = array[a];
        payload['status'] = 'Yet to start';
        payload['owner'] = '';
        payload['effectiveDate'] = '';
        payload['comments'] = '';
        data.push(payload)
      }
    }

    return data;
  }

  PageModule.prototype.getPursuitLeadAndBidManager = function (roleEmployee) {

    let data1 = [], data2 = [], data3 = [], data4 = [], data5 = [], data = [];

    let PL = roleEmployee.filter(e => e.roleId == 153)
    let object11 = {}
    object11['name'] = 'Other';
    object11['id'] = 'Other';
    data1.push(object11);

    for (let a = 0; a < PL.length; a++) {
      let object = {};
      object['name'] = PL[a].employeeIdObject.items[0].name;
      object['id'] = PL[a].employeeId;
      data1.push(object);
      data4.push(object);
    }

    let BM = roleEmployee.filter(e => e.roleId == 154)
    let object12 = {}
    object12['name'] = 'Other';
    object12['id'] = 'Other';
    data2.push(object12);

    for (let b = 0; b < BM.length; b++) {
      let object2 = {};
      object2['name'] = BM[b].employeeIdObject.items[0].name;
      object2['id'] = BM[b].employeeId;
      data2.push(object2);
      data5.push(object2);
    }

    let PDE = roleEmployee.filter(e => e.roleId == 155)
    // let object13={}
    // object13['name']='Other';
    // object13['id']='Other';
    // data3.push(object13);
    for (let c = 0; c < PDE.length; c++) {
      let object3 = {};
      object3['name'] = PDE[c].employeeIdObject.items[0].name;
      object3['id'] = PDE[c].employeeId;
      data3.push(object3);
    }

    data.push(data1);
    data.push(data2);
    data.push(data3);
    data.push(data4);
    data.push(data5);
    return data;
  }

  PageModule.prototype.fName = function (doc, docInput) {
    let op;


    for (var i = 0; i < doc.length; i++) {
      if (doc[i].docType == docInput) {
        op = 'exists';
        break;
      }
      else {
        op = 'Na';
      }
    }

    //  if(doc.length>0){

    //   op='exists'
    //  }else{
    //   op;
    //  }
    return op;

  }
  PageModule.prototype.downloadDetails = function (employeeData, metaDataArray) {

    var multidata = new Array();

    for (let i = 0; i <= employeeData.length; i++) {
      var instanceArray = [];
      if (i == 0) {
        instanceArray.push('BU');
        instanceArray.push('MU');
        instanceArray.push('OptyID');
        instanceArray.push('SLID');
        instanceArray.push('Pursuit Name');
        instanceArray.push('Account');
        instanceArray.push('Stage Group');
        instanceArray.push('Close Month');
        multidata.push(instanceArray);
      }
      else {
        instanceArray.push(employeeData[i - 1].manBu)
        instanceArray.push(employeeData[i - 1].manMu);
        instanceArray.push(employeeData[i - 1].manOptyID);
        instanceArray.push(employeeData[i - 1].manSLId);
        instanceArray.push(employeeData[i - 1].manPursuitname);
        instanceArray.push(employeeData[i - 1].manAccount);
        instanceArray.push(employeeData[i - 1].manStageGrp);
        instanceArray.push(employeeData[i - 1].manClosemonth);
        multidata.push(instanceArray);
      }

    }

    var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Details");
    var ws = XLSX.utils.aoa_to_sheet(multidata);
    wb.Sheets["Details"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

    //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



    fileBytes = FileToBytes(fileBytes);
    console.log(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Details" + new Date().toISOString().split('T')[0] + ".xlsx";


    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }



  return PageModule;
});
