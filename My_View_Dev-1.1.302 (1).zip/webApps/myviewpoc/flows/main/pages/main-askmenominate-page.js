define([], () => {
  'use strict';

  class PageModule {
     validateRole(userId,role) {
   var temp =0;
   for( var i=0;i<role.length;i++)
   {
     if(role[i].employeeId == userId)
     {
       temp = 1;
     } 
     
   }
  return temp;

    }
  }
  
  return PageModule;
});
