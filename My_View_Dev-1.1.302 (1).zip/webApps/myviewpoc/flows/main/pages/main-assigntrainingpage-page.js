define(['ojs/ojarraytreedataprovider','ojs/ojknockout-keyset', 'ojs/ojknockout',"ojs/ojkeyset","ojs/ojbootstrap"], function(ArrayTreeDataProvider, ojknockout_keyset_1,ko,ojkeyset_1,define,ojbootstrap_1)  {
  'use strict';

     var PageModule = function PageModule() {};

  PageModule.prototype.developTree=function(treeArray) {
      console.log('Data'+JSON.stringify(treeArray));


    return new ArrayTreeDataProvider(treeArray, {
                    keyAttributes: "id", keyAttributesScope: "siblings", childrenAttribute: "children"
                });
    };

PageModule.prototype.developTreeArray = function (trainingTreeArray,t_currTy,t_curr,t_cour,t_top) {
    if(trainingTreeArray==null){
      trainingTreeArray=new Array();

    }
      var treeElement='';
      treeElement=treeElement+'{"id":"'+t_currTy.id+'","name":"'+t_currTy.curriculumType+'","children":[';
      for(var courseIndex = 0; courseIndex < t_curr.length; courseIndex++) {
        if(t_curr[courseIndex].curriculumType==t_currTy.id){              
        treeElement=treeElement+'{"id":'+t_curr[courseIndex].id+',"curriculum":"'+t_curr[courseIndex].curriculum+'","children":[';
        //console.log("!!!",treeElement);
        for(var topicIndex = 0; topicIndex < t_cour.length; topicIndex++) {
          if(t_cour[topicIndex].curriculum==t_curr[courseIndex].id) {
            treeElement=treeElement+'{"id":'+t_cour[topicIndex].id+',"course":"'+t_cour[topicIndex].course+'","children":[';
            for(var sessionIndex = 0; sessionIndex < t_top.length; sessionIndex++) {
              if(t_top[sessionIndex].course==t_cour[topicIndex].id && t_top[sessionIndex].activeAssessment != 'N') {
                treeElement=treeElement+'{"id":'+t_top[sessionIndex].id+',"topic":"'+t_top[sessionIndex].topic+'"},';
              }
            }
            treeElement=treeElement.charAt(treeElement.length-1)==','?treeElement.substring(0,treeElement.length-1):treeElement;
            treeElement=treeElement+']},';
          }
        }
         treeElement=treeElement.charAt(treeElement.length-1)==','?treeElement.substring(0,treeElement.length-1):treeElement;
         treeElement=treeElement+']},';
        }
      }
      treeElement=treeElement.charAt(treeElement.length-1)==','?treeElement.substring(0,treeElement.length-1):treeElement;
      treeElement=treeElement+']}';
     // console.log("@@@",treeElement);
      trainingTreeArray.push(JSON.parse(treeElement));
      //console.log("!!!",t_curr);
      //console.log("!!!",t_cour);
     // console.log("!!!",t_top);
     // console.log("!!!",t_sess);
      //console.log("!!!",trainingTreeArray);
      var retObject={"trainingTreeArray":trainingTreeArray};
       //console.log("###",treeElement);
      return retObject;
  };
  
  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnValue = function (arg1) {
    console.log("!!!",arg1);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.curriculumFunction = function (t_curr) {
    var currObj = [];
    var courObj = [];
    var topObj = [];
    var sessObj = [];
      currObj.push(t_curr[0].children);
      for(var courIndex = 0; courIndex < currObj[0].length; courIndex++) {
        courObj.push(currObj[0][courIndex].children);
        for(var topIndex = 0; topIndex < courObj[courIndex].length; topIndex++) {
          topObj.push(courObj[courIndex][topIndex].children);
        }
      }
      for(var sessionIndex = 0; sessionIndex < topObj.length; sessionIndex++) {
        for(var sessIndex = 0; sessIndex < topObj[sessionIndex].length; sessIndex++) {
          sessObj.push(topObj[sessionIndex][sessIndex]);
          //a.push(topObj[sessionIndex][sessIndex]);
        }
      }

      // for(var seIndex = 0;seIndex < sessObj.length; seIndex++) {
      //   a['sessions'] = sessObj[seIndex];
      //   console.log("!!!",sessObj[seIndex]);
      // }

      //console.log("!!!",t_curr[0].children.length);
      //console.log("!!!",currObj[0]);
      //console.log("!!!",sessObj);
      //console.log("!!!",a);

       return sessObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.courseFunction = function (t_cour) {
    var courObj = [];
    var topObj = [];
    var sessObj = [];
      courObj.push(t_cour[0].children);
      for(var courIndex = 0; courIndex < courObj.length; courIndex++) {
      for(var topIndex = 0; topIndex < courObj[courIndex].length; topIndex++) {
        topObj.push(courObj[courIndex][topIndex].children);
      }
      }
      for(var sessionIndex = 0; sessionIndex < topObj.length; sessionIndex++) {
        for(var sessIndex = 0; sessIndex < topObj[sessionIndex].length; sessIndex++) {
          sessObj.push(topObj[sessionIndex][sessIndex]);
        }
      }
      //console.log("!!!",courObj);
      //console.log("!!!",courObj[0].length);
      //console.log("!!!",topObj);

      return sessObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.topicFunction = function (t_top) {
    var topObj = [];
    var sessObj = [];
      topObj.push(t_top[0].children);
      for(var sessionIndex = 0; sessionIndex < topObj.length; sessionIndex++) {
        for(var sessIndex = 0; sessIndex < topObj[sessionIndex].length; sessIndex++) {
          sessObj.push(topObj[sessionIndex][sessIndex]);
        }
      }
      //console.log("!!!",sessObj);

      return sessObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.selectedSession = function (curr,cour,top,sess) {
    var innerArray = [];
     var sessionObj = {};
     //sessionObj = {...curr,...cour,...top,...sess};
    // if(curr != null) {
    //   if(cour!= null) {
    //     if(top != null) {
    //       if(sess != null) {
    //         sessionObj = {...curr,...cour,...top,...sess};
    //       }
    //     }
    //   }
    // }
    
    // else if(cour!= null) {
    //   if(top != null) {
    //     if(sess != null) {
    //       sessionObj = {...cour,...top,...sess};
    //     }
    //   }
    // }

    // else if(top != null) {
    //   if(sess != null) {
    //       sessionObj = {...top,...sess};
    //   }
    // }

    // else {
    //   sessionObj = {...sess};
    // }

    for(var i = 0; i < curr.length; i++){
      //sessionObj['sessions'] = curr[i];
      innerArray.push(curr[i]);
    }

    for(var j = 0; j < cour.length; j++){
     //sessionObj['sessions'] = cour[j];
      innerArray.push(cour[j]);
    }

    for(var k = 0; k < top.length; k++){
      //sessionObj['sessions'] = top[k];
      innerArray.push(top[k]);
    }

    for(var l = 0; l < sess.length; l++){
      //sessionObj['sessions'] = sess[l];
      innerArray.push(sess[l]);
    }

     //console.log("!!!",innerArray);
     //console.log("!!!",curr);
     //console.log("!!!",cour);
     //console.log("!!!",top);
     //console.log("!!!",sess);

     return innerArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getEmployeeName = function (empName) {
    var innerArrayObj = {};
    innerArrayObj['name'] = empName['name'];
    innerArrayObj['employeeID'] = empName['employeeID'];
    innerArrayObj['location'] = empName['location'];
    innerArrayObj['email'] = empName['email'];
    //console.log("!!!",innerArrayObj);
    return innerArrayObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.SessionFunction = function (sess) {
    var sessObj = [];
    for(var sessIndex = 0; sessIndex < sess.length; sessIndex++) {
      sessObj.push(sess[sessIndex]);
      //console.log("!!!",sess);
    }
    return sessObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.postData = function (data,emp,t_top,val,assignLog) {
    var returnArray = [];
    //var innerArray = [];
    for(var i = 0; i < emp.length; i++) {
      for(var j = 0; j < data.length; j++) {
        for(var k = 0; k < t_top.length; k++) {
          if(t_top[k].topic == data[j].topic) {
             var count = 0;
              for(var index = 0; index < val.length; index++) {
                 var innerValue = val[index]['targetDate'];
                //  && data[j].targetDate == innerValue
      if(t_top[k].activityCode == val[index].activityCode && emp[i].employeeID == val[index].employeeID && val[index].Status != "Completed") {
           //console.log("!!!1");
           count += 1;
           break;
        }
   }
   if(count == 0) {
            var innerObj = {};
            innerObj['employeeID'] =  emp[i]['employeeID'];
             innerObj['Status'] =  "Assigned";
            innerObj['topic'] = t_top[k]['id'];
            innerObj['activityCode'] = t_top[k]['activityCode'];
            //innerObj['location'] =  emp[i]['location'];
            innerObj['curriculumType'] = t_top[k]['curriculumType'];
            innerObj['curriculum'] =t_top[k]['curriculum'];
            innerObj['course'] = t_top[k]['course'];
            innerObj['targetDate'] = data[j].targetDate;
            innerObj['activeFlag'] = 'Y';
            assignLog.successAssign.push(innerObj);
   }
   else {
            var innerObj2 = {};
            innerObj2['employeeID'] =  emp[i]['employeeID'];
            //innerObj2['name'] =  emp[i]['name'];
            innerObj2['topic'] = t_top[k]['topic'];
            //innerObj2['activityCode'] = t_top[k]['activityCode'];
            //innerObj2['location'] =  emp[i]['location'];
            // innerObj2['curriculumType'] = t_top[k]['curriculumType'];
            //innerObj2['curriculum'] =t_top[k]['curriculum'];
            //innerObj2['course'] = t_top[k]['course'];
            innerObj2['targetDate'] = data[j].targetDate;
            innerObj2['activeFlag'] = 'Y';
            assignLog.errorAssign.push(innerObj2);
   }
          }
        }
      }
    }
//     for(var m = 0; m < returnArray.length; m++){
//       var count = 0;
//       for(var index = 0; index < val.length; index++) {
//       if(returnArray[m].activityCode == val[index].activityCode && returnArray[m].employeeID == val[index].employeeID) {
//            count += 1;
//            continue;
//         }
//    }
//    if(count == 0) {
//             var innerObj = {};
//             innerObj['employeeID'] = returnArray[m]['employeeID'];
//             innerObj['name'] = returnArray[m]['name'];
//             innerObj['topic'] = returnArray[m]['topic'];
//             innerObj['activityCode'] = returnArray[m]['activityCode'];
//             innerObj['location'] = returnArray[m]['location'];
//             innerObj['curriculumType'] = returnArray[m]['curriculumType'];
//             innerObj['curriculum'] = returnArray[m]['curriculum'];
//             innerObj['course'] = returnArray[m]['course'];
//             innerArray.push(innerObj);
//    }
//  }
    //console.log("!!!",returnArray);
    //console.log("!!!",innerArray);
    //console.log("!!!",val);
    //console.log("!!!",emp);
    //console.log("!!!",data);
    //console.log("!!!",t_top);
    //console.log("!!!",assignLog);
    return assignLog;
  };

PageModule.prototype.postDataUsingUpload = function (uploadData,val,t_emp) {
   var returnArray = [];
   //for(var index = 0; index < t_emp.length; index++) {
    for(var i = 0; i < uploadData.length; i++) {
         var count = 0;
        for(var j = 0; j < val.length; j++) {
          var innerValue = val[j]['targetDate'];
          //console.log("!!!",innerValue);
        if(uploadData[i].activityCode == val[j].activityCode && t_emp.find(ele => ele.id == val[j].employeeID).employeeID == uploadData[i].employeeID  && uploadData[i].targetDate == innerValue && val[j].Status != "Completed") {
          count += 1;
          //console.log("!!!2");
          continue;
        }
           }
      if(count == 0) {
            var dataObj = {};
            for(var e = 0; e < t_emp.length; e++) {
              if(t_emp[e].employeeID == uploadData[i].employeeID) {
                dataObj['employeeID'] = t_emp[e].id;
              }
            }
            // var empID=t_emp.find(empID => empID.id == uploadData[i]['employeeID']);
            // var emp= t_emp.find(empID => empID.id == uploadData[i]['employeeID']).id;
            // dataObj['employeeID'] = emp;
            //dataObj['name'] = emp[index]['name'];
            dataObj['activeFlag'] = 'Y';
            dataObj['topic'] = uploadData[i].topic;
            dataObj['activityCode'] = uploadData[i].activityCode;
            dataObj['curriculumType'] = uploadData[i].curriculumType;
            dataObj['curriculum'] = uploadData[i].curriculum;
            dataObj['course'] = uploadData[i].course;
             dataObj['targetDate'] = uploadData[i].targetDate;
           //dataObj['location'] = emp[i]['location'];
            returnArray.push(dataObj);
             }
    }
  //}
  //console.log("!!!",returnArray);
  //console.log("!!!",val);
  //console.log("!!!",t_emp);
  return returnArray;  
  
};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  // PageModule.prototype.courseEnable = function () {
  //   var arg = "$current.data.course == null";
  //   return arg;
  // };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  // PageModule.prototype.disableAll = function () {
  //   var arg = "";
  //   return arg;
  // };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.selectedRow = function (t_train,selRow) {
    var id;
    for(var i = 0; i < t_train.length; i++) {
      if(t_train[i].employeeID == selRow.employeeID) {
         id= t_train[i].employeeID;
      }
    }
    //console.log("!!!",t_train);
    //console.log("!!!",selRow.employeeID);
    //console.log("!!!",id);
  
  return id;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.resetButton = function (t_train) {
    var id = [];
    for(var i = 0; i < t_train.length; i++) {
      id.push(t_train[i].id);
    }
    //console.log("!!!",id);
    return id;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.selectedChanged = function (event) {
                  const newSelected = event;
                  // Update the selected list
                  let text = "none";
                  if (newSelected.values().size > 0) {
                      const textArray = [];
                      newSelected.values().forEach((value) => {
                          textArray.push(value);
                      });
                      text = textArray.toString();
                  }
                  //document.getElementById("selected-list").textContent = text;
                  //console.log("!!!",text);
                  return text;
              };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTopic = function (text) {
    var count = 0;
    var tem = "";
    var temp = [];
    var id = [];
    for(var i = 0; i < text.length; i++) {
      if(text[i] == ",") {
        temp.push(tem);
        tem = "";
        continue; 
      }
      tem += text[i];
      if(i == text.length-1) {
        temp.push(tem);
      }
    }
    //console.log("!!!",text.length);
    for( var textIndex = 0; textIndex < temp.length; textIndex++) {
      count += 1;
      //console.log("!!!",count);
      if(count == 4) {
        id.push(temp[textIndex]);
        //console.log("!!!",temp);
        count = 0;
      }
    }
    //console.log("!!!",text);
    //console.log("!!!",id);
    //console.log("!!!",temp);
    return id;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.deleteRow = function (train,selectedRow) {
    var returnArray = [];
    for(var i = 0; i < train.length; i++) {
      //console.log("!!!",selectedRow[0].employeeID);
      if(train[i].employeeID == selectedRow[0].employeeID) {
        continue;
      }
      var innerObj = {};
      innerObj['employeeID'] = train[i]['employeeID'];
      innerObj['name'] = train[i]['name'];
      returnArray.push(innerObj);
    }
    //console.log("!!!",selectedRow);
    //console.log("!!!",returnArray);

    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
 PageModule.prototype.getMail = function(train) {
    var emails = ""; // Initialize an empty string to hold the emails
    for (var i = 0; i < train.length; i++) {
        var count = 0;
        for (var j = 0; j < train.length; j++) {
            if (train[i].email == train[j].email && count == 0) {
                emails += train[i].email + "\n"; // Concatenate the email to the string
                count += 1;
            }
        }
    }
    return emails; // Return the string containing emails
};


  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnUniqueName = function (empData) {
     var arrayobj=Object.values(empData);
     var returnArray = [];
     const arrayUniqueByKey = [...new Map(empData.map(item =>  [item['name'], item])).values()];
     for(var i = 0; i < arrayUniqueByKey.length; i++) {
        var innerObj = {};
        innerObj['name'] = arrayUniqueByKey[i].name;
        innerObj['employeeID'] = arrayUniqueByKey[i].employeeID;
        returnArray.push(innerObj);
     }         
     //console.log("!!!",returnArray);
     return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnSessions = function (post,t_top,t_cour,t_curr) {
    //var arrayobj=Object.values(post);
     var returnArray = [];
     //const arrayUniqueByKey = [...new Map(post.map(item =>  [item['topic'], item])).values()];
     for(var l = 0; l < t_curr.length; l++) {
     for(var k = 0; k < t_cour.length; k++) {
     for(var j = 0; j < t_top.length; j++) {
         for(var i = 0; i < post.length; i++) {
            if(post[i].topic == t_top[j].id && post[i].course == t_cour[k].id && post[i].curriculum == t_curr[l].id) {
             var innerObj = {};
             innerObj['curriculum'] = t_curr[l].id; 
             innerObj['course'] = t_cour[k].id; 
             innerObj['topic'] = t_top[j].topic; 
             innerObj['topicLink'] = t_top[j].topicLink;
             innerObj['trainingHours'] = t_top[j].trainingHours;
             innerObj['targetDate'] = post[i].targetDate;
            innerObj['employeeID'] = post[i].employeeID;
             returnArray.push(innerObj); 
                  }
              }
          }
       }
     }
     console.log("!!!",returnArray);
     return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.emailBody = function (name,sessions,empID,curriculum,course) {
    var body = "";
    var myViewlink = "https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/";
    var raiseTicketLink = "https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/?page=shell&shell=main&main=main-suggestionformat";
    body += "<head> <style>.sty{text-align: center; vertical-align: middle;} .center {margin-left:75; margin-right: 100px;} table { font-family: arial, sans-serif; border-collapse: collapse; width: 78%;} td, th { border: 1px solid; text-align:left; padding: 10px; font-size: 12px;} th { background-color: #ADD8E6; text-align:center; } </style> </head> <br>";
    body += "Dear, ";
    body += name;
    body += "<br><br>The following activity is assigned to you. Please ensure that the activity is completed by the due date in the table below: <br><br>";
    body += "<table class = center><tr> <th>Curriculum</th> <th>Course</th> <th>Sr no</th> <th>Topic Name</th> <th>Link</th> <th>Training Duration</th> <th>Due Date</th> </tr>";
//    // for(var index1 = 0; index1 < curriculum.length; index1++) {
//     //   body += "<tr><td>"+curriculum[index1].curriculum+"</td>";
//       for(var index2 = 0; index2 < course.length; index2++) { 
//         // body += "<td>"+course[index2].course+"</td><td>";
//         var count = 0;
//     for(var i = 0; i < sessions.length; i++) {
//        var date = new Date(sessions[i].targetDate);
//        const formattedDate = date.toLocaleDateString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).replace(/[/]/g, '-');
//       if(sessions[i].employeeID == empID && sessions[i].course == course[index2].id) {
//         // if(count == 0) {
//         //   body += "<table>";
//         //      }
//              body += "<tr><td>"+course[index2].course+"</td><td>"+sessions[i].topic+"</td><td class = sty><a href="+sessions[i].topicLink+">Click Here</a></td><td class = sty>"+sessions[i].trainingHours+" Hours</td><td class = sty>"+formattedDate+"</td></tr></td>";
//           }
//        } 
//      }
//  //}
 
//table heading
for(var index1 = 0; index1 < curriculum.length; index1++) {
       
        var coun = 0;
        for(var in3 = 0; in3 < sessions.length; in3++) {
            if(curriculum[index1].id == sessions[in3].curriculum && sessions[in3].employeeID == empID) {
               coun += 1;
            }
        }
	var curriculumRowspan = coun; //total curriculum.topics count;
  //console.log("!!!",curriculumRowspan);
	body += "<tr><td rowspan="+curriculumRowspan+" class = sty>"+curriculum[index1].curriculum+"</td>";
	
	for(var index2 = 0; index2 < course.length; index2++) {
	//	if(index2 != 0){ body += "<tr>";}
		if(course[index2].curriculum == curriculum[index1].id) {
                        var coun2 = 0;
                        for(var in2 = 0; in2 < sessions.length; in2++) {
                            if(course[index2].id == sessions[in2].course && sessions[in2].employeeID == empID) {
                               coun2 += 1;
                            }
                        }
			var courseRowspan = coun2;
			body += "<td rowspan="+courseRowspan+" class = sty>"+course[index2].course+"</td>";
			

			var count = 0;
			for(var j = 0; j < sessions.length; j++) {
			   // if(j!=0){ body+="<tr>";}
			    if(sessions[j].course == course[index2].id && sessions[j].employeeID == empID) {
          	              count += 1;
                       	      body += "<td class = sty>"+count+"</td>";
                    	    }

        	            if(sessions[j].course == course[index2].id && sessions[j].employeeID == empID) {
                	       body += "<td>"+sessions[j].topic+"</td>";
			    }
              
	                    if(sessions[j].course == course[index2].id && sessions[j].employeeID == empID) {
	                       body += "<td class = sty><a href="+sessions[j].topicLink+">Click Here</a></td>";
	                    }
              
	                    if(sessions[j].course == course[index2].id && sessions[j].employeeID == empID) {
	                       body += "<td class = sty>"+sessions[j].trainingHours+" Hours</td>";
	                    }
              
	                    if(sessions[j].course == course[index2].id && sessions[j].employeeID == empID) {
	                       var date = new Date(sessions[j].targetDate);
        	               const formattedDate = date.toLocaleDateString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).replace(/[/]/g, '-');
	                       body += "<td class = sty>"+formattedDate+"</td></tr>";
	                    }
		
			}

		}
	}
}


body +="</table><br><br>";
     body += "To access the above Training Modules, <a href="+myViewlink+">click here</a> Or you can follow the path: My View -->> My Training -->> My Assigned Training<br><br>";
     body += "Note:<br><br>";
     body += "  &nbsp; &nbsp; &nbsp; •	In case of any issues while accessing below links then please raise a ticket on <a href="+raiseTicketLink+">My View</a>(Login on My View >> My view -> My Ticket -> Create Ticket)";
     body += "<br><br>From,<br>NA Oracle Competency</body>";
    //body+="<head> <style> table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; } td, th { border: 1px solid; text-align: left; padding: 10px; } th { background-color: #ADD8E6; } </style> </head> <body>  <br>  <table><tr> <th>Company</th> <th>Contact</th> <th>Country</th> </tr> </table></body>";
    //body+="<html><head><style>table, th,td {border: 1px solid black;}</style></head><body><table><tr><th>Sessions</th><th>"+name+"</th></tr><tr><td>  "+sessions[0].sessions+"  </td><td>javascript</td></tr></table></body></html>";
    //console.log("!!!",body);
    //console.log("!!!",sessions);
    //console.log("!!!",empID);
    return body;
  };

 PageModule.prototype.emailBodyForUpload = function (empID,name,sessions) {
    console.log("!!!",name);
    var body = "";
    var link="www.google.com";
    body += "<head> <style> table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; } td, th { border: 1px solid; text-align: left; padding: 10px; } th { background-color: #ADD8E6; } </style> </head> <br>";
    body += "Hello, ";
    body += name;
    body += "<br><br> We request you to attend and complete the Mandatory Training Modules below: <br><br>";
    body += "<table><tr> <th>Curriculum Name</th> <th>Course Name</th> <th>Topic Name</th> <th>Link</th> <th>Training Duration</th> <th>Due Date</th> </tr>";
    // for(var j = 0; j < name.length; j++) {
    for(var i = 0; i < sessions.length; i++) {
      if(sessions[i].employeeID == empID) {
         if(i == sessions.length-1) {
        body += "<tr><td>"+sessions[i].topic+"</td><td><a href="+sessions[i].topicLink+">Click Here</a></td><td>"+sessions[i].trainingHours+"</td><td>"+sessions[i].targetDate+"</td></tr>";
        body += "</table>";
        body += "<br><br>From,<br>NA Oracle Competency</body>";
      }
      else{
        body += "<tr><td>"+sessions[i].topic+"</td><td><a href="+sessions[i].topicLink+">Click Here</a></td><td>"+sessions[i].trainingHours+"</td><td>"+sessions[i].targetDate+"</td></tr>";
      }
      }
    }
    // }
    //body+="<head> <style> table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; } td, th { border: 1px solid; text-align: left; padding: 10px; } th { background-color: #ADD8E6; } </style> </head> <body>  <br>  <table><tr> <th>Company</th> <th>Contact</th> <th>Country</th> </tr> </table></body>";
    //body+="<html><head><style>table, th,td {border: 1px solid black;}</style></head><body><table><tr><th>Sessions</th><th>"+name+"</th></tr><tr><td>  "+sessions[0].sessions+"  </td><td>javascript</td></tr></table></body></html>";
    //console.log("!!!",name);
   // console.log("!!!",empID);
   // console.log("!!!",sessions);
  //  console.log("!!!",body);

    return body;
  };

  PageModule.prototype.timer = function (top,emp) {
    var returnTime = "";
    returnTime = "... "  + Math.ceil(emp.length*top.length/120) + " min";

    //console.log("!!!",returnTime);

    return returnTime;

  };

   PageModule.prototype.uploadTrainingTopicData = function (excelData,t_top,t_cour,t_curr,t_curTy,t_emp) {
    var readExcelPromise = new Promise(function (resolve) {
      var excelFile = excelData[0];
      //console.log("@@@",excelFile);
      var size;

      var reader = new FileReader();

      reader.onload = function (e) {

        var data = e.target.result;
        var excelPayloadArray = new Array();
        var workBook = XLSX.read(data, { type: 'binary'});
        var allSheets = workBook.SheetNames;
        size = allSheets.size;
        var sheetRows;
        for (var i = 0; i < 1; i++) {
          sheetRows = XLSX.utils.sheet_to_json(workBook.Sheets[allSheets[i]]);
        }
            //console.log("!!!",sheetRows);
            if(sheetRows[0].topic == null) {
              if(sheetRows[0].course == null) {
                if(sheetRows[0].curriculum == null){
                  for (var index4 = 0; index4 < sheetRows.length; index4++) {
              var parsedSheetRows4=sheetRows[index4];
               //console.log("!!!1");
              for( var t = 0; t < t_curTy.length; t++) {
              if( parsedSheetRows4['curriculumType'] == t_curTy[t]['curriculumType'] ) {
                  //console.log("!!!2");
                  for(var s = 0; s < t_top.length; s++) {
                    if( t_top[s]['curriculumType'] == t_curTy[t]['id']) {
                      //console.log("!!!3");
                    //  for(var ind2 = 0; ind2 < t_emp.length; ind2++) {
                    //  if(t_emp[ind2].employeeID == parsedSheetRows2.employeeID) {
                       //console.log("!!!4");
                      var retpayload4={};
                       retpayload4['employeeID']=parsedSheetRows4['employeeID'];
                       //retpayload['name']=t_emp[ind]['name'];
                       //retpayload['email']=t_emp[ind]['email'];
                      // retpayload4['startDate']=parsedSheetRows4['startDate'].replace(/[/]/g, '-');
                       retpayload4['targetDate']=parsedSheetRows4['targetDate'].replace(/[/]/g, '-');
                       retpayload4['activityCode']=t_top[s]['activityCode'];
                       retpayload4['curriculumType']=t_top[s]['curriculumType'];
                             var curTy4=t_curTy.find(curTy4 => curTy4.id == retpayload4['curriculumType']);
                             var curT4= t_curTy.find(curTy4 => curTy4.id == retpayload4['curriculumType']).curriculumType;
                             retpayload4['curriculumTypeName']=curT4;
                       retpayload4['curriculum']=t_top[s]['curriculum'];
                             var curr4=t_curr.find(curr4 => curr4.id == retpayload4['curriculum']);
                             var cur4= t_curr.find(curr4 => curr4.id == retpayload4['curriculum']).curriculum;
                             retpayload4['curriculumName']=cur4;
                       retpayload4['course']=t_top[s]['course'];
                            var cours4=t_cour.find(cours4 => cours4.id == retpayload4['course']);
                            var cour4= t_cour.find(cours4 => cours4.id == retpayload4['course']).course;
                             retpayload4['courseName']=cour4;
                       retpayload4['topic']=t_top[s]['id'];
                       retpayload4['topicName']=t_top[s]['topic'];
                       excelPayloadArray.push(retpayload4); 
                    //      }
                    // }
                 }
              }
               }
              }
               }
                 //console.log("!!!4",excelPayloadArray);
                }
                else {
                   for (var index3 = 0; index3 < sheetRows.length; index3++) {
              var parsedSheetRows3=sheetRows[index3];
               //console.log("!!!1");
              for( var n = 0; n < t_curr.length; n++) {
              if( parsedSheetRows3['curriculum'] == t_curr[n]['curriculum'] ) {
                  //console.log("!!!2");
                  for(var p = 0; p < t_top.length; p++) {
                    if( t_top[p]['curriculum'] == t_curr[n]['id']) {
                      //console.log("!!!3");
                    //  for(var ind2 = 0; ind2 < t_emp.length; ind2++) {
                    //  if(t_emp[ind2].employeeID == parsedSheetRows2.employeeID) {
                       //console.log("!!!4");
                      var retpayload3={};
                       retpayload3['employeeID']=parsedSheetRows3['employeeID'];
                       //retpayload['name']=t_emp[ind]['name'];
                       //retpayload['email']=t_emp[ind]['email'];
                     //  retpayload3['startDate']=parsedSheetRows3['startDate'].replace(/[/]/g, '-');
                       retpayload3['targetDate']=parsedSheetRows3['targetDate'].replace(/[/]/g, '-');
                       retpayload3['activityCode']=t_top[p]['activityCode'];
                       retpayload3['curriculumType']=t_top[p]['curriculumType'];
                             var curTy3=t_curTy.find(curTy3 => curTy3.id == retpayload3['curriculumType']);
                             var curT3= t_curTy.find(curTy3 => curTy3.id == retpayload3['curriculumType']).curriculumType;
                             retpayload3['curriculumTypeName']=curT3;
                       retpayload3['curriculum']=t_top[p]['curriculum'];
                             var curr3=t_curr.find(curr3 => curr3.id == retpayload3['curriculum']);
                             var cur3= t_curr.find(curr3 => curr3.id == retpayload3['curriculum']).curriculum;
                             retpayload3['curriculumName']=cur3;
                       retpayload3['course']=t_top[p]['course'];
                            var cours3=t_cour.find(cours3 => cours3.id == retpayload3['course']);
                            var cour3= t_cour.find(cours3 => cours3.id == retpayload3['course']).course;
                             retpayload3['courseName']=cour3;
                       retpayload3['topic']=t_top[p]['id'];
                       retpayload3['topicName']=t_top[p]['topic'];
                       excelPayloadArray.push(retpayload3); 
                    //      }
                    // }
                 }
              }
               }
              }
               }
                 //console.log("!!!3",excelPayloadArray);
                }
              }
              else {
               for (var index2 = 0; index2 < sheetRows.length; index2++) {
              var parsedSheetRows2=sheetRows[index2];
               //console.log("!!!1");
              for( var j = 0; j < t_cour.length; j++) {
              if( parsedSheetRows2['course'] == t_cour[j]['course'] ) {
                  //console.log("!!!2");
                  for(var k = 0; k < t_top.length; k++) {
                    if( t_top[k]['course'] == t_cour[j]['id']) {
                      //console.log("!!!3");
                    //  for(var ind2 = 0; ind2 < t_emp.length; ind2++) {
                    //  if(t_emp[ind2].employeeID == parsedSheetRows2.employeeID) {
                       //console.log("!!!4");
                      var retpayload2={};
                       retpayload2['employeeID']=parsedSheetRows2['employeeID'];
                       //retpayload['name']=t_emp[ind]['name'];
                       //retpayload['email']=t_emp[ind]['email'];
                      // retpayload2['startDate']=parsedSheetRows2['startDate'].replace(/[/]/g, '-');
                       retpayload2['targetDate']=parsedSheetRows2['targetDate'].replace(/[/]/g, '-');
                       retpayload2['activityCode']=t_top[k]['activityCode'];
                       retpayload2['curriculumType']=t_top[k]['curriculumType'];
                             var curTy2=t_curTy.find(curTy2 => curTy2.id == retpayload2['curriculumType']);
                             var curT2= t_curTy.find(curTy2 => curTy2.id == retpayload2['curriculumType']).curriculumType;
                             retpayload2['curriculumTypeName']=curT2;
                       retpayload2['curriculum']=t_top[k]['curriculum'];
                             var curr2=t_curr.find(curr2 => curr2.id == retpayload2['curriculum']);
                             var cur2= t_curr.find(curr2 => curr2.id == retpayload2['curriculum']).curriculum;
                             retpayload2['curriculumName']=cur2;
                       retpayload2['course']=t_top[k]['course'];
                            var cours2=t_cour.find(cours2 => cours2.id == retpayload2['course']);
                            var cour2= t_cour.find(cours2 => cours2.id == retpayload2['course']).course;
                             retpayload2['courseName']=cour2;
                       retpayload2['topic']=t_top[k]['id'];
                       retpayload2['topicName']=t_top[k]['topic'];
                       excelPayloadArray.push(retpayload2); 
                    //      }
                    // }
                 }
              }
               }
              }
               }
                 //console.log("!!!2",excelPayloadArray);
              }
            }
          else {
            for (var index = 0; index < sheetRows.length; index++) {
              var parsedSheetRows=sheetRows[index];
              for( var m = 0; m < t_top.length; m++) {
              if( parsedSheetRows['topic'] == t_top[m]['topic'] ) {
                  // for(var ind = 0; ind < t_emp.length; ind++) {
                  //   if(t_emp[ind].employeeID == parsedSheetRows.employeeID) {
                      var retpayload={};
                       retpayload['employeeID']=parsedSheetRows['employeeID'];
                       //retpayload['name']=t_emp[ind]['name'];
                       //retpayload['email']=t_emp[ind]['email'];
                       retpayload['targetDate']=parsedSheetRows['targetDate'].replace(/[/]/g, '-');
                       retpayload['activityCode']=t_top[m]['activityCode'];
                       retpayload['curriculumType']=t_top[m]['curriculumType'];
                             var curTy=t_curTy.find(curTy => curTy.id == retpayload['curriculumType']);
                             var curT= t_curTy.find(curTy => curTy.id == retpayload['curriculumType']).curriculumType;
                             retpayload['curriculumTypeName']=curT;
                       retpayload['curriculum']=t_top[m]['curriculum'];
                             var curr=t_curr.find(curr => curr.id == retpayload['curriculum']);
                             var cur= t_curr.find(curr => curr.id == retpayload['curriculum']).curriculum;
                             retpayload['curriculumName']=cur;
                       retpayload['course']=t_top[m]['course'];
                            var cours=t_cour.find(cours => cours.id == retpayload['course']);
                            var cour= t_cour.find(cours => cours.id == retpayload['course']).course;
                             retpayload['courseName']=cour;
                       retpayload['topic']=t_top[m]['id'];
                       retpayload['topicName']=t_top[m]['topic'];
                       excelPayloadArray.push(retpayload); 
                    //      }
                    // }
                 }
              }
             //console.log("!!!",excelPayloadArray);
            }
             //console.log('JSON'+JSON.stringify(sheetRows[index]));
          
        }
        resolve(excelPayloadArray);
      };
      reader.readAsBinaryString(excelFile);
      console.log(size);
    });
    
    console.log(readExcelPromise);
    return readExcelPromise;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.searchArrayFunction = function (t_curTy,t_curr,t_cour,t_top,t_curType) {
    var innerArray = [];

    for(var i = 0; i < t_curTy.length; i++) {
      var innerObj = {};
      innerObj['id'] = t_curTy[i]['id'];
      innerObj['curriculumType'] = t_curTy[i]['curriculumType'];
      innerArray.push(innerObj);
    }

   for(var j = 0; j < t_curr.length; j++) {
      var innerObj2 = {};
      innerObj2['id'] = t_curr[j]['curriculumType'];
      var curTy=t_curType.find(curTy => curTy.id == t_curr[j].curriculumType);
      var curT= t_curType.find(curTy => curTy.id == t_curr[j].curriculumType).curriculumType;
      //console.log("!!!",curT);
      innerObj2['curriculumType'] = curT;
      innerArray.push(innerObj2);
    }

   for(var k = 0; k < t_cour.length; k++) {
      var innerObj3 = {};
      innerObj3['id'] = t_cour[k]['curriculumType'];
      var curr=t_curType.find(curr => curr.id == t_cour[k].curriculumType);
      var cur= t_curType.find(curr => curr.id == t_cour[k].curriculumType).curriculumType;
      innerObj3['curriculumType'] = cur;
      innerArray.push(innerObj3);
    }

    for(var l = 0; l < t_top.length; l++) {
      var innerObj4 = {};
      innerObj4['id'] = t_top[l]['curriculumType'];
      var cours=t_curType.find(cours => cours.id == t_top[l].curriculumType);
      var cour= t_curType.find(cours => cours.id == t_top[l].curriculumType).curriculumType;
      innerObj4['curriculumType'] = cour;
      innerArray.push(innerObj4);
    }

    const arrayUniqueByKey = [...new Map(innerArray.map(item =>  [item['curriculumType'], item])).values()];
    //console.log("!!!",arrayUniqueByKey);
    //console.log("!!!",innerArray);
    //console.log("!!!",t_curr);
    //console.log("!!!",t_cour);
    //console.log("!!!",t_top);

    return arrayUniqueByKey;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.onExpand = function (search) {
    //var expanded;
    //   return new ojknockout_keyset_1.ObservableKeySet().add([
    //   "Oracle"
    // ]);
    console.log(">>>",search);
    
     //console.log("!!!!",expanded);
    //  if (expanded().has(search)) {
    //                   console.log("!!!",expanded);
    //               }
    //               else {
    //                  console.log("!!!",expanded);
    //               }
     // return expanded;
     //document.getElementById("treeview").expanded=this.expanded;
      

  };
  PageModule.prototype.getexpand = function () {
   //  var data= new ArrayTreeDataProvider(myarray,{keyAttributes:'name',keyAttributeScope:'siblings',childrenAttribute:'departmentObject.items'});
    //console.log("...",myarray);
 var expanded = new ojkeyset_1.ExpandAllKeySet();
 //console.log("...",myarray);
return expanded;
   };

//  PageModule.prototype.getcollapse = function () {
//  var collapse = new ojkeyset_1.CollapseAllKeySet();
// return collapse;
//    };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTopicFromID = function (t_curTy,t_curr,t_cour,t_top,text_top,target_cour) {
    var returnArray = [];
    for( var i = 0; i < t_top.length; i++) {
      for(var j = 0; j < text_top.length; j++) {
        //console.log("!!!",t_top[i]);
        if (t_top[i].id == text_top[j]) {
          var innerObj = {};
          for(var k = 0; k < t_curTy.length; k++) {
            if(t_curTy[k].id == t_top[i].curriculumType) {
               //console.log("!!!");
               innerObj['curriculumType'] = t_curTy[k].curriculumType;
            }
          }
          for(var l = 0; l < t_curr.length; l++) {
            if(t_curr[l].id == t_top[i].curriculum) {
               //console.log("!!!");
               innerObj['curriculum'] = t_curr[l].curriculum;
            }
          }
          //innerObj['curriculum'] = t_top[i].curriculum;
           for(var m = 0; m < t_cour.length; m++) {
            if(t_cour[m].id == t_top[i].course) {
              //console.log("!!!");
               innerObj['course'] = t_cour[m].course;
            }
          }
          for(var n = 0; n < target_cour.length; n++) {
            if(target_cour[n].id == t_top[i].course) {
              innerObj['topic'] = t_top[i].topic;
              innerObj['targetDate'] = target_cour[n].targetDate;
            }
          }

          //innerObj['course'] = t_top[i].course;
          //console.log("!!!",innerObj);
          returnArray.push(innerObj); 
        }
      }
    }
     //console.log("!!!",target_cour);
     //console.log("!!!",returnArray);
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uploadedEmployeeIDdetails = function (uploadData,t_emp) {
    var innerArray = [];
    for(var i = 0; i < t_emp.length; i++) {
      var count = 0;
      for(var j = 0; j < uploadData.length; j++) {
        if(uploadData[j].employeeID == t_emp[i].employeeID && count == 0) {
          var innerObj = {};
          innerObj['employeeID'] = t_emp[i]['employeeID'];
          innerObj['name'] = t_emp[i]['name'];
          innerObj['email'] = t_emp[i]['email'];
           innerObj['id'] = t_emp[i]['id'];
          innerArray.push(innerObj);
          count += 1;
        }
      }
    }   
    //console.log("!!!",innerArray);
    //console.log("!!!",t_emp);
    //console.log("!!!",uploadData);

    return innerArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
//   PageModule.prototype.storeTargetDateWithData = function (empty,key,tDate,review,variable) {
//     //console.log("fff",variable.length);
//     var innerArray = [];
    
   
      
//     //   for(var index = 0; index < review.length; index++) {
//     //   if(key == index) {
//     //     var innerObj = {};
//     //     if(variable.length!=0){
//     //       for(var i = 0; i < variable.length; i++) {
//     //     if(variable[i].Sno==review[index].Sno){
//     //       console.log("gggh",variable[i].Sno);
//     //       this.variable[i].targetDate=tDate;      
//     //         }
//     //     }
//     //     }
//     //     else{
//     //     innerObj['Sno'] = review[index].Sno;
        
//     //     innerObj['targetDate'] = tDate;
//     //     innerArray.push(innerObj);
        
//     //     //review['targetDate'] = tDate;
//     //   }
//     //   }
//     // }
//    if(empty != true) {   
// for(var index = 0; index < review.length; index++) {
//       if(key == index) {
//       for(var i = 0; i < variable.length; i++) {
//          var innerObj = {};
//         if(variable[i].Sno==review[index].Sno){
//           innerObj['targetDate'] = tDate;
//           innerObj['Sno'] = variable[i].Sno;
//           innerArray.push(innerObj);
//           //console.log("gggh",variable[i].Sno);  
//             }
//         else{
//         innerObj['Sno'] = review[index].Sno;
//         innerObj['targetDate'] = tDate;
//         innerArray.push(innerObj);
        
//         //review['targetDate'] = tDate;
//       }
//         }
//       }
// }
//     console.log("ggg",innerArray);
//    } 

//     else {
//       for(var index2 = 0; index2 < review.length; index2++) {
//        if(key == index2) {
//          var innerObj2 = {};
//          innerObj2['Sno'] = review[index2].Sno;
//          innerObj2['targetDate'] = tDate;
//        }
//       }
//      }
//     return innerArray;
//   };

   PageModule.prototype.storeTargetDateWithData = function (key,tDate,review) {
     var returnArray = [];
     for(var i = 0; i < review.length; i++) {
       if(i == key) {
         var innerObj = {};
         innerObj['Sno'] = review[i].Sno;
         innerObj['targetDate'] = tDate;
         returnArray.push(innerObj); 
       }
     }
     return returnArray;
   };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.uniqueTargetDate = function (key_tDate) {
    //var innerArray = key_tDate;
    // for(var i = key_tDate.length; i >= 0; i--) {
    //   var innerObj = {};
    //   innerObj['Sno'] = key_tDate[i]['Sno'];
    //   innerObj['targetDate'] = key_tDate[i]['targetDate'];
    //   innerArray.push(innerObj);
    // }
    const arrayUniqueByKey = [...new Map(key_tDate.map(item =>  [item['Sno'], item])).values()];
    //console.log("!!!",innerArray);
    //console.log("!!!",arrayUniqueByKey);

    return arrayUniqueByKey;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.validateTargetDate = function (review,unique) {
    //var num = 0;
    console.log("!!!",review);
    console.log("!!!",unique);
    var val = "";
    for(var i = 0; i < review.length; i++) {
      var count = 0;
      for(var j = 0; j < unique.length; j++) {
        if(unique[j].Sno == review[i].Sno && unique[j].targetDate != null) {
         // num += 1;
          count += 1;
        }
      }
      if(val == "" && count == 0) {
          val += review[i].Sno;
          //console.log("!!!",val);
        } 
        else if (count == 0) {
          val += " ,";
          val += review[i].Sno;
          //console.log("!!!",val);
        }
    }
    // if(num == review.length+1) {
    //   val = true;
    // }
      return val;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnFinalReview = function (review,targetDate) {
    var innerArray = [];
    for(var i = 0; i < review.length; i++) {
      var innerObj = {};
      if(targetDate.length != 0) {
         var count = 0;
      for(var j = 0; j < targetDate.length; j++) {
        if(targetDate[j].Sno == review[i].Sno && count == 0) {
          innerObj['curriculumType'] = review[i].curriculumType;
          innerObj['curriculum'] = review[i].curriculum;
          innerObj['course'] = review[i].course;
          innerObj['topic'] = review[i].topic;
          var date = new Date(targetDate[j].targetDate);
          const formattedDate = date.toISOString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).substring(0,10).replace(/[/]/g, '-');
          innerObj['targetDate'] = targetDate[j].targetDate;
          innerArray.push(innerObj);
          count += 1;
          break;
        }
      }
      if(count == 0) {
          innerObj['curriculumType'] = review[i].curriculumType;
          innerObj['curriculum'] = review[i].curriculum;
          innerObj['course'] = review[i].course;
          innerObj['topic'] = review[i].topic;
          var date2 = new Date(review[i].targetDate);
          const formattedDate2 = date2.toISOString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).substring(0,10).replace(/[/]/g, '-');
          innerObj['targetDate'] = review[i].targetDate;
          //innerObj['targetDate'] = review[i].targetDate;
          //.targetDate.replace(/[/]/g, '-');
          innerArray.push(innerObj);
        }
     }
     else {
      //  for(var k = 0; k < review.length; k++) {
      //    var innerObj3 = {};
      //    innerObj3['curriculumType'] = review[i].curriculumType;
      //    innerObj3['curriculum'] = review[i].curriculum;
      //    innerObj3['course'] = review[i].course;
      //    innerObj3['topic'] = review[i].topic;
      //    var date3 = new Date(review[i].targetDate);
      //    const formattedDate3 = date3.toISOString('en-GB', {day: 'numeric',month: 'numeric', year: 'numeric'}).substring(0,10).replace(/[/]/g, '-');
      //    innerObj3['targetDate'] = formattedDate3;
      //    innerArray.push(innerObj3);
      //  }
      innerArray = review;
     }
    }
    //console.log("!!!",targetDate);
    //console.log("!!!",innerArray);
    return innerArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.reloadPage = function () {
    location.reload();
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.fetchTreeDataBasedOnActiveLink = function (t_curTy,t_curr,t_cour,t_top,treeViewType) {
    for(var i = 0; i < t_cour.length; i++) {
      var count1 = 0;
   for(var j = 0; j < t_top.length; j++) {
         if(t_top[j].course == t_cour[i].id && count1 == 0) {
             var innerObj1 = {};
             innerObj1['id'] = t_cour[i].id;
             innerObj1['course'] = t_cour[i].course;
             innerObj1['curriculum'] = t_cour[i].curriculum;
             innerObj1['curriculumType'] = t_cour[i].curriculumType;
             treeViewType.courseArray.push(innerObj1);
             count1 += 1;
       }
    }
}

for(var k = 0; k < t_curr.length; k++) {
  var count2 = 0;
   for(var l = 0; l < t_top.length; l++) {
         if(t_curr[k].id == t_top[l].curriculum && count2 == 0) {
             var innerObj2 = {};
             innerObj2['id'] = t_curr[k].id;
             innerObj2['curriculum'] = t_curr[k].curriculum;
             innerObj2['curriculumType'] = t_curr[k].curriculumType;
             treeViewType.curriculumArray.push(innerObj2);
             count2 += 1;
       }
    }
}

for(var m = 0; m < t_curTy.length; m++) {
  var count3 = 0;
   for(var n = 0; n < t_top.length; n++) {
         if(t_curTy[m].id == t_top[n].curriculumType && count3 == 0) {
             var innerObj3 = {};
             innerObj3['id'] = t_curTy[m].id;
             innerObj3['curriculumType'] = t_curTy[m].curriculumType;
             treeViewType.curriculumTypeArray.push(innerObj3);
             count3 += 1;
       }
    }
}

    //console.log("!!!",treeViewType);
    return treeViewType;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnUniqueCourse = function (post,t_cour) {
    var arrayobj=Object.values(post);
     var returnArray = [];
     const arrayUniqueByKey = [...new Map(post.map(item =>  [item['course'], item])).values()];
     for(var i = 0; i < arrayUniqueByKey.length; i++) {
       for(var j = 0; j < t_cour.length; j++) {
         if(arrayUniqueByKey[i].course == t_cour[j].id) {
           var innerObj = {};
           innerObj['curriculum'] = t_cour[j].curriculum;
           innerObj['course'] = t_cour[j].course;
           innerObj['id'] = t_cour[j].id;
        returnArray.push(innerObj);
         }
       }
     }         
     //console.log("!!!",returnArray);
     return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnUniqueCurriculum = function (post,t_curr) {
    var arrayobj=Object.values(post);
     var returnArray = [];
     const arrayUniqueByKey = [...new Map(post.map(item =>  [item['curriculum'], item])).values()];
     for(var i = 0; i < arrayUniqueByKey.length; i++) {
       for(var j = 0; j < t_curr.length; j++) {
         if(arrayUniqueByKey[i].curriculum == t_curr[j].id) {
           var innerObj = {};
           innerObj['curriculum'] = t_curr[j].curriculum;
           innerObj['id'] = t_curr[j].id;
           returnArray.push(innerObj);
         }
       }
     }         
     //console.log("!!!",returnArray);
     return returnArray;
  };

  PageModule.prototype.getcourseID = function (text) {
    var count = 0;
    var tem = "";
    var temp = [];
    var id = [];
    for(var i = 0; i < text.length; i++) {
      if(text[i] == ",") {
        temp.push(tem);
        tem = "";
        continue; 
      }
      tem += text[i];
      if(i == text.length-1) {
        temp.push(tem);
      }
    }
    //console.log("!!!",text.length);
    for( var textIndex = 0; textIndex < temp.length; textIndex++) {
      count += 1;
      //console.log("!!!",count);
      if(count == 4) {
        id.push(temp[textIndex-1]);
        //console.log("!!!",temp);
        count = 0;
      }
    }
    //console.log("!!!",text);
    //console.log("!!!",id);
    //console.log("!!!",temp);
    return id;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getCourseByID = function (t_curTy,t_curr,t_cour,text_cour) {
     var returnArray = [];
    for( var i = 0; i < t_cour.length; i++) {
      for(var j = 0; j < text_cour.length; j++) {
        //console.log("!!!",t_top[i]);
        if (t_cour[i].id == text_cour[j]) {
          var innerObj = {};
          for(var k = 0; k < t_curTy.length; k++) {
            if(t_curTy[k].id == t_cour[i].curriculumType) {
               //console.log("!!!");
               innerObj['curriculumType'] = t_curTy[k].curriculumType;
            }
          }
          for(var l = 0; l < t_curr.length; l++) {
            if(t_curr[l].id == t_cour[i].curriculum) {
               //console.log("!!!");
               innerObj['curriculum'] = t_curr[l].curriculum;
            }
          }
          //innerObj['curriculum'] = t_top[i].curriculum;
          //  for(var m = 0; m < t_cour.length; m++) {
          //   if(t_cour[m].id == t_cour[i].course) {
          //     //console.log("!!!");
          //      innerObj['course'] = t_cour[m].course;
          //   }
          // }
          //innerObj['course'] = t_top[i].course;
           innerObj['course'] = t_cour[i].course;
           innerObj['id'] = t_cour[i].id;
          returnArray.push(innerObj);
          //console.log("!!!",innerObj);
        }
      }
    }
     //console.log("!!!",t_top);
     //console.log("!!!",returnArray);

     var arrayobj=Object.values(returnArray);
     const arrayUniqueByKey = [...new Map(returnArray.map(item =>  [item['course'], item])).values()];
    return arrayUniqueByKey;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.returnTopicReview = function (review,targetDate) {
    var innerArray = [];
    for(var i = 0; i < review.length; i++) {
      for(var j = 0; j < targetDate.length; j++) {
        if(targetDate[j].Sno == review[i].Sno) {
          var innerObj = {};
          innerObj['curriculumType'] = review[i].curriculumType;
          innerObj['curriculum'] = review[i].curriculum;
          innerObj['course'] = review[i].course;
          innerObj['id'] = review[i].id;
          // var date = new Date(targetDate[j].targetDate);
          // const formattedDate = date.toLocaleDateString('en-US', {month: 'numeric',day: 'numeric', year: 'numeric'});
          innerObj['targetDate'] = targetDate[j].targetDate ;
          innerArray.push(innerObj);
        }
      }
    }
    //console.log("!!!",innerArray);

    return innerArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getTopicID = function (t_top,t_cour,courADP) {
    var returnArray = [];
    for(var i = 0; i < t_cour.length; i++) {
      for(var j = 0; j < courADP.length; j++) {
        if(courADP[j].course == t_cour[i].course) {
          for(var k = 0; k < t_top.length; k++) {
            if(t_top[k].course == t_cour[i].id) {
              returnArray.push(t_top[k].id);
            }
          }
        }
      }
    }
    //console.log("!!!",returnArray);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.searchBasedTreeData = function (t_curTy,t_curr,t_cour,t_top,treeViewType) {
     for(var i = 0; i < t_cour.length; i++) {
      var count1 = 0;
   for(var j = 0; j < t_top.length; j++) {
         if(t_top[j].course == t_cour[i].id && count1 == 0 && t_top[j].activeLink == 'Y') {
             var innerObj1 = {};
             innerObj1['id'] = t_cour[i].id;
             innerObj1['course'] = t_cour[i].course;
             innerObj1['curriculum'] = t_cour[i].curriculum;
             innerObj1['curriculumType'] = t_cour[i].curriculumType;
             treeViewType.courseArray.push(innerObj1);
             count1 += 1;
       }
    }
}

for(var k = 0; k < t_curr.length; k++) {
  var count2 = 0;
   for(var l = 0; l < t_top.length; l++) {
         if(t_curr[k].id == t_top[l].curriculum && count2 == 0  && t_top[l].activeLink == 'Y') {
             var innerObj2 = {};
             innerObj2['id'] = t_curr[k].id;
             innerObj2['curriculum'] = t_curr[k].curriculum;
             innerObj2['curriculumType'] = t_curr[k].curriculumType;
             treeViewType.curriculumArray.push(innerObj2);
             count2 += 1;
       }
    }
}

for(var m = 0; m < t_curTy.length; m++) {
  var count3 = 0;
   for(var n = 0; n < t_top.length; n++) {
         if(t_curTy[m].id == t_top[n].curriculumType && count3 == 0  && t_top[n].activeLink == 'Y') {
             var innerObj3 = {};
             innerObj3['id'] = t_curTy[m].id;
             innerObj3['curriculumType'] = t_curTy[m].curriculumType;
             treeViewType.curriculumTypeArray.push(innerObj3);
             count3 += 1;
       }
    }
}
    //console.log("!!!",t_top);
    //console.log("!!!",t_cour);
    //console.log("!!!",t_curr);
    //console.log("!!!",t_curTy);
    return treeViewType;
  };
  
  PageModule.prototype.percentageCalc = function (simple,medium,complex,percent3) {
    var data={};
    if(simple!=undefined && medium!=undefined){
      percent3['complex']=100-(simple+medium);
      percent3['simple']=simple;
      percent3['medium']=medium;
      return percent3;
    }
    else if(medium!=undefined && complex!=undefined){
     percent3['simple']=100-(medium+complex);
     percent3['medium']=medium;
     percent3['complex']=complex;
      return percent3;
    }
    else if(simple!=undefined && complex!=undefined){
      percent3['medium']=100-(simple+complex);
      percent3['simple']=simple;
      percent3['complex']=complex;
      return percent3;
    }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.marksperQ = function (arg1) {
    var data;
    data=100/arg1;
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  
  PageModule.prototype.QSelection = function (TestBO,TestCategoryBO) {
    for (var p=0; p<TestCategoryBO.length; p++){
      var simple=TestCategoryBO[p].simplePercentage;
      var medium=TestCategoryBO[p].mediumPercentage;
      var complex=TestCategoryBO[p].complexPercentage;
      var TotalQ=TestCategoryBO[p].noOfQuestions;
    
    var rr=100/TotalQ;
    var x,y,z;
    x=simple/rr;
    y=medium/rr;
    z=complex/rr;
    var data=[];
    var quetions=[];
    var qsimple=[];
    var qmedium=[];
    var qcomplex=[];
    for (var i=0; i<TestBO.length; i++){
      if (TestBO[i].qLevel=="Beginner"){
        var a=TestBO[i].qText;
        qsimple.push(a);
        console.log("11!!",a);
      }
    }
   
    for (var j=0; j<TestBO.length; j++){
      if(TestBO[j].qLevel=="Intermediate"){
        var b=TestBO[j].qText;
        qmedium.push(b);
      }
    }
    
    for (var k=0; k<TestBO.length; k++){
      if(TestBO[k].qLevel=="Expert"){
         var c=TestBO[k].qText;
        qcomplex.push(c);
      }
    }
    while(data.length<x){
    var randomSimple = qsimple[Math.floor(Math.random()*qsimple.length)];
    if(!data.includes(randomSimple)){
      data.push(randomSimple);
    }
    }
    //for(var m=0; m<y; m++){
    while(data.length<(y+x)){
    var randomMedium = qmedium[Math.floor(Math.random()*qmedium.length)];
    if(!data.includes(randomMedium)){
      data.push(randomMedium);
    }
    }
    //for(var n=0; n<z+1; n++){
    while(data.length<(z+x+y)){
    var randomComplex = qcomplex[Math.floor(Math.random()*qcomplex.length)];
    if(!data.includes(randomComplex)){
      data.push(randomComplex);
    }
    }
    
    shuffle(data);
    console.log("44#",data);
    // console.log("88##",quetions);
    }

    function shuffle(array) {
  let currentIndex = array.length,  randomIndex;


  // While there remain elements to shuffle.
  while (currentIndex != 0) {
   console.log("79#",currentIndex,randomIndex);
    // Pick a remaining element.
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    console.log("78#",randomIndex);

    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
  }
   //console.log("80#",currentIndex,randomIndex);

  return array;
  }
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.testTopic = function (postData,t_emp) {
    var returnArray = [];
    for(var i = 0; i < postData.length; i++) {
      if(postData[i].topic.includes("Assessment")) {
        var innerObj = {};
        for(var j = 0; j < t_emp.length; j++) {
           innerObj['topic'] = postData[i].topic;
           innerObj['employeeID'] = t_emp[j].employeeID;
        }
        returnArray.push(innerObj);
      }
    }
    // const arrayUniqueByKey = [...new Map(returnArray.map(item =>  [item['topic'], item])).values()];
    console.log("!!!",returnArray);
    return returnArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.postTest = function (ques,post) {
    console.log("!!!",post);
    console.log("!!!",ques);
  };
  
  return PageModule;
});
