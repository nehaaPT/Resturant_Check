define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    currentweekstartdate(arg1) {
         const currentDate = new Date();

// Calculate the day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday) 
const dayOfWeek = currentDate.getDay();

// Calculate the number of days to subtract to get to Monday
 const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;

// Calculate the start date of the week (Monday) 
const startDateOfWeek = new Date(currentDate); startDateOfWeek.setDate(currentDate.getDate() - daysToMonday);

// Convert the start date to ISO string 
const isoStringStartDate = startDateOfWeek.toISOString().split('T')[0];

return isoStringStartDate;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    benchobject(Emp,currentweekstart,QueArray,masterQue1,masterQue2) {
          
       var data=[];
  for (var i = 0; i < Emp.length; i++) {
        // for (var j = 0; j < QueArray.length; j++) {
            var retpayload = {};
              var availableDate= Emp[i].mobile;
                if(availableDate!=undefined){
             
                   var refDate = new Date(availableDate);
  var dayOfWeek = refDate.getDay(); // 0 (Sunday) to 6 (Saturday)
  refDate.setDate(refDate.getDate() - dayOfWeek); // Adjust to the most recent Sunday

  var currentDate = new Date();
  var timeDiff = currentDate.getTime() - refDate.getTime();

  // Convert the time difference to weeks
  var weeks = Math.floor(timeDiff / (1000 * 60 * 60 * 24 * 7));

  // Adding 1 to the weeks count to start counting from Week 1
  var output = "Week " + (weeks + 1);
                 }
            retpayload['employeeID'] = Emp[i].id;
            retpayload['weekstartdate'] = currentweekstart != undefined ? currentweekstart : '';
            retpayload['benchweek']=output!=undefined?output:'';
            // retpayload['masterQue'] =masterQue1;
            // retpayload['Que'] = QueArray[j].question;
            data.push(retpayload);

        //      var retpayload1 = {};
        //     retpayload1['employeeID'] = Emp[i].id;
        //     retpayload1['weekstartdate'] = currentweekstart != undefined ? currentweekstart : '';
        //     retpayload1['masterQue'] =masterQue2;
        //     retpayload1['Que'] = QueArray[j].question;
        //     data.push(retpayload1);
        // }

   }
    return data;
    }



    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    benchbatch(BOName,operation,dataBO) {
      var batchProcessingVariableArray = new Array();
       for (var i = 0; i < dataBO.length; i++) {
    
      var data = '{"id": "part' + i + '","path": "/' + BOName + '/","operation": "' + operation + '",	"payload": '+JSON.stringify(dataBO[i])+'}';
        
      batchProcessingVariableArray.push(data);


    }
    return JSON.parse('{"parts":[' + batchProcessingVariableArray + ']}');
    }

  
   

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
   searchtable(BenchBO, EmpBO, Location, Capability) {
  var data = [];
  var employeeIDs = new Set();

  for (var i = 0; i < BenchBO.length; i++) {
    var retpayload = {};
    var emp = EmpBO.find(ele => ele.id == BenchBO[i].employeeID);
    var cap= Capability.find(caele => caele.id == emp.globalPractice);
    if (emp != undefined) {
      var loca = Location.find(ele => ele.id == emp.location);
      retpayload['employeeID'] = emp.employeeID;
      retpayload['id'] = emp.id;
      retpayload['employeename'] = emp.name;
      retpayload['localGrade'] = emp.localGrade;
      retpayload['location'] = loca != undefined ? loca.location : '';
      retpayload['office'] = emp.office;
      retpayload['joiningdate'] = emp.joiningDate;
      retpayload['community'] = cap != undefined ? cap.name : '';

      if (!employeeIDs.has(emp.employeeID)) {
        data.push(retpayload);
        employeeIDs.add(emp.employeeID);
      }
    }
  }
  return data;
}


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    shownInterestContrubuted(BenchBO,Emp,QueArray) {
       var data=[];
        for (var i = 0; i < Emp.length; i++) {
        for (var j = 0; j < QueArray.length; j++) {
         if(BenchBO[i].masterQue == "Are you interested in contributing to Oracle initiatives?" && BenchBO[i].Que == QueArray[j].question && BenchBO[i].answer == "Yes"){
            var retpayload={};
            retpayload['id']=BenchBO[i].id;
             console.log("11", retpayload);
             data.push(retpayload);
          }
           if (BenchBO[i].masterQue == "If your answer for first question is yes then Did you contribute to Oracle initiatives?" && BenchBO[i].Que == QueArray[j].question && BenchBO[i].answer == "Yes") {
            var retpayload1={};
            retpayload1['id']=BenchBO[i].id;
            retpayload1['employeeID']=BenchBO[i].employeeID;

             console.log("22", retpayload1);
             data.push(retpayload1);
          }

        }
        }
        console.log("##", data);
       return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    weekstartdate(BenchResponse) {
           var data=[];
       var uniqueDates = [...new Set(BenchResponse.map(item => item.weekstartdate))]; // Get unique dates

    uniqueDates.forEach(date => {
        var payload={};
        payload['weekstartdate'] = date;
         data.push(payload);  
    });

    return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    shownInterestButContributed(BenchBO,QueArray,EmpBO,Location,Capability) {
          var data=[];
          var employeeIDs = new Set(); 
       let emplist=BenchBO.filter(ele => ele.masterQue=='If your answer for first question is yes then Did you contribute to Oracle initiatives?' && ele.answer=='Yes');
  
          for(var i = 0; i< emplist.length; i++){
   
     var payload={};
    //  let emplist=BenchBO.filter(ele => ele.masterQue=='If your answer for first question is yes then Did you contribute to Oracle initiatives?' && ele.answer=='Yes');
   
        let emp=EmpBO.find(ele=> ele.id==emplist[i].employeeID);
         if (emp != undefined) {
            var loca = Location.find(ele => ele.id == emp.location);
         payload['id']=emp.id;
         payload['employeeID']=emp.employeeID; 
        payload['employeeID']=emp.employeeID;
      
      payload['employeeName']= emp.name;
            payload['employeeName']= emp.name;
            payload['localGrade']= emp.localGrade;
            payload['location']= loca != undefined ? loca.location : '';
            payload['office']= emp.office;
            payload['joiningDate']= emp.joiningDate;
              payload['community']= Capability.find(caele => caele.id == emp.globalPractice).name;

          // data.push(payload);
             if (!employeeIDs.has(emp.employeeID)) {
        data.push(payload);
        employeeIDs.add(emp.employeeID);
      }
          }
          }
     
      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    unmatchRecords(BenchBO,QueArray) {
      var data=[];
          
       var unmatchedRecords = [];
  


        for(let i=0;i< QueArray.length;i++)
          
        {
          let payload={};
       
          payload['question']=QueArray[i].question;
          payload['qid']=QueArray[i].id;
         
          let interested=BenchBO.filter(ele => ele.subQue === QueArray[i].id && ele.masterQue=='If your answer for first question is yes then Did you contribute to Oracle initiatives?' && ele.answer=='No');
          let count=0;
          if(interested.length!=0)
          {
             
            for (let j=0;j<interested.length;j++)   
            {
         
                 unmatchedRecords.push(interested[j]);
                  // unmatchedRecords.push(interested[j].id);
            
            }
            
          }
          //  payload['unmatchedRecord']=unmatchedRecords ;
          payload['noofpeople']=count;
          data.push(payload);
        }
       console.log('##',data);
     
       return {data,unmatchedRecords} ;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    unmatchEmployee(unmatchedrecords,EmpBO,Location,Capability,BenchBO) {
         let data = [];
  let uniqueEmployeeIDs = new Set();

  for (let i = 0; i < unmatchedrecords.length; i++) {
    var unmat = unmatchedrecords[i].employeeID;
    let emp = EmpBO.find(ele => ele.id == unmat);
    if (!uniqueEmployeeIDs.has(emp.employeeID)) {
        var loca = Location.find(ele => ele.id == emp.location);
      let load = {
        id:emp.id,
        employeeID: emp.employeeID,
        employeeName: emp.name,
        localGrade: emp.localGrade,
         office: emp.office,
        joiningDate: emp.joiningDate,
        community: Capability.find(caele => caele.id == emp.globalPractice).name
      };
      data.push(load);
      uniqueEmployeeIDs.add(emp.employeeID);
    }
  }
  return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    DefaulterCategory(BenchDairyBO,BenchResponceBO,EmpBO,Location,Capability) {

      let data=[];
      for(let i=0; i<BenchDairyBO.length; i++){
        let record=BenchResponceBO.find(ele=> ele.employeeID==BenchDairyBO[i].employeeID);
        if(!record){
          data.push(BenchDairyBO[i]);
        }
      }
      data = [...new Map(data.map(item =>  [item['employeeID'], item])).values()];   
      let data1=[];
      for(let b=0; b<data.length; b++){
        let emp=EmpBO.find(ele=> ele.id==data[b].employeeID);
        let loca = Location.find(ele => ele.id == emp.location);
        let load={};
         load['id']=emp.id;
         load['employeeID']=emp.employeeID; 
         load['employeeName']= emp.name;
         load['localGrade']= emp.localGrade;
         load['location']= loca != undefined ? loca.location : '';
         load['office']= emp.office;
         load['joiningDate']= emp.joiningDate;
         load['community']= Capability.find(caele => caele.id == emp.globalPractice).name;
         data1.push(load);
      }
      console.log('data',data1);
      return data1;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    searchTableCategory(BenchBO,QueArray,EmpBO,Location,Capability) {
       var data=[];
          var employeeIDs = new Set(); 
          for(var i = 0; i< BenchBO.length; i++){
   
     var payload={};
   
   
        let emp=EmpBO.find(ele=> ele.id==BenchBO[i].employeeID);
         if (emp != undefined) {
            var loca = Location.find(ele => ele.id == emp.location);
         payload['id']=emp.id;
         payload['employeeID']=emp.employeeID; 
        payload['employeeID']=emp.employeeID;
      
      payload['employeeName']= emp.name;
            payload['employeeName']= emp.name;
            payload['localGrade']= emp.localGrade;
            payload['location']= loca != undefined ? loca.location : '';
            payload['office']= emp.office;
            payload['joiningDate']= emp.joiningDate;
              payload['community']= Capability.find(caele => caele.id == emp.globalPractice).name;

         
             if (!employeeIDs.has(emp.employeeID)) {
        data.push(payload);
        employeeIDs.add(emp.employeeID);
      }
          }
          }
          return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    preweekdates(arg1) {
                  var dates = {};
const currentDate = new Date();

// Calculate the day difference between the current day and Monday (0)
const dayDifference = (currentDate.getDay() - 1 + 7) % 7; // 0 for Monday, 6 for Sunday

// Set the current date to the start of the current week (Monday)
currentDate.setDate(currentDate.getDate() - dayDifference);

// Subtract 7 days to get the start of the previous week
const startDate = new Date(currentDate);
startDate.setDate(startDate.getDate() - 7);

// Calculate the end date of the previous week (add 6 days)
const endDate = new Date(startDate);
endDate.setDate(startDate.getDate() + 6);

const startDateString = startDate.toISOString().split('T')[0];
const endDateString = endDate.toISOString().split('T')[0];

// Return the formatted start and end dates of the previous week
// dates['startDate'] = startDateString;
 dates['endDate'] = endDateString;

console.log(dates);
return dates;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    currentweek(arg1) {
         // const currentDate = new Date();

// Set the day of the week to Monday (1)
const currentDate = new Date();

// Calculate how many days to subtract to get to the previous Monday
const daysToSubtract = (currentDate.getDay() + 6) % 7;
currentDate.setDate(currentDate.getDate() - daysToSubtract);

// Create a new date object for the start of the week
const startDate = new Date(currentDate);

// Add 6 days to get the end of the week
const endDate = new Date(startDate);
endDate.setDate(endDate.getDate() + 6);

const startDateString = startDate.toISOString().split('T')[0];
const endDateString = endDate.toISOString().split('T')[0];

// Return the formatted start and end dates of the current week
return {
  startDate: startDateString,
  endDate: endDateString
};
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    tabledata(BenchBO, Currentstart, Preweekmonday) {
        var data = [];
    var uniqueDates = new Set();

    for (var i = 0; i < BenchBO.length; i++) {
        var date = BenchBO[i].weekstartdate;
        // Check if the date is unique before processing
         if (!uniqueDates.has(date)) {
            uniqueDates.add(date);
            var retpayload = {};
            var answer = BenchBO[i].answer;

            if (new Date(date) >= new Date(Currentstart) && answer === null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].shadowWeek;
                retpayload['status'] = 'Pending';
                retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            } else if (new Date(date) < new Date(Preweekmonday) && answer === null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].shadowWeek;
                retpayload['status'] = 'Defaulter';
                 retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            } else if (answer != null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].shadowWeek;
                retpayload['status'] = 'Completed';
                 retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            }
         }
    }
    return data;
}
  

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    firstTable(BenchQue,BenchBO) {
             var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue ==='Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(cle=>cle.subQue==BenchQue[i].id);
    if(abc.answer==="Yes"){
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
     retpayload['answers'] = abc.answer;
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    }
        }
        return data;
    }
   


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    secondTableCompleted(BenchBO,BenchQue) {
            var data = [];
             let responses = BenchBO.filter(ele => ele.masterQue === 'If your answer for first question is yes then Did you contribute to Oracle initiatives?');
  for (var i = 0; i < responses.length; i++) {
   
     let abc= BenchQue.find(ele=>ele.id==responses[i].subQue);
    let retpayload = {};
    retpayload['id'] = responses[i].id;
    retpayload['Que'] = abc.question;
     retpayload['answers'] = responses[i].answer;
     retpayload['status']=responses[i].approverStatus;
     retpayload['comment1']=responses[i].comment1;
     
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    }
        
        return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    searchtableforDownload(BenchBO,EmpBO,Capability,Location,BenchResponse,BenchQue) {
      var data = [];

  for (var i = 0; i < BenchResponse.length; i++) {
    var retpayload = {};
      // var benchResponse= BenchBO.filter(ele=> ele.employeeID==BenchResponse.employeeID);
        let Que= BenchQue.find(ele=>ele.id==BenchResponse[i].subQue);
    var emp = EmpBO.find(ele => ele.id == BenchResponse[i].employeeID);
  
    if (emp != undefined) {
      
      
      var loca = Location.find(ele => ele.id == emp.location);
      retpayload['employeeID'] = emp.employeeID;
      retpayload['id'] = emp.id;
      retpayload['employeename'] = emp.name;
        retpayload['email'] = emp.email;
      retpayload['localGrade'] = emp.localGrade;
      retpayload['location'] = loca != undefined ? loca.location : '';
      retpayload['office'] = emp.office;
      retpayload['joiningdate'] = emp.joiningDate;
      retpayload['community'] = Capability.find(caele => caele.id == emp.globalPractice).name;
     retpayload['masterQue'] =BenchResponse[i].masterQue;
    retpayload['subQue'] = Que.question;
     retpayload['weekstartdate'] = BenchResponse[i].weekstartdate;          
    retpayload['workwith'] =  BenchResponse[i].workwith;  
     retpayload['answer'] = BenchResponse[i].answer;
      retpayload['details'] = BenchResponse[i].details;
      retpayload['reason'] = BenchResponse[i].reason;
                    // retpayload['joiningdate'] = benchResponse.masterQue;
                    //   retpayload['joiningdate'] = benchResponse.masterQue;
      data.push(retpayload);
     
    }
  }
  return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    Download(downloaddata,cert_metadata) {
        var multArray = new Array();
    var headerArray = new Array();
    var metadataArray = new Array();
    
    //headers
    cert_metadata.forEach(element => headerArray.push(element.headerName));
    cert_metadata.forEach(element => metadataArray.push(element.metadata));
    multArray.push(headerArray);


    //column data
    for(var i = 0;i<downloaddata.length;i++){
      var innerArray = new Array();
       var certificationdata;

      //   innerArray.push(downloaddata[i].id);
      //  innerArray.push(downloaddata[i].id);
         innerArray.push(downloaddata[i].employeeID);
        innerArray.push(downloaddata[i].employeename);
          innerArray.push(downloaddata[i].email);
        innerArray.push(downloaddata[i].localGrade);
        innerArray.push(downloaddata[i].location);
        innerArray.push(downloaddata[i].office);
        innerArray.push(downloaddata[i].joiningdate);
        innerArray.push(downloaddata[i].community);
        innerArray.push(downloaddata[i].masterQue);
        innerArray.push(downloaddata[i].subQue);
        innerArray.push(downloaddata[i].answer);
     
      innerArray.push(downloaddata[i].workwith);
      
      innerArray.push(downloaddata[i].details);
      innerArray.push(downloaddata[i].reason);
         innerArray.push(downloaddata[i].weekstartdate);
      //  innerArray.push(downloaddata[i].id);
      
      
      
   
     
      
     
     
     
      
      
       
        
    
    

       
  
      multArray.push(innerArray);
    }
    
      var wb = XLSX.utils.book_new();
    wb.SheetNames.push("BenchEmplyeeDetails");
    
    var ws = XLSX.utils.aoa_to_sheet(multArray);
    wb.Sheets["BenchEmplyeeDetails"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});

    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "BenchEmplyeeDetails" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    };
    }



    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    thirdTableADP(arg1) {
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    previousMondayDate(inputDate) {
       const date = new Date(inputDate);
  const day = date.getDay();
  const diff = date.getDate() - day - 6;

  const lastMondayDate = new Date(date.setDate(diff));
  const formattedDate = lastMondayDate.toISOString().slice(0, 10);

  return formattedDate;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    nearestDate(datesArray,date) {
        var collectDates = [];
for (var i = 0; i < datesArray.length; i++) {
    collectDates.push(datesArray[i].diaryweekstartdate);
}

// Convert the date string to a Date object
const currentDate = new Date(date);

// Filter out dates that are greater than the current date
const filteredDates = collectDates.filter((d) => new Date(d) > currentDate);

// Find the minimum date from the filtered array
const nextDate = new Date(Math.min.apply(null, filteredDates.map((d) => new Date(d))));

// Format nextDate in yyyy-mm-dd format
const formattedNextDate = nextDate.toISOString().split('T')[0];

console.log(formattedNextDate);

return formattedNextDate;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    firstdiary(BenchQue,BenchBO) {
             var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
  
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
     retpayload['answers'] =  abc!==undefined?abc.answer:"";
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    
        }
        return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    DownloadNotContributed(unmatchedrecords,EmpBO,Location,Capability,BenchBO,Que) {
      let data = [];

for (let i = 0; i < unmatchedrecords.length; i++) {
    var unmat = unmatchedrecords[i].id;
     let bench= BenchBO.find(ele => ele.id==unmat);
    let que=Que.find(ele => ele.id==bench.subQue);
    let emp = EmpBO.find(ele => ele.id == bench.employeeID);
   
    var loca = Location.find(ele => ele.id == emp.location);
    let load = {
        id:emp.id,
        employeeID: emp.employeeID,
        employeeName: emp.name,
        localGrade: emp.localGrade,
        office: emp.office,
        joiningDate: emp.joiningDate,
        community: Capability.find(caele => caele.id == emp.globalPractice).name,
        que:que.question,
        masterQue:bench.masterQue,
         answer:bench.answer,
        details:bench.details,
        hoursSpend:bench.hoursSpend,
         workwith:bench.workwith,
        reason:bench.reason,
        officeAttendance:bench.officeAttendance,
         weekstartdate:bench.weekstartdate
    };
    data.push(load);
}

return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    downloadnotContributed(downloaddata,cert_metadata) {
          var multArray = new Array();
    var headerArray = new Array();
    var metadataArray = new Array();
    
    //headers
    cert_metadata.forEach(element => headerArray.push(element.headerName));
    cert_metadata.forEach(element => metadataArray.push(element.metadata));
    multArray.push(headerArray);


    //column data
    for(var i = 0;i<downloaddata.length;i++){
      var innerArray = new Array();
       var certificationdata;

      //   innerArray.push(downloaddata[i].id);
      // innerArray.push(certificationdata);
      innerArray.push(downloaddata[i].employeeID);
      innerArray.push(downloaddata[i].employeeName);
       innerArray.push(downloaddata[i].localGrade);
       innerArray.push(downloaddata[i].community);
     innerArray.push(downloaddata[i].office);
      innerArray.push(downloaddata[i].joiningDate);
      innerArray.push(downloaddata[i].que);
     innerArray.push(downloaddata[i].masterQue);
     innerArray.push(downloaddata[i].answer);
      innerArray.push(downloaddata[i].details);
   innerArray.push(downloaddata[i].workwith);
   innerArray.push(downloaddata[i].reason);
    innerArray.push(downloaddata[i].officeAttendance);
    innerArray.push(downloaddata[i].weekstartdate);
      multArray.push(innerArray);
    }
    
      var wb = XLSX.utils.book_new();
    wb.SheetNames.push("BenchEmplyeeDetails");
    
    var ws = XLSX.utils.aoa_to_sheet(multArray);
    wb.Sheets["BenchEmplyeeDetails"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});

    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "BenchEmplyeeDetails" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    };

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    DownloadContributed(BenchBO,QueArray,EmpBO,Location,Capability) {
        var data=[];
          // var employeeIDs = new Set(); 
       let emplist=BenchBO.filter(ele => ele.masterQue=='If your answer for first question is yes then Did you contribute to Oracle initiatives?' && ele.answer=='Yes');
  
          for(var i = 0; i< emplist.length; i++){
   
     var payload={};
    //  let emplist=BenchBO.filter(ele => ele.masterQue=='If your answer for first question is yes then Did you contribute to Oracle initiatives?' && ele.answer=='Yes');
       
        let emp=EmpBO.find(ele=> ele.id==emplist[i].employeeID);
         if (emp != undefined) {
            var loca = Location.find(ele => ele.id == emp.location);
             let que=QueArray.find(ele => ele.id==emplist[i].subQue);
         payload['id']=emp.id;
         payload['employeeID']=emp.employeeID; 
        payload['employeeID']=emp.employeeID;
      
      payload['employeeName']= emp.name;
            payload['employeeName']= emp.name;
            payload['localGrade']= emp.localGrade;
            payload['location']= loca != undefined ? loca.location : '';
            payload['office']= emp.office;
            payload['joiningDate']= emp.joiningDate;
              payload['community']= Capability.find(caele => caele.id == emp.globalPractice).name;
              payload['que']= que.question;
              payload['masterQue']= emplist[i].masterQue;
              payload['answer']= emplist[i].answer;
              payload['details']= emplist[i].details;
              payload['workwith']=  emplist[i].workwith;
              payload['reason']= emplist[i].reason;
              payload['officeAttendance']= emplist[i].officeAttendance;
              payload['weekstartdate']= emplist[i].weekstartdate;
         data.push(payload);
      //        if (!employeeIDs.has(emp.employeeID)) {
      //   data.push(payload);
      //   employeeIDs.add(emp.employeeID);
      // }
          }
          }
     
      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    downloadfileContribution(arg1) {
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    previousMondays(arg1) {
         const today = new Date();
    const year = today.getFullYear();
    const mondays = [];

    for (let i = 0; i < 10; i++) { // Change 10 to the number of previous Mondays you want\
      var payload={};
        const dayOfWeek = today.getDay();
        const diff = (dayOfWeek + 6) % 7; // Calculate the difference to the previous Monday
        const monday = new Date(today);
        monday.setDate(today.getDate() - diff - (7 * i)); // Get the date of the previous Monday
        if (monday.getFullYear() === year) {
             const formattedDate = `${monday.toISOString().slice(0, 10)}`;
             payload ['Monday'] = formattedDate;
            mondays.push(payload);
        }
    }

    return mondays;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    checkdateinBO(datesFromBo, selectedDate) {
        let presentDates = datesFromBo.filter(date => date.weekstartdate === selectedDate);
    
    if (presentDates.length > 0) {
        return true;
    } else {
        return false;
    }

    }
  }


  function FileToBytes(s) {

      var datatoload = new ArrayBuffer(s.length);

    var view = new Uint8Array(datatoload);

    for (var i = 0; i < s.length; i++)

      view[i] = s.charCodeAt(i) & 0xFF;

    return datatoload;

  }
  return PageModule;
});
