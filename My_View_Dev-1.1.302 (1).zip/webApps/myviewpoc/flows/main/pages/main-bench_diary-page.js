define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
tabledata(BenchBO, Currentstart, Preweekmonday) {
    var data = [];
    var uniqueDates = new Set();

    for (var i = 0; i < BenchBO.length; i++) {
        var date = BenchBO[i].weekstartdate;
        // Check if the date is unique before processing
         if (!uniqueDates.has(date)) {
            uniqueDates.add(date);
            var retpayload = {};
            var answer = BenchBO[i].answer;

            if (new Date(date) >= new Date(Currentstart) && answer === null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].benchweek;
                retpayload['status'] = 'Pending';
                retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            } else if (new Date(date) < new Date(Preweekmonday) && answer === null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].benchweek;
                retpayload['status'] = 'Defaulter';
                 retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            } else if (answer != null) {
                retpayload['id'] = BenchBO[i].id;
                retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
                retpayload['benchweek'] = BenchBO[i].benchweek;
                retpayload['status'] = 'Completed';
                 retpayload['employeeID'] =BenchBO[i].employeeID;
                data.push(retpayload);
            }
         }
    }
    return data;
}

updateADP(adp,current,value){
  var data=[];
  for(let i=0; i<adp.length; i++){
    let load={};
    load['answers']=adp[i].id===current.id?value:adp[i].answers;
    load['Que']=adp[i].Que;
    load['id']=adp[i].id;
    data.push(load);
  }
  return data;
}


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    preweekdates(arg1) {
            var dates = {};
const currentDate = new Date();

// Calculate the day difference between the current day and Monday (0)
const dayDifference = (currentDate.getDay() - 1 + 7) % 7; // 0 for Monday, 6 for Sunday

// Set the current date to the start of the current week (Monday)
currentDate.setDate(currentDate.getDate() - dayDifference);

// Subtract 7 days to get the start of the previous week
const startDate = new Date(currentDate);
startDate.setDate(startDate.getDate() - 7);

// Calculate the end date of the previous week (add 6 days)
const endDate = new Date(startDate);
endDate.setDate(startDate.getDate() + 6);

const startDateString = startDate.toISOString().split('T')[0];
const endDateString = endDate.toISOString().split('T')[0];

// Return the formatted start and end dates of the previous week
// dates['startDate'] = startDateString;
 dates['endDate'] = endDateString;

console.log(dates);
return dates;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    currentweek(arg1) {
        // const currentDate = new Date();

// Set the day of the week to Monday (1)
const currentDate = new Date();

// Calculate how many days to subtract to get to the previous Monday
const daysToSubtract = (currentDate.getDay() + 6) % 7;
currentDate.setDate(currentDate.getDate() - daysToSubtract);

// Create a new date object for the start of the week
const startDate = new Date(currentDate);

// Add 6 days to get the end of the week
const endDate = new Date(startDate);
endDate.setDate(endDate.getDate() + 6);

const startDateString = startDate.toISOString().split('T')[0];
const endDateString = endDate.toISOString().split('T')[0];

// Return the formatted start and end dates of the current week
return {
  startDate: startDateString,
  endDate: endDateString
};
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    a(quetion,value) {
      let retpayload={};
      retpayload[quetion]=value;
      return retpayload;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    description(index,description) {

      var array=[];
array=['interviewDescription','solutionDescription','trainingDescription','offergenerationDescription','whitepaperDescription','developmentoftoolsDescription','pursuitDescriptions'];
let load={};
load[array[index]]=description;
return load;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    tableData(BenchBO,Currentstart,Preweekmonday) {
     var data = [];
     
          
      for (var i=0; i<BenchBO.length; i++){
          var retpayload = {};
           var date=BenchBO[i].weekstartdate;
           var trainingRecording=BenchBO[i].TrainingRecording;



if (new Date(date) >= new Date(Currentstart)  && trainingRecording === null) {
         retpayload['id'] = BenchBO[i].id;
    retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
    retpayload['benchweek'] = BenchBO[i].shadowWeek;
    retpayload['status'] ='Pending';
    data.push(retpayload);
} else if (new Date(date) < new Date(Preweekmonday) && trainingRecording === null) {
    retpayload['id'] = BenchBO[i].id;
    retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
    retpayload['benchweek'] = BenchBO[i].shadowWeek;
    retpayload['status'] ='Defaulter';
    data.push(retpayload);
} else if (trainingRecording != null) {
    retpayload['id'] = BenchBO[i].id;
    retpayload['diaryweekstartdate'] = BenchBO[i].weekstartdate;
    retpayload['benchweek'] = BenchBO[i].shadowWeek;
    retpayload['status'] = 'Completed';
    data.push(retpayload);
}
      }
      return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    radioSetvalues(currentValues,employeeID,weekstartdate,radioset,predata) {
     var storeValues=[];
 
    storeValues.push({ 
    currentValues: currentValues, 
    employeeID: employeeID, 
    weekstartdate: weekstartdate, 
    radioset: radioset, 
    predata: predata 
  });
   
  console.log("###", storeValues);
  return storeValues;
  }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    anserBatch(BOName,operation,dataBO,weekstartdate,employeeID) {
    var batchProcessingVariableArray = [];

  for (var i = 0; i < dataBO.length; i++) {
    var data = {
      id: "part" + i,
      path: "/" + BOName + "/",
      "operation": operation,
      "payload":{ "answer":dataBO[i].answers,
      "subQue":dataBO[i].id,
      "employeeID":employeeID,
      "masterQue":'Are you interested in contributing to Oracle initiatives?',
      "weekstartdate":weekstartdate
      }
    };
    batchProcessingVariableArray.push(data);
  }

  return JSON.stringify({ parts: batchProcessingVariableArray });
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    secondtable(storedData,radioset) {
     var data = [];
  // var uniqueQueSet = new Set();

  for (var i = 0; i < storedData.length; i++) {
    if (storedData[i].answers === "Yes") {
      // var currentQue = storedData[i].currentValues.Que;
      // if (!uniqueQueSet.has(currentQue)) {
        var retpayload = {};
        retpayload['id'] = storedData[i].id;
        retpayload['Que'] = storedData[i].Que;
        data.push(retpayload);
      //   uniqueQueSet.add(currentQue);
      // }
    }
  }
      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    previousResponse(BenchBO)  {
  var data = [];
  for (var i = 0; i < BenchBO.length; i++) {
    if (BenchBO[i].masterQue == "Are you interested in contributing to Oracle initiatives?" && BenchBO[i].Que == 'Pursuits') {
      let retpayload = {};
      retpayload['id'] = BenchBO[i].id;
      retpayload['answer'] = BenchBO[i].answer;
      data.push(retpayload);
    }
    else if (BenchBO[i].masterQue == "Are you interested in contributing to Oracle initiatives?" && BenchBO[i].Que == 'DevelopmentOfTools'){
      let retpayload = {};
      retpayload['id'] = BenchBO[i].id;
      retpayload['answer'] = BenchBO[i].answer;
      data.push(retpayload);

    }
  }
  return data;
}

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    firstTable(BenchQue,BenchBO) {
         var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
    if(abc.answer=="Yes"){
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
     retpayload['answers'] = abc.answer;
     retpayload['status'] = abc.approverStatus;
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    }
        }
        return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    radioSetSecond(currentValues, radioset, employeeID, weekstartdate,hrs,description,connectedwith,reason) {
       var storeValues=[];
 
  // Combine currentValues and radioset and add them as a pair to the array
    storeValues.push({ currentValues, radioset, employeeID, weekstartdate});
   
  console.log("###", storeValues);
  return storeValues;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    createDescription(BOName,operation,dataBO,employeeID,weekstartdate,BenchQue) {
      var batchProcessingVariableArray = [];

  for (var i = 0; i < dataBO.length; i++) {
   let que=BenchQue.find(ele=>ele.question==dataBO[i].Que);
    var data = {
      id: "part" + i,
      path: "/" + BOName + "/",
      "operation": operation,
      "payload":{ "answer":dataBO[i].answers,
      "subQue":que.id,
      "employeeID":employeeID,
      "masterQue":'If your answer for first question is yes then Did you contribute to Oracle initiatives?',
      "weekstartdate":weekstartdate,
      "workwith":dataBO[i].workWith,
      "reason":dataBO[i].reason,
      "details":dataBO[i].description,
      "hoursSpend":dataBO[i].hrSpend
      }
    };
    batchProcessingVariableArray.push(data);
  }

// var jsonString = JSON.stringify({ parts: batchProcessingVariableArray });
//     return JSON.parse(jsonString);

 var json= JSON.stringify({ "parts": batchProcessingVariableArray });
 return JSON.parse(json);
  //  return JSON.stringify('{"parts":[' + batchProcessingVariableArray + ']}');
 // return JSON.parse({parts: batchProcessingVariableArray});
    }

    stringToArray(str, separator) {
    return str.split(separator);
}

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    preweekstartdate(arg1)  {
           var dates = {};
const currentDate = new Date();

// Calculate the day difference between the current day and Monday (0)
const dayDifference = (currentDate.getDay() - 1 + 7) % 7; // 0 for Monday, 6 for Sunday

// Set the current date to the start of the current week (Monday)
currentDate.setDate(currentDate.getDate() - dayDifference);

// Subtract 7 days to get the start of the previous week
const startDate = new Date(currentDate);
startDate.setDate(startDate.getDate() - 7);

// Calculate the end date of the previous week (add 6 days)
const endDate = new Date(startDate);
endDate.setDate(startDate.getDate() + 6);

const startDateString = startDate.toISOString().split('T')[0];
const endDateString = endDate.toISOString().split('T')[0];

// Return the formatted start and end dates of the previous week
dates['startDate'] = startDateString;
 dates['endDate'] = endDateString;

console.log(dates);
return dates;


}


    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    secondTablePreviousData(storedData) {
       var data=[];
      for (var i=0; i<storedData.length; i++){
        if(storedData[i].answers=="Yes"){
       var retpayload={};
       retpayload['id']=storedData[i].id;
       retpayload['Que']=storedData[i].Que;
        retpayload['answers']='';
        // retpayload['status'] = storedData[i].approverStatus;
       data.push(retpayload);
        }
      }
      return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    secondTableCompleted(BenchBO,BenchQue) {
            var data = [];
             let responses = BenchBO.filter(ele => ele.masterQue === 'If your answer for first question is yes then Did you contribute to Oracle initiatives?');
  for (var i = 0; i < responses.length; i++) {
   
     let abc= BenchQue.find(ele=>ele.id==responses[i].subQue);
    let retpayload = {};
    retpayload['id'] = responses[i].id;
    retpayload['Que'] = abc.question;
     retpayload['answers'] = responses[i].answer;
     retpayload['status']=responses[i].approverStatus;
      retpayload['comment1']=responses[i].comment1;
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    }
        
        return data;
      
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    thirdTable(BenchQue,BenchBO) {
           var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
  
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
     retpayload['answers'] =  "";
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    
        }
        return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    updateADPsecond(adp,current,value) {
        var data=[];
  for(let i=0; i<adp.length; i++){
    let load={};
    load['answers']=adp[i].id===current.id?value:adp[i].answers;
    load['Que']=adp[i].Que;
    load['id']=adp[i].id;
    data.push(load);
  }
  return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    thirdTableADPupdate(adp,current,value) {
       var data=[];
  for(let i=0; i<adp.length; i++){
    let load={};
    load['answers']=adp[i].id===current.id?value:adp[i].answers;
    load['Que']=adp[i].Que;
    load['id']=adp[i].id;
    data.push(load);
  }
  return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    checkstatus(data1) {
  let button =0;
      for(let i=0; i<data1.length; i++){
       if(data1[i].answers!='' ){
          button+=1;
      }

    }
    if(button==data1.length){
      return true;
    }
    else{
      return false;
    }
  }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    firsttimefillingdiary(BechBO,employeeID) {
      let data =0;
      for(let i=0; i<BechBO.length; i++){ 
       var record= BechBO.find(ele=> ele.employeeID==employeeID);
      }
      if (record !== undefined) {
    return true;
  } else {
    return false;
  }

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    firsttimeTable(BenchQue,BenchBO) {
           var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
  
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
     retpayload['answers'] =  abc!==undefined?abc.answer:"";
    // retpayload['answers'] = responses.answer;
    data.push(retpayload);
    
        }
        return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    nearestDate(datesArray,date) {
   var collectDates = [];
for (var i = 0; i < datesArray.length; i++) {
    collectDates.push(datesArray[i].diaryweekstartdate);
}

// Convert the date string to a Date object
const currentDate = new Date(date);

// Filter out dates that are greater than the current date
const filteredDates = collectDates.filter((d) => new Date(d) > currentDate);

// Find the minimum date from the filtered array
const nextDate = new Date(Math.min.apply(null, filteredDates.map((d) => new Date(d))));

// Format nextDate in yyyy-mm-dd format
const formattedNextDate = nextDate.toISOString().split('T')[0];

console.log(formattedNextDate);

return formattedNextDate;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    updateADPfirsttry(adp,value,current) {
      var data=[];
  for(let i=0; i<adp.length; i++){
    let load={};
    load['answers']=adp[i].id===current.id?value:adp[i].answers;
    load['Que']=adp[i].Que;
    load['id']=adp[i].id;
    data.push(load);
  }
  return data;
      

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    thirdTableCompleted(BenchBO,BenchQue) {
               var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
  
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
    //  retpayload['answers'] =  "No";
    retpayload['answers'] = abc.answer;
    data.push(retpayload);
    
        }
        return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    previousMondayDate(inputDate) {
    const date = new Date(inputDate);
  const day = date.getDay();
  const diff = date.getDate() - day - 6;

  const lastMondayDate = new Date(date.setDate(diff));
  const formattedDate = lastMondayDate.toISOString().slice(0, 10);

  return formattedDate;
  }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    checkstatusthirdtable(data1) {
      let button =0;
      for(let i=0; i<data1.length; i++){
       if(data1[i].answers!='' ){
          button+=1;
      }

    }
    if(button==data1.length){
      return true;
    }
    else{
      return false;
    }
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    saveButtonPopUpTable(BenchQue,BenchBO) {
                     var data = [];
  for (var i = 0; i < BenchQue.length; i++) {
    let responses = BenchBO.filter(ele => ele.subQue === BenchQue[i].id && ele.masterQue == 'Are you interested in contributing to Oracle initiatives?');
    let abc= responses.find(ele=>ele.subQue==BenchQue[i].id)
  
    let retpayload = {};
    retpayload['id'] = BenchQue[i].id;
    retpayload['Que'] = BenchQue[i].question;
    //  retpayload['answers'] =  "No";
    retpayload['answers'] = abc!==undefined?abc.answer:"";
    data.push(retpayload);
    
        }
        return data;
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    updateSavepopupTableADP(adp,current,value) {
            var data=[];
  for(let i=0; i<adp.length; i++){
    let load={};
    load['answers']=adp[i].id===current.id?value:adp[i].answers;
    load['Que']=adp[i].Que;
    load['id']=adp[i].id;
    data.push(load);
  }
  return data;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    addDataTOADP(adp,hr,email,description,secondtablerowid,reason) {
    var data = [];
var uniqueData = [];

for (let i = 0; i < adp.length; i++) {
  if (secondtablerowid == adp[i].id) {
    let load = {};
    load['answers'] = adp[i].answers;
    load['Que'] = adp[i].Que;
    load['hrSpend'] = hr;
    load['workWith'] = email;
    load['description'] = description;
   load['reason'] = reason;
    load['id'] = adp[i].id;
    
    // Check if the id already exists in uniqueData
    if (!uniqueData.some(item => item.id === load.id)) {
      uniqueData.push(load);
    }
  }
}

return uniqueData;

    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    updateAddDataADP(adp,final) {
 
for (let i = 0; i < adp.length; i++) {
        let load = {
            'answers': adp[i].answers,
            'Que': adp[i].Que,
            'hrSpend': adp[i].hrSpend,
            'workWith': adp[i].workWith,
            'description': adp[i].description,
            'reason': adp[i].reason,
            'id': adp[i].id
        };

        let existingIndex;
        if (final) {
            existingIndex = final.findIndex(item => item.id === adp[i].id);
        }

        // Check if data already contains a record with the same id
        if (existingIndex !== -1) {
            // Replace the existing record with the latest one
            final[existingIndex] = load;
        } else {
            // If not found, push the new record into the array
            final.push(load);
        }
    }
    return final;


    }
    
  }
  return PageModule;
});


