define([], () => {
  'use strict';

  class PageModule {
    
  }
  PageModule.prototype.postDataSearch = function (E_main,E_sector,E_comminity,E_location,E_name,year,month,account) {
     var data = new Array();
     var data1 = new Array();
    var format;
     for(var i=0; i<E_main.length;i++){
       var retpayload = {};
       var ele=E_name.find(ele => ele.id == E_main[i].employeeBO);
      //  var ele2=E_cyc.find(ele2 => ele2.id == E_main[i].recognisationCycleBO); 
       
       var mon= (new Date(E_main[i].yearMonth).getMonth()<9 ? '0'+ (new Date(E_main[i].yearMonth).getMonth()+1): ''+ (new Date(E_main[i].yearMonth).getMonth()+1) );
       var yr =  new Date(E_main[i].yearMonth).getFullYear();

          var date=new Date(E_main[i].yearMonth);
           
        
       if( month !='' && year!= '')
       {
        if(yr == year && mon == month)
         {
           

             retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele!=undefined?E_location.find(locele => locele.id == ele.location).location:'NA';
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
              data.push(retpayload);
         }
       }
        
        else if( year != '')
           {
             if( yr== year)
             {
           
              
             retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
              data.push(retpayload);
            }
          }
        else if( month != '')
          {
            if( mon== month)
           {
           
               
              retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
              data.push(retpayload);
            }
          }
        
        else if(year == '' || month == '')
        {
         
            if(E_main[i].teamAppreciation==null && account == '')
            {
            retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] =ele==undefined?'NA':ele.location==null?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
            data.push(retpayload);
           
            }
            else if(account != '' && E_main[i].teamAppreciation==null )
            {
            retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
            data1.push(retpayload);

          }
          else if( account != '' && E_main[i].teamAppreciation!=null)
          {
            retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
              retpayload ['region']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).region;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
            data1.push(retpayload);

          }
          
        }
        // if(E_main[i].teamAppreciation != null)
        // {
        //    retpayload['accountName']=E_main[i].accountName;
        //    retpayload['teamAppreciation']=E_main[i].teamAppreciation;
        //    retpayload['customerName']=E_main[i].customerName;
        //   retpayload['appreciationMsg']=E_main[i].appreciationMsg;
        //    data.push(retpayload);
        // }
       
      }
     console.log(">>",data);
     if(account !='')
     {
      return data1; 
     }
     else{
       return data; 
     }
     
    
  }
  PageModule.prototype.downloadRRDetails=function(employeeData,metaDataArray){
  
  var multidata = new Array();

  for(let i = 0;i<=employeeData.length;i++)
  {
    var instanceArray = []; 
    if(i == 0) {
      instanceArray.push('Employee-ID');
      instanceArray.push('Name');
      instanceArray.push('Grade');
      instanceArray.push('Sector');
      instanceArray.push('Community');
      instanceArray.push('Location');
      instanceArray.push('AccountName');
      instanceArray.push('CustomerName');
      instanceArray.push('Appreciation of team');
      instanceArray.push('Appreciation Message/Quote');
      instanceArray.push('region');
      instanceArray.push('YearMonth');
      multidata.push(instanceArray);
    }
    else {

       var date=new Date(employeeData[i-1].yearMonth);
        if(isNaN(Number(employeeData[i-1].employeeID,Number))) {
          instanceArray.push(employeeData[i-1].employeeID);
        }
        else{
         instanceArray.push(Number(employeeData[i-1].employeeID));
         //console.log("%%",Number(employeeData[i-1].employeeID));
       }
       instanceArray.push(employeeData[i-1].name);
       instanceArray.push(employeeData[i-1].grade);
       instanceArray.push(employeeData[i-1].sector);
       instanceArray.push(employeeData[i-1].community);
       instanceArray.push(employeeData[i-1].location);
       instanceArray.push(employeeData[i-1].accountName);
       instanceArray.push(employeeData[i-1].customerName);
       instanceArray.push(employeeData[i-1].teamAppreciation);
        instanceArray.push(employeeData[i-1].appreciationMsg);
        instanceArray.push(employeeData[i-1].region);
       instanceArray.push(employeeData[i-1].yearMonth=((date.getDate()<=9?'0'+date.getDate():''+(date.getDate()))+'-'+(date.toLocaleString('default', { month: 'short' }))+'-'+date.getFullYear()));
       multidata.push(instanceArray);
   }
   
   }

  var wb = XLSX.utils.book_new();
  wb.SheetNames.push("Appreciation Details");
  var ws = XLSX.utils.aoa_to_sheet(multidata);
  wb.Sheets["Appreciation Details"] = ws;
  var fileBytes = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

  //saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), 'test.xlsx');



  fileBytes=FileToBytes(fileBytes);
console.log(fileBytes);
var blob = new Blob([fileBytes],{type:'octet/stream'});
var filename = "Appreciation Details_"+new Date().toISOString().split('T')[0]+".xlsx";

 
if(navigator.msSaveBlob){ // IE 10+
  navigator.msSaveBlob(blob,filename);
} else {
  var link = document.createElement("a");
  if(link.download !== undefined){ // feature detection
    // Browsers that support HTML5 download attribute
    var url = URL.createObjectURL(blob);
    link.setAttribute("href",url);
    link.setAttribute("download",filename);
    link.setAttribute("target","_blank");
    link.style.visibility='hidden';
    document.body.appendChild(link);
    link.click();
    console.log('Link'+JSON.stringify(link));
   // var win = window.open(url, "_blank");
  //  win.focus();
    document.body.removeChild(link);
  }
}
 }
  function FileToBytes(s) {
          var buf = new ArrayBuffer(s.length);
          var view = new Uint8Array(buf);
          for (var i = 0; i < s.length; i++)
           view[i] = s.charCodeAt(i) & 0xFF;
          return buf;
  }
  PageModule.prototype.getuniqueClient = function (Category) {
    var arrayobj=Object.values(Category);
    
    const arrayUniqueByKey = [...new Map(Category.map(item =>  [item['accountName'], item])).values()];   
    console.log(">>",arrayUniqueByKey);      
    
    return arrayUniqueByKey;
  };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
     PageModule.prototype.blankSearch= function (E_main,E_sector,E_comminity,E_location,E_name,foramt) {
    var data = new Array();
     var data1 = new Array();
     for(var i=0; i<E_main.length;i++){
       var retpayload = {};
       var ele=E_name.find(ele => ele.id == E_main[i].employeeBO);
  
        if (E_main[i].teamAppreciation!=null)
         {
            retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':ele.location==null?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
            data.push(retpayload);
          
        }
        else{
          retpayload['yearMonth']=E_main[i].yearMonth;
            retpayload ['employeeID']=ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).employeeID;
            retpayload ['name']= ele==undefined?'NA': E_name.find(ele => ele.id == E_main[i].employeeBO).name;
            retpayload ['grade']= ele==undefined?'NA':E_name.find(ele => ele.id == E_main[i].employeeBO).grade;
            retpayload ['sector'] = ele==undefined?'NA':E_sector.find(secele => secele.id == ele.bu).name;
            retpayload ['community'] = ele==undefined?'NA':E_comminity.find(comele => comele.id == ele.globalPractice).name;
            retpayload ['location'] = ele==undefined?'NA':ele.location==null?'NA':E_location.find(locele => locele.id == ele.location).location;
             retpayload['accountName']=E_main[i].accountName;
            retpayload['teamAppreciation']=E_main[i].teamAppreciation==null?'Employee':E_main[i].teamAppreciation;
            retpayload['customerName']=E_main[i].customerName;
            retpayload['appreciationMsg']=E_main[i].appreciationMsg;
              data1.push(retpayload);
        }
     }
     console.log(">>",data);
     if(foramt=='Team')
     {
      return data;
     }
     else
     {
       return data1;
     }

     }
      PageModule.prototype.buildQFormat = function (format) {
    var qparameter=''
    if (format=="Both")
    qparameter="(employeeBOObject.format='US' or employeeBOObject.format='India')";

    else if(format=="US") {
      qparameter="employeeBOObject.format='US'";
    }
    else{
      qparameter="employeeBOObject.format='India'";
    }
    console.log("@1"+qparameter)

   return qparameter;
  };
  
  return PageModule;
});
