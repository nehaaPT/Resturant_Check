define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    createQParameter(searchVar,user) {
      var q;
       q = "status ='"+searchVar.status+"' AND ideaName LIKE '%"+searchVar.ideaName+"%' AND ideaBelongsToApplication LIKE '%"+searchVar.ideaBelongsToApplication+"%' and ( ideaGeneratorEmpID='"+user+"')" ;
          console.log("qq",q);
      // if(searchVar.status != '')
      // {
      //     q = "status ='"+searchVar.status+"' AND technology = '"+searchVar.technology+"' AND ideaGeneratorEmpIDObject.name LIKE '%"+searchVar.ideaGeneratorEmployeeName+"%'";
      //     console.log("qq",q);
      // }
      // else
      // {
      //    q=" AND technology = '"+searchVar.technology+"' AND ideaGeneratorEmpIDObject.name LIKE '%"+searchVar.ideaGeneratorEmployeeName+"%' AND cIChampionEmailID = '"+user+"'";
      // }
      return q;
    }

    display(innovationBO,userBOid) {
      var q;
      var count=0;
      console.log("roles....",userBOid);
      for(var i = 0;i<innovationBO.length;i++)
      {
       console.log("roles....",innovationBO[i]);
        if(userBOid==innovationBO[i].ideaGeneratorEmpID)
        {
          q="(ideaGeneratorEmpID = '"+userBOid+"')";
        }
        if(userBOid==innovationBO[i].cIChampionEmailID)
        {
          q="(ideaGeneratorEmpID = '"+userBOid+"' ) or ((status = 'CI CHAMPION APPROVAL REQUESTED' or status ='SENT BACK BY CI CHAMPION' or status = 'EM APPROVAL REQUESTED') and (cIChampionEmailID = '"+userBOid+"'))";
        }
        if(userBOid==innovationBO[i].eMEmailID)
        {
          q="(ideaGeneratorEmpID = '"+userBOid+"') or ((status = 'EM APPROVAL REQUESTED' or status ='SENT BACK BY EM' or status = 'CLOSED') and (eMEmailID = '"+userBOid+"'))";   
        }
        if(userBOid==innovationBO[i].additionalEM)
        {
          q="(ideaGeneratorEmpID = '"+userBOid+"') or ((status = 'EM APPROVAL REQUESTED' or status ='SENT BACK BY EM' or status = 'CLOSED') and (additionalEM = '"+userBOid+"'))";   
        }
      }
      console.log("roles....",q);
      return q;
    }

    display2(innovationBO,userBOid) {
      var q="(ideaGeneratorEmpID = '"+userBOid+"')";
      var count=0,emRoleCount = 0,empRoleCount = 0,muRoleCount = 0, addEmCount = 0;
      console.log("roles....",userBOid);
      for(var i = 0;i<innovationBO.length;i++)
      {
       console.log("roles....",innovationBO[i]);
        if(userBOid==innovationBO[i].ideaGeneratorEmpID)
        {
          empRoleCount +=1;
        }
        if(userBOid==innovationBO[i].muSpoc)
        {
          muRoleCount+=1;
        }
        if(userBOid==innovationBO[i].eMEmailID)
        {
          emRoleCount += 1;
        }
        //  if(userBOid==innovationBO[i].additionalEM)
        // {
        //   addEmCount += 1;
        // }
      }
      // if(muRoleCount > 0){
      //   q += " or (muSpoc = '"+userBOid+"')";
      // }
      // if(emRoleCount > 0){
      //   q+= " or (eMEmailID = '"+userBOid+"')";
      // }
      
      console.log("roles....",q);
      return q;
    }

    checkStatus(userBOid,userRoleId,updateVar){
      let enable = true;
      if(userBOid == userRoleId.ideaGeneratorID){
          if( updateVar.status =='IN PROGRESS' || updateVar.status == 'SENT BACK BY MU SPOC' || updateVar.status == 'SENT BACK BY EM'){
            return false;
          }
          else return true;
        }
        else if(userBOid == userRoleId.muSpocId){
           if(updateVar.status == 'MU SPOC APPROVAL REQUESTED'){
            return false;
          }
          else return true;
        }
        else if(userBOid == userRoleId.eMId){
          if(updateVar.status == 'EM APPROVAL REQUESTED' || updateVar.status =='PROPOSED' || updateVar.status == 'MU SPOC APPROVAL REQUESTED'){
            return false;
          }
          else return true;
        }
        //  else if(userBOid == userRoleId.addEMId){
        //   if(updateVar.status == 'EM APPROVAL REQUESTED' || updateVar.status =='PROPOSED' || updateVar.status == 'MU SPOC APPROVAL REQUESTED'){
        //     return false;
        //   }
        //   else return true;
        // }
        console.log("eeee",enable,userBOid,userRoleId,updateVar);
        //return enable;
      }
    

    checkStatusforSavingDetails(updateVar){
      let enable = true;
      
          if(updateVar.status != "IN PROGRESS" && updateVar.status != "PROPOSED" && updateVar.status != "REJECTED" && updateVar.status != "SENT BACK BY EM" && updateVar.status != "SENT BACK BY MU SPOC"){
            return true;
          }
          else return false;
        
        console.log("eeee",enable,userBOid,userRoleId,updateVar);
        //return enable;
      }
  
  }
  // PageModule.prototype.returnVisibillity=function(roleAccessArray,screen,type){
  //     var data=roleAccessArray.find(element=>element.functionality==screen)
  //     if(data.accessType==type)
  //     {
  //       return false;
  //     }
  //     else{
  //     return true;
  //     }

  // };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */

     PageModule.prototype.checkBenefit= function (benefitClass) {
       var enableSaving = {};

       if(benefitClass == 'Capgemini Group Value Add (CGVA)'){
          enableSaving['enablePtva'] =true;
          enableSaving['enableCgva'] =false;
          enableSaving['enableCva'] =true;
          return enableSaving;
       }
       else if(benefitClass == 'Customer Value Add (CVA)'){
         enableSaving['enablePtva'] =true;
          enableSaving['enableCgva'] =true;
          enableSaving['enableCva'] =false;
          return enableSaving;
       }
       else if(benefitClass == 'Project Team Value Add (PTVA)'){
         enableSaving['enablePtva'] =false;
          enableSaving['enableCgva'] =true;
          enableSaving['enableCva'] =true;
          return enableSaving;
       }
       else if(benefitClass == 'Both (CVA & PTVA)'){
         enableSaving['enablePtva'] =false;
          enableSaving['enableCgva'] =true;
          enableSaving['enableCva'] =false;
          return enableSaving;
       }
       else if(benefitClass == 'Both (CGVA & PTVA)'){
         enableSaving['enablePtva'] =false;
          enableSaving['enableCgva'] =false;
          enableSaving['enableCva'] =true;
          return enableSaving;
       }
       else if(benefitClass == 'Both (CGVA & CVA)'){
         enableSaving['enablePtva'] =true;
          enableSaving['enableCgva'] =false;
          enableSaving['enableCva'] =false;
          return enableSaving;
       }


    };

    PageModule.prototype.createPayloadFunction = function (data,EmpBO,PrjBO,clientBO,BuBO) {
    console.log("#3030",data);
    data.muSpoc=EmpBO.find(ele =>ele.email == data.muSpoc)?EmpBO.find(ele =>ele.email == data.muSpoc).id:'';
    data.eMEmailID=EmpBO.find(ele =>ele.email == data.eMEmailID)?EmpBO.find(ele =>ele.email == data.eMEmailID).id:'';
    data.cIChampionEmailID=EmpBO.find(ele => ele.email == data.cIChampionEmailID)?EmpBO.find(ele => ele.email == data.cIChampionEmailID).id:'';
    data.projectId=PrjBO.find(pele=>pele.projectCode == data.projectId)?PrjBO.find(pele=>pele.projectCode == data.projectId).id:'';
    data.ideaGeneratorEmpID=EmpBO.find(ele =>ele.employeeID == data.ideaGeneratorEmpID)?EmpBO.find(ele =>ele.employeeID == data.ideaGeneratorEmpID).id:'';
    data.accountName=clientBO.find(ele => ele.clientName == data.accountName)?clientBO.find(ele => ele.clientName == data.accountName).id:'';
    //data.marketUnit=BuBO.find(ele => ele.name == data.marketUnit)?BuBO.find(ele => ele.name == data.marketUnit).id:'';
    data.technology=data.technology==""?"-":data.technology;
    data.subProcess=data.subProcess==""?"-":data.subProcess;
    data.ideaBelongsToApplication=data.ideaBelongsToApplication==""?"-":data.ideaBelongsToApplication;
    data.additionalEM = data.additionalEM !== null ? data.additionalEM:'';
    console.log('#3030',data);
    return data;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.assignEmployee = function (ideaGenEmpId,populateVariable,EmpBO,BuBO) {
    console.log("$45",ideaGenEmpId,populateVariable);
    populateVariable.ideaGeneratorEmpName = EmpBO.find(ele => ele.employeeID == ideaGenEmpId).name;
    populateVariable.ideaGeneratorEmpEmail = EmpBO.find(ele => ele.employeeID == ideaGenEmpId).email;
    populateVariable.ideaGeneratorEmpSector = BuBO.find(buele =>buele.id == (EmpBO.find(ele => ele.employeeID == ideaGenEmpId).bu)).id;
    console.log("$45",populateVariable);
    return populateVariable;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.assignProject = function (prjId,populateVariable,PrjBO,ClientBO) {
    console.log("$55",populateVariable);
    populateVariable.projectName = PrjBO.find(prj =>prj.projectCode == prjId).projectName;
    populateVariable.accountName = ClientBO.find(cele=>cele.id == (PrjBO.find(prj=>prj.projectCode == prjId).client)).clientName;
    console.log("$55",populateVariable);
    return populateVariable;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.generateCurrentDate = function () {
    var date = new Date();
	  
    var current_date = date.toISOString();
    return current_date;
  };
  PageModule.prototype.generatePreviousDate = function () {
    var date = new Date();
    date.setDate(date.getDate() - 1);

	  
    var current_date = date.toISOString();
    return current_date;
  };

  PageModule.prototype.autoPopulate = function (user,EmpBO,populateVariable,BuBO,EmpProject,PrjBO,ClientBO,PrjMasterBO) {
   console.log("1111",user);
   console.log("123",EmpProject);
   populateVariable.ideaGeneratorEmpID = EmpBO.find(ele => ele.id == user).employeeID;
   populateVariable.ideaGeneratorEmpName = EmpBO.find(ele => ele.id == user).name;
   populateVariable.ideaGeneratorEmpEmail = EmpBO.find(ele => ele.id == user).email;
   populateVariable.ideaGeneratorEmpSector = BuBO.find(buele =>buele.id == (EmpBO.find(ele => ele.id == user).bu)).id;
   populateVariable.projectCode =PrjBO.find(ele => ele.id == EmpProject[0].project).projectCode;
   populateVariable.projectName =PrjBO.find(ele => ele.id == EmpProject[0].project).projectName;
   populateVariable.accountName =ClientBO.find(ele => ele.id == EmpProject[0].client).clientName;
   var PrjMasEM = PrjMasterBO.find(ele => ele.projectCode == EmpProject[0].project)?(PrjMasterBO.find(ele => ele.projectCode == EmpProject[0].project).emID):'';
   var CIChampion = PrjMasterBO.find(ele => ele.projectCode == EmpProject[0].project)?(PrjMasterBO.find(ele => ele.projectCode == EmpProject[0].project).cIChampion):'';
   populateVariable.eMEmailID =EmpBO.find(empele => empele.id == PrjMasEM)?EmpBO.find(empele => empele.id == PrjMasEM).email:'';
   populateVariable.muSpoc = EmpBO.find(ele => ele.id == (BuBO.find(bele => bele.id == populateVariable.ideaGeneratorEmpSector).muSpoc))?EmpBO.find(ele => ele.id == (BuBO.find(bele => bele.id == populateVariable.ideaGeneratorEmpSector).muSpoc)).email:'';
   populateVariable.cIChampionEmailID = EmpBO.find(empele => empele.id == CIChampion)?EmpBO.find(empele => empele.id == CIChampion).email:'';
   populateVariable.applicationMaintenanceDevelopm = PrjMasterBO.find(ele => ele.projectName == EmpProject[0].project)?(PrjMasterBO.find(ele => ele.projectName == EmpProject[0].project).amsAd):'';
   console.log("2222",populateVariable);
   return populateVariable;
  };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.creditCategory=function(totalSaving){
      if(totalSaving==null)
      {
        return 32;
      }
      else if(totalSaving<5000 && totalSaving!=0)
      {
        return 7;
      }
      else if(totalSaving>=5000 && totalSaving<10000)
      {
         return 8;
      }
      else if(totalSaving>=10000 && totalSaving<20000)
      {
        return 9;
      }
      else if(totalSaving>20000)
      {
        return 10;
      }
    };

    PageModule.prototype.updateCredit=function(emp,creditData,intensity) {

      // if(emp=='Billable')
      // {
        return Number(creditData)+Number(intensity);
      // }
      // else
      // {
      //   var totalCredit;
      //   var point=Number(intensity);
      //   point=intensity*0.5;
      //   totalCredit=Number(creditData)+Number(point);
      //   return totalCredit;
      // }
      
    };

    PageModule.prototype.updateUnit=function(unit) {
      var units=Number(unit);
      var total=units+1;
      return total;
    };

    PageModule.prototype.innovationGetCredit=function(intensity,emp) {
      var point;
      // if(emp=='Billable')
      // {
        point=intensity;
      // }
      // else
      // {
      //   point=intensity*0.5;
      // }
      return point;
    }

     PageModule.prototype.getData = function (EmpBO,PrjBO,BuBO,ClientBO,InnovationBO) {
    var data =[];
    console.log("#345",InnovationBO);
    for(var i = 0; i<InnovationBO.length; i++) {

      var retpayload = {};
      retpayload['actualEndDate'] = InnovationBO[i].actualEndDate;
      retpayload['applicationMaintenanceDevelopm'] = InnovationBO[i].applicationMaintenanceDevelopm;
      
      retpayload['status'] = InnovationBO[i].status;

      retpayload['benefitClassification'] = InnovationBO[i].benefitClassification;
      
      retpayload['canThisBeUseInOtherOBLAccounts'] = InnovationBO[i].canThisBeUseInOtherOBLAccounts;
      retpayload['cGVAActual'] = InnovationBO[i].cGVAActual;
      
      retpayload['cloudOnPrem'] = InnovationBO[i].cloudOnPrem;
      retpayload['cVAActual'] = InnovationBO[i].cVAActual;
      retpayload['totalSavingsYear'] = InnovationBO[i].totalSavingsYear;
      retpayload['detailsOfSolutionProvided'] = InnovationBO[i].detailsOfSolutionProvided;
      retpayload['eDGETechnology'] = InnovationBO[i].eDGETechnology;
      retpayload['estimatedEndDate'] = InnovationBO[i].estimatedEndDate;
      retpayload['fTERel'] = InnovationBO[i].fTERel;
      retpayload['functionalTechnical'] = InnovationBO[i].functionalTechnical;
      retpayload['ideaBelongsToApplication'] = InnovationBO[i].ideaBelongsToApplication;
      retpayload['ideaName'] = InnovationBO[i].ideaName;
      retpayload['ideaDescriptionDetails'] = InnovationBO[i].ideaDescriptionDetails;
      retpayload['ideaGenerationDate'] = InnovationBO[i].ideaGenerationDate;
      var ideagenerationyear = new Date(InnovationBO[i].ideaGenerationDate);
      retpayload['ideaGenerationYear'] = ideagenerationyear.getFullYear();
      retpayload['improvementType'] = InnovationBO[i].improvementType;
      retpayload['pTVAActual'] = InnovationBO[i].pTVAActual;
      retpayload['savingCalculations'] = InnovationBO[i].savingCalculations;
      retpayload['subProcess'] = InnovationBO[i].subProcess;
      retpayload['technology'] = InnovationBO[i].technology;
      retpayload['id'] = InnovationBO[i].id;
      
      
      
      var empele = EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID);     
      //var buele = BuBO.find(buele => buele.id == empele.bu);
     
      retpayload['ideaGeneratorEmpID'] = EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID)?EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID).employeeID:null;
      retpayload['ideaGeneratorEmpName'] = EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID)?EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID).name:null;
      retpayload['ideaGeneratorEmpEmail'] = EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID)?EmpBO.find(empele => empele.id == InnovationBO[i].ideaGeneratorEmpID).email:null;


      retpayload['cIChampionEmailID'] = EmpBO.find(empele => empele.id == InnovationBO[i].cIChampionEmailID)?EmpBO.find(empele => empele.id == InnovationBO[i].cIChampionEmailID).email:null;
      retpayload['eMEmailID'] = EmpBO.find(empele => empele.id == InnovationBO[i].eMEmailID)?EmpBO.find(empele => empele.id == InnovationBO[i].eMEmailID).email:null;
      retpayload['muSpoc'] = EmpBO.find(empele => empele.id == InnovationBO[i].muSpoc)?EmpBO.find(empele => empele.id == InnovationBO[i].muSpoc).email:null;
      //retpayload['localGrade'] = EmpBO.find(empele => empele.id == InnovationBO[i].employee)?EmpBO.find(empele => empele.id == InnovationBO[i].employee).localGrade:null;


      retpayload['marketUnit'] = BuBO.find(ele => ele.id== InnovationBO[i].marketUnit)?BuBO.find(ele => ele.id== InnovationBO[i].marketUnit).name:null;
      
      
      retpayload['projectId'] = PrjBO.find(ele => ele.id == InnovationBO[i].projectId)?PrjBO.find(ele => ele.id == InnovationBO[i].projectId).projectCode:null;
      retpayload['projectName'] = PrjBO.find(ele => ele.id == InnovationBO[i].projectId)?PrjBO.find(ele => ele.id == InnovationBO[i].projectId).projectName:null;

      //retpayload['accountName'] = ClientBO.find(cle => cle.id == (PrjBO.find(ele => ele.id == InnovationBO[i].projectId).client))?ClientBO.find(cle => cle.id == (PrjBO.find(ele => ele.id == InnovationBO[i].projectId).client)).clientName:null;
     retpayload['accountName'] = PrjBO.find(ele => ele.id == InnovationBO[i].projectId)?ClientBO.find(cle => cle.id == (PrjBO.find(ele => ele.id == InnovationBO[i].projectId).client)).clientName:null;
     
      console.log('@25'+JSON.stringify(retpayload));
      //console.log('@255',retpayload['visaBOid'],retpayload['employeeID'],retpayload['employeeName']);
      data.push(retpayload);
    }
    return data;
  };

      PageModule.prototype.downloadInnovationData = function (downloaddata,innovation_metadata) {
    console.log("@23",downloaddata);
    var multArray = new Array();
    var headerArray = new Array();
    var metadataArray = new Array();
    
    //headers
    innovation_metadata.forEach(element => headerArray.push(element.headerName));
    innovation_metadata.forEach(element => metadataArray.push(element.metadata));
    multArray.push(headerArray);


    //column data
    for(var i = 0;i<downloaddata.length;i++){
      var innerArray = new Array();
       var ideagenerationdate;
      let IdeaGenDate,EstEndDate,ActEndDate,FTERel;

      const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      if(downloaddata[i].ideaGenerationDate != null){
        ideagenerationdate = new Date(downloaddata[i].ideaGenerationDate);
        IdeaGenDate = ideagenerationdate.getDate() + "-" + months[ideagenerationdate.getMonth()] + "-" + ideagenerationdate.getFullYear();
      }
      if(downloaddata[i].estimatedEndDate != null){
        var estimatedenddate = new Date(downloaddata[i].estimatedEndDate);
        EstEndDate = estimatedenddate.getDate() + "-" + months[estimatedenddate.getMonth()] + "-" + estimatedenddate.getFullYear();
      }
      if(downloaddata[i].actualEndDate != null){
        var actualenddate = new Date(downloaddata[i].actualEndDate);
        ActEndDate = actualenddate.getDate() + "-" + months[actualenddate.getMonth()] + "-" + actualenddate.getFullYear();
      }
      if(downloaddata[i].fTERel != null){
        var fterel = new Date(downloaddata[i].fTERel);
        FTERel = months[fterel.getMonth()] + "-" + fterel.getFullYear();
      }

      innerArray.push(downloaddata[i].id);
      innerArray.push(IdeaGenDate);
      innerArray.push(downloaddata[i].ideaBelongsToApplication);
      innerArray.push(downloaddata[i].ideaName);
      innerArray.push(downloaddata[i].ideaDescriptionDetails);
      innerArray.push(downloaddata[i].detailsOfSolutionProvided);
      innerArray.push(downloaddata[i].status);
      innerArray.push(downloaddata[i].applicationMaintenanceDevelopm);
      innerArray.push(downloaddata[i].benefitClassification);
      innerArray.push(EstEndDate);
      innerArray.push(ActEndDate);
      innerArray.push(downloaddata[i].improvementType);
      innerArray.push(downloaddata[i].savingCalculations);
      innerArray.push(downloaddata[i].pTVAActual);
      innerArray.push(downloaddata[i].cVAActual);
      innerArray.push(downloaddata[i].cGVAActual);
      //innerArray.push(downloaddata[i].totalSavingsYear);
      innerArray.push(downloaddata[i].marketUnit);
      innerArray.push(downloaddata[i].projectId);
      innerArray.push(downloaddata[i].accountName);
      innerArray.push(downloaddata[i].eMEmailID);
      innerArray.push(downloaddata[i].muSpoc);
      innerArray.push(downloaddata[i].cIChampionEmailID);
      //innerArray.push(FTERel);
      innerArray.push(downloaddata[i].functionalTechnical);
      innerArray.push(downloaddata[i].subProcess);
      //innerArray.push(downloaddata[i].technology);
      innerArray.push(downloaddata[i].ideaGeneratorEmpID);
      innerArray.push(downloaddata[i].ideaGeneratorEmpName);
      innerArray.push(downloaddata[i].ideaGeneratorEmpEmail);
      innerArray.push(downloaddata[i].cloudOnPrem);
      //innerArray.push(downloaddata[i].eDGETechnology);
      //innerArray.push(downloaddata[i].canThisBeUseInOtherOBLAccounts);
      innerArray.push(ideagenerationdate.getFullYear());

      multArray.push(innerArray);
    }





    // write to Excel
     var wb = XLSX.utils.book_new();
    wb.SheetNames.push("Innovation");
    
    var ws = XLSX.utils.aoa_to_sheet(multArray);
    wb.Sheets["Innovation"] = ws;
    var fileBytes = XLSX.write(wb, { bookType: 'xlsx', type: 'binary'});

    fileBytes = FileToBytes(fileBytes);
    var blob = new Blob([fileBytes], { type: 'octet/stream' });
    var filename = "Innovation_" + new Date().toISOString().split('T')[0] + ".xlsx";

    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.setAttribute("target", "_blank");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        console.log('Link' + JSON.stringify(link));
        // var win = window.open(url, "_blank");
        //  win.focus();
        document.body.removeChild(link);
      }
    }
  };
  function FileToBytes(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i < s.length; i++)
      view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
  PageModule.prototype.getYearnMonth = function () {

      var abc=[];

      var retpayload={}

      const d = new Date();



      retpayload['month'] = d.toLocaleString('default', { month: 'short' })

      retpayload['year'] = d.getFullYear();

      

      abc.push(retpayload);

      return abc;

  };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
     PageModule.prototype.validateSavingDetails = function(updateVar) {
      if(updateVar.benefitClassification == 'Capgemini Group Value Add (CGVA)'){
         if(updateVar.cGVAActual!=0 && updateVar.cGVAActual!='' && updateVar.cGVAActual!=null && updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else if(updateVar.benefitClassification == 'Customer Value Add (CVA)'){
         if(updateVar.cVAActual!=0 && updateVar.cVAActual!='' && updateVar.cVAActual!=null && updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else if(updateVar.benefitClassification == 'Project Team Value Add (PTVA)'){
         if(updateVar.pTVAActual!=0 && updateVar.pTVAActual!='' &&updateVar.pTVAActual!=null &&updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else if(updateVar.benefitClassification == 'Both (CVA & PTVA)'){
         if(updateVar.cVAActual!=0 && updateVar.pTVAActual!=0 && updateVar.cVAActual!='' && updateVar.pTVAActual!=''&& updateVar.cVAActual!=null && updateVar.pTVAActual!=null &&updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else if(updateVar.benefitClassification == 'Both (CGVA & PTVA)'){
         if(updateVar.cGVAActual!=0 && updateVar.pTVAActual!=0 && updateVar.cGVAActual!='' && updateVar.pTVAActual!='' && updateVar.cGVAActual!=null && updateVar.pTVAActual!=null &&updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else if(updateVar.benefitClassification == 'Both (CGVA & CVA)'){
         if(updateVar.cGVAActual!=0 && updateVar.cVAActual!=0 && updateVar.cGVAActual!='' && updateVar.cVAActual!='' &&updateVar.cGVAActual!=null && updateVar.cVAActual!=null &&updateVar.actualEndDate!=undefined && updateVar.ideaDescriptionDetails!=null && updateVar.detailsOfSolutionProvided!= null && updateVar.benefitClassification != null)
          return true;
          else return false;
       }
       else return false;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    
  // PageModule.prototype.generateCurrentDate = function () {
  //   var date = new Date();
	  
  //   var current_date = date.toISOString();
  //   return current_date;
  // };
  
  //"status ='"+$page.variables.searchVar.status+"' AND technology LIKE'%"+$page.variables.searchVar.technology+"%' AND ideaGenerationDate ='"+$page.variables.searchVar.ideaGenerationDate+"'"


//   PageModule.prototype.expandAll = function (){
//   $("#collapsible-header").addClass("active");
//   // $("#collapsible").collapsible({accordion: false});
// };

// function collapseAll(){
//   $("#collapsible-header").removeClass(function(){
//     return "active";
//   });
//   $(".collapsible").collapsible({accordion: true});
//   $(".collapsible").collapsible({accordion: false});
// }
PageModule.prototype.validateFile = function(ext) {
        var extt = ext.split('.').pop();
        //console.log('@@uu :' + extt);
        if (extt == "pdf" || extt == "docx" || extt == "jpg" || extt == "jpeg" || extt == "pptx" || extt == "txt") {
            //console.log('@@uu11 :' + extt);
            return 'valid';

        }

        return 'non-valid';
    };

    PageModule.prototype.filename = function (boid,Innovation,index,current) {
    var fileName;
    
    fileName=boid.concat("_",Innovation,"_",index,".",(current.name).split('.')[1]);
    // $chain.results.callFunctionFilename+"."+($current.data.name).split('.')[1]
     console.log('>>>topic'+ Innovation);
    return fileName;
   
  };

     PageModule.prototype.createPay = function(fileObj, bucketName, fileName) {
        
        var form = new FormData();
        form.append('file', fileObj, fileName);
        form.append('json', '{"filename":"' + fileName + '", "bucket_name" : "' + bucketName + '"}');
    
        return form;
    };

    PageModule.prototype.downloadFile = function (base64File, filename) {
    console.log('@@File Name' + filename);

        var fileBytes = atob(base64File);
        fileBytes = FileToBytes(fileBytes);
        console.log(fileBytes);
        // var fileBytes='68976c31-f92f-4ec0-b9d3-0fe5b237232c@_@FWuOVOF4UhKKvvPWIeKnwpHZg3AqNgjOdJL7GmRMald1FkKH0AU2ieloHd8JJgbKubbbUjZVCJOqM9yJ37TYm'
        //var blob = new Blob([fileBytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        var blob = new Blob([fileBytes], {
            type: 'octet/stream'
        });
        //var filename = "CDE.xlsx";


        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.setAttribute("target", "_blank");
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                console.log('Link' + JSON.stringify(link));
                // var win = window.open(url, "_blank");
                //  win.focus();
                document.body.removeChild(link);
            }
        }

  };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.previewFile=function(file) {
      
      return new Promise(resolve => {
    var file = file;
    var reader = new FileReader();
    // Read file content on file loaded event
    reader.onload = function(event) {
      resolve(event.target.result);
    };
    
    // Convert data to base64 
    reader.readAsDataURL(file);
  });


    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.uploadFileName=function(files,uploadedFiles) {
      
        
          uploadedFiles.push(files.name);
          
        
       
        return uploadedFiles;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.createPayloadFileName=function(filename,temp_file) {
      var fileName;
      if(temp_file==undefined || temp_file == ''){
          fileName = filename;
      }
      else{
        fileName = filename +','+temp_file;
      }
      

      return fileName;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
      PageModule.prototype.popFileIndices=function(files,index) {
      for(var i=index.length-1;i>=0;i--){
      files.splice(index[i],1);
      }
      
      return files;
    };

    PageModule.prototype.popFile=function(files,index) {
      files.splice(index,1);
      
      return files;
    };

    PageModule.prototype.getPopFileIndex=function(files,popFileName) {
      var index ;
      for(var i=0;i<files.length;i++){
        if(files[i].name == popFileName){
          index = i;
          break;
        }
      }
      console.log("index...",index,files,popFileName);
      
      return index;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.getBucketFileName=function(fileName) {
      var downloadFiles = fileName.split(',');
      var downloadFile=[];
      
      for(var i=0;i<downloadFiles.length;i++){
        var retpayload={};
        retpayload['fileName'] = downloadFiles[i];
        downloadFile.push(retpayload);
      }
      console.log("filess",downloadFile);
      return downloadFile;
    }


  return PageModule;
});
