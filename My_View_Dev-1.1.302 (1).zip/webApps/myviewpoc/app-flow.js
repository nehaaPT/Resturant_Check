define([], function () {
  'use strict';

  var AppModule = function AppModule() {};

  AppModule.prototype.consolidateData=function(data,entity){

      var str='';
    for(var i=0;i<data.length;i++){
      if(i==data.length-1){
        str+=data[i][entity];
      }
      else{
        str+=data[i][entity]+',';

      }

    }

    console.log('#AppModule20'+str);
    return str;

  }

  AppModule.prototype.createTask=function(P_TaskBO, P_CategoryBO, P_Category, P_Detail, P_Token){
    var retPayload = {};

    var task = P_TaskBO.reduce((p, c) => p.value > c.value ? p : c);
    var taskID = task.taskID+1;
    var cat = P_CategoryBO.find(ele => ele.category == P_Category);

    // var existingTask  = P_TaskBO.find(function(data){return data.categoryID == cat.categoryID  && data.token == P_Token;});
    var existingTask  = P_TaskBO.find(function(data){return data.categoryID == cat.categoryID  && data.token == '174612';});

    if(existingTask != undefined){
      retPayload['taskID'] = 'True';
    }

    else{
      retPayload['taskID'] = taskID;
      retPayload['categoryID'] = cat != undefined ? cat.categoryID : null;
      retPayload['detail'] = P_Detail;
      // retPayload['token'] = P_Token;
      retPayload['token'] = '174612';
    }

    return retPayload;
  };

  AppModule.prototype.createAssignTaskBody = function(P_TaskID, P_EmployeeID){
    var retPayload = {};
    retPayload['taskID'] = P_TaskID;
    // retPayload['employyID'] = P_EmployeeID;
    retPayload['employyID'] = '174612';
    return retPayload;
  };

  return AppModule;
});